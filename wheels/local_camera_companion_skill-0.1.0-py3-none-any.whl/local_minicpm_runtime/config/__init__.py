# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Bundled config + fixture data for local-minicpm-runtime.

Currently contains:
  - ``default_speaker_embedding.npy`` — ``[1, 192]`` float32 speaker
    embedding for the native MiniCPM-o-4.5 TTS path. v0.1 ships a
    zero placeholder; operators should regenerate from a clean
    reference voice via ``scripts/build_speaker_embedding.py``.
"""
