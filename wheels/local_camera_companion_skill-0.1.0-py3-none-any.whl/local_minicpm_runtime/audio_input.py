# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Audio input gatekeeper for the Skill.

Validates audio files before they reach the model wrapper and provides an
optional microphone capture helper whose dependencies (``sounddevice``,
``soundfile``) are imported lazily — the package imports cleanly without
them, and ``record_from_microphone`` raises a clear ``RuntimeError`` if
they are missing at call time.

Decoding and resampling are intentionally **not** done here; the model
wrapper handles that. This module is pure stdlib at import time.
"""

from __future__ import annotations

import logging
import wave
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Union

PathLike = Union[str, Path]

logger = logging.getLogger(__name__)

DEFAULT_SAMPLE_RATE = 16000
DEFAULT_MAX_RECORD_SECONDS = 30
DEFAULT_ALLOWED_EXTENSIONS = (".wav", ".mp3", ".m4a", ".flac", ".ogg")


class AudioInputHandler:
    """Validates audio files and (optionally) captures from a microphone."""

    def __init__(
        self,
        sample_rate: int = DEFAULT_SAMPLE_RATE,
        max_record_seconds: int = DEFAULT_MAX_RECORD_SECONDS,
        allowed_extensions: Sequence[str] = DEFAULT_ALLOWED_EXTENSIONS,
        strict_validation: bool = True,
    ) -> None:
        self.sample_rate = int(sample_rate)
        self.max_record_seconds = int(max_record_seconds)
        self.allowed_extensions = tuple(
            (ext if ext.startswith(".") else f".{ext}").lower()
            for ext in allowed_extensions
        )
        self.strict_validation = bool(strict_validation)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_audio_file(self, path: PathLike) -> Path:
        """Return the resolved Path if the file passes all checks.

        Raises:
            FileNotFoundError: when the file does not exist.
            ValueError: for unsupported extension, empty file, or
                (when detectable) audio longer than ``max_record_seconds``.
        """
        p = Path(path).expanduser()
        if not p.is_file():
            raise FileNotFoundError(f"Audio file not found: {p}")

        ext = p.suffix.lower()
        if ext not in self.allowed_extensions:
            raise ValueError(
                f"Unsupported audio extension: {ext!r}; "
                f"allowed: {sorted(self.allowed_extensions)}"
            )

        if p.stat().st_size <= 0:
            raise ValueError(f"Audio file is empty: {p}")

        if self.strict_validation:
            duration = self.get_audio_duration(p)
            if duration is not None and duration > self.max_record_seconds:
                raise ValueError(
                    f"Audio too long: {duration:.2f}s > "
                    f"limit {self.max_record_seconds}s ({p})"
                )

        return p

    def get_audio_duration(self, path: PathLike) -> Optional[float]:
        """Return duration in seconds, or ``None`` if not detectable.

        Only ``.wav`` is inspected (via stdlib ``wave``). Other formats
        return ``None`` — the validator treats that as "detection
        unavailable, accept" per the Issue's wording.
        """
        p = Path(path)
        if p.suffix.lower() != ".wav":
            return None
        try:
            with wave.open(str(p), "rb") as wf:
                framerate = wf.getframerate()
                if framerate <= 0:
                    return None
                return wf.getnframes() / float(framerate)
        except (wave.Error, EOFError, OSError):
            return None

    def prepare_audio_for_model(self, path: PathLike) -> Path:
        """Validate the file and return its resolved path.

        Decoding / resampling is intentionally left to the model wrapper.
        """
        return self.validate_audio_file(path)

    # ------------------------------------------------------------------
    # Optional microphone capture
    # ------------------------------------------------------------------

    def record_from_microphone(
        self,
        output_path: PathLike,
        seconds: Optional[float] = None,
        device: Optional[int] = None,
    ) -> Path:
        """Record from the microphone and write a 16-bit PCM WAV.

        ``device`` selects the sounddevice input index; when ``None``
        the system default is used. On Windows RDP / headless setups
        the default may be invalid (``-1``) — in that case pass the
        index of the USB mic from ``sounddevice.query_devices()``
        (e.g. a Jabra headset usually surfaces as a WDM-KS input).

        Optional dependencies ``sounddevice`` and ``soundfile`` are
        imported lazily inside this method. If either is missing a clear
        ``RuntimeError`` is raised.
        """
        if seconds is None:
            seconds = float(self.max_record_seconds)
        seconds = float(seconds)
        if seconds <= 0:
            raise ValueError(
                f"seconds must be > 0, got {seconds}"
            )

        out = Path(output_path).expanduser()
        if out.parent and not out.parent.exists():
            out.parent.mkdir(parents=True, exist_ok=True)

        try:
            import sounddevice as sd  # type: ignore
            import soundfile as sf  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "Microphone capture requires the optional 'sounddevice' "
                "and 'soundfile' packages. Install them with "
                "`pip install sounddevice soundfile`."
            ) from exc

        try:  # pragma: no cover - requires real hardware
            frames = int(round(seconds * self.sample_rate))
            kwargs: Dict[str, Any] = {
                "samplerate": self.sample_rate,
                "channels": 1,
                "dtype": "int16",
            }
            if device is not None:
                kwargs["device"] = int(device)
            audio = sd.rec(frames, **kwargs)
            sd.wait()
            sf.write(str(out), audio, self.sample_rate, subtype="PCM_16")
        except Exception:  # pragma: no cover - hardware-dependent
            logger.exception("Microphone capture failed")
            raise

        return out


__all__ = [
    "AudioInputHandler",
    "DEFAULT_SAMPLE_RATE",
    "DEFAULT_MAX_RECORD_SECONDS",
    "DEFAULT_ALLOWED_EXTENSIONS",
]
