# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""MiniCPM-o 4.5 native Token2Wav synthesis runtime.

Composes the four Token2Wav sub-model handles (and optional TTS
sub-model handles) from the compiled bundle into a runtime that
exposes ``synthesize(text, output_path) -> Path``.

The actual OpenVINO inference for each pipeline step is the only
OpenVINO seam. Tests inject deterministic ``*_fn`` callables; the
default seams lazily delegate to ``OpenVINOToken2WavInferSteps``
(Task 43), which wires the four converted Token2Wav sub-models +
a byte-fallback tokenizer. See
[`docs/native_token2wav_infer_steps.md`](../../../docs/native_token2wav_infer_steps.md).
"""

from __future__ import annotations

import logging
import wave
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Union

from .compiled_model_bundle import CompiledModelBundle
from .errors import OVRuntimeError

PathLike = Union[str, Path]
logger = logging.getLogger(__name__)


_DEFAULT_MAX_LENGTH = 800
# MiniCPM-o-4.5 native HiFT vocoder produces 24 kHz audio. The
# upstream reference checkout (.scratch_converter) writes WAVs at
# this rate via ``torchaudio.save(..., sample_rate=24000)``. Earlier
# byte-fallback experiments used 16 kHz; the native path now sets
# the correct rate so the WAV plays at the intended pitch.
_DEFAULT_SAMPLE_RATE = 24000

# Per-character speech-duration estimates used by the duration-vs-text
# degenerate detector (Signature 4). Tuned to typical TTS speech
# rates:
#   - CJK ideographs: ~0.20s/char (roughly 5 chars/sec, matching
#     MiniCPM-o's TTS cadence on Chinese reference clips).
#   - Other characters (ASCII letters, digits, punctuation,
#     whitespace): ~0.075s/char (~13 chars/sec, English speech
#     rate).
# These are deliberate UNDER-estimates of the actual rate so the
# 2× multiplier still leaves comfortable headroom — natural speech
# variance is typically ±30% around the central estimate.
_CHARDUR_CJK_SEC = 0.20
_CHARDUR_OTHER_SEC = 0.075


def _estimate_speech_duration_sec(text: str) -> float:
    """Return a rough speech-duration estimate for ``text`` in seconds.

    Counts CJK ideographs at ``_CHARDUR_CJK_SEC`` per char and other
    visible characters at ``_CHARDUR_OTHER_SEC``. Whitespace runs are
    collapsed to single spaces before counting so multi-space inputs
    don't inflate the estimate. Empty input → 0.0.
    """
    if not isinstance(text, str) or not text:
        return 0.0
    cleaned = " ".join(text.split())
    if not cleaned:
        return 0.0
    total = 0.0
    for ch in cleaned:
        cp = ord(ch)
        if 0x4E00 <= cp <= 0x9FFF or 0x3400 <= cp <= 0x4DBF:
            total += _CHARDUR_CJK_SEC
        else:
            total += _CHARDUR_OTHER_SEC
    return total


def _contains_cjk(text: str) -> bool:
    """Return True iff ``text`` contains any CJK ideograph.

    Used by ``_apply_voice_prime`` to gate the Chinese filler
    prefix to inputs that actually contain Chinese. Pure-Latin
    inputs (English flashcard carrier sentences, Latin proper
    nouns) skip the prime so the TTS LM is not handed a
    foreign-language contaminant prefix.

    Detection covers the practical Chinese ranges (CJK Unified
    Ideographs + Extension A). Symbols, punctuation, and Latin
    are not considered CJK.
    """
    if not isinstance(text, str) or not text:
        return False
    for ch in text:
        cp = ord(ch)
        if 0x4E00 <= cp <= 0x9FFF or 0x3400 <= cp <= 0x4DBF:
            return True
    return False


def _is_japanese_dominant(text: str) -> bool:
    """Return True iff ``text`` contains Japanese kana.

    Japanese flashcard replies like ``"日本語では「ほん」です。"``
    mix Han ideographs (which ``_contains_cjk`` flags as CJK) with
    hiragana / katakana. Treating these as "Chinese" and prepending
    the ``"好，"`` voice-prime contaminates Japanese prosody. The
    presence of ANY kana is a reliable signal that the input is
    Japanese rather than Chinese — Mandarin / Cantonese text never
    contains hiragana or katakana.

    Ranges:

    - Hiragana: U+3040..U+309F
    - Katakana: U+30A0..U+30FF
    """
    if not isinstance(text, str) or not text:
        return False
    for ch in text:
        cp = ord(ch)
        if 0x3040 <= cp <= 0x309F or 0x30A0 <= cp <= 0x30FF:
            return True
    return False


@dataclass
class Token2WavConfig:
    """Synthesis config — text length cap and audio params.

    The flow-matching ODE parameters (``n_timesteps``,
    ``inference_cfg_rate``, ``output_size``, ``up_rate``,
    ``random_seed``) match upstream defaults from the reference
    OVFlow class. They are only consumed by the default
    ``flow_estimator_fn`` — operators who inject their own seam can
    ignore them.
    """

    max_length: int = _DEFAULT_MAX_LENGTH
    sample_rate: int = _DEFAULT_SAMPLE_RATE
    sample_width: int = 2  # int16 PCM
    channels: int = 1
    # Number of Euler ODE steps in flow-matching denoising. Upstream
    # default is 10. Reducing it speeds up TTS but degrades quality.
    n_timesteps: int = 10
    # Classifier-free guidance scale. Upstream default 0.7.
    inference_cfg_rate: float = 0.7
    # Mel feature dim and token-to-mel upsampling ratio.
    output_size: int = 80
    up_rate: int = 2
    # Seed for the noise tensor used as ODE initial condition. Stable
    # across runs so synthesis of the same audio tokens produces a
    # bit-identical WAV.
    random_seed: int = 0
    # Degenerate-output detection thresholds. A WAV is considered
    # degenerate when its duration is at-or-near ``max_steps``-cap
    # AND its RMS energy is below the silence threshold — both of
    # those conditions together signal a TTS-LM cycle-lock (the
    # generator never emitted EOS, the loop hit max_steps, and the
    # vocoder produced near-silence-with-clicks). The thresholds are
    # conservative; clean speech easily clears RMS 0.02. Cycle-lock
    # diagnostics observed RMS ~0.013, ZCR ~0.007, exactly 20.00s.
    degenerate_rms_threshold: float = 0.02
    # The cap is ~20s at the upstream max_steps=500 default; a fraction
    # of 0.95 means "≥ 19.0 seconds". Tunable for operators who
    # override max_steps.
    degenerate_duration_cap_sec: float = 19.0
    degenerate_duration_fraction: float = 0.95
    # Number of times to retry synthesis with a different sampling
    # seed before giving up and writing the most recent (still
    # degenerate) attempt. Each retry advances the sampling seed, so
    # attempts explore new audio-token trajectories. On-device field
    # reports (learning-machine coin/time turns) showed the earlier
    # single retry still handing garbled cycle-locked audio to the
    # user when BOTH attempts degenerated — the log's own "all N
    # attempt(s) produced degenerate audio" line. Raised to 3 (4 total
    # attempts) to rescue those; the extra latency only occurs on turns
    # that would otherwise be garbled.
    max_degenerate_retries: int = 3
    # Partial-silence cycle-lock signature. Real-machine session
    # dd39d149... showed turn_003's reply hit the duration cap at
    # 20.00s exact with rms=0.04 (above the silence threshold) but
    # 28% of 100ms windows below 0.005 — i.e. audible-but-choppy
    # "speech with extensive gaps". The pure-silence rms gate
    # missed this case. When the audio is at-cap AND its silent-
    # window fraction exceeds this threshold, treat as degenerate
    # too. 0.0 disables.
    degenerate_silent_window_threshold: float = 0.005
    degenerate_silent_window_fraction: float = 0.25
    # Aggressive silent-window gate that fires **regardless** of
    # at-cap duration. Above this fraction, the audio is so
    # silence-dominated that no legitimate Chinese / English speech
    # can plausibly produce it (real choppy speech tops out around
    # ~0.30). Real-machine v14 / v16 sessions showed cycle-locks
    # at sub-cap durations:
    #   v14 turn 008: silent_frac=0.51 / dur=8.32s (caught at 0.45)
    #   v16 turn 012: silent_frac=0.42 / dur=7.00s (slipped past
    #                 0.45; user reported "voice has block")
    # Lower to 0.40 to catch the blocky-but-not-silence-dominated
    # mode. Risk: false positives on legitimate replies that
    # contain ~0.40 silent windows (long pauses, comma-heavy lists).
    # Real-machine clean replies measured 0.23-0.38, so 0.40 still
    # has headroom. 0.0 disables the gate.
    degenerate_silent_window_fraction_high: float = 0.40
    # Duration-vs-text mismatch gate. Real-machine round-5 session
    # 22:50 turn 4: model produced 6.2s of garbled babbling for the
    # 35-char carrier sentence ``"The English word is: utility knife."``.
    # Expected duration at ~0.075 s/char English ≈ 2.6s; actual 6.2s
    # = 2.4× over. RMS was a healthy 0.14 and silent-window fraction
    # was ~0.30 (no existing signature caught it). This signature
    # triggers when actual_duration > (expected * multiplier) AND
    # actual_duration > min_duration_floor (skip tiny WAVs).
    # ``expected`` is computed from the input text length:
    # CJK chars (codepoint >= 0x4E00) count as 0.20s/char,
    # other chars count as 0.075s/char (roughly English speech rate).
    # 0.0 disables.
    degenerate_duration_per_char_multiplier: float = 2.0
    degenerate_duration_min_floor_sec: float = 4.0
    # Gross-overshoot variant of signature 4a WITHOUT the min-floor gate.
    # Field report (learning-machine): a 2-char reply ("九。", expected
    # ~0.28s) cycle-locked to 3.80s (13.6×) but slipped past 4a because
    # 3.80s < the 4.0s floor — so it was neither flagged nor retried, and
    # the user heard a stretched/garbled clip that didn't match the text.
    # This catches catastrophic short-text overshoot regardless of the
    # floor. The high multiplier (vs 4a's 2.0×) plus a small min-expected
    # gate keeps naturally terse-but-valid replies (~2-3× at most) safe.
    # 0.0 disables.
    degenerate_duration_gross_multiplier: float = 5.0
    degenerate_duration_gross_min_expected_sec: float = 0.2
    # Under-short variant of signature 4. Round-6 evidence: when
    # the first attempt produces an over-long degenerate output
    # and the retry's "new sampling seed" path lands on a stuck
    # trajectory the OTHER way (premature EOS / truncation), the
    # WAV comes out much shorter than the expected duration for
    # the input text. Real session 23:19 turn 3 retry: 1.80s for
    # a 2.63s-expected 35-char carrier (0.69×). Flag when the
    # ratio is below this threshold AND the expected duration is
    # above the floor (so we don't false-positive on tiny prompts
    # like the pre-warm path). 0.0 disables.
    degenerate_duration_per_char_undershoot: float = 0.4
    degenerate_duration_min_expected_sec: float = 1.5


@dataclass
class Token2WavResult:
    """Result of a synthesis run."""

    output_path: Path
    duration_frames: int
    active_device: Optional[str] = None
    fallback_used: bool = False
    extras: Dict[str, Any] = field(default_factory=dict)


class MiniCPMO45Token2WavRuntime:
    """Native Token2Wav runtime.

    Public surface:
      - ``synthesize(text, output_path) -> Path``
      - ``runtime_info() -> dict``

    The constructor accepts five callables that are the OpenVINO
    inference seams. By default, each lazily delegates to
    ``OpenVINOToken2WavInferSteps`` (Task 43) which wires the four
    converted Token2Wav sub-models plus a byte-fallback tokenizer.
    Tests inject fakes for any subset of the five callables.
    """

    def __init__(
        self,
        bundle: CompiledModelBundle,
        config: Optional[Token2WavConfig] = None,
        tokenizer_fn: Optional[Callable[[str], Any]] = None,
        flow_embedding_fn: Optional[
            Callable[[Any, CompiledModelBundle], Any]
        ] = None,
        flow_encoder_fn: Optional[
            Callable[[Any, CompiledModelBundle], Any]
        ] = None,
        flow_estimator_fn: Optional[
            Callable[[Any, CompiledModelBundle], Any]
        ] = None,
        hift_fn: Optional[
            Callable[[Any, CompiledModelBundle], Any]
        ] = None,
    ) -> None:
        self.bundle = bundle
        self.config = config or Token2WavConfig()
        self._tokenizer_fn = tokenizer_fn or self._default_tokenizer_fn
        self._flow_embedding_fn = (
            flow_embedding_fn or self._default_flow_embedding_fn
        )
        self._flow_encoder_fn = (
            flow_encoder_fn or self._default_flow_encoder_fn
        )
        self._flow_estimator_fn = (
            flow_estimator_fn or self._default_flow_estimator_fn
        )
        self._hift_fn = hift_fn or self._default_hift_fn
        # Lazily constructed on the first ``synthesize`` call when no
        # explicit seam callables were injected.
        self._infer_steps: Any = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def synthesize(
        self, text: str, output_path: PathLike, base_seed: int = 0
    ) -> Path:
        """Validate text, run the synthesis pipeline, write a WAV.

        ``base_seed`` starts the sampling-seed sequence at a non-zero offset.
        Since synthesis is deterministic given (text, seed), a caller that
        detected wrong *content* (via ASR-verify) can re-synthesize the same
        text at a fresh ``base_seed`` to escape a bad-but-valid-shape
        trajectory the duration/energy degenerate checks can't catch.

        Non-streaming pipeline (matches upstream
        ``OVFlow.inference`` + ``OVHiFT.inference``)::

            _prepare_text_tokens  →  _run_flow_embedding
                                  →  _run_flow_estimator (n_timesteps Euler steps with CFG)
                                  →  _run_hift_vocoder
                                  →  _write_wav  →  _validate_wav_output

        ``_run_flow_encoder`` is **not** used in the non-streaming
        chain. The flow_encoder_chunk IR is for the streaming path
        (``inference_chunk`` upstream); kept available but unused.
        """
        prepared = self._validate_text(text)
        out = Path(output_path).expanduser().resolve()
        if out.parent and not out.parent.exists():
            out.parent.mkdir(parents=True, exist_ok=True)

        audio_bytes, attempts = self._synthesize_with_retry(
            prepared, base_seed=base_seed
        )
        written = self._write_wav(audio_bytes, out)
        self._validate_wav_output(written)
        if attempts > 1:
            logger.info(
                "Token2Wav: %d-attempt synthesis (degenerate first "
                "attempt) — %s",
                attempts, out.name,
            )
        return written

    def _synthesize_with_retry(self, prepared_text: str, base_seed: int = 0):
        """Run the full pipeline; retry once if the audio is degenerate.

        Returns ``(audio_bytes, attempts)``. Always returns the most
        recent attempt's bytes — even if all retries also degenerate
        we write *something* and let the validation gates / caller
        catch the malformed output. A WARN log fires when every
        attempt was degenerate.
        """
        # Reset the TTS LM sampling seed at the start of every call.
        # ``_advance_tts_sampling_seed`` (the degenerate-retry hook)
        # only ever increments the seed, so without this reset a
        # cycle-lock recovery on turn N permanently shifts the seed
        # for turns N+1, N+2, ... — which visibly changes the modal
        # voice across turns.
        self._reset_tts_sampling_seed()
        # Offset the starting seed (content-verify re-synthesis passes a
        # non-zero base_seed to force a different trajectory). The advance
        # hook increments by 1, so reach base_seed by advancing that many times.
        for _ in range(max(0, int(base_seed))):
            self._advance_tts_sampling_seed()
        max_retries = max(0, int(self.config.max_degenerate_retries))
        audio_bytes = b""
        attempts = 0
        for attempt in range(max_retries + 1):
            attempts = attempt + 1
            tokens = self._prepare_text_tokens(prepared_text)
            embedded = self._run_flow_embedding(tokens)
            estimated = self._run_flow_estimator(embedded)
            audio_bytes = self._run_hift_vocoder(estimated)
            if not self._is_degenerate(
                audio_bytes, expected_text=prepared_text
            ):
                return audio_bytes, attempts
            if attempt < max_retries:
                self._advance_tts_sampling_seed()
                logger.info(
                    "Token2Wav: degenerate audio detected on attempt "
                    "%d (cycle-lock / over-long / silent); retrying "
                    "with new sampling seed.",
                    attempts,
                )
        # All attempts degenerate — write what we have but warn loudly.
        logger.warning(
            "Token2Wav: all %d attempt(s) produced degenerate audio. "
            "Writing the last attempt anyway. Consider raising "
            "Token2WavConfig.max_degenerate_retries or investigating "
            "the upstream sampling.",
            attempts,
        )
        return audio_bytes, attempts

    def _is_degenerate(
        self,
        audio_bytes: bytes,
        *,
        expected_text: Optional[str] = None,
    ) -> bool:
        """Return True iff the synthesized audio looks like a
        TTS-LM cycle-lock failure. Four signatures:

        1. **Pure silence at-cap:** rms below
           ``degenerate_rms_threshold`` AND duration at-cap.
           Original PR #233 detector. Catches the "silent
           20-second WAV" mode.
        2. **Partial silence at-cap (PR #234 / session dd39d149):**
           rms above the silence threshold but the fraction of
           100ms windows with rms < silent_window_threshold
           exceeds ``degenerate_silent_window_fraction``. Catches
           the "audible-but-choppy" cycle-lock where speech is
           interleaved with extensive gaps. Gated by at-cap
           duration to avoid false positives on short pause-heavy
           replies.
        3. **High-silent-fraction (any duration, real-machine
           v14):** when silent-window fraction exceeds
           ``degenerate_silent_window_fraction_high`` (default
           0.40), treat as degenerate **regardless** of duration.
           Real Chinese / English speech tops out around ~0.30
           silent-window fraction, so 0.40+ is physically
           impossible for legitimate output and indicates the
           cycle-lock signature seen at any duration.
        4. **Duration-vs-text mismatch (round-5/6):** Two variants.
           (a) Over-long (round-5, session 22:50): when the produced
           audio is more than
           ``degenerate_duration_per_char_multiplier``× the expected
           duration AND longer than
           ``degenerate_duration_min_floor_sec``, treat as
           degenerate (garbled-but-energetic babbling).
           (b) Under-short (round-6, session 23:19): when the
           produced audio is less than
           ``degenerate_duration_per_char_undershoot``× the
           expected duration AND the expected duration is above
           ``degenerate_duration_min_expected_sec``, treat as
           degenerate (premature EOS / truncation). Gated by the
           min-expected floor so trivial prompts don't false-positive.

        Fail-safe: any error in the detector itself returns False so
        synthesis still completes (better one bad WAV than a crash).
        """
        try:
            import numpy as np

            arr = np.frombuffer(audio_bytes, dtype=np.int16)
            if arr.size == 0:
                return False
            sample_rate = max(1, int(self.config.sample_rate))
            duration_sec = arr.size / float(sample_rate)
            cap_sec = float(self.config.degenerate_duration_cap_sec)
            fraction = float(self.config.degenerate_duration_fraction)
            at_cap = duration_sec >= cap_sec * fraction
            arr_f = arr.astype(np.float32)
            rms = float(np.sqrt(np.mean(arr_f ** 2))) / 32768.0
            # Signature 1: pure silence at-cap.
            if at_cap and rms < float(
                self.config.degenerate_rms_threshold
            ):
                return True
            # Signature 4: duration-vs-text mismatch. The TTS LM is
            # over-decoding for the input text length, producing
            # garbled babbling at a normal RMS that bypasses all the
            # silence-based signatures. Real-machine round-5 session
            # 22:50 turn 4: 35-char carrier sentence produced 6.2s of
            # garbage (expected ~2.6s).
            multiplier = float(
                self.config.degenerate_duration_per_char_multiplier
            )
            min_floor = float(
                self.config.degenerate_duration_min_floor_sec
            )
            undershoot = float(
                self.config.degenerate_duration_per_char_undershoot
            )
            min_expected = float(
                self.config.degenerate_duration_min_expected_sec
            )
            if expected_text:
                expected_sec = _estimate_speech_duration_sec(expected_text)
            else:
                expected_sec = 0.0
            # 4a — over-long: TTS LM emitted too many audio tokens
            # for the input text (garbled babbling).
            if (
                multiplier > 0.0
                and expected_sec > 0.0
                and duration_sec > min_floor
                and duration_sec > expected_sec * multiplier
            ):
                logger.info(
                    "Token2Wav: duration mismatch over-long (text=%d "
                    "chars, expected~%.2fs, actual=%.2fs, ratio=%.2f×)",
                    len(expected_text),
                    expected_sec,
                    duration_sec,
                    duration_sec / max(expected_sec, 0.01),
                )
                return True
            # 4a-gross — catastrophic overshoot on SHORT text, below the
            # 4a min-floor. Fires without the floor so short cycle-locks
            # (e.g. a 2-char reply ballooning to 3.8s) are caught + retried.
            gross_multiplier = float(
                self.config.degenerate_duration_gross_multiplier
            )
            gross_min_expected = float(
                self.config.degenerate_duration_gross_min_expected_sec
            )
            if (
                gross_multiplier > 0.0
                and expected_sec > gross_min_expected
                and duration_sec > expected_sec * gross_multiplier
            ):
                logger.info(
                    "Token2Wav: duration mismatch gross over-long (text=%d "
                    "chars, expected~%.2fs, actual=%.2fs, ratio=%.2f×)",
                    len(expected_text),
                    expected_sec,
                    duration_sec,
                    duration_sec / max(expected_sec, 0.01),
                )
                return True
            # 4b — under-short: TTS LM emitted EOS too early
            # (truncated reply). Gated by expected_sec > min_expected
            # so trivial prompts (single chars, pre-warm scratch)
            # don't false-positive.
            if (
                undershoot > 0.0
                and expected_sec > min_expected
                and duration_sec < expected_sec * undershoot
            ):
                logger.info(
                    "Token2Wav: duration mismatch under-short (text=%d "
                    "chars, expected~%.2fs, actual=%.2fs, ratio=%.2f×)",
                    len(expected_text),
                    expected_sec,
                    duration_sec,
                    duration_sec / max(expected_sec, 0.01),
                )
                return True
            # Compute the silent-window fraction once for both
            # signatures 2 and 3 below.
            silent_threshold = float(
                self.config.degenerate_silent_window_threshold
            )
            window = max(1, sample_rate // 10)  # 100ms
            n_windows = max(1, len(arr_f) // window)
            silent_count = 0
            for i in range(n_windows):
                seg = arr_f[i * window : (i + 1) * window]
                if seg.size == 0:
                    continue
                seg_rms = (
                    float(np.sqrt(np.mean(seg ** 2))) / 32768.0
                )
                if seg_rms < silent_threshold:
                    silent_count += 1
            silent_frac = silent_count / float(n_windows)
            # Signature 3: high silent-window fraction at any
            # duration. Above this threshold the audio is too
            # silence-dominated to be legitimate speech. Gated by
            # a minimum duration (0.5s) so trivial test fixtures
            # and pre-warm scratch outputs don't trip the gate.
            high_frac_threshold = float(
                self.config.degenerate_silent_window_fraction_high
            )
            if (
                high_frac_threshold > 0.0
                and duration_sec >= 0.5
                and silent_frac > high_frac_threshold
            ):
                return True
            # Signature 2: partial silence at-cap.
            if not at_cap:
                return False
            silent_frac_threshold = float(
                self.config.degenerate_silent_window_fraction
            )
            if silent_frac_threshold <= 0.0:
                return False
            return silent_frac > silent_frac_threshold
        except Exception:  # noqa: BLE001 - fail-safe
            return False

    def _advance_tts_sampling_seed(self) -> None:
        """Best-effort: bump the underlying TTS step's sampling seed
        so the next attempt explores a different trajectory.

        The runtime doesn't hold ``OpenVINOTTSGenerationStep``
        directly — it lives inside the ``MiniCPMO45NativeTTSAudioTokenizer``
        that ``runtime_factory`` wires into ``tokenizer_fn``.
        ``runtime_factory`` therefore attaches a hook called
        ``_sampling_seed_advancer`` so the runtime can reach in and
        bump the seed without an awkward back-reference.

        No-op when the hook is absent (byte-fallback path or test
        fakes that don't wire it up).
        """
        advancer = getattr(self, "_sampling_seed_advancer", None)
        if not callable(advancer):
            return
        try:
            advancer()
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "Token2Wav: sampling-seed advancer raised: %s", exc
            )

    def _reset_tts_sampling_seed(self) -> None:
        """Best-effort: reset the underlying TTS step's sampling seed
        to 0 at the start of every synthesis call.

        Symmetric to ``_advance_tts_sampling_seed``. Wired by
        ``runtime_factory`` as ``_sampling_seed_resetter`` so the
        runtime can reach the underlying ``OpenVINOTTSGenerationStep``
        without holding a direct reference. No-op when the hook is
        absent (byte-fallback path or test fakes that don't wire it).
        """
        resetter = getattr(self, "_sampling_seed_resetter", None)
        if not callable(resetter):
            return
        try:
            resetter()
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "Token2Wav: sampling-seed resetter raised: %s", exc
            )

    def pin_speaker_embedding(self, embedding: Any) -> None:
        """Pin a ``[1, 192]`` float32 speaker embedding for all future
        ``synthesize`` calls.

        The next ``_ensure_infer_steps`` call (which lazy-builds the
        infer helper) wires the embedding into a fresh
        ``Token2WavInferConfig`` so flow_embedding / flow_encoder
        condition on a stable voice. Calling this resets the lazy
        infer cache so the override takes effect immediately even
        if synthesis already ran once.
        """
        self._pinned_speaker_embedding = embedding
        # Reset so the next synthesize rebuilds infer_steps with the
        # new config. This is cheap — infer_steps is just a small
        # Python wrapper around the compiled OV handles.
        self._infer_steps = None

    def runtime_info(self) -> Dict[str, Any]:
        info = (
            self.bundle.runtime_info()
            if hasattr(self.bundle, "runtime_info")
            else {}
        )
        return {
            "active_device": info.get("active_device"),
            "model_dir": info.get("model_dir"),
            "loaded": True,
            "fallback_used": info.get("fallback_used", False),
            "compiled_models": info.get("compiled_models", []),
            "max_length": self.config.max_length,
            "sample_rate": self.config.sample_rate,
        }

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def _validate_text(self, text: str) -> str:
        if text is None or not str(text).strip():
            raise ValueError(
                "MiniCPMO45Token2WavRuntime.synthesize: text must be "
                "a non-empty string."
            )
        s = " ".join(str(text).split())
        if len(s) > self.config.max_length:
            raise ValueError(
                "MiniCPMO45Token2WavRuntime.synthesize: text exceeds "
                f"max_length={self.config.max_length} chars (got {len(s)})."
            )
        return s

    # ------------------------------------------------------------------
    # Pipeline seams
    # ------------------------------------------------------------------

    def _prepare_text_tokens(self, text: str) -> Any:
        # Voice-prime: prepend a constant short phrase to the input
        # so Token2Wav's speech-token autoregression always warms up
        # from the same conditioning, reducing per-turn voice drift
        # (session b09cc684 turns 4 + 6: Sichuan / Shanghai dialect
        # drift). Gated by ``Token2WavInferConfig.voice_prime`` so
        # tests / future tuning can disable.
        primed = self._apply_voice_prime(text)
        return self._tokenizer_fn(primed)

    def _apply_voice_prime(self, text: str) -> str:
        steps = self._infer_steps
        if steps is None:
            # Defer to _ensure_infer_steps for the default config.
            steps = self._ensure_infer_steps()
        cfg = getattr(steps, "config", None)
        if cfg is None:
            return text
        if not bool(getattr(cfg, "voice_prime", False)):
            return text
        prime = str(getattr(cfg, "voice_prime_text", "") or "")
        if not prime:
            return text
        # Skip if the prime is already at the start so a caller-side
        # retry doesn't double-up the prefix.
        if text.startswith(prime):
            return text
        # Round-6: skip the Chinese voice-prime ``"好，"`` for inputs
        # with NO CJK characters. The prime was added to stabilise
        # the speaker's vowel-formant trajectory across CHINESE
        # turns (b09cc684 dialect drift). For pure-English / pure-
        # Latin inputs like the flashcard carrier sentence
        # ``"The English word is: utility knife."`` the prime is a
        # foreign-language contaminant: real-machine session 23:19
        # showed the TTS LM producing 6.2s of garbled audio
        # (over-decode) when given ``"好，The English word is: ..."``
        # and a 1.80s under-short retry, both bit-identical across
        # turns. Mixed Chinese/English inputs keep the prime so the
        # documented drift fix stays effective for them.
        if not _contains_cjk(text):
            logger.debug(
                "Token2Wav: skipping voice-prime (no-CJK input, "
                "len=%d)",
                len(text),
            )
            return text
        # Round-7: Japanese flashcard replies like
        # ``"日本語では「ほん」です。"`` mix kanji (in the CJK range)
        # with hiragana / katakana. The presence of ANY kana is a
        # reliable Japanese marker — Mandarin text never contains
        # hiragana or katakana — so skip the prime to avoid mixing
        # a Chinese filler into Japanese prosody (real-machine
        # session 20260630-194619 turn 2 evidence).
        #
        # Known limitation (out of scope for round-7): MiniCPM-o-4.5
        # Token2Wav has no per-language conditioning and its bundled
        # speaker embedding is Mandarin-trained, so French / German /
        # Japanese pronunciations remain foreign-accented even with
        # the prime skipped. Skipping the prime brings JA back to
        # the same model-quality baseline as EN; per-language voice
        # tuning is a roadmap item.
        if _is_japanese_dominant(text):
            logger.debug(
                "Token2Wav: skipping voice-prime (Japanese-dominant "
                "input, len=%d)",
                len(text),
            )
            return text
        return prime + text

    def _run_flow_embedding(self, tokens: Any) -> Any:
        return self._flow_embedding_fn(tokens, self.bundle)

    def _run_flow_encoder(self, embedded: Any) -> Any:
        return self._flow_encoder_fn(embedded, self.bundle)

    def _run_flow_estimator(self, encoded: Any) -> Any:
        return self._flow_estimator_fn(encoded, self.bundle)

    def _run_hift_vocoder(self, estimated: Any) -> bytes:
        out = self._hift_fn(estimated, self.bundle)
        if isinstance(out, (bytes, bytearray)):
            return bytes(out)
        # Permit numpy-like objects.
        tobytes = getattr(out, "tobytes", None)
        if callable(tobytes):
            return tobytes()
        raise OVRuntimeError(
            "HiFT vocoder must return ``bytes`` or an object with "
            f"``.tobytes()``; got {type(out).__name__}."
        )

    # ------------------------------------------------------------------
    # WAV writing + validation
    # ------------------------------------------------------------------

    def _write_wav(self, audio: bytes, output_path: Path) -> Path:
        if not isinstance(audio, (bytes, bytearray)):
            raise OVRuntimeError(
                "_write_wav expects ``bytes`` (16-bit PCM); got "
                f"{type(audio).__name__}."
            )
        with wave.open(str(output_path), "wb") as wf:
            wf.setnchannels(self.config.channels)
            wf.setsampwidth(self.config.sample_width)
            wf.setframerate(self.config.sample_rate)
            wf.writeframes(bytes(audio))
        return output_path

    def _validate_wav_output(self, output_path: Path) -> None:
        """Confirm the written file is a real WAV with frames."""
        if not output_path.is_file() or output_path.stat().st_size == 0:
            raise OVRuntimeError(
                f"Token2Wav output is empty or missing: {output_path}"
            )
        try:
            with wave.open(str(output_path), "rb") as wf:
                if wf.getnframes() <= 0:
                    raise OVRuntimeError(
                        "Token2Wav output WAV has no audio frames: "
                        f"{output_path}"
                    )
        except wave.Error as exc:
            raise OVRuntimeError(
                "Token2Wav output is not a valid WAV: "
                f"{output_path} ({exc})"
            ) from exc

    # ------------------------------------------------------------------
    # Default seams (Task 43 — native infer-step delegates)
    # ------------------------------------------------------------------

    def _ensure_infer_steps(self) -> Any:
        if self._infer_steps is None:
            from .token2wav_infer_steps import (
                OpenVINOToken2WavInferSteps,
                Token2WavInferConfig,
            )

            # When the adapter pinned a speaker embedding (the typical
            # case — the bundled fixture loads from disk on construction),
            # propagate it into the per-call infer config so flow_embedding
            # / flow_encoder use a consistent voice across calls. Without
            # this, the byte-fallback path falls back to zero conditioning
            # and the flow_estimator's noise schedule produces a
            # different perceived voice for every utterance.
            cfg = None
            pinned = getattr(self, "_pinned_speaker_embedding", None)
            if pinned is not None:
                cfg = Token2WavInferConfig(speaker_embedding=pinned)
            self._infer_steps = OpenVINOToken2WavInferSteps(
                self.bundle, cfg
            )
        return self._infer_steps

    def _default_tokenizer_fn(self, text: str) -> Any:
        return self._ensure_infer_steps().prepare_text_tokens(text)

    def _default_flow_embedding_fn(self, tokens, bundle):
        return self._ensure_infer_steps().run_flow_embedding(
            tokens, bundle
        )

    def _default_flow_encoder_fn(self, embedded, bundle):
        return self._ensure_infer_steps().run_flow_encoder(
            embedded, bundle
        )

    def _default_flow_estimator_fn(self, encoded, bundle):
        return self._ensure_infer_steps().run_flow_estimator(
            encoded, bundle
        )

    def _default_hift_fn(self, estimated, bundle):
        return self._ensure_infer_steps().run_hift_vocoder(
            estimated, bundle
        )


__all__ = [
    "MiniCPMO45Token2WavRuntime",
    "Token2WavConfig",
    "Token2WavResult",
]
