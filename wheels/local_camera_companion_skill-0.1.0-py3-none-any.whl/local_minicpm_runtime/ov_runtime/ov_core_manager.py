# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Lazy-import wrapper around ``openvino.Core``.

The constructor never imports OpenVINO. The first call to
``available_devices`` / ``compile_model`` / ``compile_with_fallback``
triggers a lazy import of ``openvino`` (or pulls from a test-injected
fake module).
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from .errors import OVRuntimeDependencyError, OVRuntimeError

from local_camera_companion_skill.env_vars import (
    ENV_OV_CACHE_DIR,
    get_env,
)

PathLike = Union[str, Path]
logger = logging.getLogger(__name__)

# Override the default cache directory by setting this env var. Empty
# or unset → use ./.ov_cache/ in the current working directory. The
# legacy ``LOCAL_ENGLISH_TUTOR_OV_CACHE_DIR`` alias is honoured via the
# env-var resolver with a one-shot DeprecationWarning.
CACHE_DIR_ENV = ENV_OV_CACHE_DIR
DEFAULT_CACHE_DIRNAME = ".ov_cache"


def resolve_default_cache_dir() -> Path:
    """Return the default OV cache directory.

    Order:
      1. ``LOCAL_CAMERA_COMPANION_OV_CACHE_DIR`` env var (or the legacy
         ``LOCAL_ENGLISH_TUTOR_OV_CACHE_DIR`` alias) if set + non-empty.
      2. ``./.ov_cache/`` in the current working directory.

    Used when the caller passes ``cache_dir=None`` to ``OVCoreManager``.
    Pass ``cache_dir=False`` (sentinel) to opt out entirely.
    """
    override = (get_env(CACHE_DIR_ENV) or "").strip()
    if override:
        return Path(override)
    return Path.cwd() / DEFAULT_CACHE_DIRNAME


class OVCoreManager:
    """Owns a single ``openvino.Core`` instance, lazily created.

    Tests inject a fake module via
    ``OVCoreManager.set_openvino_module(fake_ov)`` (a class-level seam
    used by the fake-OV unit tests) and reset it via
    ``OVCoreManager.reset_openvino_module()``.
    """

    _ov_module_override: Any = None

    # Sentinel for "explicitly opt out of CACHE_DIR". Pass False (or
    # cache_dir=disable_cache) to skip the default ./.ov_cache/.
    _DISABLE_CACHE = object()

    def __init__(
        self,
        cache_dir: Optional[Union[PathLike, bool, object]] = None,
    ) -> None:
        if cache_dir is None:
            self.cache_dir: Optional[Path] = resolve_default_cache_dir()
        elif cache_dir is False or cache_dir is self._DISABLE_CACHE:
            self.cache_dir = None
        else:
            self.cache_dir = Path(cache_dir)  # type: ignore[arg-type]
        self._core: Any = None
        self._mmap_logged: bool = False

    # ------------------------------------------------------------------
    # Test seam
    # ------------------------------------------------------------------

    @classmethod
    def set_openvino_module(cls, module: Any) -> None:
        cls._ov_module_override = module

    @classmethod
    def reset_openvino_module(cls) -> None:
        cls._ov_module_override = None

    # ------------------------------------------------------------------
    # Lazy openvino + Core
    # ------------------------------------------------------------------

    def _get_openvino(self) -> Any:
        if self._ov_module_override is not None:
            return self._ov_module_override
        try:
            import openvino  # type: ignore
        except ImportError as exc:
            raise OVRuntimeDependencyError(
                "OpenVINO is required for native runtime. Install it "
                'with:  pip install '
                '"local-minicpm-runtime[openvino-runtime]"'
            ) from exc
        return openvino

    def _get_core(self) -> Any:
        if self._core is None:
            ov = self._get_openvino()
            self._core = ov.Core()
            if self.cache_dir is not None:
                self.cache_dir.mkdir(parents=True, exist_ok=True)
                try:
                    self._core.set_property(
                        {"CACHE_DIR": str(self.cache_dir)}
                    )
                    logger.info(
                        "OpenVINO CACHE_DIR=%s (compiled-blob cache "
                        "speeds up subsequent runs)",
                        self.cache_dir,
                    )
                except Exception:  # noqa: BLE001 - best effort
                    logger.warning(
                        "Failed to set CACHE_DIR=%s on openvino.Core",
                        self.cache_dir,
                    )
            self._log_mmap_status()
        return self._core

    def _log_mmap_status(self) -> None:
        """Probe and log the ENABLE_MMAP property once per core.

        OpenVINO ≥ 2024.0 mmaps weight files by default, which lets the
        OS reclaim host pages under memory pressure. If a build has it
        disabled (via env / config), parsed weights stay heap-resident
        and double-count against system RAM. We probe once and log so
        operators can spot the regression. Probe failures (older OV /
        property absent) are swallowed.
        """
        if self._mmap_logged or self._core is None:
            return
        try:
            value = self._core.get_property("ENABLE_MMAP")
            if value is False:
                logger.warning(
                    "OpenVINO ENABLE_MMAP is False — parsed weight "
                    "buffers will stay heap-resident and won't be "
                    "reclaimed under memory pressure. Investigate the "
                    "build / config if VRAM peak is unexpectedly high."
                )
            else:
                logger.info("OpenVINO ENABLE_MMAP=%r", value)
        except Exception:  # noqa: BLE001 - older OV may not expose it
            logger.debug(
                "Could not probe ENABLE_MMAP (older OpenVINO?)"
            )
        self._mmap_logged = True

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def available_devices(self) -> List[str]:
        core = self._get_core()
        try:
            return list(core.available_devices)
        except Exception as exc:  # noqa: BLE001
            raise OVRuntimeError(
                f"Could not query OpenVINO available devices: {exc}"
            ) from exc

    def compile_model(
        self,
        xml_path: PathLike,
        device: str,
        config: Optional[Dict[str, Any]] = None,
    ) -> Any:
        core = self._get_core()
        try:
            if config:
                return core.compile_model(str(xml_path), device, config)
            return core.compile_model(str(xml_path), device)
        except Exception as exc:  # noqa: BLE001
            raise OVRuntimeError(
                f"OpenVINO failed to compile {xml_path!s} on device "
                f"{device!r}: {exc}"
            ) from exc

    def compile_with_fallback(
        self,
        xml_path: PathLike,
        primary_device: str,
        fallback_device: str,
        config: Optional[Dict[str, Any]] = None,
    ) -> Tuple[Any, str, bool]:
        """Try ``primary_device`` first; fall back to ``fallback_device``.

        Returns ``(compiled_model, active_device, fallback_used)``.
        Raises ``OVRuntimeError`` only if both devices fail.
        """
        seen: set = set()
        last_exc: Optional[Exception] = None
        for device in (primary_device, fallback_device):
            if device is None or device in seen:
                continue
            seen.add(device)
            try:
                compiled = self.compile_model(xml_path, device, config)
                fallback_used = device != primary_device
                logger.info(
                    "Compiled %s on device=%s (fallback_used=%s)",
                    Path(xml_path).name,
                    device,
                    fallback_used,
                )
                return compiled, device, fallback_used
            except OVRuntimeError as exc:
                last_exc = exc
                logger.warning(
                    "Compile failed on device=%s for %s: %s",
                    device,
                    xml_path,
                    exc,
                )
        raise OVRuntimeError(
            f"Failed to compile {xml_path!s} on any of "
            f"{[primary_device, fallback_device]}: {last_exc}"
        ) from last_exc


__all__ = ["OVCoreManager", "PathLike"]
