# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""MiniCPM-o 4.5 native TTS audio-token generation step.

Implements ``generate(condition_embeds) -> List[int]`` for the
streaming-TTS pipeline. Per upstream pseudocode (verified against
``.scratch_converter`` reference), each call:

  1. First inner step (``t == 0``): feeds the full ``condition``
     tensor through the stateful TTS LM IR. ``condition`` is the
     concatenation of ``[text_cond_embeds, (text_eos_embed?), audio_bos_embed]``
     prepared by the caller (the pipeline; PR-B Phase 4).
  2. Subsequent inner steps: feeds only the last sampled audio
     token's embedding via the ``tts_code_embedding_model`` IR.
     Position ids advance by one. The KV cache is internal to the
     stateful TTS LM — no past-key-value tensors flow through the
     Python boundary, identical to the main LM step.
  3. Per step: TTS LM hidden_states → ``tts_code_head_model`` →
     audio-token logits ``[1, V]`` → argmax → next audio token id.
  4. Stops on EOS (``num_audio_tokens - 1``) or after ``max_steps``
     (default 500, per upstream).

This module is import-safe without OpenVINO or numpy. Both are
imported lazily inside ``generate`` only when a real inference is
requested. Hermetic tests inject deterministic fakes via the bundle
and ``_numpy`` monkeypatch.

The base ``OpenVINOLanguageModelStep`` contract is unchanged — this
step is a sibling, not a subclass, because the I/O shapes (audio
tokens vs. text tokens), the auxiliary IRs (code_embedding +
code_head vs. embedding), and the stop tokens all differ.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

from .compiled_model_bundle import CompiledModelBundle
from .errors import OVRuntimeDependencyError, OVRuntimeError

logger = logging.getLogger(__name__)


def _looks_like_port(obj: Any) -> bool:
    cls_name = type(obj).__name__
    return cls_name in ("ConstOutput", "Output")


@dataclass
class TTSGenerationStepConfig:
    """Per-call configuration for the TTS audio-token generation step."""

    inputs_embeds_name: Optional[str] = None
    attention_mask_name: Optional[str] = None
    position_ids_name: Optional[str] = None
    hidden_states_output_name: Optional[str] = None
    code_head_input_name: Optional[str] = None
    code_embedding_input_name: Optional[str] = None
    # ``num_audio_tokens`` and ``eos_token_id`` default to the
    # MiniCPM-o-4.5 TTS config: vocab=6562, EOS = vocab-1 = 6561.
    num_audio_tokens: int = 6562
    eos_token_id: int = 6561
    # Cap that prevents an unbounded inner loop if the model never
    # emits EOS. 500 matches upstream ``streaming_generate``.
    max_steps: int = 500
    # Sampling parameters. Pure argmax decoding locks the TTS LM
    # into degenerate single-token cycles, producing mel features
    # stuck at one audio-token's embedding (and silent WAVs). The
    # minimal stack: temperature → repetition penalty → top-k →
    # top-p → multinomial sample.
    #
    # Temperature lowered from upstream 0.8 to 0.3 for Camera
    # Companion voice consistency. The upstream default is tuned
    # for audiobook-style narration; at 0.8 the top-k of 25 spans
    # tokens that decode to visibly different timbres (male vs
    # female-leaning), producing cross-turn voice flips. 0.3
    # concentrates mass on the modal voice while keeping enough
    # stochasticity to avoid the degenerate cycles strict argmax
    # triggers on rare conditions.
    temperature: float = 0.3
    top_p: float = 0.85
    top_k: int = 25
    repetition_penalty: float = 1.05
    repetition_penalty_window: int = 16
    # When True (default), use stochastic sampling per upstream. Set
    # False for deterministic argmax decoding (tests use this so they
    # can assert on specific token IDs).
    do_sample: bool = True
    # Seed for the per-call sampling RNG. Stable across runs given
    # the same condition tensor and audio-token history.
    sampling_seed: int = 0


class OpenVINOTTSGenerationStep:
    """Audio-token autoregressive decoder backed by the TTS IR sub-models.

    Mirrors :class:`OpenVINOLanguageModelStep` but talks to a different
    set of compiled handles (``tts_language_model`` for the autoregressive
    LM, ``tts_code_head_model`` for the audio-token logit projection,
    ``tts_code_embedding_model`` for next-step single-token embedding
    lookup).
    """

    _TTS_LANGUAGE_MODEL = "tts_language_model"
    _TTS_CODE_HEAD = "tts_code_head_model"
    _TTS_CODE_EMBEDDING = "tts_code_embedding_model"

    def __init__(
        self,
        bundle: CompiledModelBundle,
        config: Optional[TTSGenerationStepConfig] = None,
    ) -> None:
        self.bundle = bundle
        self.config = config or TTSGenerationStepConfig()
        self._initialized: bool = False

        self._tts_lm_compiled: Any = None
        self._tts_lm_request: Any = None
        self._tts_code_head_compiled: Any = None
        self._tts_code_head_request: Any = None
        self._tts_code_embedding_compiled: Any = None
        self._tts_code_embedding_request: Any = None

        self._lm_input_names: Dict[str, Optional[str]] = {}
        self._lm_hidden_states_output_name: Optional[str] = None
        self._code_head_input_name: Optional[str] = None
        self._code_embedding_input_name: Optional[str] = None

        # Past-length counter: total positions consumed by the TTS LM
        # across the current condition. Resets in ``reset()``.
        self._past_length: int = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(self, condition_embeds: Any) -> List[int]:
        """Generate audio tokens for one TTS condition.

        ``condition_embeds`` is shape ``[1, L, hidden]``. The caller
        (the streaming-TTS pipeline) is responsible for assembling
        the condition: ``[text_cond, (text_eos?), audio_bos]``.

        Returns a list of audio-token IDs (length 0 if the model
        emits EOS on the first step). Tokens are NOT chunked or
        buffered here; the pipeline groups them in batches of 25
        for vocoding.
        """
        self._ensure_initialized()
        np = self._numpy()
        condition_length = self._seq_len(condition_embeds)
        if condition_length <= 0:
            raise ValueError(
                "OpenVINOTTSGenerationStep.generate: condition_embeds "
                "must be non-empty along the sequence dim."
            )

        generated: List[int] = []
        eos_id = int(self.config.eos_token_id)
        max_steps = int(self.config.max_steps)
        if max_steps <= 0:
            raise ValueError(
                "TTSGenerationStepConfig.max_steps must be positive; "
                f"got {max_steps}."
            )
        # Lazily create the sampling RNG on first need so hermetic
        # tests with do_sample=False can use a fake numpy that lacks
        # ``np.random``.
        rng_holder: Dict[str, Any] = {"rng": None}

        def _get_rng():
            if rng_holder["rng"] is None:
                rng_holder["rng"] = np.random.default_rng(
                    int(self.config.sampling_seed)
                )
            return rng_holder["rng"]

        for t in range(max_steps):
            if t == 0:
                inputs_embeds = condition_embeds
                pos_ids = np.arange(
                    self._past_length,
                    self._past_length + condition_length,
                    dtype=np.int64,
                ).reshape(1, -1)
                attn_mask = np.ones(
                    (1, self._past_length + condition_length),
                    dtype=np.int64,
                )
            else:
                last_token_id = generated[-1]
                inputs_embeds = self._run_code_embedding(last_token_id, np)
                pos_ids = np.asarray(
                    [[self._past_length + condition_length + t - 1]],
                    dtype=np.int64,
                )
                attn_mask = np.ones(
                    (1, self._past_length + condition_length + t),
                    dtype=np.int64,
                )

            hidden_states = self._run_tts_lm(
                inputs_embeds, attn_mask, pos_ids, np
            )
            logits = self._run_code_head(hidden_states)
            next_id = self._sample_next_token(
                logits, generated, _get_rng, np
            )

            if next_id == eos_id:
                break
            generated.append(next_id)

        # Total positions the TTS LM has now seen, for the next condition.
        self._past_length += condition_length + len(generated)
        return generated

    # ------------------------------------------------------------------
    # Sampling stack (matches upstream streaming_generate)
    # ------------------------------------------------------------------

    def _sample_next_token(
        self,
        logits: Any,
        history: List[int],
        rng_factory: Callable[[], Any],
        np: Any,
    ) -> int:
        """Pick the next audio-token id from the code_head logits.

        With ``do_sample=True`` (the default), applies the upstream
        gen-logits stack:

          temperature → repetition penalty → top-k → top-p → multinomial

        ``do_sample=False`` returns argmax (used by hermetic tests
        that need deterministic tokens). Without sampling, the TTS
        LM locks into degenerate single-token cycles → silent WAV.
        See debug_trace.log iteration 4 (500 steps, 2 unique tokens,
        499 copies of token 4299).
        """
        # Reduce logits to [num_audio_tokens]: pull the trailing
        # position, first VQ codebook, like _argmax_last_audio_token.
        if _looks_like_port(logits):
            raise OVRuntimeError(
                "TTS code_head returned an OpenVINO port object "
                "instead of tensor data."
            )
        arr = np.asarray(logits)
        shape = tuple(getattr(arr, "shape", ()))
        if len(shape) == 4:
            scores = arr[0, -1, :, 0]
        elif len(shape) == 3:
            scores = arr[0, -1]
        elif len(shape) == 2:
            scores = arr[-1]
        elif len(shape) == 1:
            scores = arr
        else:
            raise OVRuntimeError(
                "TTS code_head logits have an unsupported shape: "
                f"{shape}. Expected 1D-4D."
            )

        # Argmax fast path (used by hermetic tests with do_sample=False
        # and by callers that explicitly opt out of stochastic
        # decoding). Avoids numpy ops that the test fake-numpy stub
        # doesn't implement.
        if not bool(self.config.do_sample):
            return int(np.argmax(scores))

        # Real-numpy stochastic path.
        scores = np.asarray(scores, dtype=np.float32)
        # Cap at the audio-token vocab in case the head emits extra
        # bins for a fused token space.
        num_audio_tokens = int(self.config.num_audio_tokens)
        if scores.shape[0] > num_audio_tokens:
            scores = scores[:num_audio_tokens]

        temperature = float(self.config.temperature)
        if temperature > 0.0 and temperature != 1.0:
            scores = scores / temperature

        rep_penalty = float(self.config.repetition_penalty)
        if rep_penalty != 1.0 and history:
            window = int(self.config.repetition_penalty_window)
            recent = history[-window:] if window > 0 else list(history)
            for tok in set(recent):
                if 0 <= tok < scores.shape[0]:
                    if scores[tok] > 0:
                        scores[tok] = scores[tok] / rep_penalty
                    else:
                        scores[tok] = scores[tok] * rep_penalty

        top_k = int(self.config.top_k)
        if top_k > 0 and top_k < scores.shape[0]:
            kth = np.partition(scores, -top_k)[-top_k]
            scores = np.where(scores < kth, np.float32(-1e30), scores)

        # Softmax for top-p + multinomial.
        max_score = float(np.max(scores))
        exp_scores = np.exp(scores - max_score)
        probs = exp_scores / np.sum(exp_scores)

        top_p = float(self.config.top_p)
        if 0.0 < top_p < 1.0:
            order = np.argsort(probs)[::-1]
            sorted_probs = probs[order]
            cumprobs = np.cumsum(sorted_probs)
            keep = cumprobs <= top_p
            # Always keep at least one token (the top-1).
            keep[0] = True
            sorted_probs = np.where(keep, sorted_probs, 0.0)
            total = float(np.sum(sorted_probs))
            if total <= 0.0:
                sorted_probs = np.zeros_like(sorted_probs)
                sorted_probs[0] = 1.0
                total = 1.0
            sorted_probs = sorted_probs / total
            # Sample from the sorted distribution then map back.
            choice = int(
                rng_factory().choice(
                    len(sorted_probs), p=sorted_probs
                )
            )
            return int(order[choice])

        # No top-p: sample directly.
        total = float(np.sum(probs))
        if total <= 0.0:
            return int(np.argmax(scores))
        probs = probs / total
        return int(rng_factory().choice(len(probs), p=probs))

    def advance_sampling_seed(self) -> int:
        """Increment ``config.sampling_seed`` by 1 and return it.

        Used by the post-synthesis degenerate-output detector
        (``MiniCPMO45Token2WavRuntime._is_degenerate``) to break out
        of cycle-locked sampling: the next ``generate`` call seeds a
        fresh ``np.random.default_rng`` from the bumped value and
        explores a different sampling trajectory. The RNG itself
        lives on a per-call ``rng_holder`` inside ``generate()``,
        so there's no cached state to invalidate here — flipping
        the config field is sufficient.
        """
        new_seed = int(self.config.sampling_seed) + 1
        self.config.sampling_seed = new_seed
        return new_seed

    def reset_sampling_seed(self) -> int:
        """Reset ``config.sampling_seed`` to 0 and return it.

        Counterpart to ``advance_sampling_seed``. Called at the
        start of every ``MiniCPMO45Token2WavRuntime.synthesize``
        so a previous turn's degenerate-retry seed bump doesn't
        leak into the next turn's RNG state. Without this, one
        cycle-lock recovery permanently shifts the per-session
        sampling trajectory and visibly changes the modal voice.
        """
        self.config.sampling_seed = 0
        return 0

    def reset(self) -> None:
        """Reset KV-cache state for a fresh TTS generation.

        Clears the per-call counter (``_past_length``) and the OV
        Variable tensors inside the TTS LM InferRequest. The cached
        InferRequest itself is preserved so the compile cache stays
        warm.
        """
        if self._tts_lm_request is not None:
            reset_state = getattr(self._tts_lm_request, "reset_state", None)
            if callable(reset_state):
                try:
                    reset_state()
                except Exception as exc:  # noqa: BLE001 - best effort
                    logger.warning(
                        "TTS LM InferRequest.reset_state failed: %s", exc
                    )
            else:
                logger.debug(
                    "TTS LM InferRequest has no reset_state(); skipping."
                )
        self._past_length = 0

    def runtime_info(self) -> Dict[str, Any]:
        return {
            "tts_language_model_loaded": self._tts_lm_compiled is not None,
            "tts_code_head_loaded": (
                self._tts_code_head_compiled is not None
            ),
            "tts_code_embedding_loaded": (
                self._tts_code_embedding_compiled is not None
            ),
            "lm_input_names": dict(self._lm_input_names),
            "hidden_states_output_name": self._lm_hidden_states_output_name,
            "past_length": self._past_length,
            "num_audio_tokens": int(self.config.num_audio_tokens),
            "eos_token_id": int(self.config.eos_token_id),
            "max_steps": int(self.config.max_steps),
        }

    # ------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------

    def _ensure_initialized(self) -> None:
        if self._initialized:
            return
        for name in (
            self._TTS_LANGUAGE_MODEL,
            self._TTS_CODE_HEAD,
            self._TTS_CODE_EMBEDDING,
        ):
            if not self.bundle.has(name):
                raise OVRuntimeError(
                    f"CompiledModelBundle is missing the {name!r} "
                    "handle required by OpenVINOTTSGenerationStep. "
                    f"Available: {self.bundle.names()}."
                )

        self._tts_lm_compiled = self.bundle.get(self._TTS_LANGUAGE_MODEL)
        self._tts_code_head_compiled = self.bundle.get(self._TTS_CODE_HEAD)
        self._tts_code_embedding_compiled = self.bundle.get(
            self._TTS_CODE_EMBEDDING
        )

        self._lm_input_names = self._discover_lm_input_names(
            self._tts_lm_compiled
        )
        self._lm_hidden_states_output_name = (
            self._discover_hidden_states_output_name(self._tts_lm_compiled)
        )
        self._code_head_input_name = self._discover_first_input_name(
            self._tts_code_head_compiled,
            override=self.config.code_head_input_name,
        )
        self._code_embedding_input_name = self._discover_first_input_name(
            self._tts_code_embedding_compiled,
            override=self.config.code_embedding_input_name,
        )
        self._initialized = True

    def _discover_lm_input_names(
        self, compiled: Any
    ) -> Dict[str, Optional[str]]:
        out: Dict[str, Optional[str]] = {
            "inputs_embeds": self.config.inputs_embeds_name,
            "attention_mask": self.config.attention_mask_name,
            "position_ids": self.config.position_ids_name,
            # The TTS LM IR (post-stateful patch) carries a beam_idx
            # port the same way the main LM IR does. Discover it so
            # we can feed a [1] int32 zero for greedy decoding.
            "beam_idx": None,
        }
        inputs = getattr(compiled, "inputs", None)
        if not inputs:
            return out
        names = [self._port_name(p) for p in inputs]
        for key in list(out.keys()):
            if out[key] is not None:
                continue
            for n in names:
                if n is None:
                    continue
                if key in n:
                    out[key] = n
                    break
        return out

    def _discover_hidden_states_output_name(
        self, compiled: Any
    ) -> Optional[str]:
        if self.config.hidden_states_output_name is not None:
            return self.config.hidden_states_output_name
        outputs = getattr(compiled, "outputs", None)
        if not outputs:
            return None
        names = [self._port_name(p) for p in outputs]
        for n in names:
            if n is not None and "hidden_states" in n:
                return n
        return names[0] if names else None

    def _discover_first_input_name(
        self, compiled: Any, override: Optional[str] = None
    ) -> Optional[str]:
        if override is not None:
            return override
        inputs = getattr(compiled, "inputs", None)
        if not inputs:
            return None
        for p in inputs:
            n = self._port_name(p)
            if n is not None:
                return n
        return None

    @staticmethod
    def _port_name(port: Any) -> Optional[str]:
        for attr in ("any_name", "name"):
            v = getattr(port, attr, None)
            if isinstance(v, str) and v:
                return v
        names = getattr(port, "names", None)
        if names:
            try:
                return next(iter(names))
            except Exception:  # noqa: BLE001
                return None
        return None

    # ------------------------------------------------------------------
    # Inference helpers
    # ------------------------------------------------------------------

    def _run_tts_lm(
        self, inputs_embeds: Any, attn_mask: Any, pos_ids: Any, np: Any
    ) -> Any:
        feed: Dict[str, Any] = {}
        embeds_name = self._lm_input_names.get("inputs_embeds")
        mask_name = self._lm_input_names.get("attention_mask")
        pos_name = self._lm_input_names.get("position_ids")
        beam_name = self._lm_input_names.get("beam_idx")
        if embeds_name is None:
            raise OVRuntimeError(
                "TTS language_model has no inputs_embeds port."
            )
        feed[embeds_name] = inputs_embeds
        if mask_name is not None:
            feed[mask_name] = attn_mask
        if pos_name is not None:
            feed[pos_name] = pos_ids
        if beam_name is not None:
            # Greedy decoding: single beam index 0. Real OV stateful
            # IRs require this port even when num_beams=1.
            feed[beam_name] = np.zeros((1,), dtype=np.int32)
        result = self._infer(self._tts_lm_compiled, feed, "_tts_lm_request")
        return self._extract_named_output(
            result,
            self._lm_hidden_states_output_name,
            "TTS language_model",
        )

    def _run_code_head(self, hidden_states: Any) -> Any:
        feed: Dict[str, Any] = {}
        if self._code_head_input_name is not None:
            feed[self._code_head_input_name] = hidden_states
        else:
            feed[0] = hidden_states  # positional fallback
        result = self._infer(
            self._tts_code_head_compiled, feed, "_tts_code_head_request"
        )
        return self._extract_named_output(result, None, "TTS code_head")

    def _run_code_embedding(self, token_id: int, np: Any) -> Any:
        # The IR expects [1, 1, 1] int64 (per upstream pseudocode:
        # last_tok.unsqueeze(-1) shape).
        ids = np.asarray([[[int(token_id)]]], dtype=np.int64)
        feed: Dict[str, Any] = {}
        if self._code_embedding_input_name is not None:
            feed[self._code_embedding_input_name] = ids
        else:
            feed[0] = ids
        result = self._infer(
            self._tts_code_embedding_compiled,
            feed,
            "_tts_code_embedding_request",
        )
        return self._extract_named_output(
            result, None, "TTS code_embedding"
        )

    def _infer(
        self, compiled: Any, feed: Dict[str, Any], req_attr: str
    ) -> Any:
        create = getattr(compiled, "create_infer_request", None)
        if callable(create):
            req = getattr(self, req_attr)
            if req is None:
                req = create()
                setattr(self, req_attr, req)
                # Same first-call gotcha as the main LM step: a freshly
                # created stateful InferRequest may have undefined
                # Variable contents on some OV/oneDNN builds. Reset
                # once on creation so the very first infer sees the
                # cache as the model expects.
                reset_state = getattr(req, "reset_state", None)
                if callable(reset_state):
                    try:
                        reset_state()
                    except Exception as exc:  # noqa: BLE001
                        logger.warning(
                            "TTS InferRequest.reset_state() on creation "
                            "failed: %s",
                            exc,
                        )
            infer = getattr(req, "infer", None)
            if callable(infer):
                return infer(feed)
            return req(feed)
        if callable(compiled):
            return compiled(feed)
        raise OVRuntimeError(
            "TTS compiled handle is neither callable nor exposes "
            "create_infer_request()."
        )

    def _extract_named_output(
        self, result: Any, name: Optional[str], handle_label: str
    ) -> Any:
        # Prefer name-keyed access (OVDict gotcha — same as the main
        # LM step's _extract_logits).
        if name is not None and not isinstance(result, (list, tuple)):
            try:
                tensor = result[name]
            except (KeyError, TypeError):
                tensor = None
            if tensor is not None and not _looks_like_port(tensor):
                return tensor
        if isinstance(result, dict):
            if not result:
                raise OVRuntimeError(
                    f"{handle_label} produced no outputs."
                )
            return next(iter(result.values()))
        values = getattr(result, "values", None)
        if callable(values):
            try:
                first = next(iter(values()))
                if first is not None and not _looks_like_port(first):
                    return first
            except (StopIteration, TypeError):
                pass
        outputs = getattr(result, "outputs", None)
        if outputs is not None and not isinstance(result, (list, tuple)):
            try:
                first = next(iter(outputs))
                return outputs[first]
            except (StopIteration, KeyError, TypeError):
                pass
        return result

    def _argmax_last_audio_token(self, logits: Any, np: Any) -> int:
        """Reduce TTS code_head output to a single audio-token id.

        Upstream shape: ``[1, seq_len, num_audio_tokens, num_vq]``.
        The Skill currently runs num_vq=1 and reads the last position,
        first VQ codebook. For 1D/2D/3D shapes (test fakes and
        reduced-vq builds) we accept argmax over the last axis at
        the trailing position.
        """
        if _looks_like_port(logits):
            raise OVRuntimeError(
                "TTS code_head returned an OpenVINO port object "
                "instead of tensor data."
            )
        arr = np.asarray(logits)
        shape = tuple(getattr(arr, "shape", ()))
        # 4D: [B, T, V, num_vq]  → arr[0, -1, :V_audio, 0]
        if len(shape) == 4:
            return int(np.argmax(arr[0, -1, :, 0]))
        # 3D: [B, T, V]          → arr[0, -1]
        if len(shape) == 3:
            return int(np.argmax(arr[0, -1]))
        # 2D: [T, V]             → arr[-1]
        if len(shape) == 2:
            return int(np.argmax(arr[-1]))
        if len(shape) == 1:
            return int(np.argmax(arr))
        raise OVRuntimeError(
            "TTS code_head logits have an unsupported shape: "
            f"{shape}. Expected 1D-4D."
        )

    @staticmethod
    def _seq_len(arr: Any) -> int:
        shape = tuple(getattr(arr, "shape", ()))
        if len(shape) >= 2:
            return int(shape[1])
        if len(shape) == 1:
            return int(shape[0])
        return 0

    # ------------------------------------------------------------------
    # Lazy numpy
    # ------------------------------------------------------------------

    @staticmethod
    def _numpy() -> Any:
        try:
            import numpy as np  # type: ignore
        except ImportError as exc:
            raise OVRuntimeDependencyError(
                "numpy is required for the native TTS generation "
                "step. Install it with: pip install "
                '"local-minicpm-runtime[openvino-runtime]"'
            ) from exc
        return np


__all__ = ["TTSGenerationStepConfig", "OpenVINOTTSGenerationStep"]
