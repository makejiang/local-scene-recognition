# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Repository-owned native OpenVINO runtime.

Importing this package is **safe without OpenVINO installed** — the
heavy import is deferred to the factory function bodies in
``runtime_factory``. The upstream OpenVINO Notebook helper is
reference only and is **not** used at runtime.

See ``docs/real_model_adapter_design.md``.
"""

from __future__ import annotations

from .audio_runtime import AudioEmbeddingResult, MiniCPMO45AudioRuntime
from .compiled_model_bundle import CompiledModelBundle
from .errors import (
    OVRuntimeDependencyError,
    OVRuntimeError,
    OVRuntimeLayoutError,
    OVRuntimeNotImplementedError,
)
from .generation_loop import (
    GenerationConfig,
    GenerationResult,
    TextGenerationLoop,
)
from .language_model_step import (
    LanguageModelStepConfig,
    OpenVINOLanguageModelStep,
)
from .message_builder import (
    build_audio_messages,
    build_image_messages,
    build_mixed_messages,
    build_text_messages,
    build_textbook_ocr_messages,
    flatten_text_messages,
)
from .model_paths import MiniCPMO45ModelPaths
from .multimodal_runtime import MiniCPMO45MultimodalRuntime
from .native_tts import (
    DEFAULT_AUDIO_BOS_TOKEN_ID,
    DEFAULT_TEXT_EOS_TOKEN_ID,
    MiniCPMO45NativeTTSAudioTokenizer,
    NativeTTSAudioTokenizerConfig,
    is_native_tts_supported,
    required_handle_names,
)
from .ov_core_manager import OVCoreManager
from .speaker_embedding import (
    DEFAULT_FIXTURE_FILENAME as DEFAULT_SPEAKER_EMBEDDING_FILENAME,
    SPEAKER_EMBEDDING_DIM,
    default_fixture_path as default_speaker_embedding_fixture_path,
    load_default_embedding as load_default_speaker_embedding,
    load_embedding as load_speaker_embedding,
    save_embedding as save_speaker_embedding,
)
from .runtime_factory import (
    create_minicpm_o45_runtime,
    create_token2wav_runtime,
)
from .text_runtime import MiniCPMO45TextRuntime
from .token2wav_infer_steps import (
    OpenVINOToken2WavInferSteps,
    Token2WavInferConfig,
)
from .token2wav_runtime import (
    MiniCPMO45Token2WavRuntime,
    Token2WavConfig,
    Token2WavResult,
)
from .tokenizer_adapter import TokenizerAdapter
from .tts_generation_step import (
    OpenVINOTTSGenerationStep,
    TTSGenerationStepConfig,
)
from .vision_runtime import MiniCPMO45VisionRuntime, VisionEmbeddingResult

__all__ = [
    "AudioEmbeddingResult",
    "CompiledModelBundle",
    "DEFAULT_AUDIO_BOS_TOKEN_ID",
    "DEFAULT_SPEAKER_EMBEDDING_FILENAME",
    "DEFAULT_TEXT_EOS_TOKEN_ID",
    "SPEAKER_EMBEDDING_DIM",
    "GenerationConfig",
    "GenerationResult",
    "LanguageModelStepConfig",
    "MiniCPMO45NativeTTSAudioTokenizer",
    "NativeTTSAudioTokenizerConfig",
    "MiniCPMO45AudioRuntime",
    "MiniCPMO45ModelPaths",
    "MiniCPMO45MultimodalRuntime",
    "MiniCPMO45TextRuntime",
    "MiniCPMO45Token2WavRuntime",
    "MiniCPMO45VisionRuntime",
    "OVCoreManager",
    "OVRuntimeError",
    "OVRuntimeDependencyError",
    "OVRuntimeLayoutError",
    "OVRuntimeNotImplementedError",
    "OpenVINOLanguageModelStep",
    "OpenVINOToken2WavInferSteps",
    "OpenVINOTTSGenerationStep",
    "TTSGenerationStepConfig",
    "TextGenerationLoop",
    "Token2WavConfig",
    "Token2WavInferConfig",
    "Token2WavResult",
    "TokenizerAdapter",
    "VisionEmbeddingResult",
    "build_audio_messages",
    "build_image_messages",
    "build_mixed_messages",
    "build_text_messages",
    "build_textbook_ocr_messages",
    "create_minicpm_o45_runtime",
    "create_token2wav_runtime",
    "default_speaker_embedding_fixture_path",
    "flatten_text_messages",
    "is_native_tts_supported",
    "load_default_speaker_embedding",
    "load_speaker_embedding",
    "required_handle_names",
    "save_speaker_embedding",
]
