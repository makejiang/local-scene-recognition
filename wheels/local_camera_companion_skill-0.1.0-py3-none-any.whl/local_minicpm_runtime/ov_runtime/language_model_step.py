# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""MiniCPM-o 4.5 native language-model inference step.

Implements ``step_fn(prefix_token_ids, prev_logits) -> int`` for the
greedy ``TextGenerationLoop``. Calls the compiled ``language_model``
handle from a ``CompiledModelBundle`` and returns ``argmax(logits)``.

This module is import-safe without OpenVINO or numpy — both are
imported lazily inside ``__call__`` only when a real inference is
requested. Tests inject fake compiled models / fake infer requests
via the bundle and a fake numpy via monkeypatching ``_numpy``.
"""

from __future__ import annotations

import logging
import os
import sys
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .compiled_model_bundle import CompiledModelBundle
from .errors import OVRuntimeDependencyError, OVRuntimeError

from local_camera_companion_skill.env_vars import (
    ENV_DEBUG_LM_STEP,
    ENV_KV_CACHE,
    get_env,
)

logger = logging.getLogger(__name__)

# Operators can opt out of KV-cache reuse by setting this env var to
# "0" (or "false"). Default is enabled. Useful for debugging regressions
# or for older OpenVINO builds whose stateful API isn't trustworthy.
# The legacy ``LOCAL_ENGLISH_TUTOR_KV_CACHE`` name is honoured via the
# env-var resolver with a one-shot DeprecationWarning.
KV_CACHE_ENV = ENV_KV_CACHE

# Per-step diagnostic logging. Set to "1" to log at INFO level, on every
# __call__, the shape/position payload we feed to the compiled language
# model. Off by default to avoid log spam in production. Used to triage
# stateful-decode regressions where the cache desyncs from our counter.
DEBUG_LM_STEP_ENV = ENV_DEBUG_LM_STEP


def _resolve_kv_cache_default() -> bool:
    raw = (get_env(KV_CACHE_ENV) or "").strip().lower()
    if raw in ("0", "false", "no", "off"):
        return False
    # Empty / unset / any other value → enabled.
    return True


def _resolve_debug_lm_step() -> bool:
    raw = (get_env(DEBUG_LM_STEP_ENV) or "").strip().lower()
    return raw in ("1", "true", "yes", "on")


def _looks_like_port(obj: Any) -> bool:
    """Heuristic: detect an OpenVINO ``ConstOutput`` / port object.

    Used to reject port handles that an ``OVDict`` may return when
    indexed by another port (instead of by name). A real tensor has
    a numeric ``.shape`` attribute and is not a port-like object.
    """
    cls_name = type(obj).__name__
    return cls_name in ("ConstOutput", "Output")


@dataclass
class LanguageModelStepConfig:
    """Per-call configuration for the language-model inference step."""

    input_ids_name: Optional[str] = None
    attention_mask_name: Optional[str] = None
    position_ids_name: Optional[str] = None
    inputs_embeds_name: Optional[str] = None
    beam_idx_name: Optional[str] = None
    logits_output_name: Optional[str] = None
    hidden_states_output_name: Optional[str] = None
    stateful: bool = True
    use_cache: bool = True
    # When None, falls back to LOCAL_CAMERA_COMPANION_KV_CACHE env var
    # (or the legacy LOCAL_ENGLISH_TUTOR_KV_CACHE alias) — default:
    # enabled. Explicit True/False bypasses the env var.
    kv_cache_enabled: Optional[bool] = None
    debug: bool = False


class OpenVINOLanguageModelStep:
    """Greedy decoder step backed by the compiled MiniCPM-o language model.

    Designed to be plugged into ``MiniCPMO45TextRuntime.step_fn``. The
    OpenVINO + numpy imports are lazy; tests inject fakes via the
    bundle so this class can be exercised in default CI without either
    runtime dependency installed.
    """

    _LANGUAGE_MODEL_NAME = "language_model"
    _LANGUAGE_MODEL_CPU_NAME = "language_model_cpu"
    _EMBEDDING_MODEL_NAME = "embedding_model"

    def __init__(
        self,
        bundle: CompiledModelBundle,
        config: Optional[LanguageModelStepConfig] = None,
    ) -> None:
        self.bundle = bundle
        self.config = config or LanguageModelStepConfig()
        self._compiled: Any = None
        self._infer_request: Any = None
        # Optional CPU-compiled twin of the LM. Used only for audio-
        # modality calls when ``audio_offload=True``. The first such
        # call materialises this lazily via the bundle. Pure GPU and
        # text-only sessions never touch it. Each path keeps its own
        # InferRequest + KV cache; switching directions resets the
        # GPU side because the audio-prefill path doesn't share KV
        # state with text generation anyway.
        self._cpu_compiled: Any = None
        self._cpu_infer_request: Any = None
        self._input_names: Dict[str, Optional[str]] = {}
        self._output_name: Optional[str] = None
        self._hidden_states_output_name: Optional[str] = None
        self._initialized: bool = False
        # Text prefix length seen by the LM so far. Tracked separately
        # from ``_seen_tokens`` (which counts ALL positions including
        # modality embeddings) so the incremental gate can compare
        # text-prefix growth, not absolute position counts.
        self._seen_text_tokens: int = 0
        # Embedding sub-model handles for the inputs_embeds path used
        # by MiniCPM-o IR layouts (language_model takes inputs_embeds,
        # not raw token ids).
        self._embedding_compiled: Any = None
        self._embedding_request: Any = None
        # KV-cache reuse state. The MiniCPM-o-4.5 IR is stateful — its
        # XML carries 72 ReadValue + 82 Assign ops with variable_id
        # "past_key_values.<n>.<key|value>". By feeding only the new
        # token after the first call, the per-step attention scratch
        # drops from O(seq^2) to O(seq), which is the only path that
        # survives the OpenCL 4 GB single-allocation cap on integrated
        # Intel GPUs at realistic prompt lengths.
        self._seen_tokens: int = 0
        self._kv_cache_enabled: bool = (
            self.config.kv_cache_enabled
            if self.config.kv_cache_enabled is not None
            else _resolve_kv_cache_default()
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def __call__(
        self,
        prefix_token_ids: List[int],
        prev_logits: Optional[Any] = None,
        modality_embeddings: Optional[Sequence[Any]] = None,
        modality_attention_masks: Optional[Sequence[Any]] = None,
        modality_kinds: Optional[Sequence[Any]] = None,
        anchor_token_ids: Optional[Any] = None,
        audio_offload: bool = False,
    ) -> int:
        result, np = self._run(
            prefix_token_ids,
            modality_embeddings=modality_embeddings,
            modality_attention_masks=modality_attention_masks,
            modality_kinds=modality_kinds,
            anchor_token_ids=anchor_token_ids,
            audio_offload=audio_offload,
        )
        logits = self._extract_logits(result)
        next_id = self._argmax_last_token(logits, np)

        if _resolve_debug_lm_step():
            print(
                f"LM_STEP: predicted next_id={next_id}",
                file=sys.stderr,
                flush=True,
            )
        return next_id

    def __call_with_hidden__(
        self,
        prefix_token_ids: List[int],
        modality_embeddings: Optional[Sequence[Any]] = None,
        modality_attention_masks: Optional[Sequence[Any]] = None,
        modality_kinds: Optional[Sequence[Any]] = None,
        anchor_token_ids: Optional[Any] = None,
        audio_offload: bool = False,
    ) -> Tuple[int, Any]:
        """Run one decode step and return ``(next_id, hidden_states)``.

        Mirrors ``__call__`` but also returns the LM's last-layer
        ``hidden_states`` tensor. Used by the native streaming-TTS
        path: the TTS LM conditions on ``F.normalize(hidden_states)``
        projected through ``projector_semantic``. The base ``__call__``
        contract is unchanged so non-TTS callers pay zero cost.
        """
        result, np = self._run(
            prefix_token_ids,
            modality_embeddings=modality_embeddings,
            modality_attention_masks=modality_attention_masks,
            modality_kinds=modality_kinds,
            anchor_token_ids=anchor_token_ids,
            audio_offload=audio_offload,
        )
        logits = self._extract_logits(result)
        hidden_states = self._extract_hidden_states(result)
        next_id = self._argmax_last_token(logits, np)
        return next_id, hidden_states

    def _run(
        self,
        prefix_token_ids: List[int],
        *,
        modality_embeddings: Optional[Sequence[Any]] = None,
        modality_attention_masks: Optional[Sequence[Any]] = None,
        modality_kinds: Optional[Sequence[Any]] = None,
        anchor_token_ids: Optional[Any] = None,
        audio_offload: bool = False,
    ) -> Tuple[Any, Any]:
        """Run one decode step and return ``(raw_result, numpy_module)``.

        Shared implementation for ``__call__`` and ``__call_with_hidden__``.
        Owns feed preparation, KV-cache fast-path selection, and the
        infer call; output extraction is left to the caller so the
        same inference produces either ``next_id`` alone or
        ``(next_id, hidden_states)`` without redundant compute.
        """
        if not prefix_token_ids:
            raise ValueError(
                "OpenVINOLanguageModelStep: prefix_token_ids must be "
                "non-empty."
            )
        self._ensure_initialized()
        np = self._numpy()
        feed: Dict[str, Any] = {}

        # MiniCPM-o IR splits the embedding lookup out of the language
        # model: language_model takes ``inputs_embeds`` (float [B, T, H]),
        # not ``input_ids``. When the bundle has a separate
        # ``embedding_model`` and the language model has an
        # ``inputs_embeds`` port, run the embedding sub-model first.
        #
        # Modality injection (Qwen2.5-VL convention):
        # The caller (``text_runtime.generate_text_with_embeddings``)
        # has already spliced anchor tokens
        # (``<|vision_start|><|image_pad|>×N<|vision_end|>`` for vision,
        # ``<|audio_start|><unk>×N<|audio_end|>`` for audio) into the
        # prompt before tokenization. ``prefix_token_ids`` therefore
        # contains contiguous runs of pad-token-id positions, one per
        # modality embedding. We embed the full prefix normally, then
        # *replace* the pad-token embeddings with the encoder outputs
        # in place — the LM sees a sequence whose anchor structure
        # matches its training distribution, instead of an unanchored
        # block of vision tokens prepended to text.
        embeds_name = self._input_names.get("inputs_embeds")
        ids_name = self._input_names.get("input_ids")
        mask_name = self._input_names.get("attention_mask")
        pos_name = self._input_names.get("position_ids")

        # KV-cache fast path: incremental decode after the first chunk.
        # When the cached InferRequest already holds the prefix's KV
        # state, feed only the new token. This is the *only* path
        # that keeps single-step attention scratch under the OpenCL
        # 4 GB cap at realistic prompt lengths and the only one the
        # CPU plugin's ScaledDotProductAttentionWithKVCache accepts
        # for back-to-back calls.
        #
        # Modality calls take the full-prefix branch on the FIRST
        # step (to inject audio/image embeddings into the KV cache).
        # Subsequent steps must NOT re-prepend the modality — the
        # cache already holds those positions, and re-feeding them
        # produces a stale-cache mismatch (the IR's Assign ops
        # populate cache_v one position behind cache_k after the
        # second prefill). After the first call, ``_seen_text_tokens > 0``
        # and we fall through to incremental decode just like the
        # text-only path. We compare against the TEXT-prefix length
        # (not _seen_tokens, which also counts modality positions)
        # because the caller's ``prefix_token_ids`` is text-only.
        incremental = (
            self._kv_cache_enabled
            and self._seen_text_tokens > 0
            and len(prefix_token_ids) > self._seen_text_tokens
        )

        if incremental:
            new_token_id = prefix_token_ids[-1]
            if embeds_name is not None and self._embedding_compiled is not None:
                feed[embeds_name] = self._run_embedding(
                    [new_token_id], np
                )
            elif ids_name is not None:
                feed[ids_name] = np.asarray(
                    [[new_token_id]], dtype=np.int64
                )
            else:
                raise OVRuntimeError(
                    "language_model exposes neither 'inputs_embeds' nor "
                    "'input_ids' port; cannot run incremental decode."
                )
            if mask_name is not None:
                feed[mask_name] = np.ones(
                    (1, self._seen_tokens + 1), dtype=np.int64
                )
            if pos_name is not None:
                feed[pos_name] = np.asarray(
                    [[self._seen_tokens]], dtype=np.int64
                )
            self._seen_tokens += 1
            self._seen_text_tokens += 1
        elif embeds_name is not None and self._embedding_compiled is not None:
            text_emb = self._run_embedding(prefix_token_ids, np)
            text_seq = self._seq_len(text_emb)
            if modality_embeddings:
                full_embeds = self._inject_modality_into_embeds(
                    text_emb=text_emb,
                    prefix_token_ids=prefix_token_ids,
                    modality_embeddings=list(modality_embeddings),
                    modality_kinds=list(modality_kinds or []),
                    anchor_token_ids=anchor_token_ids,
                    np=np,
                )
            else:
                full_embeds = text_emb
            full_seq = self._seq_len(full_embeds)
            feed[embeds_name] = full_embeds
            if mask_name is not None:
                feed[mask_name] = np.ones(
                    (1, full_seq), dtype=np.int64
                )
            if pos_name is not None:
                feed[pos_name] = np.arange(
                    full_seq, dtype=np.int64
                ).reshape(1, -1)
            # Anchor-replace keeps text and full sequence aligned —
            # both counters move together. The previous prefix-concat
            # path tracked them separately; that asymmetry is gone.
            self._seen_tokens = full_seq
            self._seen_text_tokens = full_seq
        elif ids_name is not None:
            # Fallback path: language_model takes input_ids directly.
            # Modality embeddings cannot be injected here because there
            # is no inputs_embeds port; raise to surface the mismatch.
            if modality_embeddings:
                raise OVRuntimeError(
                    "Cannot inject modality embeddings: language_model "
                    "has no 'inputs_embeds' port. The MiniCPM-o IR "
                    "layout exposes inputs_embeds; non-conforming IRs "
                    "must use text-only generation."
                )
            feed[ids_name] = np.asarray(
                [list(prefix_token_ids)], dtype=np.int64
            )
            if mask_name is not None:
                feed[mask_name] = np.ones(
                    (1, len(prefix_token_ids)), dtype=np.int64
                )
            if pos_name is not None:
                feed[pos_name] = np.arange(
                    len(prefix_token_ids), dtype=np.int64
                ).reshape(1, -1)
            self._seen_tokens = len(prefix_token_ids)
            self._seen_text_tokens = len(prefix_token_ids)

        beam_name = self._input_names.get("beam_idx")
        if beam_name is not None:
            feed[beam_name] = np.zeros((1,), dtype=np.int32)

        if _resolve_debug_lm_step():
            shapes = {
                name: tuple(getattr(t, "shape", ()))
                for name, t in feed.items()
            }
            print(
                f"LM_STEP: incremental={incremental} "
                f"seen_tokens={self._seen_tokens} "
                f"prefix_len={len(prefix_token_ids)} "
                f"feed_shapes={shapes}",
                file=sys.stderr,
                flush=True,
            )

        result = self._infer(feed, audio_offload=audio_offload)
        return result, np

    def _inject_modality_into_embeds(
        self,
        *,
        text_emb: Any,
        prefix_token_ids: List[int],
        modality_embeddings: List[Any],
        modality_kinds: List[Any],
        anchor_token_ids: Any,
        np: Any,
    ) -> Any:
        """Replace anchor-pad token embeddings with encoder outputs.

        ``prefix_token_ids`` already contains contiguous runs of
        pad-token-id positions (one run per modality, in the order
        they appear in ``modality_embeddings``). We locate those
        runs, write the encoder's per-token output into the matching
        slice of ``text_emb`` in place, and return the resulting
        tensor. Run length must equal encoder seq dim — that's a
        load-bearing invariant the caller's ``build_anchor_marker``
        guarantees by construction.
        """
        from .anchor_tokens import find_anchor_runs

        if anchor_token_ids is None:
            raise OVRuntimeError(
                "modality embeddings provided without anchor_token_ids; "
                "the prompt cannot have been decorated correctly. "
                "Caller must resolve anchor ids before invoking the "
                "LM step (see text_runtime.generate_text_with_embeddings)."
            )
        if len(modality_kinds) != len(modality_embeddings):
            raise OVRuntimeError(
                "modality_kinds length "
                f"({len(modality_kinds)}) must match "
                f"modality_embeddings length ({len(modality_embeddings)})."
            )

        # Group runs by pad id so vision and audio modalities can
        # interleave correctly when both are present.
        out = np.copy(text_emb)
        pad_id_to_runs: Dict[int, List[Tuple[int, int]]] = {}
        seen_pad_ids: List[int] = []
        for kind in modality_kinds:
            pid = anchor_token_ids.pad_id(kind)
            if pid in pad_id_to_runs:
                continue
            seen_pad_ids.append(pid)
            pad_id_to_runs[pid] = find_anchor_runs(prefix_token_ids, pid)

        # Walk the modality list and consume one run per call.
        consumed: Dict[int, int] = {pid: 0 for pid in seen_pad_ids}
        for emb, kind in zip(modality_embeddings, modality_kinds):
            pid = anchor_token_ids.pad_id(kind)
            runs = pad_id_to_runs[pid]
            idx = consumed[pid]
            if idx >= len(runs):
                raise OVRuntimeError(
                    f"prompt has fewer {kind!r} anchor runs than "
                    f"modality embeddings ({len(runs)} runs vs "
                    f"{idx + 1}-th embedding). The prompt was not "
                    "decorated correctly."
                )
            start, length = runs[idx]
            consumed[pid] = idx + 1
            emb_seq = self._seq_len(emb)
            if length != emb_seq:
                raise OVRuntimeError(
                    f"anchor run length ({length}) does not match "
                    f"{kind!r} embedding seq dim ({emb_seq}) at "
                    f"prompt position {start}. The prompt-anchor "
                    "count is the number of pad tokens we asked the "
                    "tokenizer to emit; the embedding seq dim is what "
                    "the encoder produced. They must agree."
                )
            # ``emb`` is shape [1, length, hidden]; broadcast slice
            # assignment into the matching window of ``out``.
            out[:, start : start + length, :] = emb[:, :length, :]
        return out

    @staticmethod
    def _seq_len(arr: Any) -> int:
        """Return the sequence-length dim for a tensor of shape (1, T, ...)."""
        shape = tuple(getattr(arr, "shape", ()))
        if len(shape) >= 2:
            return int(shape[1])
        if len(shape) == 1:
            return int(shape[0])
        return 0

    def reset(self) -> None:
        """Reset KV-cache state for a fresh generation.

        Two effects:
        1. Zeros ``self._seen_tokens`` so the next ``__call__`` takes
           the first-chunk branch (full prefix + position_ids[0..T-1]).
        2. Calls ``self._infer_request.reset_state()`` so OpenVINO's
           internal Variable tensors (``past_key_values.<n>.<key|value>``)
           are cleared. Without this, a second ``generate_text`` call
           would attend over the previous turn's KV — wrong outputs.

        Best-effort: older OpenVINO builds and the fake-OV test seam
        may not expose ``reset_state``; missing-attribute degrades to
        a debug log. The cached InferRequest itself is preserved —
        re-creating it would lose the compile cache.
        """
        for label, req in (
            ("GPU", self._infer_request),
            ("CPU-twin", self._cpu_infer_request),
        ):
            if req is None:
                continue
            reset_state = getattr(req, "reset_state", None)
            if callable(reset_state):
                try:
                    reset_state()
                except Exception as exc:  # noqa: BLE001 - best effort
                    logger.warning(
                        "%s InferRequest.reset_state failed: %s",
                        label, exc,
                    )
            else:
                logger.debug(
                    "%s InferRequest has no reset_state(); skipping.",
                    label,
                )
        self._seen_tokens = 0
        self._seen_text_tokens = 0

    def runtime_info(self) -> Dict[str, Any]:
        return {
            "language_model_loaded": self._compiled is not None,
            "input_names": dict(self._input_names),
            "output_name": self._output_name,
            "hidden_states_output_name": self._hidden_states_output_name,
            "stateful": self.config.stateful,
            "use_cache": self.config.use_cache,
            "kv_cache_enabled": self._kv_cache_enabled,
            "seen_tokens": self._seen_tokens,
        }

    # ------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------

    def _ensure_initialized(self) -> None:
        if self._initialized:
            return
        if not self.bundle.has(self._LANGUAGE_MODEL_NAME):
            raise OVRuntimeError(
                "CompiledModelBundle is missing the 'language_model' "
                f"handle. Available: {self.bundle.names()}."
            )
        self._compiled = self.bundle.get(self._LANGUAGE_MODEL_NAME)
        self._input_names = self._discover_input_names(self._compiled)
        self._output_name = self._discover_output_name(self._compiled)
        self._hidden_states_output_name = (
            self._discover_hidden_states_output_name(self._compiled)
        )
        # If the language model takes inputs_embeds (MiniCPM-o layout),
        # eagerly resolve the embedding model handle from the bundle.
        if (
            self._input_names.get("inputs_embeds") is not None
            and self.bundle.has(self._EMBEDDING_MODEL_NAME)
        ):
            self._embedding_compiled = self.bundle.get(
                self._EMBEDDING_MODEL_NAME
            )
        self._initialized = True

    def _discover_input_names(
        self, compiled: Any
    ) -> Dict[str, Optional[str]]:
        out: Dict[str, Optional[str]] = {
            "input_ids": self.config.input_ids_name,
            "attention_mask": self.config.attention_mask_name,
            "position_ids": self.config.position_ids_name,
            "inputs_embeds": self.config.inputs_embeds_name,
            "beam_idx": self.config.beam_idx_name,
        }
        inputs = getattr(compiled, "inputs", None)
        if not inputs:
            return out
        names = [self._port_name(p) for p in inputs]
        for key in list(out.keys()):
            if out[key] is not None:
                continue
            for n in names:
                if n is None:
                    continue
                if key in n:
                    out[key] = n
                    break
        return out

    def _discover_output_name(self, compiled: Any) -> Optional[str]:
        if self.config.logits_output_name is not None:
            return self.config.logits_output_name
        outputs = getattr(compiled, "outputs", None)
        if not outputs:
            return None
        names = [self._port_name(p) for p in outputs]
        for n in names:
            if n is not None and "logits" in n:
                return n
        return names[0] if names else None

    def _discover_hidden_states_output_name(
        self, compiled: Any
    ) -> Optional[str]:
        if self.config.hidden_states_output_name is not None:
            return self.config.hidden_states_output_name
        outputs = getattr(compiled, "outputs", None)
        if not outputs:
            return None
        names = [self._port_name(p) for p in outputs]
        for n in names:
            if n is not None and "hidden_states" in n:
                return n
        return None

    @staticmethod
    def _port_name(port: Any) -> Optional[str]:
        for attr in ("any_name", "name"):
            v = getattr(port, attr, None)
            if isinstance(v, str) and v:
                return v
        names = getattr(port, "names", None)
        if names:
            try:
                return next(iter(names))
            except Exception:  # noqa: BLE001
                return None
        return None

    # ------------------------------------------------------------------
    # Embedding sub-model (token-id → embeddings) for MiniCPM-o layout
    # ------------------------------------------------------------------

    def _run_embedding(self, prefix_token_ids: List[int], np: Any) -> Any:
        """Convert token ids to embeddings via the ``embedding_model``.

        Returns the embeddings tensor in the shape the language-model's
        ``inputs_embeds`` port expects (typically ``[1, seq, hidden]``).
        """
        compiled = self._embedding_compiled
        ids = np.asarray([list(prefix_token_ids)], dtype=np.int64)

        # Discover the embedding model's input port name; fall back to
        # positional if no name is available.
        ids_port_name: Optional[str] = None
        inputs = getattr(compiled, "inputs", None)
        if inputs:
            for p in inputs:
                ids_port_name = self._port_name(p)
                break

        create = getattr(compiled, "create_infer_request", None)
        if callable(create):
            if self._embedding_request is None:
                self._embedding_request = create()
            req = self._embedding_request
            infer = getattr(req, "infer", None)
            feed = {ids_port_name: ids} if ids_port_name else {0: ids}
            result = infer(feed) if callable(infer) else req(feed)
        elif callable(compiled):
            feed = {ids_port_name: ids} if ids_port_name else {0: ids}
            result = compiled(feed)
        else:
            raise OVRuntimeError(
                "embedding_model handle is neither callable nor "
                "exposes create_infer_request()."
            )

        # Extract the single embeddings output. OpenVINO returns an
        # ``OVDict`` (dict-like, not a true ``dict``); fall back to
        # the .values() iterator.
        try:
            values = list(result.values())
            if values:
                return values[0]
        except (AttributeError, TypeError):
            pass
        # Real OV InferRequest result with .outputs mapping (port → tensor).
        outputs = getattr(result, "outputs", None)
        if outputs is not None:
            try:
                first = next(iter(outputs))
                return outputs[first]
            except (StopIteration, KeyError, TypeError):
                pass
        if isinstance(result, dict):
            try:
                return next(iter(result.values()))
            except StopIteration as exc:
                raise OVRuntimeError(
                    "embedding_model produced no outputs."
                ) from exc
        return result

    # ------------------------------------------------------------------
    # Inference
    # ------------------------------------------------------------------

    def prewarm_cpu_twin(self) -> Dict[str, Any]:
        """Force the CPU-pinned twin of the LM to compile + upload
        weights so the first ``audio_offload=True`` inference doesn't
        pay the OpenVINO cold-start cost.

        The MiniCPM-o-4.5 IR is a 4 GB INT4 model; compiling it on
        the CPU plugin (which the audio path requires to dodge the
        4 GB OpenCL single-allocation cap on Intel iGPUs) takes
        30-60 s on a 32 GB box. Without this prewarm the cost lands
        inside turn-1's ``asr_ms``.

        Best-effort: returns ``{"compile_ms": int, "skipped": bool,
        "reason": Optional[str]}``. Idempotent — a second call after
        ``_cpu_compiled`` is materialised returns ``skipped=True``.
        """
        import time as _time

        if self._cpu_compiled is not None:
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": "already_warm",
            }
        if not self.bundle.has(self._LANGUAGE_MODEL_CPU_NAME):
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": "no_cpu_twin",
            }
        t0 = _time.monotonic()
        try:
            self._cpu_compiled = self.bundle.get(self._LANGUAGE_MODEL_CPU_NAME)
        except Exception as exc:  # noqa: BLE001 - best effort
            return {
                "compile_ms": int((_time.monotonic() - t0) * 1000),
                "skipped": True,
                "reason": f"{type(exc).__name__}: {exc}",
            }
        return {
            "compile_ms": int((_time.monotonic() - t0) * 1000),
            "skipped": False,
            "reason": None,
        }

    def _get_cpu_compiled(self) -> Any:
        """Materialise the CPU-pinned twin of the language model.

        Resolved through the bundle's lazy factory under the
        ``language_model_cpu`` key; ``runtime_factory`` registers it
        when the GPU compile of the regular ``language_model``
        succeeds. Falls back to the regular GPU-compiled handle when
        no CPU twin is registered (e.g. CPU-only profile, where the
        regular handle is already on CPU).
        """
        if self._cpu_compiled is not None:
            return self._cpu_compiled
        if self.bundle.has(self._LANGUAGE_MODEL_CPU_NAME):
            self._cpu_compiled = self.bundle.get(
                self._LANGUAGE_MODEL_CPU_NAME
            )
        else:
            # No CPU twin → fall back to the regular handle. Logged
            # at INFO so operators can see that audio_offload is a
            # no-op in this configuration.
            logger.info(
                "audio_offload requested but bundle has no "
                "%r entry; using the default LM handle.",
                self._LANGUAGE_MODEL_CPU_NAME,
            )
            self._cpu_compiled = self._compiled
        return self._cpu_compiled

    def _infer(self, feed: Dict[str, Any], audio_offload: bool = False) -> Any:
        # Audio-offload: route to a CPU-compiled twin of the LM. The
        # GPU prefill for an audio modality call (~600+ token sequence
        # injected via ``inputs_embeds``) hits the OpenCL 4 GB
        # single-allocation cap on integrated Intel Arc parts even
        # under cpu_offload, because the cap is per-allocation and
        # the per-step attention scratch is the offending one. The
        # CPU plugin has no such cap. Text-only and image-only paths
        # keep using the GPU-compiled handle.
        if audio_offload:
            compiled = self._get_cpu_compiled()
            request_attr = "_cpu_infer_request"
        else:
            compiled = self._compiled
            request_attr = "_infer_request"
        create = getattr(compiled, "create_infer_request", None)
        if callable(create):
            req = getattr(self, request_attr)
            if req is None:
                req = create()
                setattr(self, request_attr, req)
                # Stateful IR contract: a freshly-created InferRequest's
                # Variable tensors (the past_key_values.<n>.<key|value>
                # ports) are allocated but their initial values are
                # *undefined* on some OpenVINO/oneDNN builds. The
                # MiniCPM-o-4.5 IR carries 72 ReadValue + 82 Assign ops;
                # without an explicit reset_state() the very first
                # infer() can attend over uninitialised "past KV" and
                # the LM deterministically picks token id 1 ("``") on
                # every step — observed on Intel Arc B390 driver 32.0.101.
                # Call reset_state() once on creation so the first infer
                # sees an empty cache as the model expects.
                reset_state = getattr(req, "reset_state", None)
                if callable(reset_state):
                    try:
                        reset_state()
                    except Exception as exc:  # noqa: BLE001
                        logger.warning(
                            "InferRequest.reset_state() on creation "
                            "failed: %s",
                            exc,
                        )
            infer = getattr(req, "infer", None)
            if callable(infer):
                return infer(feed)
            return req(feed)
        if callable(compiled):
            return compiled(feed)
        raise OVRuntimeError(
            "Compiled language_model handle is neither callable nor "
            "exposes create_infer_request()."
        )

    def _extract_logits(self, result: Any) -> Any:
        # Real OpenVINO's InferRequest.infer() returns an OVDict, which
        # is dict-like but ``isinstance(result, dict)`` is False. The
        # OVDict supports key-by-name AND key-by-ConstOutput — but
        # iter(OVDict) yields ConstOutput keys, and indexing OVDict by
        # a ConstOutput key returns the ConstOutput itself (not tensor
        # data) on at least some 2024+/2025+ builds. Indexing by NAME
        # always returns the tensor. So we prefer name-key access here
        # and fall back to .values() (which yields tensors) only if no
        # discovered name is available.
        if (
            self._output_name is not None
            and not isinstance(result, (list, tuple))
        ):
            try:
                tensor = result[self._output_name]
            except (KeyError, TypeError):
                tensor = None
            if tensor is not None and not _looks_like_port(tensor):
                return tensor
        # Plain dict path (test fakes return regular dicts).
        if isinstance(result, dict):
            if not result:
                raise OVRuntimeError(
                    "Language model produced no outputs."
                )
            try:
                return next(iter(result.values()))
            except StopIteration as exc:
                raise OVRuntimeError(
                    "Language model produced no outputs."
                ) from exc
        # OVDict (real OpenVINO): .values() yields tensor data even
        # when the keys are ConstOutput ports.
        values = getattr(result, "values", None)
        if callable(values):
            try:
                first = next(iter(values()))
                if first is not None and not _looks_like_port(first):
                    return first
            except (StopIteration, TypeError):
                pass
        # Last-resort: ``.outputs`` mapping (port → tensor).
        outputs = getattr(result, "outputs", None)
        if outputs is not None and not isinstance(result, (list, tuple)):
            try:
                first = next(iter(outputs))
                return outputs[first]
            except (StopIteration, KeyError, TypeError):
                pass
        return result

    def _extract_hidden_states(self, result: Any) -> Any:
        """Extract the ``hidden_states`` tensor from the LM IR result.

        The MiniCPM-o-4.5 LM IR exposes both ``logits`` and
        ``hidden_states`` as named non-KV outputs. Same OVDict pitfalls
        as ``_extract_logits`` — prefer name-key access; fall back to
        positional only when the discovered name is unavailable.
        """
        if (
            self._hidden_states_output_name is not None
            and not isinstance(result, (list, tuple))
        ):
            try:
                tensor = result[self._hidden_states_output_name]
            except (KeyError, TypeError):
                tensor = None
            if tensor is not None and not _looks_like_port(tensor):
                return tensor
        # Plain dict path (test fakes return regular dicts).
        if isinstance(result, dict):
            if "hidden_states" in result:
                return result["hidden_states"]
            # Fall back to the second value if present (logits is first).
            vals = list(result.values())
            if len(vals) >= 2:
                return vals[1]
            raise OVRuntimeError(
                "Language model produced no hidden_states output. "
                "The MiniCPM-o-4.5 IR must expose both 'logits' and "
                "'hidden_states' for native TTS conditioning."
            )
        # OVDict path: iterate values and pick the second non-port tensor.
        values = getattr(result, "values", None)
        if callable(values):
            tensors = [
                v for v in values() if not _looks_like_port(v)
            ]
            if len(tensors) >= 2:
                return tensors[1]
        raise OVRuntimeError(
            "Could not extract hidden_states from language model "
            "result. The IR must expose a 'hidden_states' output."
        )

    def _argmax_last_token(self, logits: Any, np: Any) -> int:
        # Defensive guard: surface a clear error if _extract_logits
        # accidentally returned a port handle instead of tensor data.
        # Without this, np.asarray() of a ConstOutput silently produces
        # a 0-D array and argmax returns 0 — masking the real bug.
        if _looks_like_port(logits):
            raise OVRuntimeError(
                "Language model returned an OpenVINO port object "
                "instead of tensor data. _extract_logits must return "
                "the actual tensor — check OVDict access patterns."
            )
        arr = np.asarray(logits)
        shape = tuple(getattr(arr, "shape", ()))
        if len(shape) == 1:
            return int(np.argmax(arr))
        if len(shape) == 2:
            return int(np.argmax(arr[-1]))
        if len(shape) == 3:
            return int(np.argmax(arr[0, -1]))
        raise OVRuntimeError(
            "Language model logits have an unsupported shape: "
            f"{shape}. Expected 1D, 2D, or 3D."
        )

    # ------------------------------------------------------------------
    # Lazy numpy
    # ------------------------------------------------------------------

    @staticmethod
    def _numpy() -> Any:
        try:
            import numpy as np  # type: ignore
        except ImportError as exc:
            raise OVRuntimeDependencyError(
                "numpy is required for the native language-model "
                "inference step. Install it with: pip install "
                '"local-minicpm-runtime[openvino-runtime]"'
            ) from exc
        return np


__all__ = ["LanguageModelStepConfig", "OpenVINOLanguageModelStep"]
