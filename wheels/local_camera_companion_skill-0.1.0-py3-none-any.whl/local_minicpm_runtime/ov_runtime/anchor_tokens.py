# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Anchor-token helpers for the multimodal LM bridge.

When the language model is fed an image or audio embedding, the
prompt's ``input_ids`` sequence must contain anchor tokens that
the LM was trained to attend to:

    Vision:   ``<|vision_start|>  <|image_pad|> × N  <|vision_end|>``
    Audio:    ``<|audio_start|>   <unk>          × N  <|audio_end|>``

where ``N`` is the number of seq positions in the encoder output.
At inference time the LM step embeds the full input_ids, then
*replaces* the embeddings at the ``<|image_pad|>`` / ``<unk>``
positions with the encoder's per-token output. This module owns:

  * Looking up the anchor token IDs from a HF tokenizer (so the
    code stays correct even if the tokenizer's vocab shifts).
  * Building the literal anchor-marker substring to splice into
    the user prompt before tokenization.

This is a thin pure-Python module — no OpenVINO, no torch, no
numpy. Tests inject a fake tokenizer that exposes only
``convert_tokens_to_ids``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Optional

ModalityKind = Literal["vision", "audio"]


# Literal anchor strings the chat template will tokenize into the
# right ids. We call ``convert_tokens_to_ids`` once to validate that
# every token actually exists in the tokenizer's vocabulary; that
# turns "the IRs were re-converted with an incompatible vocab" into
# a load-time exception instead of silent gibberish.
_VISION_START = "<|vision_start|>"
_VISION_END = "<|vision_end|>"
_IMAGE_PAD = "<|image_pad|>"
_AUDIO_START = "<|audio_start|>"
_AUDIO_END = "<|audio_end|>"
_AUDIO_PAD = "<unk>"  # MiniCPM-o convention; see processing_minicpmo.py


@dataclass(frozen=True)
class AnchorTokenIds:
    """Resolved anchor token ids for a given tokenizer."""

    vision_start: int
    vision_end: int
    image_pad: int
    audio_start: int
    audio_end: int
    audio_pad: int

    def pad_id(self, kind: ModalityKind) -> int:
        if kind == "vision":
            return self.image_pad
        if kind == "audio":
            return self.audio_pad
        raise ValueError(f"unknown modality kind: {kind!r}")


def resolve_anchor_token_ids(tokenizer: Any) -> AnchorTokenIds:
    """Look up the six anchor token ids from ``tokenizer``.

    ``tokenizer`` must expose ``convert_tokens_to_ids(name) -> int``
    (HF AutoTokenizer interface). Raises ``ValueError`` if any token
    is missing or maps to a sentinel like -1 / None — that means the
    converted IR layout was built from an incompatible base model
    and the bridge cannot work.
    """
    pairs = (
        ("vision_start", _VISION_START),
        ("vision_end", _VISION_END),
        ("image_pad", _IMAGE_PAD),
        ("audio_start", _AUDIO_START),
        ("audio_end", _AUDIO_END),
        ("audio_pad", _AUDIO_PAD),
    )
    resolved: dict[str, int] = {}
    for field, name in pairs:
        try:
            tid = tokenizer.convert_tokens_to_ids(name)
        except Exception as exc:  # noqa: BLE001
            raise ValueError(
                f"tokenizer cannot resolve anchor token {name!r}: {exc}"
            ) from exc
        if not isinstance(tid, int) or tid < 0:
            raise ValueError(
                f"tokenizer returned invalid id for {name!r}: {tid!r}. "
                "The model's added_tokens.json may be missing this token."
            )
        resolved[field] = tid
    return AnchorTokenIds(**resolved)


def build_anchor_marker(kind: ModalityKind, n_pad_tokens: int) -> str:
    """Return the literal string to splice into a prompt.

    Example::

        build_anchor_marker("vision", 4)
        # -> "<|vision_start|><|image_pad|><|image_pad|><|image_pad|><|image_pad|><|vision_end|>"

    The string is plain text; it gets tokenized by the chat template
    into the ids ``resolve_anchor_token_ids`` resolved at load time.
    """
    if not isinstance(n_pad_tokens, int) or n_pad_tokens <= 0:
        raise ValueError(
            f"n_pad_tokens must be a positive int; got {n_pad_tokens!r}"
        )
    if kind == "vision":
        return _VISION_START + (_IMAGE_PAD * n_pad_tokens) + _VISION_END
    if kind == "audio":
        return _AUDIO_START + (_AUDIO_PAD * n_pad_tokens) + _AUDIO_END
    raise ValueError(f"unknown modality kind: {kind!r}")


def find_anchor_runs(
    input_ids: list[int], pad_id: int
) -> list[tuple[int, int]]:
    """Return ``[(start, length), ...]`` for each maximal run of ``pad_id``.

    Used by the LM step to locate the contiguous slice of positions
    in ``inputs_embeds`` that should be overwritten with one
    modality embedding. With the chat template feeding the prompt,
    each modality contributes exactly one run; we still return a
    list so multi-image / multi-audio prompts work naturally.
    """
    runs: list[tuple[int, int]] = []
    i = 0
    n = len(input_ids)
    while i < n:
        if input_ids[i] == pad_id:
            j = i
            while j < n and input_ids[j] == pad_id:
                j += 1
            runs.append((i, j - i))
            i = j
        else:
            i += 1
    return runs


__all__ = [
    "AnchorTokenIds",
    "ModalityKind",
    "build_anchor_marker",
    "find_anchor_runs",
    "resolve_anchor_token_ids",
]
