# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""MiniCPM-o 4.5 audio encoding runtime.

Validates an audio path via the existing ``AudioInputHandler`` and
encodes it into a structured ``AudioEmbeddingResult`` (also accessible
as a dict via ``.as_dict()``). The encoder loads the waveform (stdlib
``wave`` for ``.wav``; lazy ``librosa`` for other formats), computes
mel filterbank features, and runs the compiled
``audio_encoder_model`` + ``audio_projection_model`` sub-models.

This module is import-safe without OpenVINO, numpy, or librosa. All
three are imported lazily inside ``_default_encoder_fn`` only when a
real encoding is requested.

Tests inject a deterministic ``encoder_fn`` to exercise the multimodal
flow without any real OpenVINO call.

Real-IR contract (MiniCPM-o 4.5 / Whisper-style APM):
- audio_encoder_model: input_features [B, 80, T_mel], attention_mask
  [B, 1, T_seq, T_seq] (T_seq = (T_mel - 1) // 2 + 1), beam_idx [B]
  -> hidden_states [B, T_seq, 1024]
- audio_projection_model: audio_features [B, ?, 1024]
  -> [B, ?, 4096]
- Post-projection avg-pool with kernel=5 (audio_pool_step) is applied
  numpy-side here; the OV graph does NOT include it.
"""

from __future__ import annotations

import logging
import wave
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple, Union

from ..audio_input import AudioInputHandler
from .compiled_model_bundle import CompiledModelBundle
from .errors import OVRuntimeDependencyError, OVRuntimeError

PathLike = Union[str, Path]
logger = logging.getLogger(__name__)


# Whisper-compatible mel parameters used by MiniCPM-o's APM.
_DEFAULT_SAMPLE_RATE = 16000
_DEFAULT_N_MELS = 80
_DEFAULT_HOP_LENGTH = 160
_DEFAULT_WIN_LENGTH = 400
_DEFAULT_N_FFT = 400
# CNN downsample factor in the encoder is 2 -> T_seq = (T_mel - 1) // 2 + 1.
_CNN_DOWNSAMPLE = 2
# audio_pool_step from MiniCPM-o config (avg-pool window after projection).
_DEFAULT_POOL_STEP = 5


@dataclass
class AudioEmbeddingResult:
    """Structured return value of the audio runtime.

    The dict-view (``as_dict``) carries the same fields plus a few
    legacy keys (``audio_name``, ``audio_path``) for backwards
    compatibility with callers built before Task 42. The ``debug``
    payload never contains the raw on-disk path.
    """

    audio_name: str
    audio_path: str  # resolved absolute path; NOT included in ``debug``
    embedding: Any  # numpy [1, T, D_h]
    attention_mask: Any  # numpy [1, T] int64
    debug: Dict[str, Any] = field(default_factory=dict)
    extras: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "audio_name": self.audio_name,
            "audio_path": self.audio_path,
            "audio_features": self.embedding,
            "attention_mask": self.attention_mask,
            "debug": dict(self.debug),
        }
        d.update(self.extras)
        return d


class MiniCPMO45AudioRuntime:
    """Validate + encode audio for the MiniCPM-o 4.5 native runtime."""

    _AUDIO_ENCODER_NAME = "audio_encoder_model"
    _AUDIO_ENCODER_NPU_NAME = "audio_encoder_model_npu"
    _AUDIO_PROJECTION_NAME = "audio_projection_model"

    def __init__(
        self,
        bundle: CompiledModelBundle,
        validator: Optional[AudioInputHandler] = None,
        encoder_fn: Optional[
            Callable[[Path, CompiledModelBundle], Dict[str, Any]]
        ] = None,
        *,
        audio_encoder_device: str = "auto",
    ) -> None:
        self.bundle = bundle
        self._validator = validator or AudioInputHandler()
        self._encoder_fn = encoder_fn or self._default_encoder_fn
        self._encoder_request: Any = None
        self._projection_request: Any = None
        # ``"auto"`` (default) uses whatever device the bundle's
        # ``audio_encoder_model`` resolved to. ``"NPU"`` opts into
        # the NPU twin registered by runtime_factory — frees ~0.6 GB
        # shared GPU memory and offloads compute from the iGPU /
        # CPU that the optimum LM is also using on 32 GB laptops.
        self._audio_encoder_device = str(audio_encoder_device).strip().upper()
        # Sticky flag: once an NPU compile attempt fails we stop
        # trying for this runtime's lifetime and route to the
        # regular handle. Some audio_encoder IRs use unbounded
        # dynamic shapes that the NPU plugin's compiler can't
        # handle (``ShapeOf`` upper-bounds error). We catch the
        # OVRuntimeError once, log clearly, and fall back so the
        # user keeps a working audio path.
        self._npu_compile_failed = False
        # Logged-once flag for the case where NPU was requested
        # but no NPU twin is registered (e.g. user didn't run
        # the reshape script yet).
        self._npu_unavailable_warned = False

    def _resolve_encoder_handle_name(self) -> str:
        """Return the bundle key to use for the audio encoder.

        When ``audio_encoder_device="NPU"`` and the NPU twin is
        registered AND a previous compile attempt has not failed,
        route there. Otherwise fall back to the regular handle.
        Logs once when NPU was requested but the twin isn't
        registered (typically because the static-shape IR wasn't
        produced — operator should run
        scripts/reshape_audio_encoder_for_npu.py).
        """
        if self._audio_encoder_device == "NPU":
            if self.bundle.has(self._AUDIO_ENCODER_NPU_NAME):
                if not self._npu_compile_failed:
                    return self._AUDIO_ENCODER_NPU_NAME
            elif not self._npu_unavailable_warned:
                self._npu_unavailable_warned = True
                logger.warning(
                    "audio_encoder_device='NPU' was requested but no "
                    "NPU twin is registered in the bundle. Run "
                    "scripts/reshape_audio_encoder_for_npu.py to "
                    "produce openvino_audio_encoder_model_npu.xml "
                    "with static shapes. Falling back to the default "
                    "%r handle for this runtime's lifetime.",
                    self._AUDIO_ENCODER_NAME,
                )
        return self._AUDIO_ENCODER_NAME

    def _get_encoder_with_npu_fallback(self) -> Any:
        """Fetch the encoder compiled handle.

        On the NPU path, catches a compile-time failure (typically
        ``OVRuntimeError`` from the lazy factory wrapping a
        compiler exception) and sticky-falls-back to the regular
        handle. Logs once at WARNING. All subsequent calls go
        straight to the fallback via ``_resolve_encoder_handle_name``
        because ``_npu_compile_failed`` is set.
        """
        encoder_handle_name = self._resolve_encoder_handle_name()
        try:
            return self.bundle.get(encoder_handle_name)
        except Exception as exc:  # noqa: BLE001 - NPU fallback
            if encoder_handle_name != self._AUDIO_ENCODER_NPU_NAME:
                # Compile error on the regular handle — not a
                # fallback case; re-raise.
                raise
            self._npu_compile_failed = True
            # The cached InferRequest (if any) was created against
            # the failed NPU handle — drop it so the next call
            # creates a fresh request against the fallback handle.
            self._encoder_request = None
            # Surface the FULL exception text. Earlier versions of
            # this code hardcoded "The IR uses dynamic shapes" but
            # that's only one of several possible NPU-rejection
            # causes. Letting the actual error through is the only
            # way to diagnose the next failure mode.
            logger.warning(
                "audio_encoder NPU compile failed and is being "
                "disabled for this runtime's lifetime. Falling back "
                "to %r.\n"
                "Underlying exception:\n%s\n"
                "Common causes: NPU driver version mismatch, "
                "unsupported opset/precision, or sequence length "
                "too large for the NPU tile budget. To re-enable "
                "NPU offload, address the error above and re-run.",
                self._AUDIO_ENCODER_NAME,
                exc,
            )
            return self.bundle.get(self._AUDIO_ENCODER_NAME)

    def _reset_request_state(self) -> None:
        """Best-effort ``reset_state()`` on every cached InferRequest.

        Called before each ``encode_audio``. Mirrors the pattern in
        ``OpenVINOLanguageModelStep.reset``. Missing-attribute
        degrades silently (test fakes / older OpenVINO builds may
        not expose ``reset_state``).
        """
        for label, req in (
            ("audio_encoder", self._encoder_request),
            ("audio_projection", self._projection_request),
        ):
            if req is None:
                continue
            reset_state = getattr(req, "reset_state", None)
            if not callable(reset_state):
                continue
            try:
                reset_state()
            except Exception as exc:  # noqa: BLE001 - best effort
                logger.debug(
                    "%s InferRequest.reset_state failed: %s", label, exc
                )

    def prewarm_encoder(self) -> Dict[str, Any]:
        """Force the audio encoder to compile + upload its weights.

        OpenVINO compiles the audio_encoder_model lazily on first
        ``bundle.get(name)``. On Intel integrated GPUs that compile +
        VRAM upload of the 586 MB Whisper-style IR can take 1-2
        minutes, which previously landed inside the first turn's
        ``asr_ms``. Calling this method at skill init (during the
        live-demo banner) shifts that cost out of the user-visible
        first-turn latency.

        Returns ``{"compile_ms": int, "skipped": bool,
        "reason": Optional[str]}`` for caller-side logging. Best
        effort — any exception is swallowed and surfaced via
        ``reason``.
        """
        import time as _time

        encoder_handle_name = self._resolve_encoder_handle_name()
        if not self.bundle.has(encoder_handle_name):
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": f"handle '{encoder_handle_name}' not in bundle",
            }
        t0 = _time.monotonic()
        try:
            self._get_encoder_with_npu_fallback()
        except Exception as exc:  # noqa: BLE001 - best effort
            return {
                "compile_ms": int((_time.monotonic() - t0) * 1000),
                "skipped": True,
                "reason": f"{type(exc).__name__}: {exc}",
            }
        return {
            "compile_ms": int((_time.monotonic() - t0) * 1000),
            "skipped": False,
            "reason": None,
        }

    def encode_audio(self, audio_path: PathLike) -> Dict[str, Any]:
        """Validate the audio path and run the encoder.

        Returns a dict that always carries ``audio_name`` (basename) and
        ``audio_path`` (resolved absolute path). The encoder may add any
        additional keys (``audio_features``, ``attention_mask``,
        ``debug``).
        """
        # Reset the encoder's stateful KV cache before each call. The
        # MiniCPM-o-4.5 audio_encoder IR carries 48 ReadValue + 48
        # Assign ops (Whisper-style cross-attention cache). Without
        # an explicit reset, the InferRequest persists state across
        # calls — the first audio gets a clean transcript, every
        # subsequent call attends over the previous utterance's
        # leaked KV and the model emits training-data identifiers
        # (``<|SOA:1682683823.000|>``) or memorised voice-acting
        # phrases instead of transcribing the actual audio.
        self._reset_request_state()
        validated = self._validator.validate_audio_file(audio_path)
        encoded = self._encoder_fn(validated, self.bundle)
        if not isinstance(encoded, dict):
            raise RuntimeError(
                "Audio encoder_fn must return a dict; got "
                f"{type(encoded).__name__}."
            )
        encoded.setdefault("audio_name", validated.name)
        encoded.setdefault("audio_path", str(validated))
        return encoded

    # ------------------------------------------------------------------
    # Default encoder (real OpenVINO path)
    # ------------------------------------------------------------------

    def _default_encoder_fn(
        self, audio_path: Path, bundle: CompiledModelBundle
    ) -> Dict[str, Any]:
        # Need to validate the handle exists BEFORE attempting the
        # NPU-fallback fetch (which calls bundle.get and would
        # raise KeyError on a missing handle, masquerading as a
        # compile failure). Use the resolved name (post-fallback
        # if we already failed once).
        encoder_handle_name = self._resolve_encoder_handle_name()
        if not bundle.has(encoder_handle_name):
            raise OVRuntimeError(
                "CompiledModelBundle is missing the "
                f"'{encoder_handle_name}' handle. Available: "
                f"{bundle.names()}."
            )
        np = self._numpy()
        waveform, sr = self._read_waveform(audio_path)
        if sr != _DEFAULT_SAMPLE_RATE:
            waveform = self._resample_to_16k(waveform, sr, np)
            sr = _DEFAULT_SAMPLE_RATE
        mel = self._mel_features(waveform, np)  # [1, 80, T_mel]
        t_mel = int(mel.shape[2])
        t_seq = (t_mel - 1) // _CNN_DOWNSAMPLE + 1

        # audio_encoder_model expects:
        #   input_features [B, 80, T_mel]
        #   attention_mask [B, 1, T_seq, T_seq] — 0.0 for valid frames,
        #     -inf for padded frames. With a single-segment input we
        #     have no padding so the whole mask is zeros.
        attention_mask = np.zeros(
            (1, 1, t_seq, t_seq), dtype=np.float32
        )
        beam_idx = np.zeros((1,), dtype=np.int32)

        encoder_compiled = self._get_encoder_with_npu_fallback()
        encoder_feed: Dict[str, Any] = {
            "input_features": mel,
            "attention_mask": attention_mask,
            "beam_idx": beam_idx,
        }
        encoder_out = self._infer_named(
            encoder_compiled,
            encoder_feed,
            request_attr="_encoder_request",
        )
        # encoder_out: [1, T_seq, 1024]

        projected = encoder_out
        used_projection = False
        if bundle.has(self._AUDIO_PROJECTION_NAME):
            projection_compiled = bundle.get(self._AUDIO_PROJECTION_NAME)
            projection_feed: Dict[str, Any] = {
                "audio_features": encoder_out,
            }
            projected = self._infer_named(
                projection_compiled,
                projection_feed,
                request_attr="_projection_request",
            )
            used_projection = True
        # projected: [1, T_seq, 4096]

        # Apply audio_avg_pooler (kernel=stride=pool_step=5) numpy-side.
        # Aligns with MiniCPMO.get_audio_embedding (lines 5081-5084 in
        # the upstream helper). Without it the LM would see an
        # over-long audio prefix.
        pooled = self._avg_pool_seq(
            projected, kernel=_DEFAULT_POOL_STEP, np=np
        )

        seq_len = self._seq_len(pooled)
        mask = np.ones((1, seq_len), dtype=np.int64)
        debug = {
            "shape": list(getattr(pooled, "shape", ())),
            "dtype": str(getattr(pooled, "dtype", "")),
            "active_device": bundle.active_device,
            "sample_rate": sr,
            "n_mels": _DEFAULT_N_MELS,
            "t_mel": t_mel,
            "t_seq_pre_pool": t_seq,
            "t_seq_post_pool": seq_len,
            "projected": used_projection,
            "pool_step": _DEFAULT_POOL_STEP,
        }
        return {
            "audio_features": pooled,
            "attention_mask": mask,
            "debug": debug,
        }

    # ------------------------------------------------------------------
    # Waveform read + preprocessing
    # ------------------------------------------------------------------

    def _read_waveform(self, audio_path: Path) -> Tuple[Any, int]:
        suffix = audio_path.suffix.lower()
        np = self._numpy()
        if suffix == ".wav":
            with wave.open(str(audio_path), "rb") as wf:
                n_channels = wf.getnchannels()
                sampwidth = wf.getsampwidth()
                framerate = wf.getframerate()
                nframes = wf.getnframes()
                raw = wf.readframes(nframes)
            if sampwidth == 2:
                arr = np.frombuffer(raw, dtype=np.int16).astype(
                    np.float32
                ) / 32768.0
            elif sampwidth == 4:
                arr = np.frombuffer(raw, dtype=np.int32).astype(
                    np.float32
                ) / 2147483648.0
            else:
                raise OVRuntimeError(
                    f"Unsupported WAV sample width: {sampwidth}"
                )
            if n_channels > 1:
                arr = arr.reshape(-1, n_channels).mean(axis=1)
            return arr, framerate

        # Non-WAV → lazy librosa.
        try:
            import librosa  # type: ignore
        except ImportError as exc:
            raise OVRuntimeDependencyError(
                "librosa is required to decode non-WAV audio. Install "
                "it with: pip install librosa"
            ) from exc
        wav, sr = librosa.load(
            str(audio_path), sr=_DEFAULT_SAMPLE_RATE, mono=True
        )
        return np.asarray(wav, dtype=np.float32), int(sr)

    def _resample_to_16k(self, waveform: Any, sr: int, np: Any) -> Any:
        if sr == _DEFAULT_SAMPLE_RATE:
            return waveform
        n_in = waveform.shape[0]
        n_out = int(round(n_in * _DEFAULT_SAMPLE_RATE / sr))
        if n_out <= 0:
            raise OVRuntimeError(
                f"Audio has zero length after resampling from {sr} to "
                f"{_DEFAULT_SAMPLE_RATE} Hz."
            )
        x_in = np.linspace(0.0, 1.0, n_in, dtype=np.float32)
        x_out = np.linspace(0.0, 1.0, n_out, dtype=np.float32)
        return np.interp(x_out, x_in, waveform).astype(np.float32)

    def _mel_features(self, waveform: Any, np: Any) -> Any:
        """Compute log-mel spectrogram features in shape ``[1, 80, T]``.

        MiniCPM-o's APM is a Whisper-derived encoder; inputs MUST go
        through Whisper's exact preprocessing or the encoder produces
        out-of-distribution embeddings and the LM degenerates to
        repeating a single token. Three steps:

        1. log10(clip(mel, 1e-10, ∞))
        2. dynamic-range clamp: max(log_spec, log_spec.max() - 8.0)
        3. scale to ~[-1, 1]: (log_spec + 4.0) / 4.0

        Steps 2 and 3 are the load-bearing ones. Without them values
        sit around [-10, 1] instead of [-1, 1] and the encoder output
        is noise.
        """
        try:
            import librosa  # type: ignore
        except ImportError as exc:
            raise OVRuntimeDependencyError(
                "librosa is required for audio mel-feature extraction. "
                "Install it with: pip install librosa"
            ) from exc
        mel = librosa.feature.melspectrogram(
            y=waveform,
            sr=_DEFAULT_SAMPLE_RATE,
            n_fft=_DEFAULT_N_FFT,
            hop_length=_DEFAULT_HOP_LENGTH,
            win_length=_DEFAULT_WIN_LENGTH,
            n_mels=_DEFAULT_N_MELS,
        )
        log_spec = np.log10(np.maximum(mel, 1e-10)).astype(np.float32)
        log_spec = np.maximum(log_spec, log_spec.max() - 8.0)
        log_spec = (log_spec + 4.0) / 4.0
        return log_spec[None, ...]  # [1, 80, T]

    @staticmethod
    def _avg_pool_seq(arr: Any, kernel: int, np: Any) -> Any:
        """Average-pool over the sequence dim with stride==kernel.

        ``arr`` is shape ``[B, T, D]``. Returns ``[B, T_out, D]`` where
        ``T_out = (T - kernel) // kernel + 1`` (matches torch
        ``nn.AvgPool1d(kernel_size=kernel, stride=kernel)``).
        Truncates the trailing tokens that don't fit a full window.
        """
        if kernel <= 1:
            return arr
        b, t, d = arr.shape
        t_out = (t - kernel) // kernel + 1
        if t_out <= 0:
            # Audio is too short for one full pool window — fall back
            # to a simple mean over the whole sequence so the model
            # still receives at least one audio token.
            return arr.mean(axis=1, keepdims=True)
        # Build [B, T_out, kernel, D] by reshaping the trimmed prefix.
        keep = t_out * kernel
        trimmed = arr[:, :keep, :]
        windows = trimmed.reshape(b, t_out, kernel, d)
        return windows.mean(axis=2)

    # ------------------------------------------------------------------
    # Inference helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _seq_len(arr: Any) -> int:
        shape = tuple(getattr(arr, "shape", ()))
        if len(shape) >= 2:
            return int(shape[1])
        if len(shape) == 1:
            return int(shape[0])
        return 0

    def _infer_named(
        self,
        compiled: Any,
        feed: Dict[str, Any],
        request_attr: str,
    ) -> Any:
        port_names = []
        inputs = getattr(compiled, "inputs", None)
        if inputs:
            port_names = [self._port_name(p) for p in inputs]

        if port_names and any(n is not None for n in port_names):
            actual_feed: Dict[Any, Any] = {}
            for k, v in feed.items():
                if k in port_names:
                    actual_feed[k] = v
                else:
                    chosen = next(
                        (
                            n
                            for n in port_names
                            if n is not None and (n == k or k in n or n in k)
                        ),
                        None,
                    )
                    if chosen is not None:
                        actual_feed[chosen] = v
                    else:
                        actual_feed[k] = v
        else:
            actual_feed = dict(enumerate(feed.values()))

        create = getattr(compiled, "create_infer_request", None)
        if callable(create):
            req = getattr(self, request_attr)
            if req is None:
                req = create()
                setattr(self, request_attr, req)
            infer = getattr(req, "infer", None)
            result = (
                infer(actual_feed)
                if callable(infer)
                else req(actual_feed)
            )
        elif callable(compiled):
            result = compiled(actual_feed)
        else:
            raise OVRuntimeError(
                f"Compiled handle is neither callable nor exposes "
                f"create_infer_request(); got {type(compiled).__name__}."
            )
        return self._unwrap_single_output(result)

    @staticmethod
    def _port_name(port: Any) -> Optional[str]:
        for attr in ("any_name", "name"):
            v = getattr(port, attr, None)
            if isinstance(v, str) and v:
                return v
        names = getattr(port, "names", None)
        if names:
            try:
                return next(iter(names))
            except Exception:  # noqa: BLE001
                return None
        return None

    @staticmethod
    def _unwrap_single_output(result: Any) -> Any:
        try:
            values = list(result.values())
            if values:
                return values[0]
        except (AttributeError, TypeError):
            pass
        outputs = getattr(result, "outputs", None)
        if outputs is not None and not isinstance(result, (list, tuple)):
            try:
                first = next(iter(outputs))
                return outputs[first]
            except (StopIteration, KeyError, TypeError):
                pass
        if isinstance(result, dict):
            try:
                return next(iter(result.values()))
            except StopIteration as exc:
                raise OVRuntimeError(
                    "Audio sub-model produced no outputs."
                ) from exc
        return result

    @staticmethod
    def _numpy() -> Any:
        try:
            import numpy as np  # type: ignore
        except ImportError as exc:
            raise OVRuntimeDependencyError(
                "numpy is required for the native audio encoder. "
                "Install it with: pip install "
                '"local-minicpm-runtime[openvino-runtime]"'
            ) from exc
        return np


__all__ = ["AudioEmbeddingResult", "MiniCPMO45AudioRuntime"]
