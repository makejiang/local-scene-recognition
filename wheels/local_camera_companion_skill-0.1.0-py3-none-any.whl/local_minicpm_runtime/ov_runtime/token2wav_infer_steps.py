# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Native OpenVINO infer-step wiring for the MiniCPM-o 4.5 Token2Wav
runtime.

Implements the five seams that ``MiniCPMO45Token2WavRuntime`` consumes:

  - ``prepare_text_tokens(text)``           — byte-fallback tokenizer
  - ``run_flow_embedding(tokens, bundle)``  — flow_embeddings_model
  - ``run_flow_encoder(embedded, bundle)``  — flow_encoder_chunk_model
  - ``run_flow_estimator(encoded, bundle)`` — flow_estimator_chunk_model
  - ``run_hift_vocoder(estimated, bundle)`` — hift_model + ISTFT

This module is import-safe without OpenVINO or numpy. Both are
imported lazily inside the methods only when a real inference is
requested. Tests inject deterministic fakes via the bundle / monkey-
patching ``_numpy``.

The byte-fallback tokenizer is intentionally NOT the real MiniCPM-o
audio tokenizer (s3tokenizer). It produces a deterministic int64
sequence so the four IR sub-models can be exercised end-to-end; the
audio quality on real IR will be poor until an external real
tokenizer is wired in via ``Token2WavInferConfig.tokenizer_fn``.
"""

from __future__ import annotations

import logging
import os
import sys
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional


from local_camera_companion_skill.env_vars import (
    ENV_DEBUG_TTS,
    get_env,
)


def _debug_tts() -> bool:
    return (get_env(ENV_DEBUG_TTS) or "").strip() in (
        "1", "true", "yes", "on",
    )

from .compiled_model_bundle import CompiledModelBundle
from .errors import OVRuntimeDependencyError, OVRuntimeError

logger = logging.getLogger(__name__)


_FLOW_EMBEDDING = "flow_embeddings_model"
_FLOW_ENCODER = "flow_encoder_chunk_model"
_FLOW_ESTIMATOR = "flow_estimator_chunk_model"
_HIFT = "hift_model"

# Upstream Notebook helper constants.
_SPK_EMBEDDING_DIM = 192
_HIFT_SOURCE_CACHE_LEN = 3840
_DEFAULT_T = 1.0  # single-step ODE; non-streaming smoke
_N_MELS = 80


@dataclass
class Token2WavInferConfig:
    """Per-call configuration for the Token2Wav infer steps."""

    tokenizer_fn: Optional[Callable[[str], Any]] = None
    flow_embedding_input_names: Optional[Dict[str, str]] = None
    flow_encoder_input_names: Optional[Dict[str, str]] = None
    flow_estimator_input_names: Optional[Dict[str, str]] = None
    hift_input_names: Optional[Dict[str, str]] = None
    # Optional speaker-embedding override. ``[1, 192]`` float32 numpy
    # array. When None, ``flow_embedding`` and ``flow_encoder`` fall
    # back to zeros (the byte-fallback default — produces noise, but
    # keeps the pipeline deterministic for tests). The native-TTS
    # path injects a real embedding loaded from a fixture or computed
    # via the speaker_encoder IR.
    speaker_embedding: Optional[Any] = None
    # Flow-matching ODE parameters. Defaults match upstream OVFlow.
    n_timesteps: int = 10
    inference_cfg_rate: float = 0.7
    # Flow-matching initial-noise seed. Session b09cc684 turns 4 + 6
    # showed Token2Wav drifting into Sichuan / Shanghai dialect on
    # different reply text even with the speaker embedding pinned.
    # The drift comes from speech-token autoregression diverging at
    # the LM step, but pinning the flow-matching noise z to a fixed
    # non-zero value at least keeps the vocoder timbre stable across
    # turns. 4242 is arbitrary but easy to spot in debug dumps.
    random_seed: int = 4242
    # Voice-prime: when True, prepend a constant short phrase to the
    # TTS input text so Token2Wav's speech-token autoregression
    # always warms up from the same conditioning prefix.
    #
    # DEFAULT OFF (opt-in). The prime was intended as a throwaway
    # warm-up, but its audio is rendered into the output WAV untrimmed
    # (nothing downstream slices it back off). On-device this produced
    # a distorted onset: the speech-token cold-start landed on the
    # prime and bled into the first real word, so users heard "the
    # first word is mispronounced" on every Chinese reply. Cross-turn
    # voice stability is now carried by the pinned speaker embedding +
    # the fixed flow-matching ``random_seed`` above, so the prime is no
    # longer needed for drift control. The machinery below is kept so
    # it can be re-enabled for experiments (set voice_prime=True).
    voice_prime: bool = False
    # The prime text itself. Default "好，" reads as a soft "hao"
    # filler that Mandarin speakers commonly use; chosen because:
    #   (a) it tokenises to 2 tokens with the MiniCPM tokenizer,
    #   (b) its phonemes pin the speaker's vowel-formant trajectory,
    #   (c) it does NOT carry semantic content the user mis-hears
    #       as part of the reply.
    voice_prime_text: str = "好，"
    debug: bool = False


class OpenVINOToken2WavInferSteps:
    """Small bag of callables that implement the 5 Token2Wav seams.

    The default ``MiniCPMO45Token2WavRuntime`` lazily instantiates one
    of these on the first ``synthesize`` call. Test code may inject
    each seam directly via the runtime constructor and bypass this
    class entirely.
    """

    def __init__(
        self,
        bundle: CompiledModelBundle,
        config: Optional[Token2WavInferConfig] = None,
    ) -> None:
        self.bundle = bundle
        self.config = config or Token2WavInferConfig()
        self._flow_embedding_request: Any = None
        self._flow_encoder_request: Any = None
        self._flow_estimator_request: Any = None
        self._hift_request: Any = None

    # ------------------------------------------------------------------
    # 1. Tokenizer
    # ------------------------------------------------------------------

    def prepare_text_tokens(self, text: str) -> Any:
        if self.config.tokenizer_fn is not None:
            tokens = self.config.tokenizer_fn(text)
            if tokens is None:
                raise OVRuntimeError(
                    "Token2Wav tokenizer_fn returned None."
                )
            return tokens
        np = self._numpy()
        encoded = list(text.encode("utf-8"))
        if not encoded:
            raise OVRuntimeError(
                "Token2Wav text produced zero tokens."
            )
        return np.asarray([encoded], dtype=np.int64)

    # ------------------------------------------------------------------
    # 2. flow_embeddings_model
    # ------------------------------------------------------------------

    def run_flow_embedding(
        self, tokens: Any, bundle: CompiledModelBundle
    ) -> Dict[str, Any]:
        np = self._numpy()
        compiled = self._require(bundle, _FLOW_EMBEDDING)
        token_arr = np.asarray(tokens)
        if token_arr.ndim == 1:
            token_arr = token_arr.reshape(1, -1)
        token_len = np.asarray([token_arr.shape[1]], dtype=np.int32)
        prompt_token = np.zeros((1, 0), dtype=np.int32)
        prompt_token_len = np.zeros((1,), dtype=np.int32)
        embedding = self._resolve_speaker_embedding(np)
        feed = {
            "token": token_arr.astype(np.int32),
            "token_len": token_len,
            "prompt_token": prompt_token,
            "prompt_token_len": prompt_token_len,
            "embedding": embedding,
        }
        result = self._infer_named(
            compiled, feed, "_flow_embedding_request"
        )
        h, spks = self._extract_two(result, ("h", "spks"))
        if _debug_tts():
            h_arr = np.asarray(h)
            spks_arr = np.asarray(spks)
            emb_arr = np.asarray(embedding)
            print(
                f"TTS_DEBUG flow_embedding: "
                f"input_tokens={tuple(token_arr.shape)} "
                f"embedding_norm={float(np.linalg.norm(emb_arr)):.4f} "
                f"h_shape={tuple(h_arr.shape)} h_mean={float(h_arr.mean()):.4f} "
                f"h_std={float(h_arr.std()):.4f} h_absmax={float(np.abs(h_arr).max()):.4f} "
                f"spks_shape={tuple(spks_arr.shape)} "
                f"spks_mean={float(spks_arr.mean()):.4f} "
                f"spks_std={float(spks_arr.std()):.4f}",
                file=sys.stderr, flush=True,
            )
        return {"h": h, "spks": spks}

    # ------------------------------------------------------------------
    # 3. flow_encoder_chunk_model
    # ------------------------------------------------------------------

    def run_flow_encoder(
        self, embedded: Any, bundle: CompiledModelBundle
    ) -> Dict[str, Any]:
        if not isinstance(embedded, dict) or "h" not in embedded:
            raise OVRuntimeError(
                "Token2Wav flow_encoder input must be a dict with "
                f"key 'h'; got {type(embedded).__name__}."
            )
        np = self._numpy()
        compiled = self._require(bundle, _FLOW_ENCODER)
        h_in = embedded["h"]
        h_arr = np.asarray(h_in)
        if h_arr.ndim < 2:
            raise OVRuntimeError(
                "Token2Wav flow_encoder 'h' must be at least 2D; got "
                f"shape {tuple(h_arr.shape)}."
            )
        chunk_len = int(h_arr.shape[1])
        token = np.zeros((1, chunk_len), dtype=np.int32)
        embedding = self._resolve_speaker_embedding(np)
        cnn_cache = np.zeros((1, 512, 6), dtype=np.float32)
        att_depth = self._att_cache_depth(compiled)
        att_cache = np.zeros(
            (att_depth, 1, 8, 0, 128), dtype=np.float32
        )
        feed = {
            "token": token,
            "embedding": embedding,
            "cnn_cache": cnn_cache,
            "att_cache": att_cache,
        }
        result = self._infer_named(
            compiled, feed, "_flow_encoder_request"
        )
        h, spks = self._extract_two(result, ("h", "spks"))
        return {"h": h, "spks": spks}

    # ------------------------------------------------------------------
    # 4. flow_estimator_chunk_model
    # ------------------------------------------------------------------

    def run_flow_estimator(
        self, embedded: Any, bundle: CompiledModelBundle
    ) -> Dict[str, Any]:
        """Run the flow-matching Euler ODE solver with classifier-free
        guidance.

        Per upstream ``OVFlow.inference`` + ``_solve_euler``, mel
        synthesis runs an N-step Euler integration over a cosine
        time schedule, calling the ``flow_estimator_chunk`` IR once
        per step. Inputs to each call are CFG-doubled along the
        batch dim: position 0 holds the conditioned (mu, spks, cond)
        triple; position 1 is zeros. The output velocity field is
        re-combined as::

            v = (1 + cfg) * v_cond - cfg * v_uncond

        and applied as a forward-Euler step ``x = x + dt * v``.

        Inputs come from ``run_flow_embedding`` as ``{"h", "spks"}``:
          h:    [1, mel_len, output_size]   encoder output
          spks: [1, output_size]            projected speaker embedding

        The mel result is the positive (conditioned) half: ``[1, 80, mel_len]``.
        """
        if not isinstance(embedded, dict) or "h" not in embedded:
            raise OVRuntimeError(
                "Token2Wav flow_estimator input must be a dict with "
                f"key 'h'; got {type(embedded).__name__}."
            )
        np = self._numpy()
        compiled = self._require(bundle, _FLOW_ESTIMATOR)

        h = np.asarray(embedded["h"], dtype=np.float32)
        spks = np.asarray(
            embedded.get("spks", np.zeros((1, _N_MELS), dtype=np.float32)),
            dtype=np.float32,
        )
        if h.ndim != 3 or h.shape[2] != _N_MELS:
            raise OVRuntimeError(
                "flow_embedding 'h' must be [1, mel_len, 80]; got "
                f"shape {tuple(h.shape)}."
            )
        mel_len = int(h.shape[1])

        # mu = h.transpose(1, 2): [1, 80, mel_len]
        mu_single = np.transpose(h, (0, 2, 1))
        # CFG batches: position 0 conditioned, position 1 unconditioned.
        mu_in = np.concatenate(
            [mu_single, np.zeros_like(mu_single)], axis=0
        )
        spks_in = np.concatenate(
            [spks, np.zeros_like(spks)], axis=0
        ).astype(np.float32)
        # Default mode: no prompt mel → cond is zeros (matches upstream
        # default-voice case where prompt_feat is empty).
        cond_zeros = np.zeros((1, _N_MELS, mel_len), dtype=np.float32)
        cond_in = np.concatenate(
            [cond_zeros, np.zeros_like(cond_zeros)], axis=0
        )

        # Initial noise z: [1, 80, mel_len] standard normal, seeded.
        rng = np.random.default_rng(self._random_seed())
        z = rng.standard_normal(
            size=(1, _N_MELS, mel_len), dtype=np.float32
        )

        # Cosine time schedule: t_span = 1 - cos(linspace(0, 1, N+1) * pi/2)
        n_timesteps = self._n_timesteps()
        cfg_rate = self._inference_cfg_rate()
        linspace = np.linspace(
            0.0, 1.0, n_timesteps + 1, dtype=np.float32
        )
        t_span = 1.0 - np.cos(linspace * 0.5 * np.pi)

        # Static cache shapes per upstream: cnn_cache [16, 2, 1024, 2],
        # att_cache [16, 2, 8, 0, 128] — the att-T=0 makes the chunk
        # estimator bit-identical to the legacy non-streaming estimator.
        cnn_depth = self._cnn_cache_depth(compiled)
        att_depth = self._att_cache_depth(compiled)
        cnn_cache = np.zeros(
            (cnn_depth, 2, 1024, 2), dtype=np.float32
        )
        att_cache = np.zeros(
            (att_depth, 2, 8, 0, 128), dtype=np.float32
        )

        x = z  # [1, 80, mel_len]
        if _debug_tts():
            print(
                f"TTS_DEBUG flow_estimator: mu_in[0] mean={float(mu_in[0].mean()):.4f} "
                f"std={float(mu_in[0].std()):.4f} absmax={float(np.abs(mu_in[0]).max()):.4f}; "
                f"spks_in[0] mean={float(spks_in[0].mean()):.4f} "
                f"std={float(spks_in[0].std()):.4f}; "
                f"z mean={float(z.mean()):.4f} std={float(z.std()):.4f}; "
                f"n_timesteps={n_timesteps} cfg_rate={cfg_rate} "
                f"t_span[0..2]={t_span[:3].tolist()} t_span[-1]={float(t_span[-1]):.4f}",
                file=sys.stderr, flush=True,
            )
        for step in range(n_timesteps):
            t_cur = float(t_span[step])
            t_next = float(t_span[step + 1])
            dt = t_next - t_cur
            # CFG-doubled x: identical along batch.
            x_in = np.concatenate([x, x], axis=0)
            t_in = np.asarray([t_cur, t_cur], dtype=np.float32)
            feed = {
                "x": x_in,
                "mu": mu_in,
                "t": t_in,
                "spks": spks_in,
                "cond": cond_in,
                "cnn_cache": cnn_cache,
                "att_cache": att_cache,
            }
            result = self._infer_named(
                compiled, feed, "_flow_estimator_request"
            )
            out = np.asarray(self._extract_one(result, "output"))
            # CFG combination: (1 + r) * v_cond - r * v_uncond.
            v_cond = out[0:1]
            v_uncond = out[1:2]
            v = (1.0 + cfg_rate) * v_cond - cfg_rate * v_uncond
            x = x + dt * v
            if _debug_tts() and step in (0, n_timesteps // 2, n_timesteps - 1):
                print(
                    f"TTS_DEBUG ode step={step} t={t_cur:.4f} dt={dt:.4f} "
                    f"v_cond_std={float(v_cond.std()):.4f} "
                    f"v_uncond_std={float(v_uncond.std()):.4f} "
                    f"x_after std={float(x.std()):.4f} absmax={float(np.abs(x).max()):.4f}",
                    file=sys.stderr, flush=True,
                )

        if _debug_tts():
            print(
                f"TTS_DEBUG flow_estimator final mel: shape={tuple(x.shape)} "
                f"mean={float(x.mean()):.4f} std={float(x.std()):.4f} "
                f"min={float(x.min()):.4f} max={float(x.max()):.4f}",
                file=sys.stderr, flush=True,
            )
        return {"mel": x.astype(np.float32)}

    # ------------------------------------------------------------------
    # ODE config readers (test-overridable)
    # ------------------------------------------------------------------

    def _n_timesteps(self) -> int:
        return int(getattr(self.config, "n_timesteps", 10))

    def _inference_cfg_rate(self) -> float:
        return float(getattr(self.config, "inference_cfg_rate", 0.7))

    def _random_seed(self) -> int:
        return int(getattr(self.config, "random_seed", 0))

    # ------------------------------------------------------------------
    # 5. hift_model + ISTFT
    # ------------------------------------------------------------------

    def run_hift_vocoder(
        self, estimated: Any, bundle: CompiledModelBundle
    ) -> bytes:
        if not isinstance(estimated, dict) or "mel" not in estimated:
            raise OVRuntimeError(
                "Token2Wav hift input must be a dict with key 'mel'; "
                f"got {type(estimated).__name__}."
            )
        np = self._numpy()
        compiled = self._require(bundle, _HIFT)
        mel = estimated["mel"]
        cache_source = np.zeros(
            (1, 1, _HIFT_SOURCE_CACHE_LEN), dtype=np.float32
        )
        feed = {"x": mel, "cache_source": cache_source}
        result = self._infer_named(
            compiled, feed, "_hift_request"
        )
        spectral = self._extract_one(result, "spectral")
        if _debug_tts():
            mel_arr = np.asarray(mel)
            spec_arr = np.asarray(spectral)
            print(
                f"TTS_DEBUG hift: mel_shape={tuple(mel_arr.shape)} "
                f"mel_std={float(mel_arr.std()):.4f} "
                f"mel_absmax={float(np.abs(mel_arr).max()):.4f}; "
                f"spectral_shape={tuple(spec_arr.shape)} "
                f"spectral_std={float(spec_arr.std()):.4f} "
                f"spectral_absmax={float(np.abs(spec_arr).max()):.4f}",
                file=sys.stderr, flush=True,
            )
        return self._spectral_to_pcm(spectral, np)

    @staticmethod
    def _spectral_to_pcm(spectral: Any, np: Any) -> bytes:
        """Convert HiFT spectral output [B, n_fft+2, time] to int16 PCM.

        The upstream HiFT (n_fft=16, hop=4) wraps a magnitude/phase
        encoding around the ISTFT — *not* a raw real/imag pair. Per
        the reference checkout's ``OVHiFT.inference``::

            magnitude = exp(x[:, :n_fft//2+1, :])
            phase     = sin(x[:, n_fft//2+1:, :])
            real      = magnitude * cos(phase)
            imag      = magnitude * sin(phase)
            speech    = istft(complex(real, imag), n_fft, hop, window=hann)
            speech    = clamp(speech, -audio_limit, audio_limit)

        with ``audio_limit=0.99``. We mirror that here using
        ``np.fft.irfft`` and a hand-rolled overlap-add pass with the
        Hann window so we don't pull in scipy/torch.
        """
        arr = np.asarray(spectral)
        if arr.ndim != 3:
            raise OVRuntimeError(
                "HiFT spectral output must be 3D [B, n_fft+2, T]; got "
                f"shape {tuple(arr.shape)}."
            )
        _, n_plus_two, time = arr.shape
        if n_plus_two < 2 or time < 1:
            raise OVRuntimeError(
                "HiFT spectral output has invalid shape: "
                f"{tuple(arr.shape)}."
            )
        n_fft = n_plus_two - 2
        if n_fft < 2:
            raise OVRuntimeError(
                f"HiFT n_fft must be >= 2; got {n_fft}."
            )
        # Default upstream hop_len is n_fft // 4. With n_fft=16 →
        # hop=4 → 480 samples per mel frame after the conv-post
        # upsampling chain. Matches reference checkout.
        hop = max(1, n_fft // 4)
        n_bins = n_fft // 2 + 1

        # Magnitude / phase encoding (NOT raw real/imag). Per upstream:
        #   magnitude = exp(x[:, :n_bins, :])   # n_bins rows
        #   magnitude = clip(magnitude, max=1e2)  # AFTER exp
        #   phase     = sin(x[:, n_bins:, :])   # remaining rows
        # The HiFT IR's output has shape [B, n_fft+2, T] split exactly
        # 50/50: n_bins magnitude + n_bins phase (n_fft+2 = 2*n_bins).
        log_mag = arr[0, :n_bins, :]
        phase_raw = arr[0, n_bins:, :]
        # Defensive: HiFT outputs 2*n_bins rows; pad if a different
        # build trims one. ``np.concatenate`` along axis=0 preserves
        # the time dim.
        if phase_raw.shape[0] < n_bins:
            pad = np.zeros(
                (n_bins - phase_raw.shape[0], phase_raw.shape[1]),
                dtype=phase_raw.dtype,
            )
            phase_raw = np.concatenate([phase_raw, pad], axis=0)
        elif phase_raw.shape[0] > n_bins:
            phase_raw = phase_raw[:n_bins]
        magnitude = np.exp(log_mag)
        magnitude = np.minimum(magnitude, 1e2)
        phase = np.sin(phase_raw)
        real = magnitude * np.cos(phase)
        imag = magnitude * np.sin(phase)
        complex_spec = real + 1j * imag

        # Per-frame inverse rFFT → time-domain frame of length n_fft.
        ifft = np.fft.irfft(complex_spec, n=n_fft, axis=0)

        # Overlap-add with the Hann ISTFT window (scaled by hop /
        # window-sum-of-squares to match torch.istft).
        n_frames = ifft.shape[1]
        out_len = n_fft + (n_frames - 1) * hop
        # numpy's hann window: same convention as scipy ('periodic').
        win = 0.5 - 0.5 * np.cos(
            2 * np.pi * np.arange(n_fft) / n_fft
        )
        win = win.astype(np.float32)
        signal = np.zeros((out_len,), dtype=np.float32)
        win_sumsq = np.zeros((out_len,), dtype=np.float32)
        for f in range(n_frames):
            start = f * hop
            signal[start : start + n_fft] += ifft[:, f].astype(
                np.float32
            ) * win
            win_sumsq[start : start + n_fft] += win * win
        # Normalise by window-overlap; protect against div-by-zero.
        nonzero = win_sumsq > 1e-8
        signal[nonzero] /= win_sumsq[nonzero]

        # Match upstream's clamp ±0.99 (audio_limit). Then map the
        # already-bounded float waveform to int16 without a per-clip
        # peak-normalise; that's what the reference does.
        signal = np.clip(signal, -0.99, 0.99)
        signal = (signal * 32767.0).astype(np.int16)
        return signal.tobytes()

    # ------------------------------------------------------------------
    # runtime_info
    # ------------------------------------------------------------------

    def runtime_info(self) -> Dict[str, Any]:
        bundle_info: Dict[str, Any] = {}
        if hasattr(self.bundle, "runtime_info"):
            try:
                bundle_info = self.bundle.runtime_info() or {}
            except Exception:  # noqa: BLE001
                bundle_info = {}
        return {
            "tokenizer_source": (
                "config" if self.config.tokenizer_fn else "byte_fallback"
            ),
            "compiled_models": bundle_info.get("compiled_models", []),
            "active_device": bundle_info.get("active_device"),
            "loaded": True,
            "debug": self.config.debug,
        }

    # ------------------------------------------------------------------
    # Helpers — bundle access, port discovery, infer, output extraction
    # ------------------------------------------------------------------

    @staticmethod
    def _require(bundle: CompiledModelBundle, name: str) -> Any:
        if not bundle.has(name):
            raise OVRuntimeError(
                f"CompiledModelBundle is missing the {name!r} handle. "
                f"Available: {bundle.names()}."
            )
        return bundle.get(name)

    def _resolve_speaker_embedding(self, np: Any) -> Any:
        """Return the speaker embedding tensor to feed flow_embeddings
        and flow_encoder.

        Priority:
          1. ``config.speaker_embedding`` if provided — shape-checked
             to ``[1, 192]`` float32; reshape ``[192]`` → ``[1, 192]``
             when needed for ergonomics.
          2. Else zeros of shape ``[1, 192]`` float32 (legacy default;
             produces noisy output but keeps the byte-fallback path
             deterministic for tests).
        """
        override = self.config.speaker_embedding
        if override is None:
            return np.zeros(
                (1, _SPK_EMBEDDING_DIM), dtype=np.float32
            )
        arr = np.asarray(override, dtype=np.float32)
        if arr.ndim == 1 and arr.shape[0] == _SPK_EMBEDDING_DIM:
            arr = arr.reshape(1, _SPK_EMBEDDING_DIM)
        if arr.shape != (1, _SPK_EMBEDDING_DIM):
            raise OVRuntimeError(
                "speaker_embedding override must have shape "
                f"({1}, {_SPK_EMBEDDING_DIM}); got {tuple(arr.shape)}."
            )
        return arr

    def _att_cache_depth(self, compiled: Any) -> int:
        port_names = self._port_names(compiled)
        for i, name in enumerate(port_names):
            if name and "att_cache" in name:
                shape = self._port_shape(compiled, i)
                if shape and len(shape) >= 1 and shape[0] > 0:
                    return int(shape[0])
        return 1

    def _cnn_cache_depth(self, compiled: Any) -> int:
        port_names = self._port_names(compiled)
        for i, name in enumerate(port_names):
            if name and "cnn_cache" in name:
                shape = self._port_shape(compiled, i)
                if shape and len(shape) >= 1 and shape[0] > 0:
                    return int(shape[0])
        return 1

    @staticmethod
    def _port_shape(compiled: Any, idx: int) -> Optional[List[int]]:
        inputs = getattr(compiled, "inputs", None)
        if not inputs:
            return None
        try:
            port = inputs[idx]
        except Exception:  # noqa: BLE001
            return None
        ps = getattr(port, "partial_shape", None) or getattr(
            port, "shape", None
        )
        if ps is None:
            return None
        try:
            dims: List[int] = []
            for d in ps:
                is_static = getattr(d, "is_static", None)
                if is_static is not None:
                    if is_static:
                        dims.append(int(d.get_length()))
                    else:
                        dims.append(-1)
                elif isinstance(d, int):
                    dims.append(d)
                else:
                    dims.append(-1)
            return dims
        except Exception:  # noqa: BLE001
            return None

    @staticmethod
    def _port_names(compiled: Any) -> List[Optional[str]]:
        out: List[Optional[str]] = []
        inputs = getattr(compiled, "inputs", None)
        if not inputs:
            return out
        for p in inputs:
            named: Optional[str] = None
            for attr in ("any_name", "name"):
                v = getattr(p, attr, None)
                if isinstance(v, str) and v:
                    named = v
                    break
            if named is None:
                names = getattr(p, "names", None)
                if names:
                    try:
                        named = next(iter(names))
                    except Exception:  # noqa: BLE001
                        named = None
            out.append(named)
        return out

    def _infer_named(
        self,
        compiled: Any,
        feed: Dict[str, Any],
        request_attr: str,
    ) -> Any:
        port_names = self._port_names(compiled)
        if port_names and any(n for n in port_names):
            actual: Dict[Any, Any] = {}
            for k, v in feed.items():
                if k in port_names:
                    actual[k] = v
                else:
                    chosen = next(
                        (
                            n
                            for n in port_names
                            if n and (n == k or k in n or n in k)
                        ),
                        None,
                    )
                    actual[chosen if chosen else k] = v
        else:
            actual = dict(enumerate(feed.values()))
        create = getattr(compiled, "create_infer_request", None)
        if callable(create):
            req = getattr(self, request_attr)
            if req is None:
                req = create()
                setattr(self, request_attr, req)
            infer = getattr(req, "infer", None)
            return (
                infer(actual) if callable(infer) else req(actual)
            )
        if callable(compiled):
            return compiled(actual)
        raise OVRuntimeError(
            f"Compiled handle is neither callable nor exposes "
            f"create_infer_request(); got {type(compiled).__name__}."
        )

    @staticmethod
    def _extract_one(result: Any, name: str) -> Any:
        if isinstance(result, dict):
            if name in result:
                return result[name]
            try:
                return next(iter(result.values()))
            except StopIteration as exc:
                raise OVRuntimeError(
                    "Token2Wav sub-model produced no outputs."
                ) from exc
        try:
            values = list(result.values())
            if values:
                return values[0]
        except (AttributeError, TypeError):
            pass
        return result

    @staticmethod
    def _extract_two(result: Any, names: tuple) -> tuple:
        a = OpenVINOToken2WavInferSteps._extract_one(result, names[0])
        b: Any = None
        if isinstance(result, dict) and names[1] in result:
            b = result[names[1]]
        else:
            try:
                values = list(result.values())
                if len(values) >= 2:
                    b = values[1]
            except (AttributeError, TypeError):
                pass
        if b is None:
            raise OVRuntimeError(
                f"Token2Wav sub-model output missing {names[1]!r}."
            )
        return a, b

    @staticmethod
    def _numpy() -> Any:
        try:
            import numpy as np  # type: ignore
        except ImportError as exc:
            raise OVRuntimeDependencyError(
                "numpy is required for the Token2Wav infer steps. "
                'Install with: pip install '
                '"local-minicpm-runtime[openvino-runtime]"'
            ) from exc
        return np


__all__ = [
    "OpenVINOToken2WavInferSteps",
    "Token2WavInferConfig",
]
