# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Autoregressive text generation loop.

Pure stdlib. The actual decoder step is abstracted behind a ``step_fn``
callable so unit tests can inject a fake without touching OpenVINO.

Default behaviour is repetition-aware greedy decoding: argmax with a
short look-back history that breaks single-token cycles. Tests can opt
into deterministic argmax via ``GenerationConfig(repetition_penalty=1.0,
repetition_penalty_window=0)``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, List, Optional, Set


logger = logging.getLogger(__name__)


@dataclass
class GenerationConfig:
    """Decoding config."""

    max_new_tokens: int = 512
    eos_token_ids: Set[int] = field(default_factory=set)
    # Cycle-break heuristic: when the same single token appears more
    # than ``cycle_break_threshold`` times in the trailing window, the
    # loop stops and returns what's been generated so far. Without
    # this, a confused LM (e.g. modality input it can't make sense of)
    # latches onto one token (`|`, `\n`, etc.) and runs to
    # max_new_tokens producing 500+ copies. 0 disables.
    cycle_break_window: int = 32
    cycle_break_threshold: int = 16
    # N-gram cycle-break: when the most recently emitted N tokens
    # match an N-gram that has already appeared earlier in the
    # generated stream, the loop stops. Catches sentence-level loops
    # like "'What?' I said. 'What?' I said. 'What?' I said." that
    # the single-token check at line above never sees. 0 disables.
    # Recommended values: 6-8 for English OCR (covers ~5-7 words).
    no_repeat_ngram_size: int = 0


@dataclass
class GenerationResult:
    """Result of a generation run."""

    token_ids: List[int]
    # "eos" | "max_new_tokens" | "cycle_break" | "ngram_cycle_break"
    stop_reason: str


class TextGenerationLoop:
    """Greedy decode loop with cycle-break early-exit.

    ``step_fn(prefix_token_ids, prev_logits)`` must return the next
    token id (an ``int``). Real implementations call the compiled
    language model handle and return ``argmax(logits)``. Tests inject
    a deterministic generator.
    """

    def __init__(
        self,
        step_fn: Callable[[List[int], Optional[Any]], int],
        config: Optional[GenerationConfig] = None,
        *,
        token_callback: Optional[Callable[[int], None]] = None,
    ) -> None:
        self.step_fn = step_fn
        self.config = config or GenerationConfig()
        # Token-level streaming hook (Camera Companion). When set,
        # the loop calls ``token_callback(next_id)`` after each
        # ``prefix.append(next_id)`` so callers can drive
        # incremental decoding (e.g. partial JSON parsing). Exceptions
        # raised by the callback are logged and swallowed so an
        # opportunistic streaming consumer cannot kill generation.
        self.token_callback = token_callback

    def run(self, input_ids: List[int]) -> GenerationResult:
        if self.config.max_new_tokens <= 0:
            raise ValueError(
                "GenerationConfig.max_new_tokens must be > 0; "
                f"got {self.config.max_new_tokens}."
            )
        generated: List[int] = []
        prefix = list(input_ids)
        stop_reason = "max_new_tokens"
        window = max(0, int(self.config.cycle_break_window))
        threshold = max(0, int(self.config.cycle_break_threshold))
        cycle_break_armed = window > 0 and threshold > 0
        ngram_size = max(0, int(self.config.no_repeat_ngram_size))
        ngram_armed = ngram_size > 0
        # Set of N-grams already seen in ``generated``. We only use
        # ``generated`` (not ``prefix``) so a long input prompt that
        # legitimately contains a phrase doesn't suppress that phrase
        # in the answer.
        seen_ngrams: Set[tuple] = set()
        for _ in range(self.config.max_new_tokens):
            try:
                next_id = int(self.step_fn(prefix, None))
            except Exception:  # noqa: BLE001
                logger.exception("Generation step failed")
                raise
            if next_id in self.config.eos_token_ids:
                stop_reason = "eos"
                break
            generated.append(next_id)
            prefix.append(next_id)
            # Notify the streaming consumer (if any) AFTER appending
            # so the callback sees a stable, in-order token stream.
            # Exceptions are swallowed: streaming is best-effort and
            # must never break batch generation.
            if self.token_callback is not None:
                try:
                    self.token_callback(next_id)
                except Exception:  # noqa: BLE001 - opportunistic
                    logger.exception(
                        "token_callback raised; continuing generation"
                    )
            if (
                cycle_break_armed
                and len(generated) >= window
                and generated[-window:].count(next_id) >= threshold
            ):
                # Single token repeated ``threshold`` times within
                # the trailing ``window`` — the LM is in a degenerate
                # loop. Stop emitting; downstream ``parse_model_output``
                # will at least show "(no reply)" or whatever was
                # generated before the loop, instead of 500 copies of
                # ``|`` reaching the user.
                logger.warning(
                    "Cycle-break: token %d repeated %d/%d times in "
                    "trailing window; stopping generation early.",
                    next_id, threshold, window,
                )
                stop_reason = "cycle_break"
                break
            if ngram_armed and len(generated) >= ngram_size:
                tail = tuple(generated[-ngram_size:])
                if tail in seen_ngrams:
                    # The trailing ``ngram_size`` tokens already
                    # appeared earlier in the output — the LM is
                    # repeating a phrase. Stop. (E.g. sentence-level
                    # cycles that the single-token check above never
                    # detects.)
                    logger.warning(
                        "N-gram cycle-break: trailing %d-gram %r "
                        "already seen earlier; stopping generation.",
                        ngram_size, tail,
                    )
                    stop_reason = "ngram_cycle_break"
                    break
                seen_ngrams.add(tail)
        return GenerationResult(
            token_ids=generated, stop_reason=stop_reason
        )


__all__ = ["GenerationConfig", "GenerationResult", "TextGenerationLoop"]
