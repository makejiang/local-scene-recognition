# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Tokenizer adapter for the MiniCPM-o 4.5 text generation runtime.

Lazy-imports ``transformers.AutoTokenizer`` only when
``TokenizerAdapter.from_model_dir(...)`` is called. The module itself
is import-safe without ``transformers``.

Tests inject a fake tokenizer via the constructor (``tokenizer=fake``)
so the lazy ``transformers`` import is never triggered in default CI.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Union

from .errors import OVRuntimeDependencyError
from .message_builder import flatten_text_messages

PathLike = Union[str, Path]
logger = logging.getLogger(__name__)


class TokenizerAdapter:
    """Wraps a HF tokenizer and a small set of generation conveniences."""

    def __init__(
        self,
        model_dir: Optional[PathLike] = None,
        tokenizer: Any = None,
        eos_token_ids: Optional[Set[int]] = None,
    ) -> None:
        self.model_dir = Path(model_dir) if model_dir else None
        self._tokenizer = tokenizer
        self._eos_token_ids: Set[int] = (
            set(eos_token_ids) if eos_token_ids else set()
        )

    @property
    def tokenizer(self) -> Any:
        """Expose the underlying HF tokenizer (or test fake) for code
        paths that need to call ``convert_tokens_to_ids`` directly,
        such as the multimodal anchor-token resolution. Returns
        ``None`` when no tokenizer is wired (legal for callers that
        bypass tokenization entirely)."""
        return self._tokenizer

    @classmethod
    def from_model_dir(cls, model_dir: PathLike) -> "TokenizerAdapter":
        """Load a HF AutoTokenizer from ``model_dir`` (lazy import).

        Raises:
            OVRuntimeDependencyError: when ``transformers`` is not
                installed.
        """
        try:
            from transformers import AutoTokenizer  # type: ignore
        except ImportError as exc:
            raise OVRuntimeDependencyError(
                "transformers is required for tokenization. Install it "
                'with:  pip install '
                '"local-minicpm-runtime[openvino-runtime]"'
            ) from exc

        tokenizer = AutoTokenizer.from_pretrained(
            str(model_dir), trust_remote_code=True
        )
        eos_ids: Set[int] = set()
        if getattr(tokenizer, "eos_token_id", None) is not None:
            eos_ids.add(int(tokenizer.eos_token_id))
        # MiniCPM-o uses additional turn-end tokens; collect them when present.
        for name in ("<|im_end|>", "<|endoftext|>"):
            try:
                tid = tokenizer.convert_tokens_to_ids(name)
            except Exception:  # noqa: BLE001
                tid = None
            if isinstance(tid, int) and tid >= 0:
                eos_ids.add(tid)
        return cls(
            model_dir=model_dir, tokenizer=tokenizer, eos_token_ids=eos_ids
        )

    def encode_chat_prompt(
        self, messages: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Apply the tokenizer's chat template (or fall back to encode).

        Returns ``{"input_ids": List[int]}``. Tests pass a fake
        tokenizer that exposes either ``apply_chat_template`` or
        ``encode``.

        Text-only messages whose ``content`` is a single text block
        list (the canonical multimodal shape this repo emits) are
        flattened to ``content: str`` before the call — many HF chat
        templates (including MiniCPM-o's) call ``.startswith`` on
        ``content`` and break on a list-of-blocks structure.
        """
        if self._tokenizer is None:
            raise RuntimeError(
                "TokenizerAdapter has no tokenizer. Use "
                "TokenizerAdapter.from_model_dir(...) or pass "
                "tokenizer=... to the constructor."
            )
        apply = getattr(self._tokenizer, "apply_chat_template", None)
        if callable(apply):
            normalized = self._normalize_text_only_messages(messages)
            encoded = apply(
                normalized, add_generation_prompt=True, tokenize=True
            )
            # HF tokenizers return a BatchEncoding (dict-like with keys
            # "input_ids" / "attention_mask"); extract the ids list.
            # Hermetic fake tokenizers return a plain list — handle both.
            if hasattr(encoded, "get") and not isinstance(encoded, list):
                token_ids = encoded.get("input_ids", encoded)
            else:
                token_ids = encoded
            return {"input_ids": list(token_ids)}
        # Fallback: flatten messages → encode plain text.
        text = flatten_text_messages(messages)
        encode = getattr(self._tokenizer, "encode", None)
        if not callable(encode):
            raise RuntimeError(
                "Tokenizer must provide either apply_chat_template or "
                "encode(text)."
            )
        return {"input_ids": list(encode(text))}

    @staticmethod
    def _normalize_text_only_messages(
        messages: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Replace ``content: [text-block...]`` with ``content: str``
        for messages where every block is text. Multimodal messages
        (audio/image) pass through unchanged.
        """
        out: List[Dict[str, Any]] = []
        for msg in messages:
            content = msg.get("content")
            if isinstance(content, list) and content and all(
                isinstance(b, dict) and b.get("type") == "text"
                for b in content
            ):
                joined = "\n".join(str(b.get("text", "")) for b in content)
                new_msg = dict(msg)
                new_msg["content"] = joined
                out.append(new_msg)
            else:
                out.append(msg)
        return out

    def decode_tokens(self, token_ids: List[int]) -> str:
        if self._tokenizer is None:
            raise RuntimeError("TokenizerAdapter has no tokenizer.")
        decode = getattr(self._tokenizer, "decode", None)
        if not callable(decode):
            raise RuntimeError(
                "Tokenizer must provide decode(token_ids)."
            )
        return str(decode(token_ids, skip_special_tokens=True))

    def eos_token_ids(self) -> Set[int]:
        return set(self._eos_token_ids)


__all__ = ["TokenizerAdapter"]
