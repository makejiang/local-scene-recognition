# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""MiniCPM-o 4.5 native text generation runtime.

Combines a ``CompiledModelBundle`` (loader output from
``runtime_factory.create_minicpm_o45_runtime``) with a
``TokenizerAdapter`` and a ``TextGenerationLoop`` into a runtime that
exposes ``generate_text(prompt, max_new_tokens) -> str``.

The actual decoder step (``step_fn``) is the only OpenVINO inference
seam. The default implementation lazily delegates to
``OpenVINOLanguageModelStep`` (Task 41), which calls the compiled
``language_model`` handle from the bundle and returns
``argmax(logits)``. Tests inject a deterministic ``step_fn`` via the
constructor to exercise the full generation path without OpenVINO.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional, Sequence

from .anchor_tokens import (
    AnchorTokenIds,
    ModalityKind,
    build_anchor_marker,
    resolve_anchor_token_ids,
)
from .compiled_model_bundle import CompiledModelBundle
from .errors import OVRuntimeNotImplementedError
from .language_model_step import OpenVINOLanguageModelStep
from .generation_loop import (
    GenerationConfig,
    GenerationResult,
    TextGenerationLoop,
)
from .message_builder import build_text_messages, flatten_text_messages
from .tokenizer_adapter import TokenizerAdapter


logger = logging.getLogger(__name__)


class MiniCPMO45TextRuntime:
    """Native text generation runtime for MiniCPM-o 4.5.

    Public API:
      - ``generate_text(prompt, max_new_tokens) -> str``
      - ``chat(messages, max_new_tokens) -> str`` (back-compat seam used
        by the adapter for non-text modalities; raises
        ``OVRuntimeNotImplementedError`` when any non-text content
        block is present, delegates to ``generate_text`` otherwise).
      - ``runtime_info() -> dict`` (delegated to the bundle).
    """

    def __init__(
        self,
        bundle: CompiledModelBundle,
        tokenizer: TokenizerAdapter,
        step_fn: Optional[
            Callable[[List[int], Optional[Any]], int]
        ] = None,
    ) -> None:
        self.bundle = bundle
        self.tokenizer = tokenizer
        # ``step_fn`` is the OpenVINO inference seam. Tests inject a
        # deterministic generator. The default delegates to
        # ``OpenVINOLanguageModelStep`` which calls the compiled
        # language-model handle from the bundle.
        self._step_fn = step_fn or self._default_step_fn
        self._native_step: Optional[OpenVINOLanguageModelStep] = None
        # Per-call sub-timings updated by ``generate_text_with_embeddings``
        # so outer wrappers (multimodal_runtime, the live demo) can read
        # them without changing the public return shape.
        self.last_step_timings: Dict[str, int] = {
            "prefill_ms": 0,
            "decode_ms": 0,
            "step_count": 0,
        }
        # Lazily-resolved anchor token ids. We need a real tokenizer
        # to look these up; tests injecting a fake tokenizer that
        # doesn't expose convert_tokens_to_ids will defer to the
        # caller-provided step_fn (which won't reach the lookup).
        self._anchor_token_ids: Optional[AnchorTokenIds] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate_text(
        self,
        prompt: str,
        max_new_tokens: int = 512,
        *,
        token_callback: Optional[Callable[[str], None]] = None,
    ) -> str:
        if prompt is None or not str(prompt).strip():
            raise ValueError("generate_text: prompt must be non-empty.")
        if not isinstance(max_new_tokens, int) or max_new_tokens <= 0:
            raise ValueError(
                "generate_text: max_new_tokens must be a positive int; "
                f"got {max_new_tokens!r}."
            )
        messages = build_text_messages(prompt)
        encoded = self.tokenizer.encode_chat_prompt(messages)
        input_ids: List[int] = list(encoded["input_ids"])
        config = GenerationConfig(
            max_new_tokens=max_new_tokens,
            eos_token_ids=self.tokenizer.eos_token_ids(),
        )
        # Clear any KV-cache state held by the native step from a prior
        # generation so back-to-back calls don't attend over stale KV.
        self._reset_native_step()
        per_token_id_cb = self._build_token_id_callback(token_callback)
        loop = TextGenerationLoop(
            step_fn=self._step_fn,
            config=config,
            token_callback=per_token_id_cb,
        )
        result: GenerationResult = loop.run(input_ids)
        return self.tokenizer.decode_tokens(result.token_ids)

    def generate_text_with_embeddings(
        self,
        prompt: str,
        modality_embeddings: Sequence[Any],
        modality_attention_masks: Sequence[Any],
        max_new_tokens: int = 512,
        audio_offload: bool = False,
        modality_kinds: Optional[Sequence[ModalityKind]] = None,
        no_repeat_ngram_size: int = 0,
        return_stop_reason: bool = False,
        *,
        token_callback: Optional[Callable[[str], None]] = None,
    ) -> Any:
        """Generate text conditioned on one or more modality embeddings.

        Caller passes per-modality encoder outputs as
        ``modality_embeddings`` (each ``[1, N, H]``), their attention
        masks, and a parallel ``modality_kinds`` list of ``"vision"`` /
        ``"audio"``. We splice anchor tokens into the prompt before
        tokenization (e.g. ``<|vision_start|><|image_pad|>×N<|vision_end|>``)
        so the chat template lays out a sequence the LM was actually
        trained for. The LM-step then *replaces* the embedding values at
        the anchor-pad token positions with the encoder outputs (Qwen2.5-VL
        convention) instead of prefix-concatenating an unanchored block —
        the latter produced token-soup output and was the root cause of
        the read_textbook_aloud OCR failure.

        ``audio_offload=True`` routes the LM step's inference to a
        CPU-pinned twin of the language model. Used by the audio
        modality path on integrated GPUs that can't fit the audio
        prefill scratch (~600 tokens × 4096 hidden) into the OpenCL
        4 GB single-allocation cap.
        """
        if prompt is None or not str(prompt).strip():
            raise ValueError(
                "generate_text_with_embeddings: prompt must be non-empty."
            )
        if not isinstance(max_new_tokens, int) or max_new_tokens <= 0:
            raise ValueError(
                "generate_text_with_embeddings: max_new_tokens must be "
                f"a positive int; got {max_new_tokens!r}."
            )

        embeds = list(modality_embeddings or [])
        masks = list(modality_attention_masks or [])
        kinds: List[ModalityKind] = list(modality_kinds or [])
        anchor_ids: Optional[AnchorTokenIds] = None
        decorated_prompt = prompt

        if embeds:
            if not kinds:
                raise ValueError(
                    "generate_text_with_embeddings: modality_kinds is "
                    "required when modality_embeddings is non-empty. "
                    "Pass one of 'vision' / 'audio' per embedding so "
                    "the prompt can be anchored correctly."
                )
            if len(kinds) != len(embeds):
                raise ValueError(
                    "modality_kinds length "
                    f"({len(kinds)}) must match modality_embeddings "
                    f"length ({len(embeds)})."
                )
            anchor_ids = self._get_anchor_token_ids()
            # Stitch one marker per modality at the front of the prompt,
            # in the same order as ``embeds``. Each marker is a literal
            # string the chat template will tokenize into one
            # contiguous run of pad tokens between start/end anchors.
            markers = [
                build_anchor_marker(kinds[i], self._modality_seq_len(embeds[i]))
                for i in range(len(embeds))
            ]
            decorated_prompt = "".join(markers) + prompt

        messages = build_text_messages(decorated_prompt)
        encoded = self.tokenizer.encode_chat_prompt(messages)
        input_ids: List[int] = list(encoded["input_ids"])
        config = GenerationConfig(
            max_new_tokens=max_new_tokens,
            eos_token_ids=self.tokenizer.eos_token_ids(),
            no_repeat_ngram_size=int(no_repeat_ngram_size),
        )

        step_fn = self._step_fn

        def wrapped_step(prefix: List[int], prev_logits: Optional[Any]) -> int:
            return step_fn(
                prefix,
                prev_logits,
                modality_embeddings=embeds,
                modality_attention_masks=masks,
                modality_kinds=kinds,
                anchor_token_ids=anchor_ids,
                audio_offload=audio_offload,
            )

        self._reset_native_step()
        per_token_id_cb = self._build_token_id_callback(token_callback)

        # Time the first call (prefill) separately from subsequent
        # calls (decode loop) so the live demo can attribute audio-
        # path latency. Stored on the runtime as ``last_step_timings``
        # so an outer wrapper (multimodal_runtime.generate_from_audio)
        # can read them without changing the public return type.
        import time as _time

        timings = {"prefill_ms": 0, "decode_ms": 0, "step_count": 0}
        original_step = wrapped_step

        def _timed_step(prefix: List[int], prev_logits: Optional[Any]) -> int:
            t0 = _time.monotonic()
            result = original_step(prefix, prev_logits)
            elapsed_ms = int((_time.monotonic() - t0) * 1000)
            if timings["step_count"] == 0:
                timings["prefill_ms"] = elapsed_ms
            else:
                timings["decode_ms"] += elapsed_ms
            timings["step_count"] += 1
            return result

        self.last_step_timings = timings
        loop = TextGenerationLoop(
            step_fn=_timed_step,
            config=config,
            token_callback=per_token_id_cb,
        )
        result: GenerationResult = loop.run(input_ids)
        decoded = self.tokenizer.decode_tokens(result.token_ids)
        if return_stop_reason:
            return decoded, result.stop_reason
        return decoded

    @staticmethod
    def _modality_seq_len(arr: Any) -> int:
        """Read the seq dim of a ``[1, N, H]`` (or ``[N, H]``) tensor."""
        shape = tuple(getattr(arr, "shape", ()))
        if len(shape) >= 3:
            return int(shape[1])
        if len(shape) == 2:
            return int(shape[0])
        raise ValueError(
            f"modality embedding has unexpected shape {shape!r}; "
            "expected [1, N, H] or [N, H]."
        )

    def _get_anchor_token_ids(self) -> AnchorTokenIds:
        """Resolve anchor token ids once per runtime instance."""
        if self._anchor_token_ids is None:
            tok = self.tokenizer.tokenizer
            if tok is None:
                raise RuntimeError(
                    "TextRuntime has no underlying tokenizer; cannot "
                    "resolve anchor token ids for modality injection."
                )
            self._anchor_token_ids = resolve_anchor_token_ids(tok)
        return self._anchor_token_ids

    def chat(
        self,
        messages: List[Dict[str, Any]],
        max_new_tokens: int = 512,
    ) -> str:
        """Adapter contract used by non-text modality paths.

        For text-only message lists this delegates to ``generate_text``.
        Any non-text content block (audio / image) raises
        ``OVRuntimeNotImplementedError`` — vision / audio / TTS
        runtimes will land in follow-up tasks.
        """
        if not messages:
            raise ValueError("chat: messages must be non-empty.")
        for msg in messages:
            content = msg.get("content")
            if isinstance(content, list):
                for block in content:
                    if (
                        isinstance(block, dict)
                        and block.get("type")
                        and block["type"] != "text"
                    ):
                        raise OVRuntimeNotImplementedError(
                            "Non-text modalities (audio / image / "
                            "vision_audio / textbook OCR) are reserved "
                            "for follow-up tasks. The text-only "
                            "generation runtime is implemented; "
                            "multimodal generation is not. See "
                            "docs/native_text_generation_runtime.md."
                        )
        text = flatten_text_messages(messages)
        return self.generate_text(text, max_new_tokens=max_new_tokens)

    def runtime_info(self) -> Dict[str, Any]:
        return self.bundle.runtime_info()

    # ------------------------------------------------------------------
    # Token-streaming helper (Camera Companion — incremental decode)
    # ------------------------------------------------------------------

    def _build_token_id_callback(
        self,
        text_callback: Optional[Callable[[str], None]],
    ) -> Optional[Callable[[int], None]]:
        """Wrap a caller-provided text-delta callback with a tokenizer
        adapter that decodes incrementally and emits the *new* text
        added by each token.

        The wrapped callback receives a single token ID per call (the
        shape ``TextGenerationLoop`` needs). It maintains a running
        list of generated token IDs, decodes the cumulative list on
        each step, and emits the substring that wasn't present in
        the previous decode. This handles tokenizers that produce
        multi-token characters (CJK, multi-byte UTF-8) without
        emitting partial bytes to the consumer.

        Returns ``None`` when no text callback is provided so the
        loop bypasses the hook entirely (zero overhead).
        """
        if text_callback is None:
            return None
        running_tokens: List[int] = []
        last_decoded: Dict[str, str] = {"text": ""}

        def _on_token(token_id: int) -> None:
            running_tokens.append(int(token_id))
            try:
                decoded = self.tokenizer.decode_tokens(running_tokens)
            except Exception:  # noqa: BLE001 - opportunistic
                logger.exception(
                    "tokenizer.decode_tokens failed during streaming "
                    "callback; skipping this token's emission"
                )
                return
            prev = last_decoded["text"]
            if decoded == prev:
                return
            # The new token's contribution is the suffix beyond the
            # previous decode. Some tokenizers emit a leading space
            # on the very first token; we keep it so the consumer
            # sees the same text as the eventual full decode.
            delta = decoded[len(prev):] if decoded.startswith(prev) else decoded
            last_decoded["text"] = decoded
            if delta:
                try:
                    text_callback(delta)
                except Exception:  # noqa: BLE001 - opportunistic
                    logger.exception(
                        "token_callback raised; continuing generation"
                    )

        return _on_token

    # ------------------------------------------------------------------
    # Default step_fn (Task 41 — native OpenVINO language-model step)
    # ------------------------------------------------------------------

    def _default_step_fn(
        self,
        prefix: List[int],
        prev_logits: Optional[Any],
        **kwargs: Any,
    ) -> int:
        if self._native_step is None:
            self._native_step = OpenVINOLanguageModelStep(self.bundle)
        return self._native_step(prefix, prev_logits, **kwargs)

    def prewarm_lm_cpu_twin(self) -> Dict[str, Any]:
        """Force the LM CPU twin to compile + upload weights.

        Used by the live demo during the startup banner so the first
        ``audio_offload=True`` inference doesn't pay the 30-60 s
        OpenVINO cold-compile cost. Idempotent + best-effort.
        Delegates to ``OpenVINOLanguageModelStep.prewarm_cpu_twin``
        when the native step exposes it (older fakes won't).
        """
        if self._native_step is None:
            self._native_step = OpenVINOLanguageModelStep(self.bundle)
        prewarm = getattr(self._native_step, "prewarm_cpu_twin", None)
        if not callable(prewarm):
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": "prewarm_cpu_twin_unavailable",
            }
        try:
            info = prewarm()
        except Exception as exc:  # noqa: BLE001 - best effort
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": f"{type(exc).__name__}: {exc}",
            }
        if not isinstance(info, dict):
            return {"compile_ms": 0, "skipped": True, "reason": "bad_return"}
        return info

    def _reset_native_step(self) -> None:
        """Best-effort KV-cache reset before a fresh generation call.

        Idempotent: silently no-ops when the native step hasn't been
        instantiated yet, when ``self._step_fn`` was injected (custom
        step function) and exposes no ``reset``, or when the OpenVINO
        InferRequest doesn't expose ``reset_state``. The point is to
        prevent a second ``generate_text`` from attending over the
        prior turn's KV cache; we do not want this helper to raise on
        non-stateful test seams.
        """
        if self._native_step is not None:
            self._native_step.reset()
            return
        # Custom step function: forward ``reset()`` if it has one.
        reset = getattr(self._step_fn, "reset", None)
        if callable(reset):
            try:
                reset()
            except Exception:  # noqa: BLE001 - best effort
                pass


__all__ = ["MiniCPMO45TextRuntime"]
