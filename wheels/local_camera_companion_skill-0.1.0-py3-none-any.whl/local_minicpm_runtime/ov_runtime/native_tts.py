# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Native MiniCPM-o-4.5 audio-token producer.

Composes the LM step (with hidden_states) + the TTS sub-models (
``tts_embedding``, ``tts_projector_semantic``, ``tts_language_model``,
``tts_code_head_model``, ``tts_code_embedding_model``) into a callable
``(text) -> [1, T] int64`` of audio token IDs.

The output shape matches the byte-fallback tokenizer's contract so
this can be used as a drop-in ``tokenizer_fn`` for
``MiniCPMO45Token2WavRuntime``. The four flow + hift stages
downstream consume the token sequence unchanged.

v0.1 is non-streaming: the LM is run once on the full text (a
single prefill), the TTS step is run once on the assembled
condition, and all generated audio tokens are returned in one
batch. Streaming (yield WAV chunks as they're produced) is a
follow-up; we ship a working non-streaming version first per the
PR-A/B plan.

This module is import-safe without OpenVINO or numpy: both are
imported lazily inside ``__call__`` only when a real inference is
requested. Tests inject a fake LM step / fake TTS step via the
``lm_step`` and ``tts_step`` constructor arguments.
"""

from __future__ import annotations

import logging
import os
import sys
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional


from local_camera_companion_skill.env_vars import (
    ENV_DEBUG_TTS,
    get_env,
)


def _debug_tts() -> bool:
    return (get_env(ENV_DEBUG_TTS) or "").strip() in (
        "1", "true", "yes", "on",
    )

from .compiled_model_bundle import CompiledModelBundle
from .errors import OVRuntimeDependencyError, OVRuntimeError
from .language_model_step import OpenVINOLanguageModelStep
from .tts_generation_step import (
    OpenVINOTTSGenerationStep,
    TTSGenerationStepConfig,
)

logger = logging.getLogger(__name__)


# Special token IDs from the MiniCPM-o-4.5 tokenizer. These are
# stable across the model release; if upstream renumbers them in a
# future revision we'll surface a config override here. Reference:
# the Skill defines these locally rather than re-importing the
# upstream Notebook helper (.scratch_converter/) which is reference-
# only and not installed at runtime.
DEFAULT_AUDIO_BOS_TOKEN_ID = 151687
DEFAULT_TEXT_EOS_TOKEN_ID = 151692


_TTS_EMBEDDING = "tts_embedding_model"
_TTS_PROJECTOR_SEMANTIC = "tts_projector_semantic_model"


@dataclass
class NativeTTSAudioTokenizerConfig:
    """Per-call configuration for the native TTS audio-token producer."""

    audio_bos_token_id: int = DEFAULT_AUDIO_BOS_TOKEN_ID
    text_eos_token_id: int = DEFAULT_TEXT_EOS_TOKEN_ID
    # Main-tokenizer marker ids that bracket the spoken text inside the
    # wrapped TTS prefill (…<|tts_bos|> spoken-text <|tts_eos|>). When
    # both are set AND present in the token stream, ``__call__`` slices
    # the LM hidden states + spoken-text ids to the ``[bos+1 : eos]``
    # region (upstream ``tts_bound``) so the conditioning is derived
    # from in-context hidden states at the correct RoPE positions. Left
    # None (e.g. byte-fallback tokenizer or unit tests that feed bare
    # ids) the whole token stream is used, preserving legacy behaviour.
    # These are DISTINCT from ``audio_bos_token_id`` /
    # ``text_eos_token_id`` above, which index the TTS sub-model's
    # ``tts_embedding`` and are unrelated to the main vocab.
    tts_bos_token_id: Optional[int] = None
    tts_eos_token_id: Optional[int] = None
    # When True, F.normalize the hidden_states along the last dim
    # before projection (matches upstream
    # ``tts.config.normalize_projected_hidden=True``).
    normalize_projected_hidden: bool = True
    # Cap for the inner TTS LM loop. Default 500 matches upstream.
    max_audio_tokens: int = 500


def required_handle_names() -> List[str]:
    """Return the ordered list of bundle handles this tokenizer needs.

    Used by callers (and tests) to gate construction: if the bundle
    is missing any of these, fall back to the byte-fallback tokenizer
    and skip the native path.
    """
    return [
        # Main LM + embedding for prefill.
        "language_model",
        "embedding_model",
        # TTS-specific conditioning.
        _TTS_EMBEDDING,
        _TTS_PROJECTOR_SEMANTIC,
        # The TTS audio-token decoder.
        "tts_language_model",
        "tts_code_head_model",
        "tts_code_embedding_model",
    ]


def is_native_tts_supported(bundle: CompiledModelBundle) -> bool:
    """Return True iff the bundle exposes every native-TTS handle."""
    return all(bundle.has(n) for n in required_handle_names())


class MiniCPMO45NativeTTSAudioTokenizer:
    """Drop-in ``tokenizer_fn`` for ``MiniCPMO45Token2WavRuntime``.

    Returns a numpy ``[1, T]`` int64 of audio token IDs that the
    existing flow-embedding → encoder → estimator → hift chain
    already knows how to consume. The four downstream stages are
    untouched; only the tokenization step swaps from byte-fallback
    to the real native TTS LM.
    """

    def __init__(
        self,
        bundle: CompiledModelBundle,
        text_to_token_ids: Callable[[str], List[int]],
        config: Optional[NativeTTSAudioTokenizerConfig] = None,
        *,
        lm_step: Optional[OpenVINOLanguageModelStep] = None,
        tts_step: Optional[OpenVINOTTSGenerationStep] = None,
    ) -> None:
        self.bundle = bundle
        self.text_to_token_ids = text_to_token_ids
        self.config = config or NativeTTSAudioTokenizerConfig()
        self._lm_step = lm_step
        self._tts_step = tts_step
        # Lazily resolved on the first call.
        self._tts_embedding_compiled: Any = None
        self._tts_embedding_request: Any = None
        self._projector_semantic_compiled: Any = None
        self._projector_semantic_request: Any = None
        self._initialized: bool = False

    # ------------------------------------------------------------------
    # Public callable surface
    # ------------------------------------------------------------------

    def __call__(self, text: str) -> Any:
        """Run the native TTS path and return ``[1, T]`` int64 audio tokens.

        Pipeline:
          1. Tokenize the text → text token IDs.
          2. Run the main LM on the full sequence (one prefill call)
             to get hidden_states for those token IDs. We do NOT use
             the LM's predicted next_id — the text is already final;
             we only need its hidden representations.
          3. Run ``tts_embedding`` on the text token IDs and
             ``tts_projector_semantic`` on (optionally normalized)
             hidden_states. Add them element-wise to form
             ``tts_embeds``.
          4. Append ``text_eos_embed`` and ``audio_bos_embed`` (both
             from ``tts_embedding`` of the relevant special token
             IDs) to form the final condition.
          5. Run ``OpenVINOTTSGenerationStep.generate(condition)``
             to produce the audio token sequence.
          6. Reset the LM and TTS step KV state so the next call
             starts fresh.
        """
        if text is None or not str(text).strip():
            raise ValueError(
                "MiniCPMO45NativeTTSAudioTokenizer: text must be non-empty."
            )
        np = self._numpy()
        self._ensure_initialized()

        token_ids = list(self.text_to_token_ids(str(text)))
        if not token_ids:
            raise OVRuntimeError(
                "Native TTS tokenizer produced zero text token IDs."
            )

        # The tokenizer_fn returns the full wrapped prefill sequence
        #   <|im_start|>system … <|im_start|>assistant … <|tts_bos|>
        #     spoken-text … <|tts_eos|>
        # so the LM sees the spoken text in its real chat context (RoPE
        # positions + conditioning that the TTS sub-model was trained
        # on). ``spoken`` is the ``[bos+1 : eos]`` slice — the spoken
        # region whose hidden states + ids feed the condition assembly
        # (upstream ``tts_bound``, modeling_minicpmo.py:1216-1232,
        # 1286-1314). When the wrap ids are unset / absent the whole
        # sequence is used (byte-fallback tokenizer, unit tests).
        spoken_start, spoken_stop = self._spoken_region(token_ids)

        # --- Step 1: LM prefill on the full sequence to get hidden_states. ---
        lm_step = self._require_lm_step()
        try:
            _next_id, hidden_states = lm_step.__call_with_hidden__(
                token_ids
            )
        finally:
            # Always reset — TTS callers don't want LM state from this
            # prefill bleeding into a subsequent text-generation call.
            lm_step.reset()

        # --- Step 2: condition assembly (sliced to the spoken region). ---
        # Per upstream pseudocode:
        #   hidden_embeds = tts.projector_semantic(last_hidden[bos+1:eos])
        #   if normalize_projected_hidden:
        #       hidden_embeds = F.normalize(hidden_embeds, p=2, dim=-1)
        #   tts_embeds = tts.emb_text(ids[bos+1:eos]) + hidden_embeds
        # Both the hidden states and the ids fed to tts_embedding are
        # the spoken-text slice; the surrounding template tokens are
        # context for the LM only and never vocoded. Critical: F.normalize
        # is applied to the projector OUTPUT, not the input — normalising
        # the LM hidden_states before projection is a different operation
        # (different range at the projector input) and produces
        # out-of-distribution garbage downstream.
        spoken_ids = token_ids[spoken_start:spoken_stop]
        text_ids_arr = np.asarray([spoken_ids], dtype=np.int64)
        text_emb = self._run_tts_embedding(text_ids_arr, np)
        hidden_spoken = np.asarray(hidden_states)[:, spoken_start:spoken_stop, :]
        sem_emb = self._run_projector_semantic(hidden_spoken, np)
        if self.config.normalize_projected_hidden:
            sem_emb = self._l2_normalize_last_dim(sem_emb, np)
        tts_text_cond = self._add(text_emb, sem_emb, np)

        text_eos_emb = self._embed_special(
            self.config.text_eos_token_id, np
        )
        audio_bos_emb = self._embed_special(
            self.config.audio_bos_token_id, np
        )
        condition = self._concat_seq(
            [tts_text_cond, text_eos_emb, audio_bos_emb], np
        )

        # --- Step 3: TTS audio-token generation. ---
        tts_step = self._require_tts_step()
        try:
            audio_token_ids = tts_step.generate(condition)
        finally:
            tts_step.reset()

        if not audio_token_ids:
            raise OVRuntimeError(
                "Native TTS produced zero audio tokens. The model "
                "emitted EOS on the first step — likely a condition "
                "assembly regression or a stateful KV bug."
            )

        if _debug_tts():
            cond_arr = np.asarray(condition)
            ids_arr = np.asarray(audio_token_ids)
            print(
                f"TTS_DEBUG native_tts: text_len={len(token_ids)} "
                f"text_ids[:8]={token_ids[:8]} "
                f"condition_shape={tuple(cond_arr.shape)} "
                f"condition_std={float(cond_arr.std()):.4f} "
                f"condition_absmax={float(np.abs(cond_arr).max()):.4f}; "
                f"audio_tokens len={len(audio_token_ids)} "
                f"min={int(ids_arr.min())} max={int(ids_arr.max())} "
                f"unique={int(len(set(audio_token_ids)))} "
                f"first16={list(audio_token_ids)[:16]}",
                file=sys.stderr, flush=True,
            )

        return np.asarray(
            [list(audio_token_ids)], dtype=np.int64
        )

    def _spoken_region(self, token_ids: List[int]) -> tuple:
        """Return the ``[bos+1, eos]`` slice bounds of the spoken text.

        The wrapped prefill is
          ``… <|tts_bos|> spoken-text <|tts_eos|>``
        and only the spoken-text region between the two markers is
        vocoded (upstream ``tts_bound``, modeling_minicpmo.py:1216-1232).
        We locate the LAST occurrence of ``tts_bos_token_id`` and the
        first ``tts_eos_token_id`` after it, then return
        ``(bos_idx + 1, eos_idx)``.

        Falls back to ``(0, len(token_ids))`` — i.e. treat the whole
        sequence as spoken — whenever the wrap ids are unconfigured
        (``None``) or absent from ``token_ids`` (byte-fallback tokenizer,
        hermetic unit tests). This keeps the callable working without a
        chat template, matching the pre-conditioning behaviour.
        """
        bos_id = self.config.tts_bos_token_id
        eos_id = self.config.tts_eos_token_id
        if bos_id is None or eos_id is None:
            return (0, len(token_ids))
        try:
            bos_idx = len(token_ids) - 1 - token_ids[::-1].index(int(bos_id))
        except ValueError:
            return (0, len(token_ids))
        try:
            eos_rel = token_ids[bos_idx + 1:].index(int(eos_id))
        except ValueError:
            return (0, len(token_ids))
        eos_idx = bos_idx + 1 + eos_rel
        if eos_idx <= bos_idx + 1:
            # Empty spoken region — nothing between the markers. Fall
            # back rather than emit a zero-length condition.
            return (0, len(token_ids))
        return (bos_idx + 1, eos_idx)

    # ------------------------------------------------------------------
    # Initialisation
    # ------------------------------------------------------------------

    def _ensure_initialized(self) -> None:
        if self._initialized:
            return
        for name in required_handle_names():
            if not self.bundle.has(name):
                raise OVRuntimeError(
                    "MiniCPMO45NativeTTSAudioTokenizer: bundle is "
                    f"missing required handle {name!r}. "
                    f"Available: {self.bundle.names()}."
                )
        self._tts_embedding_compiled = self.bundle.get(_TTS_EMBEDDING)
        self._projector_semantic_compiled = self.bundle.get(
            _TTS_PROJECTOR_SEMANTIC
        )
        self._initialized = True

    def _require_lm_step(self) -> OpenVINOLanguageModelStep:
        if self._lm_step is None:
            self._lm_step = OpenVINOLanguageModelStep(self.bundle)
        return self._lm_step

    def _require_tts_step(self) -> OpenVINOTTSGenerationStep:
        if self._tts_step is None:
            # Sampling overrides vs the upstream defaults (rep 1.05 /
            # window 16 / top_k 25): a stronger repetition penalty
            # (1.30) applied over a wider window (32) plus a tighter
            # top-k (20) reduce the frequency of cycle-locked / over-
            # long output on short numeric Chinese phrases. Tuned
            # empirically on the real model (scripts/sweep_tts_config.py);
            # lower rep values (1.15/1.20) still stretched arithmetic
            # phrases to 2-3× their natural length or ran to the
            # max_steps cap. The post-synthesis detector + retry in
            # MiniCPMO45Token2WavRuntime catches the rare cases that
            # still slip through.
            self._tts_step = OpenVINOTTSGenerationStep(
                self.bundle,
                TTSGenerationStepConfig(
                    max_steps=self.config.max_audio_tokens,
                    repetition_penalty=1.30,
                    repetition_penalty_window=32,
                    top_k=20,
                ),
            )
        return self._tts_step

    # ------------------------------------------------------------------
    # IR helpers (tts_embedding + projector_semantic)
    # ------------------------------------------------------------------

    def _run_tts_embedding(self, ids: Any, np: Any) -> Any:
        feed = {self._first_input_name(self._tts_embedding_compiled): ids}
        return self._infer_named_output(
            self._tts_embedding_compiled,
            feed,
            "_tts_embedding_request",
            "tts_embedding",
        )

    def _run_projector_semantic(self, hidden_states: Any, np: Any) -> Any:
        feed = {
            self._first_input_name(
                self._projector_semantic_compiled
            ): hidden_states
        }
        return self._infer_named_output(
            self._projector_semantic_compiled,
            feed,
            "_projector_semantic_request",
            "tts_projector_semantic",
        )

    def _embed_special(self, token_id: int, np: Any) -> Any:
        ids = np.asarray([[int(token_id)]], dtype=np.int64)
        return self._run_tts_embedding(ids, np)

    def _infer_named_output(
        self,
        compiled: Any,
        feed: Dict[Any, Any],
        request_attr: str,
        label: str,
    ) -> Any:
        create = getattr(compiled, "create_infer_request", None)
        if callable(create):
            req = getattr(self, request_attr)
            if req is None:
                req = create()
                setattr(self, request_attr, req)
            infer = getattr(req, "infer", None)
            result = infer(feed) if callable(infer) else req(feed)
        elif callable(compiled):
            result = compiled(feed)
        else:
            raise OVRuntimeError(
                f"{label} compiled handle is neither callable nor "
                "exposes create_infer_request()."
            )
        # Extract the single tensor — the IRs in question each have
        # exactly one output. Same OVDict caveats as elsewhere: prefer
        # values() iteration since name keys may resolve to ConstOutput
        # ports under some OV builds.
        if isinstance(result, dict):
            if not result:
                raise OVRuntimeError(f"{label} produced no outputs.")
            return next(iter(result.values()))
        values = getattr(result, "values", None)
        if callable(values):
            try:
                first = next(iter(values()))
                if first is not None:
                    return first
            except (StopIteration, TypeError):
                pass
        outputs = getattr(result, "outputs", None)
        if outputs is not None:
            try:
                first = next(iter(outputs))
                return outputs[first]
            except (StopIteration, KeyError, TypeError):
                pass
        return result

    # ------------------------------------------------------------------
    # Tensor ops (np-backed; adapter so fake-numpy tests work)
    # ------------------------------------------------------------------

    @staticmethod
    def _l2_normalize_last_dim(arr: Any, np: Any) -> Any:
        """Compute ``arr / ||arr||_2`` along the last dim.

        Matches ``torch.nn.functional.normalize(x, p=2, dim=-1)`` for
        the upstream condition-assembly. Falls back to a hand-rolled
        loop if numpy isn't available (test fakes).
        """
        normalize = getattr(np, "linalg", None)
        if normalize is not None and hasattr(normalize, "norm"):
            norms = np.linalg.norm(arr, axis=-1, keepdims=True)
            # Avoid divide-by-zero on all-zero rows.
            return arr / np.maximum(norms, 1e-12)
        # Fake-numpy path: identity, since the fake doesn't support
        # broadcasting math. Tests bypass normalisation; production
        # always has real numpy.
        return arr

    @staticmethod
    def _add(a: Any, b: Any, np: Any) -> Any:
        if hasattr(np, "add"):
            return np.add(a, b)
        # Fake-numpy fallback — tests handle this via injection.
        return a

    @staticmethod
    def _concat_seq(parts: List[Any], np: Any) -> Any:
        """Concatenate along the sequence dim (axis=1)."""
        if hasattr(np, "concatenate"):
            return np.concatenate(parts, axis=1)
        # Fake-numpy fallback: use the first part. Tests inject a
        # fake concatenate or accept this degenerate path.
        return parts[0]

    @staticmethod
    def _first_input_name(compiled: Any) -> Optional[str]:
        inputs = getattr(compiled, "inputs", None)
        if not inputs:
            return None
        for p in inputs:
            for attr in ("any_name", "name"):
                v = getattr(p, attr, None)
                if isinstance(v, str) and v:
                    return v
            names = getattr(p, "names", None)
            if names:
                try:
                    return next(iter(names))
                except Exception:  # noqa: BLE001
                    return None
        return None

    @staticmethod
    def _numpy() -> Any:
        try:
            import numpy as np  # type: ignore
        except ImportError as exc:
            raise OVRuntimeDependencyError(
                "numpy is required for the native TTS audio-token "
                "producer."
            ) from exc
        return np


__all__ = [
    "DEFAULT_AUDIO_BOS_TOKEN_ID",
    "DEFAULT_TEXT_EOS_TOKEN_ID",
    "MiniCPMO45NativeTTSAudioTokenizer",
    "NativeTTSAudioTokenizerConfig",
    "is_native_tts_supported",
    "required_handle_names",
]
