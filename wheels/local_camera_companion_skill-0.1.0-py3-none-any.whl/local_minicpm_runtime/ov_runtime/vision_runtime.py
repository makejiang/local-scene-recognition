# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""MiniCPM-o 4.5 vision encoding runtime.

Validates an image path via the existing ``CameraInputHandler`` and
encodes it into a structured ``VisionEmbeddingResult`` (also accessible
as a dict via ``.as_dict()``). The encoder calls the compiled
``vision_model`` and (when present) ``resampler_model`` sub-models
through the ``CompiledModelBundle``.

This module is import-safe without OpenVINO or numpy. ``numpy`` is
imported lazily inside ``_default_encoder_fn`` only when a real
encoding is requested. PIL is a hard dep of the package.

Tests inject a deterministic ``encoder_fn`` to exercise the multimodal
flow without any real OpenVINO call; ``encode_image`` keeps that seam
and continues to merge the encoder's return dict with ``image_name`` /
``image_path`` defaults.

Real-IR contract (MiniCPM-o 4.5 converted via the upstream Notebook):
- vision_model: pixel_values [B, 3, H, W], patch_attention_mask
  [B, 1, num_patches], position_ids [B, num_patches]
  -> hidden_states [B, num_patches, vision_dim=1152]
- resampler_model: x [1, num_patches, 1152], pos_embed [num_patches, 1, 4096]
  -> [1, 64, 4096] (64 query tokens that get fed to the LM as a
     fixed-length image-embedding prefix).
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from ..camera_input import CameraInputHandler
from .compiled_model_bundle import CompiledModelBundle
from .errors import OVRuntimeDependencyError, OVRuntimeError

PathLike = Union[str, Path]
logger = logging.getLogger(__name__)


# Default preprocessing constants for MiniCPM-o 4.5 SiglipVisionTransformer.
# Match preprocessor_config.json shipped with the converted IR.
_DEFAULT_IMAGE_SIZE = 448  # legacy single-tile resize target (kept for slicing_enabled=False path)
_DEFAULT_PATCH_SIZE = 14
_DEFAULT_NUM_PATCHES_PER_SIDE = (
    _DEFAULT_IMAGE_SIZE // _DEFAULT_PATCH_SIZE
)  # 32
_DEFAULT_NUM_PATCHES = _DEFAULT_NUM_PATCHES_PER_SIDE ** 2  # 1024
_DEFAULT_LM_HIDDEN = 4096
_DEFAULT_RESAMPLER_MAX_SIZE = (70, 70)  # matches the upstream resampler's pre-computed pos_embed grid
# Slice_image protocol — see preprocessor_config.json:
#   max_slice_nums: 9, scale_resolution: 448, slice_mode: true
_DEFAULT_MAX_SLICE_NUMS = 9
_DEFAULT_SLICE_RESOLUTION = 448

# Image normalisation for SigLIP / MiniCPM-o.
_DEFAULT_MEAN = (0.5, 0.5, 0.5)
_DEFAULT_STD = (0.5, 0.5, 0.5)


# ---------------------------------------------------------------------------
# slice_image protocol (port of MiniCPMVImageProcessor from the upstream
# transformers source: models/source/MiniCPM-o-4_5/processing_minicpmo.py).
# Pure PIL+math; no torch dependency despite the upstream code using
# torch.nn.functional.unfold (we operate on numpy arrays after the resize
# and don't need that path).
# ---------------------------------------------------------------------------


def _ensure_divide(length: int, patch_size: int) -> int:
    """Round ``length`` to the nearest multiple of ``patch_size``,
    floor at one patch."""
    return max(round(length / patch_size) * patch_size, patch_size)


def _find_best_resize(
    original_size: Tuple[int, int],
    scale_resolution: int,
    patch_size: int,
    *,
    allow_upscale: bool = False,
) -> Tuple[int, int]:
    """Resize an image so its area is roughly ``scale_resolution²``
    while preserving aspect ratio. Result dimensions are forced to be
    multiples of ``patch_size`` so the SigLIP patch embedding sees
    exactly nph × nph_w patches.
    """
    width, height = original_size
    if (width * height > scale_resolution * scale_resolution) or allow_upscale:
        r = width / height
        height = int(scale_resolution / math.sqrt(r))
        width = int(height * r)
    best_width = _ensure_divide(width, patch_size)
    best_height = _ensure_divide(height, patch_size)
    return best_width, best_height


def _get_sliced_grid(
    image_size: Tuple[int, int],
    max_slice_nums: int,
    scale_resolution: int,
    *,
    never_split: bool = False,
    min_slice_multiple: int = 1,
) -> Optional[List[int]]:
    """Choose a [cols, rows] grid that splits ``image_size`` into
    sub-tiles. Returns None when the input fits comfortably in one
    tile at ``scale_resolution`` (no slicing needed).

    ``min_slice_multiple`` raises the bar from upstream's "slice if
    area > scale_resolution²" to "slice only if area > N × scale_
    resolution²". Borderline cases (a 640×480 webcam frame is ~1.5×
    the target tile area) put the model into "describe the page"
    mode because it sees K≈2 nearly-identical tiles instead of one
    coherent image; raising the threshold to 3 keeps slicing on
    genuine high-res input (~1024×768 and up) while passing webcam
    frames through as a single tile.
    """
    original_width, original_height = image_size
    if original_height == 0 or original_width == 0:
        return None
    log_ratio = math.log(original_width / original_height)
    ratio = (
        original_width
        * original_height
        / (scale_resolution * scale_resolution)
    )
    multiple = min(math.ceil(ratio), max_slice_nums)
    if multiple < max(2, int(min_slice_multiple)) or never_split:
        return None
    candidate_split_grids_nums: List[int] = []
    for i in [multiple - 1, multiple, multiple + 1]:
        if i == 1 or i > max_slice_nums:
            continue
        candidate_split_grids_nums.append(i)

    candidate_grids: List[List[int]] = []
    for split_grids_nums in candidate_split_grids_nums:
        m = 1
        while m <= split_grids_nums:
            if split_grids_nums % m == 0:
                candidate_grids.append([m, split_grids_nums // m])
            m += 1

    best_grid = [1, 1]
    min_error = float("inf")
    for grid in candidate_grids:
        error = abs(log_ratio - math.log(grid[0] / grid[1]))
        if error < min_error:
            best_grid = grid
            min_error = error
    return best_grid


def _get_refine_size(
    original_size: Tuple[int, int],
    grid: List[int],
    scale_resolution: int,
    patch_size: int,
    *,
    allow_upscale: bool = False,
) -> Tuple[int, int]:
    """Compute the size to which the image must be resized before
    being split into ``grid`` tiles. Each tile then matches
    ``scale_resolution × scale_resolution`` after a per-tile
    ``find_best_resize``."""
    width, height = original_size
    grid_x, grid_y = grid
    refine_width = _ensure_divide(width, grid_x)
    refine_height = _ensure_divide(height, grid_y)
    grid_width = refine_width / grid_x
    grid_height = refine_height / grid_y
    best_grid_size = _find_best_resize(
        (grid_width, grid_height),
        scale_resolution,
        patch_size,
        allow_upscale=allow_upscale,
    )
    return best_grid_size[0] * grid_x, best_grid_size[1] * grid_y


def _split_to_patches(image: Any, grid: List[int]) -> List[List[Any]]:
    """Split ``image`` into a 2D list of ``grid[1]`` rows × ``grid[0]``
    columns of equal-sized tiles."""
    patches: List[List[Any]] = []
    width, height = image.size
    grid_x = int(width / grid[0])
    grid_y = int(height / grid[1])
    for i in range(0, height, grid_y):
        images: List[Any] = []
        for j in range(0, width, grid_x):
            box = (j, i, j + grid_x, i + grid_y)
            patch = image.crop(box)
            images.append(patch)
        patches.append(images)
    return patches


def _slice_image(
    image: Any,
    *,
    max_slice_nums: int = _DEFAULT_MAX_SLICE_NUMS,
    scale_resolution: int = _DEFAULT_SLICE_RESOLUTION,
    patch_size: int = _DEFAULT_PATCH_SIZE,
    never_split: bool = False,
    min_slice_multiple: int = 3,
) -> Tuple[Any, List[List[Any]], Optional[List[int]]]:
    """Apply the upstream MiniCPM-o slice_image protocol.

    Returns ``(source_image, patches, grid)``:
      - ``source_image``: a low-resolution thumbnail of the whole
        page, sized ~scale_resolution × scale_resolution. Always
        returned.
      - ``patches``: a 2D list (``grid[1]`` rows × ``grid[0]`` cols)
        of higher-resolution sub-tiles. Empty when no slicing.
      - ``grid``: the [cols, rows] choice, or None when the image
        fits in one tile.

    The caller iterates over [source_image, *flatten(patches)] and
    runs the encoder once per tile. Each tile gets the encoder's
    full SigLIP receptive field at native resolution.
    """
    from PIL import Image as PILImage

    original_size = image.size
    best_grid = _get_sliced_grid(
        original_size,
        max_slice_nums,
        scale_resolution,
        never_split=never_split,
        min_slice_multiple=min_slice_multiple,
    )
    patches: List[List[Any]] = []

    if best_grid is None:
        # No slicing — upsample to the nearest patch-divisible
        # scale_resolution-area target.
        best_size = _find_best_resize(
            original_size,
            scale_resolution,
            patch_size,
            allow_upscale=True,
        )
        source_image = image.resize(
            best_size, resample=PILImage.Resampling.BICUBIC
        )
    else:
        # Down-sample original to a low-res thumbnail for the global
        # tile, then up-sample to refine-size and split into patches.
        best_resize = _find_best_resize(
            original_size, scale_resolution, patch_size
        )
        source_image = image.copy().resize(
            best_resize, resample=PILImage.Resampling.BICUBIC
        )
        refine_size = _get_refine_size(
            original_size,
            best_grid,
            scale_resolution,
            patch_size,
            allow_upscale=True,
        )
        refine_image = image.resize(
            refine_size, resample=PILImage.Resampling.BICUBIC
        )
        patches = _split_to_patches(refine_image, best_grid)

    return source_image, patches, best_grid


@dataclass
class VisionEmbeddingResult:
    """Structured return value of the vision runtime.

    The dict-view (``as_dict``) carries the same fields plus a few
    legacy keys (``image_name``, ``image_path``) for backwards
    compatibility with callers built before Task 42. The ``debug``
    payload never contains the raw on-disk path — only shape / dtype
    / active_device summary so it can safely be logged.
    """

    image_name: str
    image_path: str  # resolved absolute path; NOT included in ``debug``
    embedding: Any  # numpy [1, S, D_h]
    attention_mask: Any  # numpy [1, S] int64
    debug: Dict[str, Any] = field(default_factory=dict)
    extras: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "image_name": self.image_name,
            "image_path": self.image_path,
            "vision_features": self.embedding,
            "attention_mask": self.attention_mask,
            "debug": dict(self.debug),
        }
        d.update(self.extras)
        return d


class MiniCPMO45VisionRuntime:
    """Validate + encode images for the MiniCPM-o 4.5 native runtime.

    The constructor accepts an optional ``validator`` (defaults to a
    fresh ``CameraInputHandler``) and an optional ``encoder_fn`` (the
    OpenVINO inference seam). Tests inject a deterministic encoder; on
    real hardware the default runs ``vision_model`` + (optional)
    ``resampler_model`` through the compiled bundle with the full
    MiniCPM-o input contract (pixel_values + patch_attention_mask +
    position_ids; resampler pos_embed precomputed in numpy).
    """

    _VISION_MODEL_NAME = "vision_model"
    _RESAMPLER_MODEL_NAME = "resampler_model"

    def __init__(
        self,
        bundle: CompiledModelBundle,
        validator: Optional[CameraInputHandler] = None,
        encoder_fn: Optional[
            Callable[[Path, CompiledModelBundle], Dict[str, Any]]
        ] = None,
        *,
        slicing_enabled: bool = True,
        max_slice_nums: int = _DEFAULT_MAX_SLICE_NUMS,
        scale_resolution: int = _DEFAULT_SLICE_RESOLUTION,
        min_slice_multiple: int = 3,
    ) -> None:
        self.bundle = bundle
        self._validator = validator or CameraInputHandler()
        self._encoder_fn = encoder_fn or self._default_encoder_fn
        self._vision_request: Any = None
        self._resampler_request: Any = None
        self._cached_pos_embed_base: Any = None  # numpy [70, 70, 4096]
        # Slice_image protocol toggle. Default ON (matches
        # preprocessor_config.json: slice_mode=true). When False, the
        # legacy fixed-resize-to-448 path runs — preserved for tests
        # that depend on the old per-call encoder shape.
        self._slicing_enabled = bool(slicing_enabled)
        self._max_slice_nums = int(max_slice_nums)
        self._scale_resolution = int(scale_resolution)
        # Threshold (in tile-area multiples) below which slicing is
        # skipped — see _get_sliced_grid. Default 3 keeps slicing for
        # genuine high-res input (≥ ~1024×768 worth of pixels) and
        # passes webcam-aspect frames through as a single tile.
        self._min_slice_multiple = int(min_slice_multiple)

    def encode_image(
        self, image_path: PathLike
    ) -> Dict[str, Any]:
        """Validate the image path and run the encoder.

        Returns a dict that always carries ``image_name`` (basename) and
        ``image_path`` (resolved absolute path). The encoder may add any
        additional keys (e.g. ``vision_features``, ``attention_mask``,
        ``debug``). The path string is included in the dict for
        backwards compatibility but **never appears in ``debug``**.
        """
        validated = self._validator.validate_image_file(image_path)
        encoded = self._encoder_fn(validated, self.bundle)
        if not isinstance(encoded, dict):
            raise RuntimeError(
                "Vision encoder_fn must return a dict; got "
                f"{type(encoded).__name__}."
            )
        encoded.setdefault("image_name", validated.name)
        encoded.setdefault("image_path", str(validated))
        return encoded

    # ------------------------------------------------------------------
    # Default encoder (real OpenVINO path)
    # ------------------------------------------------------------------

    def _default_encoder_fn(
        self, image_path: Path, bundle: CompiledModelBundle
    ) -> Dict[str, Any]:
        """Encode an image through the vision_model + resampler.

        When ``slicing_enabled`` (default), runs the upstream
        MiniCPM-o ``slice_image`` protocol: split the input into ≤ N
        sub-tiles + a global thumbnail, encode each through the
        SigLIP vision model, and concatenate the per-tile resampler
        outputs into one ``[1, K*64, 4096]`` features tensor that the
        LM bridge sees as one super-image. K = 1 + tile_count.
        """
        if not bundle.has(self._VISION_MODEL_NAME):
            raise OVRuntimeError(
                "CompiledModelBundle is missing the 'vision_model' "
                f"handle. Available: {bundle.names()}."
            )
        np = self._numpy()
        from PIL import Image

        with Image.open(image_path) as im:
            im.load()
            rgb = im.convert("RGB")

        if self._slicing_enabled:
            source_image, patches, grid = _slice_image(
                rgb,
                max_slice_nums=self._max_slice_nums,
                scale_resolution=self._scale_resolution,
                patch_size=_DEFAULT_PATCH_SIZE,
                min_slice_multiple=self._min_slice_multiple,
            )
            tiles: List[Any] = [source_image]
            for row in patches:
                tiles.extend(row)
        else:
            # Legacy single-tile path — fixed 448×448 resize.
            tile = rgb.resize(
                (_DEFAULT_IMAGE_SIZE, _DEFAULT_IMAGE_SIZE),
                Image.BICUBIC,
            )
            tiles = [tile]
            grid = None

        per_tile_embeddings: List[Any] = []
        used_resampler = False
        per_tile_shapes: List[Tuple[int, int]] = []
        for tile in tiles:
            tile_emb, used_resampler_now, tile_shape = self._encode_one_tile(
                tile, bundle, np
            )
            per_tile_embeddings.append(tile_emb)
            per_tile_shapes.append(tile_shape)
            used_resampler = used_resampler or used_resampler_now

        # Concatenate per-tile embeddings along the sequence axis. Each
        # resampler output is [1, 64, 4096]; the LM bridge accepts
        # arbitrary [1, S, 4096] and splices in matching anchor pad
        # tokens, so a K-tile run produces [1, K*64, 4096].
        if len(per_tile_embeddings) == 1:
            embedding = per_tile_embeddings[0]
        else:
            embedding = np.concatenate(per_tile_embeddings, axis=1)

        seq_len = self._seq_len(embedding)
        mask = np.ones((1, seq_len), dtype=np.int64)
        debug = {
            "shape": list(getattr(embedding, "shape", ())),
            "dtype": str(getattr(embedding, "dtype", "")),
            "active_device": bundle.active_device,
            "resampled": used_resampler,
            "num_tiles": len(tiles),
            "sliced_grid": list(grid) if grid is not None else None,
            "tile_shapes": [list(s) for s in per_tile_shapes],
        }
        return {
            "vision_features": embedding,
            "attention_mask": mask,
            "debug": debug,
        }

    def _encode_one_tile(
        self,
        tile: Any,
        bundle: CompiledModelBundle,
        np: Any,
    ) -> Tuple[Any, bool, Tuple[int, int]]:
        """Run one tile through vision_model (+ resampler when
        present). Returns ``(embedding, used_resampler, (W, H))``.

        The tile must already be sized to a multiple of
        ``_DEFAULT_PATCH_SIZE`` on each side — slice_image guarantees
        this.
        """
        from PIL import Image

        patch_size = _DEFAULT_PATCH_SIZE
        if not isinstance(tile, Image.Image):
            raise TypeError(
                f"_encode_one_tile expected PIL Image; got {type(tile).__name__}"
            )
        tile_w, tile_h = tile.size
        # Each side must be a multiple of patch_size; slice_image
        # ensures this, but defend against tests that bypass it.
        if tile_w % patch_size or tile_h % patch_size:
            new_w = max(patch_size, (tile_w // patch_size) * patch_size)
            new_h = max(patch_size, (tile_h // patch_size) * patch_size)
            tile = tile.resize((new_w, new_h), Image.BICUBIC)
            tile_w, tile_h = tile.size
        nph_w = tile_w // patch_size
        nph = tile_h // patch_size
        num_patches = nph * nph_w

        arr = np.asarray(tile, dtype=np.float32) / 255.0
        mean = np.asarray(_DEFAULT_MEAN, dtype=np.float32)
        std = np.asarray(_DEFAULT_STD, dtype=np.float32)
        arr = (arr - mean) / std
        pixel_values = arr.transpose(2, 0, 1)[None, ...]  # HWC -> CHW + batch
        patch_attention_mask = np.ones(
            (1, 1, num_patches), dtype=bool
        )
        position_ids = self._build_position_ids(
            np, nph, nph_w, num_patches
        )

        vision_compiled = bundle.get(self._VISION_MODEL_NAME)
        vision_feed: Dict[str, Any] = {
            "pixel_values": pixel_values,
            "patch_attention_mask": patch_attention_mask,
            "position_ids": position_ids.astype(np.int64),
        }
        vision_hidden = self._infer_named(
            vision_compiled,
            vision_feed,
            request_attr="_vision_request",
        )
        # vision_hidden: [1, num_patches, 1152]

        embedding = vision_hidden
        used_resampler = False
        if bundle.has(self._RESAMPLER_MODEL_NAME):
            resampler_compiled = bundle.get(self._RESAMPLER_MODEL_NAME)
            pos_embed = self._resampler_pos_embed(
                np, nph, nph_w, num_patches, _DEFAULT_LM_HIDDEN
            )
            resampler_feed: Dict[str, Any] = {
                "x": vision_hidden,
                "pos_embed": pos_embed,
            }
            embedding = self._infer_named(
                resampler_compiled,
                resampler_feed,
                request_attr="_resampler_request",
            )
            # embedding: [1, 64, 4096]
            used_resampler = True
        return embedding, used_resampler, (tile_w, tile_h)

    # ------------------------------------------------------------------
    # MiniCPM-o specific preprocessing helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_position_ids(
        np: Any, nph: int, nph_w: int, num_patches: int
    ) -> Any:
        """Replicate the SiglipVisionEmbeddings position-id bucketing.

        Mirrors the upstream at modeling_navit_siglip.py:319-364 byte
        for byte. The bucketing math hinges on TWO load-bearing
        constants the SigLIP IR was trained against:

          - ``num_patches_per_side`` is the model's *training-time*
            patch grid: ``image_size // patch_size = 448 // 14 = 32``.
            Constant — does NOT vary with runtime input shape.
          - ``boundaries`` is built at 1/32 stride (32 buckets per
            side), and ``pos_grid`` uses 32 as the row multiplier.

        For a non-square runtime grid (e.g. 24×43 from a 16:9 input
        at scale_resolution=448), the bucketing maps each runtime
        patch onto one of the 32×32 = 1024 trained positions. The
        position_embedding table has exactly 1024 entries.

        An earlier port used ``nps = max(nph, nph_w)`` as both the
        bucketing stride and the row multiplier, which produces
        position_ids up to ``nps * (nps - 1) + nps - 1`` (e.g. 1804
        for a 24×43 grid). Those out-of-range indices either
        crashed the embedding lookup or silently wrapped, producing
        the structurally wrong SigLIP outputs measured by PR #130
        (mean cosine 0.32, min -0.45 vs PT vpm).
        """
        # Training-time constant: image_size // patch_size = 448 // 14.
        # If a future model uses a different image_size, this must be
        # updated to match — but it MUST stay tied to that constant
        # because the position_embedding weights were trained on it.
        NUM_PATCHES_PER_SIDE = 32
        boundaries = np.arange(
            1.0 / NUM_PATCHES_PER_SIDE, 1.0, 1.0 / NUM_PATCHES_PER_SIDE,
            dtype=np.float32,
        )
        position_ids = np.zeros((1, num_patches), dtype=np.int64)
        fractional_h = np.arange(
            0.0, 1.0 - 1e-6, 1.0 / nph, dtype=np.float32
        )
        fractional_w = np.arange(
            0.0, 1.0 - 1e-6, 1.0 / nph_w, dtype=np.float32
        )
        # ``side="right"`` matches torch.bucketize(..., right=True) at
        # modeling_navit_siglip.py:360-361. Critical for tie-breaking
        # at exact bucket boundaries.
        bucket_h = np.searchsorted(boundaries, fractional_h, side="right")
        bucket_w = np.searchsorted(boundaries, fractional_w, side="right")
        # Row multiplier is the training-time constant, NOT the runtime
        # grid size. This keeps every output id in [0, 1024).
        pos_grid = (
            bucket_h[:, None] * NUM_PATCHES_PER_SIDE + bucket_w[None, :]
        )
        flat = pos_grid.flatten()
        position_ids[0, : flat.shape[0]] = flat
        return position_ids

    def _resampler_pos_embed(
        self,
        np: Any,
        nph: int,
        nph_w: int,
        num_patches: int,
        embed_dim: int,
    ) -> Any:
        """Compute the resampler's pos_embed input.

        Mirrors the upstream Notebook resampler wrapper's pos_embed
        precomputation. Returns a numpy array of shape
        ``[num_patches, 1, embed_dim]``.

        Cache grows on demand: when ``nph`` or ``nph_w`` exceeds the
        currently-cached grid, regenerate at a larger size. This
        supports raising ``scale_resolution`` past 448 (which pushes
        per-tile patch count past 32×32) without re-converting the IR.
        """
        cached = self._cached_pos_embed_base
        cached_h, cached_w = (
            cached.shape[:2] if cached is not None else (0, 0)
        )
        if nph > cached_h or nph_w > cached_w:
            # Pick a target that comfortably covers the current request
            # AND any future request at the same scale_resolution.
            target_h = max(_DEFAULT_RESAMPLER_MAX_SIZE[0], nph, cached_h)
            target_w = max(_DEFAULT_RESAMPLER_MAX_SIZE[1], nph_w, cached_w)
            self._cached_pos_embed_base = self._compute_2d_sincos_pos_embed(
                np, embed_dim, (target_h, target_w)
            )
        base = self._cached_pos_embed_base
        slice_2d = base[:nph, :nph_w, :].reshape(num_patches, embed_dim)
        # [num_patches, 1, embed_dim]
        return slice_2d[:, None, :].astype(np.float32)

    @staticmethod
    def _compute_2d_sincos_pos_embed(
        np: Any, embed_dim: int, image_size: Tuple[int, int]
    ) -> Any:
        # Mirrors upstream get_2d_sincos_pos_embed exactly — see
        # models/source/MiniCPM-o-4_5/modeling_minicpmo.py:3621-3638.
        # The upstream variable names emb_h / emb_w are misleading:
        # emb_h encodes the W (column) position into the FIRST half,
        # and emb_w encodes the H (row) position into the SECOND half.
        # The IR's resampler weights were trained against this exact
        # ordering. An earlier port to this file swapped them
        # (encoding H into the first half, W into the second), which
        # produced "structurally divergent" resampler outputs vs the
        # source PyTorch model — see PR #128's tensor diff verdict
        # (cosine 0.21 on the worst token, mean 0.58, max abs diff
        # 17.3). Restoring the upstream axis order is load-bearing.
        grid_h_size, grid_w_size = image_size
        grid_h = np.arange(grid_h_size, dtype=np.float32)
        grid_w = np.arange(grid_w_size, dtype=np.float32)
        # np.meshgrid(grid_w, grid_h) with default indexing="xy"
        # returns (W-repeated [H,W], H-repeated [H,W]). Stacking,
        # grid[0] = W-repeated, grid[1] = H-repeated.
        grid = np.stack(np.meshgrid(grid_w, grid_h), axis=0)
        emb_h = MiniCPMO45VisionRuntime._get_1d_sincos(
            np, embed_dim // 2, grid[0]
        )
        emb_w = MiniCPMO45VisionRuntime._get_1d_sincos(
            np, embed_dim // 2, grid[1]
        )
        return np.concatenate([emb_h, emb_w], axis=-1)

    @staticmethod
    def _get_1d_sincos(np: Any, embed_dim: int, pos: Any) -> Any:
        omega = np.arange(embed_dim // 2, dtype=np.float32)
        omega /= embed_dim / 2.0
        omega = 1.0 / 10000.0 ** omega
        out = np.einsum("hw,d->hwd", pos, omega)
        return np.concatenate([np.sin(out), np.cos(out)], axis=-1)

    # ------------------------------------------------------------------
    # Inference helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _seq_len(arr: Any) -> int:
        shape = tuple(getattr(arr, "shape", ()))
        if len(shape) >= 2:
            return int(shape[1])
        if len(shape) == 1:
            return int(shape[0])
        return 0

    def _infer_named(
        self,
        compiled: Any,
        feed: Dict[str, Any],
        request_attr: str,
    ) -> Any:
        """Run a compiled handle with a name-keyed feed dict.

        Falls back to a positional ``{0: ..., 1: ..., ...}`` feed if
        the compiled handle's input ports have no readable names.
        """
        port_names = []
        inputs = getattr(compiled, "inputs", None)
        if inputs:
            port_names = [self._port_name(p) for p in inputs]

        # If we have port names matching the requested feed, pass it
        # through as-is. Otherwise build a positional fallback.
        if port_names and any(n is not None for n in port_names):
            actual_feed: Dict[Any, Any] = {}
            for k, v in feed.items():
                if k in port_names:
                    actual_feed[k] = v
                else:
                    # Some IRs expose slightly different port names.
                    # Try a contains-match.
                    chosen = next(
                        (
                            n
                            for n in port_names
                            if n is not None and (n == k or k in n or n in k)
                        ),
                        None,
                    )
                    if chosen is not None:
                        actual_feed[chosen] = v
                    else:
                        # Nothing matched — pass under the original
                        # key and let the OV runtime decide.
                        actual_feed[k] = v
        else:
            # Positional fallback.
            actual_feed = dict(enumerate(feed.values()))

        create = getattr(compiled, "create_infer_request", None)
        if callable(create):
            req = getattr(self, request_attr)
            if req is None:
                req = create()
                setattr(self, request_attr, req)
            infer = getattr(req, "infer", None)
            result = (
                infer(actual_feed)
                if callable(infer)
                else req(actual_feed)
            )
        elif callable(compiled):
            result = compiled(actual_feed)
        else:
            raise OVRuntimeError(
                f"Compiled handle is neither callable nor exposes "
                f"create_infer_request(); got {type(compiled).__name__}."
            )
        return self._unwrap_single_output(result)

    @staticmethod
    def _port_name(port: Any) -> Optional[str]:
        for attr in ("any_name", "name"):
            v = getattr(port, attr, None)
            if isinstance(v, str) and v:
                return v
        names = getattr(port, "names", None)
        if names:
            try:
                return next(iter(names))
            except Exception:  # noqa: BLE001
                return None
        return None

    @staticmethod
    def _unwrap_single_output(result: Any) -> Any:
        # OVDict (dict-like) → first value.
        try:
            values = list(result.values())
            if values:
                return values[0]
        except (AttributeError, TypeError):
            pass
        outputs = getattr(result, "outputs", None)
        if outputs is not None and not isinstance(result, (list, tuple)):
            try:
                first = next(iter(outputs))
                return outputs[first]
            except (StopIteration, KeyError, TypeError):
                pass
        if isinstance(result, dict):
            try:
                return next(iter(result.values()))
            except StopIteration as exc:
                raise OVRuntimeError(
                    "Vision sub-model produced no outputs."
                ) from exc
        return result

    @staticmethod
    def _numpy() -> Any:
        try:
            import numpy as np  # type: ignore
        except ImportError as exc:
            raise OVRuntimeDependencyError(
                "numpy is required for the native vision encoder. "
                "Install it with: pip install "
                '"local-minicpm-runtime[openvino-runtime]"'
            ) from exc
        return np


__all__ = ["MiniCPMO45VisionRuntime", "VisionEmbeddingResult"]
