# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Errors raised by the repository-owned OpenVINO runtime layer."""

from __future__ import annotations


class OVRuntimeError(RuntimeError):
    """Base class for any error in the native OpenVINO runtime layer."""


class OVRuntimeDependencyError(OVRuntimeError):
    """The user is missing an optional runtime dependency.

    Carries an actionable ``pip install ...`` hint in the message.
    """


class OVRuntimeLayoutError(OVRuntimeError):
    """The converted IR layout under ``model_dir`` is missing or invalid."""


class OVRuntimeNotImplementedError(OVRuntimeError, NotImplementedError):
    """Native runtime path is reserved for a later task.

    Raised by ``create_*_runtime`` factory functions until the native
    OpenVINO loader is implemented inside ``ov_runtime/``. Inherits
    from both ``OVRuntimeError`` and the stdlib ``NotImplementedError``
    so existing ``except NotImplementedError`` callers keep working.
    """


__all__ = [
    "OVRuntimeError",
    "OVRuntimeDependencyError",
    "OVRuntimeLayoutError",
    "OVRuntimeNotImplementedError",
]
