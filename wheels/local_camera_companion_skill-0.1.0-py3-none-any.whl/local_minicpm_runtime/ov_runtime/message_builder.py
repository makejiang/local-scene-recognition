# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Message builders for the MiniCPM-o 4.5 native runtime.

Pure stdlib. Builds canonical message lists for text, image, audio,
mixed-modality, and textbook-OCR prompts. Used by the text + vision +
audio + multimodal runtimes under ``ov_runtime/``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Union

PathLike = Union[str, Path]


def build_text_messages(prompt: str) -> List[Dict[str, Any]]:
    """Wrap a plain user prompt in the canonical message shape.

    Returns ``[{"role": "user", "content": [{"type": "text", "text": ...}]}]``.

    Raises:
        ValueError: if ``prompt`` is None / empty / whitespace-only.
    """
    if prompt is None or not str(prompt).strip():
        raise ValueError(
            "build_text_messages: prompt must be a non-empty string."
        )
    return [
        {
            "role": "user",
            "content": [{"type": "text", "text": str(prompt)}],
        }
    ]


def flatten_text_messages(messages: List[Dict[str, Any]]) -> str:
    """Concatenate text content from a list of messages.

    Used by the text runtime as a fallback when the tokenizer's
    ``apply_chat_template`` is unavailable. Non-text content blocks
    (image / audio) are silently skipped.

    Raises:
        ValueError: if ``messages`` is empty or contains no text blocks.
    """
    if not messages:
        raise ValueError(
            "flatten_text_messages: messages must be non-empty."
        )
    parts: List[str] = []
    for msg in messages:
        content = msg.get("content")
        if isinstance(content, str):
            if content:
                parts.append(content)
            continue
        if not isinstance(content, list):
            continue
        for block in content:
            if (
                isinstance(block, dict)
                and block.get("type") == "text"
                and block.get("text")
            ):
                parts.append(str(block["text"]))
    if not parts:
        raise ValueError(
            "flatten_text_messages: no text content found in messages."
        )
    return "\n".join(parts)


def build_image_messages(
    prompt: str, image_path: PathLike
) -> List[Dict[str, Any]]:
    """Wrap a prompt + image-path in the canonical message shape."""
    if prompt is None or not str(prompt).strip():
        raise ValueError(
            "build_image_messages: prompt must be a non-empty string."
        )
    if not image_path:
        raise ValueError(
            "build_image_messages: image_path is required."
        )
    return [
        {
            "role": "user",
            "content": [
                {"type": "text", "text": str(prompt)},
                {"type": "image", "image": str(image_path)},
            ],
        }
    ]


def build_audio_messages(
    prompt: str, audio_path: PathLike
) -> List[Dict[str, Any]]:
    """Wrap a prompt + audio-path in the canonical message shape."""
    if prompt is None or not str(prompt).strip():
        raise ValueError(
            "build_audio_messages: prompt must be a non-empty string."
        )
    if not audio_path:
        raise ValueError(
            "build_audio_messages: audio_path is required."
        )
    return [
        {
            "role": "user",
            "content": [
                {"type": "text", "text": str(prompt)},
                {"type": "audio", "audio": str(audio_path)},
            ],
        }
    ]


def build_mixed_messages(
    prompt: str,
    text: Optional[str] = None,
    image_path: Optional[PathLike] = None,
    audio_path: Optional[PathLike] = None,
) -> List[Dict[str, Any]]:
    """Wrap a prompt + any combination of (text, image, audio) blocks.

    At least one of ``text``, ``image_path``, ``audio_path`` must be
    non-empty. The prompt itself is always required.
    """
    if prompt is None or not str(prompt).strip():
        raise ValueError(
            "build_mixed_messages: prompt must be a non-empty string."
        )
    if not text and not image_path and not audio_path:
        raise ValueError(
            "build_mixed_messages: at least one of text, image_path, "
            "audio_path is required."
        )
    content: List[Dict[str, Any]] = [
        {"type": "text", "text": str(prompt)}
    ]
    if text:
        content.append({"type": "text", "text": str(text)})
    if image_path is not None:
        content.append({"type": "image", "image": str(image_path)})
    if audio_path is not None:
        content.append({"type": "audio", "audio": str(audio_path)})
    return [{"role": "user", "content": content}]


def build_textbook_ocr_messages(
    image_path: PathLike,
) -> List[Dict[str, Any]]:
    """Build the canonical OCR prompt + image message list."""
    if not image_path:
        raise ValueError(
            "build_textbook_ocr_messages: image_path is required."
        )
    return [
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": (
                        "Read this textbook page image. Transcribe "
                        "the main body text in clear English, "
                        "sentence by sentence. Do not paraphrase. "
                        "Skip page numbers, captions, and figure "
                        "labels. Return only the transcribed body "
                        "text."
                    ),
                },
                {"type": "image", "image": str(image_path)},
            ],
        }
    ]


__all__ = [
    "build_audio_messages",
    "build_image_messages",
    "build_mixed_messages",
    "build_text_messages",
    "build_textbook_ocr_messages",
    "flatten_text_messages",
]
