# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Vision+text runtime backed by ``OVModelForVisualCausalLM``.

PR #134's investigation showed the SigLIP OCR ceiling on small text
came from how our hand-rolled ``MiniCPMO45VisionRuntime`` +
``MiniCPMO45TextRuntime`` fed the SigLIP IR: the bytes for
``patch_attention_mask`` / ``position_ids`` / ``image_bound`` /
``tgt_sizes`` differed from what the IR was traced to expect. End-
to-end proof: the same int8 IR fed via our runtime gave mean SigLIP
cosine 0.29 vs PT, but fed via this class produced verbatim correct
OCR in 49.8s on CPU (vs 366s at fp16).

This module replaces the OCR/vision+text path. Audio + TTS still go
through the legacy ``MiniCPMO45AudioRuntime`` / Token2Wav since
``optimum-intel`` explicitly raises ``ValueError`` on audio inputs
to ``_OVMiniCPMOForCausalLM`` (modeling_visual_language.py:2175).

Public API mirrors the vision+text subset of
``MiniCPMO45MultimodalRuntime`` so the routing switch in
``multimodal_runtime.py`` is local — callers above the runtime
(adapter, pipeline, skill_entry) don't change.

The wrapped model dir must be in ``optimum-intel``'s 6-file layout
(produced by ``optimum-cli export openvino --task image-text-to-text
--weight-format int8 ...``):

  - ``openvino_language_model.{xml,bin}``
  - ``openvino_text_embeddings_model.{xml,bin}``
  - ``openvino_vision_embeddings_model.{xml,bin}``
  - ``openvino_resampler_model.{xml,bin}``
  - ``openvino_tokenizer.{xml,bin}``
  - ``openvino_detokenizer.{xml,bin}``

This is **incompatible** with the existing 18-file layout the audio
runtime uses, so the Skill keeps two model directories on disk.
"""

from __future__ import annotations

import gc
import logging
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union


PathLike = Union[str, Path]
logger = logging.getLogger(__name__)


@dataclass
class OptimumRuntimeInfo:
    """Lightweight metadata for ``runtime_info()``.

    The legacy ``MiniCPMO45MultimodalRuntime.bundle.runtime_info()``
    returns a dict; we mirror that shape so callers don't branch on
    runtime type.
    """

    model_dir: str
    device: str
    loaded: bool

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model_dir": self.model_dir,
            "active_device": self.device,
            "fallback_used": False,
            "runtime_path": "optimum_visual",
            "loaded": self.loaded,
        }


class OptimumMiniCPMORuntime:
    """OCR / vision+text runtime backed by ``OVModelForVisualCausalLM``.

    Lazy-loads the model on first inference call. ``runtime_info()``
    works without loading. The OCR call shape is fixed (no streaming,
    greedy decoding, fixed max_new_tokens) for parity with the legacy
    path's behaviour.
    """

    _IMAGE_PLACEHOLDER = "(<image>./</image>)\n"
    # Default idle window before the optimum LM unloads itself.
    # ``0`` disables the timer entirely.
    #
    # Set to disabled by default (v18) after real-machine evidence
    # showed the unload was adding ~10s reload spikes mid-session
    # in the camera-companion continuous-voice flow. The user
    # observed alternating 6s and 16s LLM(first sentence) times on
    # similar prompts: every time they paused >30s between turns
    # (thinking, gesturing, glancing away from the camera) the
    # optimum LM unloaded and the next turn paid the reload cost.
    #
    # On the deployment box (32 GB RAM, 30 GB resident, GPU shared
    # 12/18 GB) the swap-in cost is much higher than the original
    # "2-3s" estimate because the OS has to page weights back from
    # disk under memory pressure. Net: keeping the model resident
    # is strictly better for camera-companion usage where every
    # turn is a vision-text call. Operators who want the unload
    # behavior back (e.g. for memory-constrained scenarios where
    # vision-text calls are rare) can pass ``idle_unload_seconds``
    # to the constructor.
    _DEFAULT_IDLE_UNLOAD_SECONDS: float = 0.0

    def __init__(
        self,
        model_dir: PathLike,
        *,
        device: str = "CPU",
        cache_dir: Optional[PathLike] = None,
        idle_unload_seconds: Optional[float] = None,
    ) -> None:
        self.model_dir = str(model_dir)
        self.device = str(device).upper()
        self.cache_dir = str(cache_dir) if cache_dir is not None else None
        self._model: Any = None
        self._processor: Any = None
        self._tokenizer: Any = None
        # Idle-unload state. ``_lock`` guards ``_model`` /
        # ``_processor`` / ``_tokenizer`` against the timer thread
        # racing a new inference call. ``_idle_unload_seconds=0``
        # (or negative) disables the timer entirely.
        self._idle_unload_seconds: float = (
            float(idle_unload_seconds)
            if idle_unload_seconds is not None
            else self._DEFAULT_IDLE_UNLOAD_SECONDS
        )
        self._last_inference_at: float = 0.0
        self._unload_timer: Optional[threading.Timer] = None
        self._lock = threading.RLock()
        # Number of public-API calls currently inside ``_run``. The
        # idle-unload timer refuses to unload while this is > 0 so a
        # long-running inference (the optimum LM is 60-70s on CPU
        # under memory pressure) cannot be torn down mid-call. Real-
        # machine session 4d5053bc crashed with
        # "'NoneType' object has no attribute 'tokenizer'" because
        # the timer fired during a 70s ``model.generate`` and nulled
        # state out from under the running call.
        self._inflight_count: int = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate_text(
        self,
        prompt: str,
        max_new_tokens: int = 512,
        *,
        token_callback: Optional[Callable[[str], None]] = None,
    ) -> str:
        """Text-only generation (no image)."""
        self._ensure_loaded()
        self._begin_call()
        try:
            return self._run(
                prompt=prompt,
                image=None,
                max_new_tokens=max_new_tokens,
                token_callback=token_callback,
            )
        finally:
            self._end_call()

    def generate_from_image(
        self,
        prompt: str,
        image_path: PathLike,
        max_new_tokens: int = 512,
        *,
        token_callback: Optional[Callable[[str], None]] = None,
    ) -> str:
        """Image-conditioned generation."""
        self._ensure_loaded()
        from PIL import Image

        with Image.open(str(image_path)) as im:
            im.load()
            image = im.convert("RGB")
        self._begin_call()
        try:
            return self._run(
                prompt=prompt,
                image=image,
                max_new_tokens=max_new_tokens,
                token_callback=token_callback,
            )
        finally:
            self._end_call()

    def extract_textbook_text(self, image_path: PathLike) -> str:
        """Run textbook OCR with the canonical OCR prompt + post-strip.

        Returns ``""`` on any internal failure so the Skill's empty-
        extraction path can fire the bilingual retry hint.
        """
        # Imported lazily to avoid a circular import: multimodal_runtime
        # imports this module.
        from .multimodal_runtime import (
            _OCR_PROMPT,
            _looks_like_loop_fragment,
            _strip_thinking,
        )

        try:
            self._ensure_loaded()
            from PIL import Image

            with Image.open(str(image_path)) as im:
                im.load()
                image = im.convert("RGB")
            self._begin_call()
            try:
                raw = self._run(
                    prompt=_OCR_PROMPT,
                    image=image,
                    max_new_tokens=512,
                )
            finally:
                self._end_call()
        except Exception as exc:  # noqa: BLE001 - OCR fail-soft contract
            logger.warning(
                "extract_textbook_text failed (optimum path): %s. "
                "Returning empty.",
                exc,
            )
            return ""
        cleaned = _strip_thinking(raw or "")
        # The legacy path also drops short list-loop fragments after
        # the LM cycle-break fires. ``OVModelForVisualCausalLM`` doesn't
        # expose a stop_reason; we conservatively skip that drop here
        # — the post-strip already handles most pathological outputs.
        # If list-loop fragments slip through, revisit by adding a
        # heuristic on cleaned length + bullet-item count.
        del _looks_like_loop_fragment  # marker import for consistency
        return cleaned

    def runtime_info(self) -> Dict[str, Any]:
        return OptimumRuntimeInfo(
            model_dir=self.model_dir,
            device=self.device,
            loaded=self._model is not None,
        ).to_dict()

    @property
    def bundle(self) -> Any:
        """Compat shim: legacy ``MiniCPMO45MultimodalRuntime.bundle``
        is used by callers to read ``active_device`` / ``fallback_used``.
        Return a thin object that exposes those attributes.
        """
        return _BundleShim(
            active_device=self.device,
            fallback_used=False,
            runtime_info=lambda: self.runtime_info(),
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _ensure_loaded(self) -> None:
        # Cheap fast-path: already loaded.
        if self._model is not None:
            return
        # Slow-path under lock so a racing idle-unload timer can't
        # null out _model between our test and assignment.
        with self._lock:
            if self._model is not None:
                return
            if not Path(self.model_dir).is_dir():
                raise FileNotFoundError(
                    f"OptimumMiniCPMORuntime: model_dir not found: "
                    f"{self.model_dir}. Run "
                    "`optimum-cli export openvino --weight-format int8 "
                    "--task image-text-to-text --trust-remote-code "
                    f"--model <source> {self.model_dir}` to materialise it."
                )
            from optimum.intel.openvino import OVModelForVisualCausalLM
            from transformers import AutoProcessor, AutoTokenizer

            logger.info(
                "OptimumMiniCPMORuntime: loading %s on %s...",
                self.model_dir,
                self.device,
            )
            t0 = time.time()
            self._model = OVModelForVisualCausalLM.from_pretrained(
                self.model_dir,
                trust_remote_code=True,
                device=self.device,
                cache_dir=self.cache_dir,
            )
            self._processor = AutoProcessor.from_pretrained(
                self.model_dir, trust_remote_code=True
            )
            self._tokenizer = AutoTokenizer.from_pretrained(
                self.model_dir, trust_remote_code=True
            )
            logger.info(
                "OptimumMiniCPMORuntime: loaded in %.1fs.",
                time.time() - t0,
            )

    def _begin_call(self) -> None:
        """Mark the start of a public-API call.

        Bumps ``_inflight_count`` and ``_last_inference_at`` under
        the lock so the idle timer's elapsed-since-last-call check
        sees the in-flight call as recent. Pair every call with
        ``_end_call`` in a ``finally`` block so the count returns
        to zero even if inference raises.
        """
        with self._lock:
            self._last_inference_at = time.monotonic()
            self._inflight_count += 1

    def _end_call(self) -> None:
        """Mark the end of a public-API call. Re-arms the idle
        timer so the now-quiescent runtime can drop state after
        the configured idle window."""
        with self._lock:
            self._inflight_count = max(0, self._inflight_count - 1)
        self._arm_idle_unload_timer()

    def _arm_idle_unload_timer(self) -> None:
        """Schedule a deferred unload after the configured idle window.

        Resets the existing timer if one was pending. The next
        inference call cancels and re-arms; an inference that lands
        between scheduling and firing still wins thanks to the
        ``_last_inference_at`` re-check in ``_maybe_unload``.
        """
        if self._idle_unload_seconds <= 0.0:
            return
        with self._lock:
            self._last_inference_at = time.monotonic()
            if self._unload_timer is not None:
                self._unload_timer.cancel()
            t = threading.Timer(
                self._idle_unload_seconds, self._maybe_unload
            )
            t.daemon = True
            self._unload_timer = t
            t.start()

    def _maybe_unload(self) -> None:
        """Timer callback: release the optimum LM state if no
        inference call landed since the timer was armed AND no
        call is currently in flight."""
        with self._lock:
            if self._idle_unload_seconds <= 0.0:
                return
            # Refuse to unload while a call is running. The end_call
            # path will re-arm the timer afterwards. Without this
            # guard, a single LLM generate that exceeds the idle
            # window unloads itself mid-call and the in-flight ``_run``
            # crashes with NoneType-tokenizer (real-machine session
            # 4d5053bc).
            if self._inflight_count > 0:
                return
            elapsed = time.monotonic() - self._last_inference_at
            if elapsed < self._idle_unload_seconds - 0.1:
                # A racing call landed and re-armed the timer;
                # the new timer will fire later.
                return
            if self._model is None:
                return
            self._unload_timer = None
            # Release in reverse-load order. ``gc.collect()`` nudges
            # OpenVINO's compiled-model cleanup so resident memory
            # actually drops; without it OV holds onto the IRs in
            # internal arenas for an indeterminate time.
            self._tokenizer = None
            self._processor = None
            self._model = None
            gc.collect()
            logger.info(
                "OptimumMiniCPMORuntime: idle-unloaded after %.1fs",
                elapsed,
            )

    def shutdown(self) -> None:
        """Release the optimum LM and cancel the idle timer.

        Called by callers that want to free the model deterministically
        (tests, lifecycle managers). Idempotent.
        """
        with self._lock:
            if self._unload_timer is not None:
                self._unload_timer.cancel()
                self._unload_timer = None
            self._tokenizer = None
            self._processor = None
            self._model = None
            gc.collect()

    def _run(
        self,
        *,
        prompt: str,
        image: Any,
        max_new_tokens: int,
        token_callback: Optional[Callable[[str], None]] = None,
    ) -> str:
        """Build chat-template inputs and call ``generate``.

        When ``token_callback`` is provided, a HuggingFace
        ``TextIteratorStreamer`` is attached to ``model.generate`` and
        ``generate`` is run on a worker thread; the main thread
        iterates the streamer, forwards each text delta to
        ``token_callback``, and accumulates the full reply for the
        return value. Streamer + thread are imported lazily so the
        non-streaming path keeps zero overhead.
        """
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("prompt must be a non-empty string")

        # Pre-pend the upstream image placeholder when an image is
        # present. The chat template reads ``(<image>./</image>)``
        # tokens to splice the vision features into the prompt at
        # inference time.
        if image is not None:
            content = f"{self._IMAGE_PLACEHOLDER}{prompt}"
            images_arg: Any = [[image]]
        else:
            content = prompt
            images_arg = None

        msgs = [{"role": "user", "content": content}]
        chat_text = self._processor.tokenizer.apply_chat_template(
            msgs, tokenize=False, add_generation_prompt=True
        )
        inputs = self._processor(
            [chat_text], images_arg, return_tensors="pt"
        )

        if token_callback is None:
            # Legacy batch path — unchanged.
            ids = self._model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=False,
            )
            prefix_len = inputs["input_ids"].shape[1]
            out_ids = ids[0, prefix_len:]
            return self._tokenizer.decode(
                out_ids, skip_special_tokens=True
            )

        # Streaming path — Camera Companion token-level streaming.
        # Lazy imports keep transformers/threading off the legacy
        # path's hot import surface.
        import threading

        from transformers import TextIteratorStreamer

        streamer = TextIteratorStreamer(
            self._tokenizer,
            skip_prompt=True,
            skip_special_tokens=True,
        )

        generate_kwargs = dict(
            inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            streamer=streamer,
        )

        gen_error: Dict[str, BaseException] = {}

        def _generate_in_worker() -> None:
            try:
                self._model.generate(**generate_kwargs)
            except BaseException as exc:  # noqa: BLE001
                gen_error["err"] = exc

        worker = threading.Thread(
            target=_generate_in_worker,
            name="OptimumMiniCPMORuntime.generate",
            daemon=True,
        )
        worker.start()

        accumulated: List[str] = []
        for delta in streamer:
            if not delta:
                continue
            accumulated.append(delta)
            try:
                token_callback(delta)
            except Exception:  # noqa: BLE001 - opportunistic
                logger.exception(
                    "token_callback raised; continuing generation"
                )

        worker.join()
        if "err" in gen_error:
            raise gen_error["err"]
        return "".join(accumulated)


@dataclass(frozen=True)
class _BundleShim:
    """Thin stand-in for ``CompiledModelBundle`` so callers that read
    ``runtime.bundle.active_device`` / ``.fallback_used`` keep working
    when the multimodal runtime is hybrid (optimum for vision, custom
    for audio)."""

    active_device: str
    fallback_used: bool
    runtime_info: Any

    def has(self, _name: str) -> bool:
        return False

    def get(self, name: str) -> Any:
        raise AttributeError(
            f"_BundleShim has no compiled handle '{name}'. The hybrid "
            "runtime path doesn't expose vision/text sub-models — they "
            "live inside OVModelForVisualCausalLM. Audio sub-models are "
            "still on the legacy bundle; route through the audio "
            "runtime instead."
        )

    def names(self) -> list:
        return []


__all__ = ["OptimumMiniCPMORuntime", "OptimumRuntimeInfo"]
