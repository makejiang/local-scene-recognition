# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Multimodal runtime composing text + vision + audio runtimes.

The factory returns this; the adapter delegates each modality call
directly to the matching method (``generate_from_image``,
``generate_from_audio``, ``generate_from_mixed``,
``generate_from_vision_audio``, ``extract_textbook_text``).

After Task 42 modality file references no longer leak into the text
prompt as ``[image:basename]`` / ``[audio:basename]`` tags. Each
modality entry point validates and encodes the input through the
vision/audio runtime, then calls
``text_runtime.generate_text_with_embeddings(prompt, embeds, masks)``
which feeds ``[modality_embedding..., text_token_embedding]`` as the
language-model's ``inputs_embeds``. Greedy argmax still picks the
next text token.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Union

from .audio_runtime import MiniCPMO45AudioRuntime
from .compiled_model_bundle import CompiledModelBundle
from .message_builder import (
    flatten_text_messages,
)
from .text_runtime import MiniCPMO45TextRuntime
from .vision_runtime import MiniCPMO45VisionRuntime

if TYPE_CHECKING:
    from .optimum_visual_runtime import OptimumMiniCPMORuntime

PathLike = Union[str, Path]
logger = logging.getLogger(__name__)


# Verified empirically with diagnose_ocr against the real model: the
# strict /no_think + numbered-rules variant *triggers* the thinking
# trace instead of suppressing it (the model decides the rules
# warrant deliberation). The original light-touch transcription
# prompt is the one that keeps the model out of think mode.
_OCR_PROMPT = (
    "Read this textbook page image. Transcribe the main body text in "
    "clear English, sentence by sentence. Do not paraphrase. Do not "
    "continue past the last visible sentence on the page. Skip page "
    "numbers, captions, and figure labels. Return only the "
    "transcribed body text."
)


# Detect degenerate bracket-token soup: outputs that consist mostly
# of short bracketed tokens like "[IMAGE] [PAGE] [VERBAT] ...". Real
# textbook pages don't contain this; it's purely a thinking-model
# failure mode where the LM latches onto structural tokens from the
# prompt and emits them in a loop.
_BRACKET_TOKEN_RE = re.compile(r"\[[A-Z_][A-Z0-9_ ]{0,20}\]")


# Match a complete <think>...</think> block (greedy across newlines) AND
# the "open <think> with no closer" case the thinking model sometimes
# emits when it hits the token budget mid-thought.
_THINK_BLOCK_RE = re.compile(
    r"<think>.*?(?:</think>|\Z)", re.DOTALL | re.IGNORECASE
)
# Fallback: when the model truncates its leading <think> tag (output
# starts mid-thought with no opener) but emits the closing </think>
# literally somewhere later, drop everything up to and including the
# first </think>. Example: 'ay, let's tackle this. The user wants
# ... compile these sentences in order. </think> Access to parallel
# processing is a modern imperative...'  -> keeps only the part after
# the </think>. Real OCR output never contains a bare </think>.
_THINK_CLOSE_TAIL_RE = re.compile(
    r"\A.*?</think>\s*", re.DOTALL | re.IGNORECASE
)
# Common preambles the model sometimes prepends after </think> instead of
# returning bare transcription. Drop one leading line only.
_PREAMBLE_RE = re.compile(
    r"^\s*(?:got it[\.,]?|okay[\.,]?|sure[\.,]?|"
    r"the (?:main )?(?:body )?text (?:reads|is|on the page is)[:\.]?|"
    r"here(?:'s| is) the transcription[:\.]?|"
    r"transcription[:\.]?)\s*",
    re.IGNORECASE,
)
# Non-ASCII (typically Chinese) instruction-echo prefix. The MiniCPM-o
# base model is bilingual; on English textbook pages it sometimes
# paraphrases the OCR prompt back in Chinese before the actual
# transcription, e.g. "好的，我将根据您提供的图片内容，逐字准确转录图片中
# 的文本。 Good morning, everyone...". The English page itself never
# starts with a CJK sentence, so a leading run of CJK chars terminated
# by CJK punctuation (。！？) followed by ASCII content is always echo.
# We only drop the prefix when ≥4 CJK chars are present so a stray
# loanword in legit content doesn't trigger.
_CJK_CHAR = r"㐀-鿿豈-﫿"
_CJK_PUNCT = r"　-〿＀-￯"
_CJK_PREAMBLE_RE = re.compile(
    rf"\A[\s{_CJK_PUNCT}]*"
    rf"(?:[{_CJK_CHAR}][{_CJK_CHAR}{_CJK_PUNCT}\s]*){{4,}}"
    rf"[。！？．]\s*",
)
# Instruction-echo patterns: when the page is hard to OCR (cover shot,
# low sharpness, minimal body text), MiniCPM-o-4.5 sometimes paraphrases
# the OCR prompt back at us — "I'll read the textbook page image and
# transcribe..." — instead of transcribing. We drop full sentences that
# match these patterns. They're ALL false-positive echoes; no real
# textbook page narrates what's about to happen.
_ECHO_SENTENCE_RES = (
    re.compile(
        r"\b(?:I(?:'ll| will| am going to)|let me|i'?m going to)\s+"
        r"(?:read|transcribe|read out|read aloud|skip|return|provide|"
        r"give you|share|process|extract|analyse|analyze|describe|look at)"
        r"\b[^.!?]*[.!?]\s*",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:sentence by sentence|page numbers?,?\s*captions?,?\s*"
        r"and figure labels?|main body text|verbatim transcription)"
        r"\b[^.!?]*[.!?]\s*",
        re.IGNORECASE,
    ),
    # "Certainly." / "Sure!" / "Of course." conversational openers.
    re.compile(
        r"^\s*(?:certainly|sure|of course|absolutely|alright|ok|okay)"
        r"[\s,!.\-:]*",
        re.IGNORECASE,
    ),
    # "Here is the transcription of the [page]" — partial preambles that
    # leak past the original PREAMBLE_RE because of varied phrasing.
    re.compile(
        r"\bhere(?:'s| is)\s+(?:the\s+)?(?:transcription|transcribed text|"
        r"text|content|main body)\s*(?:of\s+the\s+\w*)?[.\-:]*\s*",
        re.IGNORECASE,
    ),
    # Refusal sentences — the model telling us it can't read the image.
    # Treat as no-text-found and let the empty-extraction polite path
    # handle it instead of synthesising the refusal.
    re.compile(
        r"[^.!?]*\b(?:not visible|cannot (?:see|read|make out)|can't (?:see|"
        r"read|make out)|unable to (?:see|read|view|access|extract)|no (?:"
        r"visible |readable )?text (?:visible|present|found|in the image)|"
        r"if you (?:have|could provide) a (?:different|clearer)|please "
        r"provide (?:a clearer|more|the text)|i'?ll be happy to help)"
        r"\b[^.!?]*[.!?]\s*",
        re.IGNORECASE,
    ),
    # Permission-seeking clarification — "Would you like me to
    # proceed with the transcription…?" / "Shall I transcribe the
    # text?" The model asking instead of doing. Never the page.
    re.compile(
        r"\b(?:would you like|shall i|do you want|may i)\s+"
        r"(?:me to\s+)?(?:proceed|transcribe|read|continue|provide|"
        r"give|share|describe)"
        r"\b[^.!?]*[.!?]\s*",
        re.IGNORECASE,
    ),
    # "You will be given a series of sentences." — the model echoing
    # an imagined instruction template. Real pages don't address the
    # reader in second person about sentences.
    re.compile(
        r"\bYou (?:will|are going to) be given\b[^.!?]*[.!?]\s*",
        re.IGNORECASE,
    ),
    # "I need to carefully read through the text in the image..." /
    # "I need to transcribe..." — first-person planning narration the
    # model emits when it falls back to chat behaviour. The literal
    # body text never starts with "I need to read the text in the
    # image".
    re.compile(
        r"\bI need to\s+(?:carefully\s+)?(?:read|transcribe|review|"
        r"identify|extract|analyse|analyze|look at|check|process)\b"
        r"[^.!?]*[.!?]\s*",
        re.IGNORECASE,
    ),
    # "transcribe it exactly as it appears, without adding..." —
    # explicit prompt-paraphrase. Always echo, never page text.
    re.compile(
        r"\btranscribe (?:it|the text|the content)?\s*(?:exactly\s+)?"
        r"(?:as it appears|verbatim|word.?for.?word|literally)"
        r"\b[^.!?]*[.!?]\s*",
        re.IGNORECASE,
    ),
)


# Generic-textbook-description phrases the model emits when it
# hallucinates a description of a page instead of transcribing it.
# Hits are NOT stripped on their own (they may legitimately appear
# in some pages); they're a SIGNAL — when 2+ markers appear in the
# output, the whole thing is treated as hallucination and dropped.
_HALLUCINATION_MARKERS_RE = re.compile(
    r"\b(?:"
    r"key (?:terminology|concepts|takeaways)|"
    r"theoretical framework|"
    r"clear definitions and examples|"
    r"aid comprehension|"
    r"subsequent paragraphs?|"
    r"mathematical equations and logical arguments|"
    r"supporting evidence and real-world applications|"
    r"build upon the previous|"
    r"coherent and comprehensive presentation|"
    r"reinforcing the importance of the concepts|"
    r"the (?:section|chapter|page|text|passage) (?:concludes|elaborates|"
    r"introduces|discusses|presents|covers|provides|explains|begins)"
    r")\b",
    re.IGNORECASE,
)
_HALLUCINATION_THRESHOLD = 2


def _looks_like_hallucinated_description(text: str) -> bool:
    """True when the output reads like a generic 'this textbook page
    introduces concepts and elaborates on theory' description rather
    than verbatim transcription."""
    if not text:
        return False
    hits = _HALLUCINATION_MARKERS_RE.findall(text)
    return len(hits) >= _HALLUCINATION_THRESHOLD


# Refusal markers — phrases the model uses when it refuses to
# transcribe an unreadable image (apology, image-quality complaint,
# offer to help if a clearer image is provided). The per-sentence
# regex in _ECHO_SENTENCE_RES catches some phrasings but not all,
# and chasing every contraction / verb variant is fragile. Treat
# the output as a refusal — and therefore equivalent to no-text-found
# — when 2+ of these markers cluster together.
_REFUSAL_MARKERS_RE = re.compile(
    r"\b(?:"
    r"i'?m sorry|"
    r"can(?:not|'?t) (?:provide|read|see|transcribe|make out|"
    r"discern|extract)|"
    r"unable to (?:provide|read|see|transcribe|view|access|"
    r"extract|make out|discern)|"
    r"obscured|pixelated|illegible|unreadable|"
    r"too blurry|heavily blurred|"
    r"difficult to (?:discern|read|see|make out)|"
    r"clearer image|different image|"
    r"i'?(?:ll|d) be happy to help|"
    r"if you (?:have|could|can) (?:provide|share)|"
    r"describe the text"
    r")\b",
    re.IGNORECASE,
)
_REFUSAL_THRESHOLD = 2

# Stock paywall / "page-not-accessible" hallucination phrases the
# model emits when it perceives the image as a blocked / cropped /
# sample resource (e.g. a photo with heavy glare in the top half).
# These phrases come from the training corpus (web articles behind
# paywalls, "you must log in" notices) and are NEVER real textbook
# content. A single hit is a confident signal — unlike the generic
# refusal markers above, no real page contains "You may be trying
# to access this content".
_PAYWALL_HALLUCINATION_RE = re.compile(
    r"\b(?:"
    r"you may be trying to access (?:this|the)|"
    r"this content (?:is|may be) (?:restricted|blocked|unavailable|"
    r"protected|cut)|"
    r"please (?:log in|sign in|subscribe) to (?:view|access|read|"
    r"continue)|"
    r"access to (?:this )?(?:content|page|article) (?:is|requires|"
    r"may be|requires a)|"
    r"to view (?:this|the) (?:full )?(?:content|article|page),?\s+"
    r"(?:please|you (?:must|need|should))"
    r")\b",
    re.IGNORECASE,
)


def _looks_like_refusal(text: str) -> bool:
    """True when the output reads like the model refusing to OCR
    (apology + image-quality complaint + offer to help) rather than
    actual page content. Real textbook prose almost never clusters
    these phrases, so 2+ hits is a confident signal.

    Also fires on stock paywall / blocked-content hallucinations
    (single hit suffices — those phrases never occur on real
    textbook pages)."""
    if not text:
        return False
    if _PAYWALL_HALLUCINATION_RE.search(text):
        return True
    hits = _REFUSAL_MARKERS_RE.findall(text)
    return len(hits) >= _REFUSAL_THRESHOLD


# Sentence chunker: a "sentence" is a run of non-terminator chars
# followed by [.!?] and any trailing close-quotes / brackets. We use
# findall instead of split because the terminal punctuation often sits
# inside a quoted phrase (`‘What?’`, `"Run!"`) where a plain `(?<=[.!?])\s+`
# split would treat the closing quote as part of the next sentence.
_SENTENCE_FIND_RE = re.compile(
    r"[^.!?]+[.!?]+[\"'’”)\]]*",
    re.DOTALL,
)


def _split_sentences(text: str) -> List[str]:
    """Return a list of sentence strings (with their terminal
    punctuation and trailing close-quotes attached). Whitespace
    between sentences is dropped from each entry."""
    found = _SENTENCE_FIND_RE.findall(text)
    return [s.strip() for s in found if s.strip()]


def _norm_sentence(s: str) -> str:
    """Normalise a sentence for cycle comparison: lowercase, collapse
    whitespace, strip terminal punctuation. Treats `'What?'` and
    ` 'what?' ` as equal."""
    out = re.sub(r"\s+", " ", s.strip().lower())
    return out.rstrip(".!?,;: ")


# Short-phrase cycle: matches inline 3+ repetitions of a short word or
# phrase, e.g. ``What? What? What?`` or ``OK! OK! OK!``. Two regex
# variants run together, covering the two production failure shapes:
#
#   (a) ``"What?" "What?" "What?"`` — each repetition is fully quoted.
#   (b) ``"What? What? What?"`` — repetitions inside one outer quote.
#
# The 8-gram generation cycle-break is too coarse for these (the unit
# is only 2-3 tokens), and _strip_sentence_cycle looks at tail
# repetitions only. This stripper is targeted at the inline case.
_PHRASE_CYCLE_QUOTED_RE = re.compile(
    r"(?P<unit>[\"'“‘][^\"'“”‘’\n]{1,40}"
    r"[\"'”’])(?:[ \t,]*(?P=unit)){2,}",
    re.UNICODE,
)
# Bare-word/phrase repetition with terminal punctuation, e.g.
# ``What? What? What?`` (3+ identical 1-3 word chunks each ending in
# .!?). Word boundaries on both sides keep this from chewing into
# legitimate prose.
_PHRASE_CYCLE_BARE_RE = re.compile(
    r"\b(?P<unit>(?:\w+\s+){0,2}\w+[.!?])"
    r"(?:\s+(?P=unit)){2,}",
    re.UNICODE,
)


def _strip_phrase_cycle(text: str) -> str:
    """Collapse 3+ inline repetitions of a short phrase.

    Real failure: the model emitted ``"What? What? What?"`` mid-output
    on a partially OCR-read page (log 14, paragraph 5). Both quoted
    and unquoted repetitions are handled.
    """
    if not text:
        return text
    text = _PHRASE_CYCLE_QUOTED_RE.sub(lambda m: m.group("unit"), text)
    text = _PHRASE_CYCLE_BARE_RE.sub(lambda m: m.group("unit"), text)
    return text


def _strip_sentence_cycle(text: str, *, min_cycles: int = 3) -> str:
    """Truncate trailing sentence-level cycles.

    The single-token cycle-break in ``generation_loop`` catches LM
    degeneration into ``The The The The...``; ``_strip_repetition_tail``
    catches the same pattern post-hoc. Neither sees the
    sentence-level cycle that the base model falls into when it has
    transcribed the visible body and starts looping the last
    sentence(s) — e.g. ``'What?' I said. 'What?' I said. 'What?' I
    said.`` for the rest of the budget. We split on sentence
    terminators and drop trailing repetitions of a 1-, 2-, or
    3-sentence unit when it appears at least ``min_cycles`` times.
    The truncated text keeps the cycle exactly once so legitimate
    "stop and restart" patterns aren't lost.
    """
    if not text:
        return text
    sentences = _split_sentences(text)
    if len(sentences) < 2:
        return text
    norm = [_norm_sentence(s) for s in sentences]
    n = len(sentences)
    # Try cycle lengths 1, 2, 3. Longer-period cycles are rare and
    # likely to false-positive on legitimate parallel structure.
    for k in (1, 2, 3):
        if n < k * min_cycles:
            continue
        # Walk backwards counting how many times the last k-block
        # repeats. We compare normalised sentence content.
        last_block = norm[n - k:]
        # Skip cycles whose unit is empty / whitespace.
        if not any(s.strip() for s in last_block):
            continue
        repeats = 1
        idx = n - k
        while idx - k >= 0 and norm[idx - k:idx] == last_block:
            repeats += 1
            idx -= k
        if repeats >= min_cycles:
            # Keep everything up to and including the FIRST occurrence
            # of the cycle; drop the (repeats - 1) subsequent copies.
            keep_end = idx + k
            kept = sentences[:keep_end]
            return " ".join(kept).strip()
    return text


def _strip_unterminated_sentence_repeat(text: str) -> str:
    """Drop a trailing un-terminated phrase that duplicates a
    preceding terminated sentence.

    Production shape this catches:
      ``"Before we start, please come to the front. Before we start,
      please come to the front"``

    The model produced one terminated sentence, started writing it
    again, and got cut off by the n-gram cycle-break before the
    second period landed. ``_strip_sentence_cycle`` requires
    ``min_cycles=3`` and a terminator on every copy, so it doesn't
    fire here. The shape is:

      ``<head><sentence>.[<sentence again, no period>]\\Z``

    where the trailing copy is a prefix of the terminated copy
    (possibly identical). We compare normalised text and drop the
    tail when the prefix-match is exact + at least 5 words long
    (avoids false positives on legitimate parallel structure).
    """
    if not text:
        return text
    cleaned = text.rstrip()
    if cleaned.endswith((".", "!", "?")):
        return text  # last sentence is terminated; standard cycle strip handles it
    sentences = _split_sentences(text)
    if len(sentences) < 1:
        return text
    # Find the un-terminated tail by re-splitting on sentence enders
    # and grabbing whatever's after the last terminator.
    last_term = max(
        text.rfind("."),
        text.rfind("!"),
        text.rfind("?"),
    )
    if last_term < 0:
        return text
    tail = text[last_term + 1:].strip()
    if not tail:
        return text
    # Compare tail (possibly partial) against any preceding sentence.
    norm_tail = _norm_sentence(tail).rstrip(",;:")
    if not norm_tail or len(norm_tail.split()) < 5:
        return text
    for sent in sentences:
        norm_sent = _norm_sentence(sent).rstrip(",;:")
        # Tail must be a prefix of (or equal to) a previous sentence.
        if norm_sent.startswith(norm_tail):
            # Drop the trailing duplicate. Keep everything up to and
            # including the last terminator.
            return text[: last_term + 1].rstrip()
    return text


def _strip_repetition_tail(text: str, *, min_repeats: int = 4) -> str:
    """Drop a trailing run of identical short tokens.

    The base LM occasionally degenerates into "The The The The..." or
    "1. 1. 1. 1." when it has nothing left to transcribe. The
    ``generation_loop`` cycle-break terminates the loop, but the
    repeated tokens still land in the output. Cut them.
    """
    if not text:
        return text
    words = text.split()
    if len(words) < min_repeats:
        return text
    # Walk backwards collapsing runs of identical short words.
    end = len(words)
    while end >= min_repeats:
        last = words[end - 1].lower().rstrip(",.;:!?")
        if not last or len(last) > 8:
            break
        run = 0
        i = end - 1
        while i >= 0 and words[i].lower().rstrip(",.;:!?") == last:
            run += 1
            i -= 1
        if run >= min_repeats:
            end = i + 1
            continue
        break
    # Then drop runs of identical 2-3 word phrases at the tail
    # (e.g. "of the of the of the of the" — generation went into a
    # short-phrase loop without sentence terminators, so neither
    # _strip_phrase_cycle nor _strip_sentence_cycle catches it).
    # Drop the whole run, mirroring the single-word loop above.
    for unit_size in (2, 3):
        if end < unit_size * min_repeats:
            continue
        unit = tuple(
            w.lower().rstrip(",.;:!?")
            for w in words[end - unit_size : end]
        )
        if not all(unit) or any(len(w) > 8 for w in unit):
            continue
        run = 1
        i = end - unit_size
        while i - unit_size >= 0:
            prev = tuple(
                w.lower().rstrip(",.;:!?")
                for w in words[i - unit_size : i]
            )
            if prev != unit:
                break
            run += 1
            i -= unit_size
        if run >= min_repeats:
            end = i  # drop the whole run, not just keep one copy
    return " ".join(words[:end]).strip()


# Match a numbered-list-style fragment that's the entire output (after
# thinking-strip and phrase-cycle stripping). Production failure shape
# observed in the wild: ``"4. Come to the front and introduce"`` — a
# digit + period + space + a 3-7 word verb phrase, no trailing
# terminator. Real body text always has either (a) a sentence terminator
# or (b) >= 8 words. Generation that ngram_cycle_break-ed right after
# one such fragment is almost always a list-loop and should be
# discarded so the polite empty-extraction path fires.
_NUM_LIST_LOOP_RE = re.compile(
    r"\A\s*(?:\d{1,2}\s*[\.\)]\s*)?[A-Za-z][^.!?]{4,80}\Z"
)


def _looks_like_loop_fragment(text: str, *, ngram_broke: bool) -> bool:
    """Return True if ``text`` looks like the partial output left
    behind after a numbered-list / sentence loop was killed by the
    no-repeat-ngram cycle-break before producing a complete sentence.

    Requires ``ngram_broke=True`` so we don't drop legitimate short
    transcriptions that the model chose to terminate with EOS.
    """
    if not ngram_broke:
        return False
    cleaned = (text or "").strip()
    if not cleaned:
        return False
    # >= 8 words: even after a cycle-break the model produced enough
    # content that the partial output is recoverable text.
    if len(cleaned.split()) >= 8:
        return False
    if cleaned.rstrip()[-1:] in (".", "!", "?"):
        return False
    return _NUM_LIST_LOOP_RE.match(cleaned) is not None


# Phrases the thinking model uses inside a <think> block right before
# it transitions to the actual transcription. If a <think> block was
# never closed (cycle-break or token-budget exhaustion mid-think), look
# for one of these markers and treat anything quoted after it as the
# answer. Without this salvage path the unclosed-think output drops
# the entire (recoverable) transcription.
_THINK_TRANSITION_RES = (
    re.compile(
        r"(?:let me|i(?:'ll| will))\s+(?:transcribe|write|provide)"
        r"\s+(?:the\s+)?(?:text|transcription)\b[^:]*:\s*",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bnow,?\s+let me transcribe\b[^:]*:\s*",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bsentence by sentence\s*:\s*",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:the\s+)?(?:body\s+)?text\s+(?:reads|says|is)\s*:\s*",
        re.IGNORECASE,
    ),
)
# Quoted page-content fragments inside an unclosed think block. Real
# textbook pages don't contain dialogue-quoted templates, so a
# contiguous run of quoted segments at the end of an unclosed think
# block is the answer the model was about to deliver.
_QUOTED_SEGMENT_RE = re.compile(r'"([^"]+?)"', re.DOTALL)


def _pick_best_quoted(quoted: List[str]) -> str:
    """Given a list of quoted-string candidates from inside a <think>
    block, return the most likely "full transcription" segment.

    Heuristic: a thinking model that's about to answer typically emits
    the page's body text once as a long, mostly-complete quoted
    sentence. Earlier quoted fragments are usually short fragments
    from its planning narrative ("the line says: ..."), which often
    get truncated mid-word by the cycle-break.

    Picks the longest quoted segment IF it's substantially longer
    (≥ 1.5×) than the second-longest AND has at least 30 characters.
    Otherwise falls back to concatenating all candidates in order
    (the previous behavior). The "substantially longer" guard
    prevents picking a 60-char fragment when there's a 50-char
    competitor — those are usually two complementary fragments and
    concatenation reads better.
    """
    cleaned = [s.strip() for s in quoted if s.strip()]
    if not cleaned:
        return ""
    if len(cleaned) == 1:
        return cleaned[0]
    by_length = sorted(cleaned, key=len, reverse=True)
    longest, second = by_length[0], by_length[1]
    if len(longest) >= 30 and len(longest) >= 1.5 * len(second):
        return longest
    return " ".join(cleaned)


def _salvage_answer_from_unclosed_think(raw: str) -> str:
    """When ``<think>`` opens and never closes (cycle-break or budget
    exhaustion mid-think), salvage the answer the model was about to
    write. Two strategies, in order:

      1. Find a "now let me transcribe…:" / "text reads:" transition
         phrase inside the think block and pick the best quoted
         answer segment after it.
      2. Failing that, pick the best quoted fragment anywhere in the
         buffer — the model was already emitting the answer when it
         got cut off.

    "Best" defers to ``_pick_best_quoted``: prefers the longest
    quoted segment when it's substantially longer than its
    neighbors (typical of "the model wrote the full sentence once
    after several short planning fragments"). Falls back to
    concatenating all candidates when no single fragment dominates.

    Returns ``""`` when no salvage candidate is found.
    """
    if "<think>" not in raw.lower() or "</think>" in raw.lower():
        return ""
    # Strategy 1: transition phrase. Use the LAST match — earlier ones
    # might appear in the model's planning narration.
    last_match = None
    for pat in _THINK_TRANSITION_RES:
        for m in pat.finditer(raw):
            if last_match is None or m.end() > last_match.end():
                last_match = m
    if last_match is not None:
        tail = raw[last_match.end():].strip()
        if tail:
            quoted = _QUOTED_SEGMENT_RE.findall(tail)
            # Catch a trailing OPEN quote — the model was emitting
            # the answer when generation got cut off, so the last
            # closing-quote may never have been written. Strip the
            # opening quote and append the partial.
            partial = re.search(r'"([^"]+)\Z', tail, re.DOTALL)
            if partial is not None:
                quoted.append(partial.group(1))
            if quoted:
                return _pick_best_quoted(quoted)
            return tail
    # Strategy 2: best quoted fragment anywhere in the buffer.
    quoted_all = [m.group(1) for m in _QUOTED_SEGMENT_RE.finditer(raw)]
    # Trailing open-quote with no closer — model was emitting the
    # answer when generation got cut off. Append it as a candidate.
    partial = re.search(r'"([^"]+)\Z', raw, re.DOTALL)
    if partial is not None:
        quoted_all.append(partial.group(1))
    if not quoted_all:
        return ""
    return _pick_best_quoted(quoted_all)


def _strip_thinking(raw: str) -> str:
    """Strip ``<think>…</think>`` blocks, instruction echoes, and
    degenerate repetition tails from raw OCR output.

    The MiniCPM-o-4.5 base model is a thinking-style chat model; on
    hard / sparse pages it falls back to chat behavior — emitting a
    thought block, paraphrasing the prompt back, and (when it has
    nothing left) repeating short tokens until the cycle-break fires.
    None of those belong in the text we hand to TTS.
    """
    if not raw:
        return ""
    # Salvage path: ``<think>`` block that never closed (cycle-break
    # or budget exhaustion mid-think). Without this, the unclosed-
    # think regex below would drop the recoverable answer the model
    # was about to write. Run BEFORE the standard strip so the
    # salvaged text replaces ``raw`` and goes through the rest of
    # the cleanup chain (preamble strip, refusal check, etc.).
    if "<think>" in raw.lower() and "</think>" not in raw.lower():
        salvaged = _salvage_answer_from_unclosed_think(raw)
        if salvaged:
            raw = salvaged
    # Standard <think>...</think> stripping (handles both fully-closed
    # and unclosed-running-to-end variants).
    cleaned = _THINK_BLOCK_RE.sub("", raw)
    # Tail-only fallback: if the leading <think> opener was truncated
    # at the start of generation but the model emitted </think>
    # literally somewhere later, drop everything up to that closer.
    # We check on the raw-stripped text; "<think>" presence in the
    # ORIGINAL would already have been caught above.
    if "</think>" in cleaned.lower() and "<think>" not in cleaned.lower():
        cleaned = _THINK_CLOSE_TAIL_RE.sub("", cleaned)
    # Bracket-token soup ("[IMAGE] [PAGE] [VERBAT]..."): degenerate
    # generation; never real OCR. Detect early and return empty so
    # the polite empty-extraction path fires.
    if _looks_like_bracket_soup(cleaned):
        return ""
    # Refusal detection runs on the post-think, pre-echo-strip text.
    # _ECHO_SENTENCE_RES below removes some refusal sentences but not
    # all phrasings; if we ran the marker-count check after, partial
    # stripping could leave just one marker in residue and miss the
    # refusal. Counting on the un-stripped text is more robust.
    if _looks_like_refusal(cleaned):
        return ""
    # Drop a leading CJK instruction-echo prefix before any other
    # cleanup runs — once it's gone the existing English-preamble
    # patterns ("here's the transcription:", "the text on the page
    # is:") can match the now-leading English text.
    cleaned = _CJK_PREAMBLE_RE.sub("", cleaned, count=1)
    for pat in _ECHO_SENTENCE_RES:
        cleaned = pat.sub("", cleaned)
    cleaned = _PREAMBLE_RE.sub("", cleaned, count=1)
    cleaned = _strip_repetition_tail(cleaned)
    cleaned = _strip_unterminated_sentence_repeat(cleaned)
    cleaned = _strip_sentence_cycle(cleaned)
    cleaned = _strip_phrase_cycle(cleaned)
    cleaned = cleaned.strip()
    # Final guard: hallucinated descriptions of "what kind of content
    # this page contains" rather than verbatim transcription.
    if _looks_like_hallucinated_description(cleaned):
        return ""
    return cleaned


def _looks_like_bracket_soup(text: str) -> bool:
    """True when the output is mostly short [BRACKETED_TOKENS]."""
    if not text:
        return False
    matches = _BRACKET_TOKEN_RE.findall(text)
    if len(matches) < 5:
        return False
    bracket_chars = sum(len(m) for m in matches)
    # Whitespace doesn't count toward total — looking for the ratio of
    # bracketed-token text to total non-space text.
    non_space_total = len(re.sub(r"\s+", "", text))
    if non_space_total == 0:
        return False
    return bracket_chars / non_space_total >= 0.6


class MiniCPMO45MultimodalRuntime:
    """Compose text + vision + audio runtimes.

    Each modality method validates + encodes the input via the
    vision/audio runtime, then delegates to
    ``text_runtime.generate_text_with_embeddings(...)``. Tests inject
    deterministic encoder + step_fn callables to exercise the full
    pipeline without OpenVINO.
    """

    def __init__(
        self,
        text_runtime: MiniCPMO45TextRuntime,
        vision_runtime: MiniCPMO45VisionRuntime,
        audio_runtime: MiniCPMO45AudioRuntime,
        optimum_runtime: Optional["OptimumMiniCPMORuntime"] = None,
    ) -> None:
        self.text_runtime = text_runtime
        self.vision_runtime = vision_runtime
        self.audio_runtime = audio_runtime
        # When set, vision+text inference (generate_text,
        # generate_from_image, extract_textbook_text, no-audio
        # generate_from_mixed) routes through OVModelForVisualCausalLM
        # instead of vision_runtime + text_runtime. Audio paths stay
        # on the legacy custom runtime regardless. See PR #134 for
        # why this is needed: our hand-rolled vision_runtime feeds
        # the SigLIP IR with bytes that diverge from what the IR was
        # traced to expect; OVModelForVisualCausalLM uses the
        # processor's own preprocessing so OCR comes out verbatim.
        self.optimum_runtime = optimum_runtime
        # Per-call sub-timings written by ``generate_from_audio`` so
        # the live demo can attribute ASR latency (encoder vs LM
        # prefill vs LM decode). Outer callers read this AFTER the
        # generate call returns; we don't change the public return
        # type.
        self.last_audio_timings: Dict[str, int] = {
            "encoder_ms": 0,
            "lm_prefill_ms": 0,
            "lm_decode_ms": 0,
            "lm_step_count": 0,
        }

    @property
    def bundle(self) -> CompiledModelBundle:
        return self.text_runtime.bundle

    # ------------------------------------------------------------------
    # Modality entry points
    # ------------------------------------------------------------------

    def generate_text(self, prompt: str, max_new_tokens: int = 512) -> str:
        if self.optimum_runtime is not None:
            return self.optimum_runtime.generate_text(
                prompt, max_new_tokens=max_new_tokens
            )
        return self.text_runtime.generate_text(
            prompt, max_new_tokens=max_new_tokens
        )

    def generate_from_image(
        self,
        prompt: str,
        image_path: PathLike,
        max_new_tokens: int = 512,
    ) -> str:
        if self.optimum_runtime is not None:
            return self.optimum_runtime.generate_from_image(
                prompt, image_path, max_new_tokens=max_new_tokens
            )
        encoded = self.vision_runtime.encode_image(image_path)
        return self.text_runtime.generate_text_with_embeddings(
            prompt,
            modality_embeddings=[encoded["vision_features"]],
            modality_attention_masks=[encoded["attention_mask"]],
            modality_kinds=["vision"],
            max_new_tokens=max_new_tokens,
        )

    def generate_from_audio(
        self,
        prompt: str,
        audio_path: PathLike,
        max_new_tokens: int = 512,
        *,
        audio_offload: bool = True,
    ) -> str:
        import time as _time

        encode_t0 = _time.monotonic()
        encoded = self.audio_runtime.encode_audio(audio_path)
        encoder_ms = int((_time.monotonic() - encode_t0) * 1000)
        text, stop_reason = self.text_runtime.generate_text_with_embeddings(
            prompt,
            modality_embeddings=[encoded["audio_features"]],
            modality_attention_masks=[encoded["attention_mask"]],
            modality_kinds=["audio"],
            max_new_tokens=max_new_tokens,
            # Audio prefill scratch can overflow the OpenCL 4 GB cap
            # on integrated Intel iGPUs; the default routes the LM
            # through its CPU twin for audio calls. Operator may flip
            # this with ``--asr-on-gpu`` on the live demo when their
            # hardware doesn't hit the cap — INT4 LM forward on the
            # iGPU is ~5-10× faster than the CPU twin per turn. If
            # the GPU path raises OOM, switch back.
            audio_offload=audio_offload,
            # n-gram cycle-break. Catches multi-token loops greedy
            # argmax falls into on degenerate encoder embeddings.
            # Lowered 8 → 4 in fix/asr-tts-quality-b09cc684 after
            # session b09cc684 turn_008 leaked a 5-token
            # ``<|SOA:58 Italy <|UTT:1|>`` training identifier that
            # the 8-gram check let through. A 4-gram repeat is rare
            # in Chinese conversational speech (typical reduplication
            # like "好好好的" is shorter), so the tighter window
            # catches token-soup leaks without false-positives.
            no_repeat_ngram_size=4,
            return_stop_reason=True,
        )
        # Stash sub-timings so outer wrappers (environment_skill,
        # the live demo JSONL appender) can attribute the cost.
        step_timings = getattr(self.text_runtime, "last_step_timings", {}) or {}
        self.last_audio_timings = {
            "encoder_ms": encoder_ms,
            "lm_prefill_ms": int(step_timings.get("prefill_ms", 0) or 0),
            "lm_decode_ms": int(step_timings.get("decode_ms", 0) or 0),
            "lm_step_count": int(step_timings.get("step_count", 0) or 0),
        }
        if stop_reason == "ngram_cycle_break":
            logger.warning(
                "generate_from_audio: dropping ngram-cycle-locked "
                "transcript (%d chars).", len(text or ""),
            )
            return ""
        return text

    def generate_from_mixed(
        self,
        prompt: str,
        text: Optional[str] = None,
        image_path: Optional[PathLike] = None,
        audio_path: Optional[PathLike] = None,
        max_new_tokens: int = 512,
        *,
        token_callback: Optional[Callable[[str], None]] = None,
    ) -> str:
        # No-audio paths route through optimum when configured. Audio
        # is rejected by optimum-intel's MiniCPM-o subclass (raises
        # ValueError on audio_features), so we keep the legacy path
        # for any audio input.
        if self.optimum_runtime is not None and audio_path is None:
            full_prompt = prompt
            if text:
                full_prompt = f"{prompt}\n{text}"
            optimum_kwargs: Dict[str, Any] = {"max_new_tokens": max_new_tokens}
            if token_callback is not None:
                optimum_kwargs["token_callback"] = token_callback
            if image_path is None:
                return self.optimum_runtime.generate_text(
                    full_prompt, **optimum_kwargs
                )
            return self.optimum_runtime.generate_from_image(
                full_prompt, image_path, **optimum_kwargs
            )
        embeddings: List[Any] = []
        masks: List[Any] = []
        kinds: List[str] = []
        if image_path is not None:
            image_encoded = self.vision_runtime.encode_image(image_path)
            embeddings.append(image_encoded["vision_features"])
            masks.append(image_encoded["attention_mask"])
            kinds.append("vision")
        if audio_path is not None:
            audio_encoded = self.audio_runtime.encode_audio(audio_path)
            embeddings.append(audio_encoded["audio_features"])
            masks.append(audio_encoded["attention_mask"])
            kinds.append("audio")
        # Optional extra text is appended to the prompt directly. We
        # never inject it as a separate modality block, since the
        # tokenizer already handles plain text.
        full_prompt = prompt
        if text:
            full_prompt = f"{prompt}\n{text}"
        text_kwargs: Dict[str, Any] = {"max_new_tokens": max_new_tokens}
        if token_callback is not None:
            text_kwargs["token_callback"] = token_callback
        if not embeddings:
            return self.text_runtime.generate_text(full_prompt, **text_kwargs)
        audio_present = audio_path is not None
        # Audio leg shares the n-gram cycle-break + drop-on-cycle
        # behaviour with generate_from_audio. Image-only paths stay
        # untouched — the no-repeat constraint there would suppress
        # legitimate repeats in long descriptive captions.
        if audio_present:
            text_kwargs["no_repeat_ngram_size"] = 8
            text_kwargs["return_stop_reason"] = True
        # Image-only paths stay on GPU (the vision feature seq is
        # short enough to fit). Audio embeddings overflow GPU
        # prefill scratch on integrated iGPUs → route LM to CPU
        # twin for that call only.
        result = self.text_runtime.generate_text_with_embeddings(
            full_prompt,
            modality_embeddings=embeddings,
            modality_attention_masks=masks,
            modality_kinds=kinds,
            audio_offload=audio_present,
            **text_kwargs,
        )
        if audio_present:
            text, stop_reason = result
            if stop_reason == "ngram_cycle_break":
                logger.warning(
                    "generate_from_mixed: dropping ngram-cycle-locked "
                    "transcript (audio path).",
                )
                return ""
            return text
        return result

    def generate_from_vision_audio(
        self,
        prompt: str,
        image_path: PathLike,
        audio_path: Optional[PathLike] = None,
        max_new_tokens: int = 512,
    ) -> str:
        return self.generate_from_mixed(
            prompt=prompt,
            text=None,
            image_path=image_path,
            audio_path=audio_path,
            max_new_tokens=max_new_tokens,
        )

    def extract_textbook_text(self, image_path: PathLike) -> str:
        """Run textbook OCR. Returns ``""`` on any internal failure so
        the Skill's empty-extraction path can fire.
        """
        # New path: route through OVModelForVisualCausalLM when the
        # Skill was configured with vision_text_model_dir. The wrapper
        # handles the OCR prompt + post-strip itself; we just delegate.
        # PR #134 verified end-to-end correct OCR on
        # error/captured_textbook.jpg via this path (49.8s on CPU at
        # int8 vs 366s at fp16).
        if self.optimum_runtime is not None:
            return self.optimum_runtime.extract_textbook_text(image_path)
        try:
            encoded = self.vision_runtime.encode_image(image_path)
            text, stop_reason = self.text_runtime.generate_text_with_embeddings(
                _OCR_PROMPT,
                modality_embeddings=[encoded["vision_features"]],
                modality_attention_masks=[encoded["attention_mask"]],
                modality_kinds=["vision"],
                # Cap at a sensible page-budget. Typical textbook page
                # paragraph is 50-150 words (~100-300 tokens); 512 is
                # plenty of headroom and limits the model's room to
                # invent fictional continuation past the visible text
                # (observed: with 2048 tokens the model wrote 600+
                # tokens of original prose extending the page's last
                # sentence). The strict prompt + this cap together
                # contain the model to "transcribe and stop".
                max_new_tokens=512,
                # Stop the LM at the source when it falls into a
                # sentence-level loop ("'What?' I said. 'What?' I
                # said. ..."). The single-token cycle-break never
                # sees these because the repeated unit is a phrase.
                # 8 tokens covers ~5-7 English words.
                no_repeat_ngram_size=8,
                # Surface the cycle-break verdict so we can drop
                # truncated list-loop fragments below.
                return_stop_reason=True,
            )
        except Exception as exc:  # noqa: BLE001 - OCR fail-soft contract
            logger.warning(
                "extract_textbook_text failed: %s. Returning empty.",
                exc,
            )
            return ""
        cleaned = _strip_thinking(text or "")
        # If the no-repeat-ngram detector killed generation while only a
        # short numbered-list-style fragment had been emitted, treat the
        # output as a failed OCR (return ""). The Skill's empty-
        # extraction path then fires the polite "couldn't find readable
        # text" hint instead of speaking the truncated fragment to a
        # learner. Real failure observed: ``"4. Come to the front and
        # introduce"`` from a small-text-in-big-frame webcam capture.
        if stop_reason == "ngram_cycle_break" and _looks_like_loop_fragment(
            cleaned, ngram_broke=True
        ):
            logger.info(
                "extract_textbook_text: dropping list-loop fragment after "
                "ngram_cycle_break: %r",
                cleaned[:120],
            )
            return ""
        return cleaned

    # ------------------------------------------------------------------
    # Generic message-list dispatch (back-compat for chat() callers)
    # ------------------------------------------------------------------

    def chat(
        self,
        messages: List[Dict[str, Any]],
        max_new_tokens: int = 512,
    ) -> str:
        """Dispatch a message list by inspecting content blocks.

        Routing:
          - text-only → ``text_runtime.generate_text``
          - image block (only) → ``generate_from_image``
          - audio block (only) → ``generate_from_audio``
          - both image and audio blocks → ``generate_from_vision_audio``
        """
        if not messages:
            raise ValueError("chat: messages must be non-empty.")
        has_image = False
        has_audio = False
        first_image: Optional[str] = None
        first_audio: Optional[str] = None
        for msg in messages:
            content = msg.get("content")
            if not isinstance(content, list):
                continue
            for block in content:
                if not isinstance(block, dict):
                    continue
                if block.get("type") == "image" and block.get("image"):
                    has_image = True
                    first_image = first_image or str(block["image"])
                elif block.get("type") == "audio" and block.get("audio"):
                    has_audio = True
                    first_audio = first_audio or str(block["audio"])
        prompt = flatten_text_messages(messages)
        if has_image and has_audio and first_image is not None:
            return self.generate_from_vision_audio(
                prompt,
                first_image,
                first_audio,
                max_new_tokens=max_new_tokens,
            )
        if has_image and first_image is not None:
            return self.generate_from_image(
                prompt, first_image, max_new_tokens=max_new_tokens
            )
        if has_audio and first_audio is not None:
            return self.generate_from_audio(
                prompt, first_audio, max_new_tokens=max_new_tokens
            )
        return self.text_runtime.generate_text(
            prompt, max_new_tokens=max_new_tokens
        )

    def runtime_info(self) -> Dict[str, Any]:
        return self.text_runtime.runtime_info()


__all__ = ["MiniCPMO45MultimodalRuntime"]
