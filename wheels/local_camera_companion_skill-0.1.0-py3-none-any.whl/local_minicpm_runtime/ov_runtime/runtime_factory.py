# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Repository-owned native OpenVINO runtime factory.

This module is the only place inside the Skill that orchestrates the
construction of the native OpenVINO runtime. The upstream OpenVINO
Notebook helper file is **reference only** — we do not import,
vendor, or require it.

``create_minicpm_o45_runtime`` validates the converted IR layout,
lazy-imports OpenVINO, compiles the core sub-models with GPU-first /
CPU-fallback, and returns a fully wired ``MiniCPMO45MultimodalRuntime``.
Tasks 41–43 wired the native infer requests for the language-model
step, vision/audio embedding injection, and Token2Wav synthesis;
``create_token2wav_runtime`` returns a fully functional
``MiniCPMO45Token2WavRuntime``.

This module is import-safe without OpenVINO — the heavy import lives
inside ``OVCoreManager`` and is only triggered when a factory function
is actually called.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Optional, Union

from .compiled_model_bundle import CompiledModelBundle
from .config_profiles import get_profile_name, resolve_compile
from .model_paths import MiniCPMO45ModelPaths
from .ov_core_manager import OVCoreManager

PathLike = Union[str, Path]
logger = logging.getLogger(__name__)


def _make_lazy_factory(
    *,
    core_manager: "OVCoreManager",
    xml: Path,
    sub_model_name: str,
    anchored_device: str,
    profile: str,
) -> Any:
    """Build a zero-arg compile factory for a sub-model.

    The returned callable, on first invocation, runs ``resolve_compile``
    against the anchored device + profile, then calls
    ``core_manager.compile_model``. Errors propagate as
    ``OVRuntimeError``; the bundle's ``get(name)`` is the single point
    where lazy compile failure becomes visible to callers.

    Optional sub-models that the operator never invokes pay zero
    compile cost. Optional sub-models that *are* invoked but fail to
    compile raise just like core sub-models would — the historical
    "best-effort, drop on failure" contract was tied to eager compile
    at construction; with lazy compile, dropping a registered entry on
    its first ``.get()`` call would silently mask the error from
    callers that depend on the handle. Better to surface it.
    """

    def _compile() -> Any:
        target_device, ov_config = resolve_compile(
            sub_model_name=sub_model_name,
            requested_device=anchored_device,
            profile=profile,
        )
        return core_manager.compile_model(
            xml, target_device, config=ov_config
        )

    return _compile


def create_minicpm_o45_runtime(
    model_dir: PathLike,
    device: str = "GPU",
    fallback_device: str = "CPU",
    cache_dir: Optional[PathLike] = None,
    *,
    optimum_model_dir: Optional[PathLike] = None,
    optimum_device: str = "CPU",
    audio_encoder_device: str = "auto",
) -> Any:
    """Build a native OpenVINO multimodal runtime for MiniCPM-o 4.5.

    Sequence:
      1. ``MiniCPMO45ModelPaths.from_model_dir`` validates the IR layout
         (raises ``OVRuntimeLayoutError`` on missing required files).
      2. ``OVCoreManager(cache_dir=...)`` lazy-imports openvino on first
         use.
      3. The first core sub-model is compiled with GPU-first /
         CPU-fallback via ``compile_with_fallback``. The resolved device
         pins the bundle's ``active_device`` and ``fallback_used``.
      4. Remaining core sub-models are compiled on the same device for
         consistency. Optional sub-models (TTS, Token2Wav) are compiled
         best-effort when their files are present; failures are logged
         but don't abort the bundle.
      5. ``TokenizerAdapter.from_model_dir(...)`` lazy-imports
         transformers and loads the HF tokenizer.
      6. ``MiniCPMO45TextRuntime`` + ``MiniCPMO45VisionRuntime`` +
         ``MiniCPMO45AudioRuntime`` are wired into a
         ``MiniCPMO45MultimodalRuntime`` that exposes text / image /
         audio / mixed / vision-audio / textbook-OCR generation
         methods. The bundle is reachable as ``runtime.bundle``.

    Returns a fully wired ``MiniCPMO45MultimodalRuntime``. The
    default text path uses ``OpenVINOLanguageModelStep`` (Task 41);
    vision/audio embedding injection (Task 42) and Token2Wav TTS
    (Task 43) are wired through the same factory's companion
    ``create_token2wav_runtime``.
    """
    paths = MiniCPMO45ModelPaths.from_model_dir(model_dir)
    core_manager = OVCoreManager(cache_dir=cache_dir)
    profile = get_profile_name()
    if profile != "default":
        logger.info(
            "create_minicpm_o45_runtime: using OV config profile %r "
            "(LOCAL_CAMERA_COMPANION_OV_CONFIG_PROFILE)",
            profile,
        )

    # Compile the first core sub-model eagerly to anchor the bundle's
    # active_device + fallback_used. Every other sub-model (core +
    # optional) is registered as a lazy factory and compiled on first
    # access via bundle.get(name). This skips ~2.2 GB of compile +
    # VRAM upload for text-only free_talk requests that never invoke
    # vision / audio / TTS.
    compiled: dict = {}
    lazy_factories: Dict[str, Any] = {}
    active_device: Optional[str] = None
    fallback_used: bool = False

    core_names = paths.core_names()
    # Anchor on ``language_model`` rather than the first declared core
    # name. The LM is the autoregressive bottleneck and (with
    # cpu_offload) the one sub-model the user explicitly wants on GPU.
    # Earlier this code anchored on ``core_names[0]`` (embedding_model),
    # which under cpu_offload resolved to CPU and pinned every other
    # sub-model — including the LM — to CPU as a side effect.
    anchor_name = (
        "language_model"
        if "language_model" in core_names
        else core_names[0]
    )
    anchor_xml = paths.get(anchor_name)
    anchor_target, anchor_config = resolve_compile(
        sub_model_name=anchor_name,
        requested_device=device,
        profile=profile,
    )
    handle, active_device, fallback_used = (
        core_manager.compile_with_fallback(
            anchor_xml,
            anchor_target,
            fallback_device,
            config=anchor_config,
        )
    )
    compiled[anchor_name] = handle

    # Register lazy factories for the remaining core + optional
    # sub-models. They resolve against the freshly-anchored
    # active_device so GPU-first / CPU-fallback + cpu_offload propagate
    # consistently. Compile happens on first bundle.get(name).
    for name in core_names:
        if name == anchor_name:
            continue
        lazy_factories[name] = _make_lazy_factory(
            core_manager=core_manager,
            xml=paths.get(name),
            sub_model_name=name,
            anchored_device=active_device,
            profile=profile,
        )

    optional_names = [n for n in paths.paths if n not in core_names]
    for name in optional_names:
        lazy_factories[name] = _make_lazy_factory(
            core_manager=core_manager,
            xml=paths.get(name),
            sub_model_name=name,
            anchored_device=active_device,
            profile=profile,
        )

    # Register a CPU-pinned twin of the language model. Used by
    # OpenVINOLanguageModelStep when callers pass ``audio_offload=True``
    # — the audio modality prefill (~600+ tokens × 4096 hidden) blows
    # past the OpenCL 4 GB single-allocation cap on integrated Arc
    # iGPUs even with cpu_offload, but the CPU plugin handles the
    # same shapes fine. Skipped when the LM itself already resolved
    # to CPU (cpu_only profile, or GPU compile failed and we fell
    # back) — in that case the regular handle is the CPU one.
    if "language_model" in paths.paths and active_device != "CPU":
        lazy_factories["language_model_cpu"] = _make_lazy_factory(
            core_manager=core_manager,
            xml=paths.get("language_model"),
            sub_model_name="language_model_cpu",
            anchored_device="CPU",
            profile=profile,
        )

    # Register an NPU-pinned twin of the audio encoder. Camera
    # Companion 32 GB laptops have the audio encoder (~0.6 GB)
    # competing with the optimum LM for iGPU shared memory.
    # Routing it to NPU frees that resource and keeps the encoder
    # off the iGPU's OpenCL allocator. Only register when:
    #   - the active device is GPU (no benefit to NPU-offloading
    #     from CPU; avoid bloating bundle.names() in CPU profiles)
    #   - a dedicated static-shape NPU IR is present on disk
    #     (``openvino_audio_encoder_model_npu.xml``). The default
    #     audio_encoder export uses unbounded dynamic dims that
    #     the NPU plugin's compiler rejects with a ShapeOf error;
    #     scripts/reshape_audio_encoder_for_npu.py produces a
    #     static-shape variant that the NPU compiler accepts.
    #     Without that file present, the audio runtime's graceful
    #     fallback kicks in (resolve to the regular handle).
    if (
        "audio_encoder_model" in paths.paths
        and active_device == "GPU"
    ):
        npu_xml = paths.get("audio_encoder_model").with_name(
            "openvino_audio_encoder_model_npu.xml"
        )
        if npu_xml.is_file():
            lazy_factories["audio_encoder_model_npu"] = _make_lazy_factory(
                core_manager=core_manager,
                xml=npu_xml,
                sub_model_name="audio_encoder_model_npu",
                anchored_device="NPU",
                profile=profile,
            )

    bundle = CompiledModelBundle(
        model_dir=paths.model_dir,
        active_device=active_device,  # type: ignore[arg-type]
        fallback_used=fallback_used,
        compiled_models=compiled,
        lazy_factories=lazy_factories,
        cache_dir=cache_dir,
    )

    # Lazy: tokenizer load + runtime wrappers. ``transformers`` is
    # imported only inside ``TokenizerAdapter.from_model_dir``.
    from .audio_runtime import MiniCPMO45AudioRuntime
    from .multimodal_runtime import MiniCPMO45MultimodalRuntime
    from .text_runtime import MiniCPMO45TextRuntime
    from .tokenizer_adapter import TokenizerAdapter
    from .vision_runtime import MiniCPMO45VisionRuntime

    tokenizer = TokenizerAdapter.from_model_dir(paths.model_dir)
    text_runtime = MiniCPMO45TextRuntime(bundle=bundle, tokenizer=tokenizer)
    vision_runtime = MiniCPMO45VisionRuntime(bundle=bundle)
    audio_runtime = MiniCPMO45AudioRuntime(
        bundle=bundle,
        audio_encoder_device=audio_encoder_device,
    )

    # Optional: when an OVModelForVisualCausalLM-format dir is provided,
    # build a hybrid runtime that routes vision+text through it while
    # audio + TTS stay on the legacy bundle. See PR #134 + the Option 1
    # refactor: hand-rolled vision_runtime feeds the SigLIP IR with
    # bytes that diverge from what the IR was traced to expect; the
    # optimum-intel runtime uses the processor's own preprocessing so
    # OCR comes out verbatim.
    optimum_runtime = None
    if optimum_model_dir is not None:
        from .optimum_visual_runtime import OptimumMiniCPMORuntime

        optimum_runtime = OptimumMiniCPMORuntime(
            optimum_model_dir,
            device=optimum_device,
            cache_dir=cache_dir,
        )
        logger.info(
            "create_minicpm_o45_runtime: vision+text path routed "
            "through OptimumMiniCPMORuntime (model_dir=%s, device=%s).",
            optimum_model_dir,
            optimum_device,
        )

    return MiniCPMO45MultimodalRuntime(
        text_runtime=text_runtime,
        vision_runtime=vision_runtime,
        audio_runtime=audio_runtime,
        optimum_runtime=optimum_runtime,
    )


def create_token2wav_runtime(
    model_dir: PathLike,
    device: str = "GPU",
    fallback_device: str = "CPU",
    cache_dir: Optional[PathLike] = None,
) -> Any:
    """Build a native OpenVINO Token2Wav synthesis runtime.

    Sequence:
      1. ``MiniCPMO45ModelPaths.from_model_dir(require_token2wav=True)``
         validates the IR layout (raises ``OVRuntimeLayoutError`` if
         any of the four mandatory Token2Wav files is missing).
      2. ``OVCoreManager(cache_dir=...)`` lazy-imports openvino.
      3. The first Token2Wav sub-model is compiled with GPU-first /
         CPU-fallback. Remaining sub-models are pinned to that device.
      4. Optional TTS sub-models (the six TTS files) are compiled
         best-effort when present; per-file failures are logged but
         do not abort the runtime.
      5. Returns a fully wired ``MiniCPMO45Token2WavRuntime`` whose
         synthesis seams lazily delegate to
         ``OpenVINOToken2WavInferSteps`` (Task 43). The default
         tokenizer is a byte-fallback; pass a real ``s3tokenizer``
         adapter via ``Token2WavInferConfig.tokenizer_fn`` for
         production audio quality.
    """
    paths = MiniCPMO45ModelPaths.from_model_dir(
        model_dir, require_token2wav=True
    )
    core_manager = OVCoreManager(cache_dir=cache_dir)
    profile = get_profile_name()
    if profile != "default":
        logger.info(
            "create_token2wav_runtime: using OV config profile %r",
            profile,
        )

    # Eagerly compile only the first Token2Wav sub-model to anchor
    # active_device + fallback_used. The remaining three core
    # Token2Wav sub-models and the six optional TTS sub-models become
    # lazy factories — they compile on first access via bundle.get().
    compiled: dict = {}
    lazy_factories: Dict[str, Any] = {}
    active_device: Optional[str] = None
    fallback_used: bool = False

    token2wav_names = (
        "flow_embeddings_model",
        "flow_encoder_chunk_model",
        "flow_estimator_chunk_model",
        "hift_model",
    )
    first_name = token2wav_names[0]
    first_xml = paths.get(first_name)
    first_target, first_config = resolve_compile(
        sub_model_name=first_name,
        requested_device=device,
        profile=profile,
    )
    handle, active_device, fallback_used = (
        core_manager.compile_with_fallback(
            first_xml,
            first_target,
            fallback_device,
            config=first_config,
        )
    )
    compiled[first_name] = handle

    for name in token2wav_names[1:]:
        lazy_factories[name] = _make_lazy_factory(
            core_manager=core_manager,
            xml=paths.get(name),
            sub_model_name=name,
            anchored_device=active_device,
            profile=profile,
        )

    optional_tts = (
        "tts_embedding_model",
        "tts_language_model",
        "tts_projector_spk_model",
        "tts_projector_semantic_model",
        "tts_code_embedding_model",
        "tts_code_head_model",
    )
    for name in optional_tts:
        if name not in paths.paths:
            continue
        lazy_factories[name] = _make_lazy_factory(
            core_manager=core_manager,
            xml=paths.get(name),
            sub_model_name=name,
            anchored_device=active_device,
            profile=profile,
        )

    # Register lazy factories for the main LM + embedding + TTS-deps
    # (speaker_encoder, speech_tokenizer) when their IR files are
    # present. The native-TTS audio-token producer (PR-B Phase 4)
    # needs the main LM's hidden_states + the TTS sub-models — so
    # the Token2Wav bundle has to know about them. Cost is zero when
    # native TTS isn't used: lazy factories don't compile until
    # bundle.get(name) is called.
    extra_for_native_tts = (
        "language_model",
        "embedding_model",
        "speaker_encoder_model",
        "speech_tokenizer_model",
    )
    for name in extra_for_native_tts:
        if name not in paths.paths:
            continue
        lazy_factories[name] = _make_lazy_factory(
            core_manager=core_manager,
            xml=paths.get(name),
            sub_model_name=name,
            anchored_device=active_device,
            profile=profile,
        )

    bundle = CompiledModelBundle(
        model_dir=paths.model_dir,
        active_device=active_device,  # type: ignore[arg-type]
        fallback_used=fallback_used,
        compiled_models=compiled,
        lazy_factories=lazy_factories,
        cache_dir=cache_dir,
    )

    from .token2wav_runtime import MiniCPMO45Token2WavRuntime

    return _build_token2wav_runtime_with_optional_native_tts(
        bundle=bundle,
        model_dir=paths.model_dir,
    )


def _build_token2wav_runtime_with_optional_native_tts(
    bundle: CompiledModelBundle, model_dir: Path
) -> Any:
    """Construct ``MiniCPMO45Token2WavRuntime``, wiring the native-TTS
    tokenizer + speaker embedding when the bundle supports it.

    Routing decision:
      - If the bundle exposes every native-TTS handle (main LM,
        embedding, TTS LM, code_head, code_embedding, tts_embedding,
        tts_projector_semantic) AND a default speaker-embedding
        fixture loads cleanly → build the native tokenizer and pass
        it as ``tokenizer_fn``.
      - Otherwise fall back to the existing byte-fallback tokenizer
        path (current behaviour). Logged at INFO so operators can
        tell which path they're on.
    """
    from .native_tts import (
        MiniCPMO45NativeTTSAudioTokenizer,
        NativeTTSAudioTokenizerConfig,
        is_native_tts_supported,
    )
    from .speaker_embedding import (
        load_default_embedding,
    )
    from .token2wav_infer_steps import Token2WavInferConfig
    from .token2wav_runtime import MiniCPMO45Token2WavRuntime
    from .tokenizer_adapter import TokenizerAdapter

    tokenizer_fn = None
    speaker_embedding = None
    if is_native_tts_supported(bundle):
        try:
            speaker_embedding = load_default_embedding(
                fallback_to_zeros=False
            )
        except FileNotFoundError as exc:
            logger.info(
                "Native TTS supported but speaker-embedding fixture "
                "missing (%s); falling back to byte-fallback "
                "tokenizer + zero speaker embedding.",
                exc,
            )
            speaker_embedding = None

        if speaker_embedding is not None:
            try:
                adapter = TokenizerAdapter.from_model_dir(model_dir)
                hf_tokenizer = adapter._tokenizer  # noqa: SLF001 — intentional reach-through

                # Wrapped-prefill conditioning (upstream-faithful). The
                # native TTS sub-model was trained to read hidden states
                # from the spoken text *in its real chat context*, i.e.
                #   <|im_start|>system … <|im_start|>assistant … <|tts_bos|>
                #     spoken-text <|tts_eos|>
                # Feeding a bare encode(text) at RoPE position 0 gives
                # the LM out-of-distribution hidden states and produces
                # wrong phonemes. So we render the system+assistant prefix
                # once (add_generation_prompt=True, use_tts_template=True
                # ⇒ the prefix ends in <|tts_bos|>) and, per call, append
                # the spoken-text ids + <|tts_eos|>. native_tts slices the
                # [bos+1 : eos] region for the condition (see
                # NativeTTSAudioTokenizerConfig.tts_bos/eos_token_id).
                _TTS_SYS_PROMPT = (
                    "You are a helpful assistant. You can accept audio "
                    "and text input and output voice and text."
                )
                _prefix_ids = list(
                    hf_tokenizer.apply_chat_template(
                        [{"role": "system", "content": _TTS_SYS_PROMPT}],
                        add_generation_prompt=True,
                        use_tts_template=True,
                        enable_thinking=False,
                        tokenize=True,
                    )
                )
                _tts_bos_id = hf_tokenizer.convert_tokens_to_ids(
                    "<|tts_bos|>"
                )
                _tts_eos_id = hf_tokenizer.convert_tokens_to_ids(
                    "<|tts_eos|>"
                )

                def _text_to_token_ids(text: str) -> Any:
                    spoken = hf_tokenizer.encode(
                        text, add_special_tokens=False
                    )
                    return list(_prefix_ids) + list(spoken) + [_tts_eos_id]

                tokenizer_fn = MiniCPMO45NativeTTSAudioTokenizer(
                    bundle=bundle,
                    text_to_token_ids=_text_to_token_ids,
                    config=NativeTTSAudioTokenizerConfig(
                        tts_bos_token_id=_tts_bos_id,
                        tts_eos_token_id=_tts_eos_id,
                    ),
                )
                logger.info(
                    "Token2Wav runtime wired with native "
                    "MiniCPM-o-4.5 TTS audio-token producer + "
                    "default speaker embedding."
                )
            except Exception as exc:  # noqa: BLE001
                logger.info(
                    "Native TTS handles + speaker fixture present, "
                    "but tokenizer load failed (%s); falling back to "
                    "byte-fallback tokenizer.",
                    exc,
                )
                tokenizer_fn = None
                speaker_embedding = None
        else:
            logger.info(
                "Token2Wav runtime falling back to byte-fallback "
                "tokenizer (no speaker-embedding fixture)."
            )
    else:
        logger.info(
            "Token2Wav runtime falling back to byte-fallback "
            "tokenizer (bundle missing one or more native-TTS handles)."
        )

    if tokenizer_fn is not None and speaker_embedding is not None:
        # Inject the embedding override via Token2WavInferConfig so the
        # downstream flow_embedding + flow_encoder both pick it up.
        infer_config = Token2WavInferConfig(
            speaker_embedding=speaker_embedding,
        )
        # MiniCPMO45Token2WavRuntime doesn't take an infer_config
        # directly — it constructs OpenVINOToken2WavInferSteps lazily
        # on first call. We pre-build the inference helper with the
        # config and pass its bound methods as the seam callables.
        from .token2wav_infer_steps import OpenVINOToken2WavInferSteps

        infer_steps = OpenVINOToken2WavInferSteps(bundle, infer_config)
        runtime = MiniCPMO45Token2WavRuntime(
            bundle=bundle,
            tokenizer_fn=tokenizer_fn,
            flow_embedding_fn=infer_steps.run_flow_embedding,
            flow_encoder_fn=infer_steps.run_flow_encoder,
            flow_estimator_fn=infer_steps.run_flow_estimator,
            hift_fn=infer_steps.run_hift_vocoder,
        )

        # Wire the post-synthesis degenerate-detector's seed-advance
        # hook. ``tokenizer_fn`` is a ``MiniCPMO45NativeTTSAudioTokenizer``;
        # its ``_tts_step`` (an ``OpenVINOTTSGenerationStep``) is built
        # lazily on first call, so the lambda defers field access.
        # When the runtime detects degenerate audio it calls this
        # hook to bump ``OpenVINOTTSGenerationStep.config.sampling_seed``
        # so the retry samples a different audio-token trajectory.
        def _advance_seed() -> None:
            tts_step = getattr(tokenizer_fn, "_tts_step", None)
            if tts_step is None:
                return
            advance = getattr(tts_step, "advance_sampling_seed", None)
            if callable(advance):
                advance()

        # Symmetric reset hook called at the start of every
        # ``synthesize`` so a previous turn's degenerate-retry seed
        # bump doesn't leak into the next turn's RNG state. Without
        # this, the per-session sampling_seed drifts upward each time
        # ``_advance_seed`` fires, shifting the modal voice for every
        # subsequent utterance.
        def _reset_seed() -> None:
            tts_step = getattr(tokenizer_fn, "_tts_step", None)
            if tts_step is None:
                return
            reset = getattr(tts_step, "reset_sampling_seed", None)
            if callable(reset):
                reset()

        runtime._sampling_seed_advancer = _advance_seed
        runtime._sampling_seed_resetter = _reset_seed
        return runtime

    # Default path: legacy byte-fallback tokenizer + zero speaker
    # embedding. Backward-compatible with existing operators.
    return MiniCPMO45Token2WavRuntime(bundle=bundle)


__all__ = [
    "PathLike",
    "create_minicpm_o45_runtime",
    "create_token2wav_runtime",
]
