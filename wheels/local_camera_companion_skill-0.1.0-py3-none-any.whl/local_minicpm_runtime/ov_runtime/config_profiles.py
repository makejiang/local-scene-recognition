# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""OpenVINO compile-config profiles for memory / perf experiments.

Driven by the ``LOCAL_CAMERA_COMPANION_OV_CONFIG_PROFILE`` env var (or
the legacy ``LOCAL_ENGLISH_TUTOR_OV_CONFIG_PROFILE`` alias with a
one-shot DeprecationWarning) read in
``runtime_factory.create_minicpm_o45_runtime``. The default profile
leaves runtime behaviour identical to today's wiring.

The profiles exist so an operator can A/B/C/D-test memory strategies
on a target AI PC where ``test_real_skill_smoke_text_on_device``
currently OOMs the integrated GPU. Real measurements happen via
``scripts/run_runtime_benchmark.py --profile <name>`` which captures
``GPU_MEMORY_STATISTICS`` before / after each call.

The profile dicts are flat ``Dict[str, Any]`` because OpenVINO's
``Core.compile_model(model, device, config)`` expects the same shape.
The companion ``resolve_compile`` helper additionally returns the
resolved device — some profiles (``cpu_offload``, ``cpu_only``)
override the requested device for specific sub-models.

This module is import-safe — it does NOT import openvino. Every
caller passes the env-var-driven (device, config) pair into the OV
Core; the lookup itself is pure stdlib.
"""

from __future__ import annotations

import os
from typing import Any, Dict, FrozenSet, Optional, Tuple

from local_camera_companion_skill.env_vars import (
    ENV_OV_CONFIG_PROFILE,
    get_env,
)


_PROFILE_ENV = ENV_OV_CONFIG_PROFILE


# All valid profile names + their compile-time config dicts.
OV_CONFIG_PROFILES: Dict[str, Dict[str, Any]] = {
    "default": {},
    "low_memory": {
        # Single inference stream → lowest peak GPU memory.
        "NUM_STREAMS": "1",
        # Already the OpenVINO default; pin for clarity.
        "PERFORMANCE_HINT": "LATENCY",
        # Half-precision intermediates → ~2x smaller activations.
        "INFERENCE_PRECISION_HINT": "f16",
    },
    # cpu_offload's config is empty; the trick is the per-sub-model
    # device override below — LM stays on GPU, embedding/vision/audio
    # encoders run on CPU.
    "cpu_offload": {},
    # Sanity baseline: everything on CPU. Slow but never OOMs the GPU.
    "cpu_only": {},
}


# Sub-model names that the cpu_offload profile relocates to CPU. The
# main language model itself stays on the originally requested device
# so the autoregressive loop keeps the GPU's higher throughput.
#
# When the voice-loop is active (mic in + native TTS out) the GPU
# holds: main LM (~1.2 GB) + TTS LM (~700 MB) + audio encoder
# (~150 MB) + flow_estimator (~150 MB) + smaller heads — easily over
# the 4 GB OpenCL single-allocation cap on integrated Arc B390. The
# TTS LM is the biggest non-main weight; offloading it (and the
# Token2Wav stack, which is invoked once per turn rather than per
# token) drops GPU pressure to a single autoregressive loop.
_CPU_OFFLOAD_TARGETS: FrozenSet[str] = frozenset({
    # NOTE: ``embedding_model`` is intentionally NOT in this set.
    # The main LM calls into the embedding model once per generated
    # token; splitting them across devices forces a per-token
    # CPU↔GPU copy that destroys decode throughput. Keep them
    # co-located on whatever device the LM resolved to.
    "vision_model",
    "audio_encoder_model",
    "audio_projection_model",
    "resampler_model",
    # PR-A / PR-B native-TTS sub-models. Token2Wav (HiFT etc.)
    # benefits more from CPU than GPU on integrated chips because the
    # IRs run once per turn, not once per token.
    "tts_language_model",
    "tts_embedding_model",
    "tts_projector_semantic_model",
    "tts_projector_spk_model",
    "tts_code_embedding_model",
    "tts_code_head_model",
    "speaker_encoder_model",
    "speech_tokenizer_model",
    "flow_embeddings_model",
    "flow_encoder_chunk_model",
    "flow_estimator_chunk_model",
    "hift_model",
})


def get_profile_name(env: Optional[Dict[str, str]] = None) -> str:
    """Return the active profile name from the env (or ``"default"``).

    ``env`` is exposed as a parameter purely so hermetic tests can
    inject a fake mapping without monkeypatching ``os.environ``. The
    new ``LOCAL_CAMERA_COMPANION_OV_CONFIG_PROFILE`` wins; if only the
    legacy ``LOCAL_ENGLISH_TUTOR_OV_CONFIG_PROFILE`` is set, the
    resolver emits a one-shot DeprecationWarning.
    """
    name = (get_env(_PROFILE_ENV, env=env) or "").strip()
    return name or "default"


def resolve_compile(
    *,
    sub_model_name: str,
    requested_device: str,
    profile: Optional[str] = None,
) -> Tuple[str, Dict[str, Any]]:
    """Map ``(sub_model, requested_device, profile)`` → ``(device, config)``.

    Args:
        sub_model_name: Logical name of the IR sub-model being compiled
            (e.g. ``"language_model"``, ``"vision_model"``).
        requested_device: The device the caller asked for (typically
            ``"GPU"``); profiles may override this for specific
            sub-models.
        profile: Optional profile name. Defaults to the env-driven
            value resolved by ``get_profile_name``.

    Returns:
        ``(device, config_dict)`` — pass these as the second and
        third positional args to OpenVINO's ``Core.compile_model``.

    Raises:
        ValueError: when ``profile`` is not a known profile name.
    """
    name = (profile or get_profile_name()).lower()
    if name not in OV_CONFIG_PROFILES:
        raise ValueError(
            f"Unknown OV_CONFIG_PROFILE {name!r}; valid profiles: "
            f"{sorted(OV_CONFIG_PROFILES)}"
        )
    config = dict(OV_CONFIG_PROFILES[name])
    device = requested_device
    if name == "cpu_only":
        device = "CPU"
    elif name == "cpu_offload" and sub_model_name in _CPU_OFFLOAD_TARGETS:
        device = "CPU"
    # CPU-pinned twin of the LM (audio_offload=True path). Without a
    # thread cap the CPU plugin grabs every logical core for the
    # 600-token audio prefill; OS scheduler contention with the audio
    # encoder thread, mic capture, cv2 preview, and TTS streaming
    # threads then produces wildly non-deterministic per-turn latency
    # (session 35a933b6: same 1.3 s clip → ASR 7.5 s on one turn and
    # 128 s on the next). Capping at 6 threads leaves room for the
    # other workers. Skipped for non-CPU devices and when the caller
    # already chose ``cpu_only`` (the LM is the regular handle, not
    # a twin).
    if (
        sub_model_name == "language_model_cpu"
        and device == "CPU"
    ):
        config.setdefault("INFERENCE_NUM_THREADS", "6")
    return device, config


__all__ = [
    "OV_CONFIG_PROFILES",
    "get_profile_name",
    "resolve_compile",
]
