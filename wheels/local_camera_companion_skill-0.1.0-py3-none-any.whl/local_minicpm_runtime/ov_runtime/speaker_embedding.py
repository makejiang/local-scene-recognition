# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Speaker embedding loader + audio-to-embedding helper.

The native MiniCPM-o-4.5 TTS architecture requires a ``[1, 192]``
float32 speaker embedding to condition the Token2Wav vocoder. There
is no "default voice" baked into the IR — operators either:

  1. **Use the bundled fixture.** ``config/default_speaker_embedding.npy``
     is a precomputed ``[1, 192]`` float32 NPY shipped with the Skill.
     It's *not* a model weight; it's a single small embedding tensor
     suitable for redistribution. ``load_default_embedding()`` reads
     it via ``importlib.resources`` so it works after pip install.
  2. **Bake their own.** ``compute_from_audio(wav_path, bundle)``
     runs the converted ``openvino_speaker_encoder_model.xml`` IR
     (PR-A Phase 1) on a clean reference recording. The CLI
     ``scripts/build_speaker_embedding.py`` wraps this end-to-end.

Like the rest of ``ov_runtime``, this module is import-safe without
OpenVINO: numpy is the only mandatory runtime dependency for the
loader, and the audio-encoder path imports OpenVINO lazily.
"""

from __future__ import annotations

import logging
from importlib import resources
from pathlib import Path
from typing import Any, Optional, Union

from .compiled_model_bundle import CompiledModelBundle
from .errors import OVRuntimeDependencyError, OVRuntimeError

logger = logging.getLogger(__name__)

PathLike = Union[str, Path]

SPEAKER_EMBEDDING_DIM = 192
DEFAULT_FIXTURE_FILENAME = "default_speaker_embedding.npy"
SPEAKER_ENCODER_HANDLE = "speaker_encoder_model"


def _numpy() -> Any:
    try:
        import numpy as np  # type: ignore
    except ImportError as exc:
        raise OVRuntimeDependencyError(
            "numpy is required to load or compute speaker embeddings."
        ) from exc
    return np


def _validate_shape(arr: Any) -> Any:
    """Coerce 1D [192] → [1, 192]; raise if neither shape matches."""
    np = _numpy()
    arr = np.asarray(arr, dtype=np.float32)
    if arr.ndim == 1 and arr.shape[0] == SPEAKER_EMBEDDING_DIM:
        arr = arr.reshape(1, SPEAKER_EMBEDDING_DIM)
    if arr.shape != (1, SPEAKER_EMBEDDING_DIM):
        raise OVRuntimeError(
            "Speaker embedding must have shape "
            f"({1}, {SPEAKER_EMBEDDING_DIM}) float32; "
            f"got {tuple(arr.shape)} {arr.dtype}."
        )
    return arr


def load_embedding(path: PathLike) -> Any:
    """Load a ``[1, 192]`` float32 speaker embedding from an NPY file.

    Coerces ``[192]`` → ``[1, 192]`` for ergonomics. Raises
    ``FileNotFoundError`` if the file is missing,
    ``OVRuntimeError`` if the shape or dtype doesn't match.
    """
    np = _numpy()
    p = Path(path).expanduser()
    if not p.is_file():
        raise FileNotFoundError(
            f"Speaker embedding file not found: {p}"
        )
    arr = np.load(str(p))
    return _validate_shape(arr)


def save_embedding(path: PathLike, embedding: Any) -> Path:
    """Validate + write a ``[1, 192]`` float32 speaker embedding to NPY."""
    np = _numpy()
    arr = _validate_shape(embedding)
    out = Path(path).expanduser().resolve()
    if out.parent and not out.parent.exists():
        out.parent.mkdir(parents=True, exist_ok=True)
    np.save(str(out), arr)
    return out


def default_fixture_path() -> Path:
    """Return the filesystem path of the bundled default fixture.

    Uses ``importlib.resources.files`` so it works after a pip
    install (where the package may live in site-packages, not the
    source tree).
    """
    pkg_root = resources.files("local_minicpm_runtime")
    fixture = pkg_root / "config" / DEFAULT_FIXTURE_FILENAME
    # ``files()`` returns a Traversable; ``Path(str(t))`` gives the
    # filesystem path for an installed wheel or a source checkout.
    return Path(str(fixture))


def load_default_embedding(
    *, fallback_to_zeros: bool = False
) -> Any:
    """Load the bundled default speaker-embedding fixture.

    When the fixture is missing (e.g. unbuilt source checkout) and
    ``fallback_to_zeros=True``, return ``[1, 192]`` zeros so callers
    can still get a deterministic embedding without crashing. Audio
    quality with zeros is poor; the flag exists as a graceful-degrade
    path for the byte-fallback story.
    """
    np = _numpy()
    p = default_fixture_path()
    if not p.is_file():
        if fallback_to_zeros:
            logger.warning(
                "Default speaker-embedding fixture not found at %s; "
                "falling back to zeros (audio quality will degrade).",
                p,
            )
            return np.zeros(
                (1, SPEAKER_EMBEDDING_DIM), dtype=np.float32
            )
        raise FileNotFoundError(
            f"Default speaker-embedding fixture not found at {p}. "
            "Run scripts/build_speaker_embedding.py to generate one, "
            "or pass fallback_to_zeros=True to degrade silently."
        )
    return load_embedding(p)


def compute_from_audio(
    audio_path: PathLike,
    bundle: CompiledModelBundle,
    *,
    audio_loader: Optional[Any] = None,
) -> Any:
    """Run the speaker-encoder IR on a WAV file and return ``[1, 192]``.

    The upstream ``campplus.onnx`` (now ``openvino_speaker_encoder_model.xml``
    after PR-A Phase 1) takes audio fbank features ``[B, T, 80]`` and
    returns a ``[B, 192]`` speaker embedding. This helper:

      1. Loads the audio with ``audio_loader`` (default: ``soundfile``
         if available, else raises). Mono, 16 kHz expected.
      2. Computes 80-bin Kaldi-style fbank features (deferred to
         optional helper; raises a clear error if not available
         since this is operator-tooling, not runtime path).
      3. Runs the speaker encoder IR.
      4. Validates and returns the ``[1, 192]`` float32 embedding.

    The audio + fbank computation is non-trivial and lives outside
    the runtime hot path. v0.1 raises NotImplementedError with a
    pointer to ``scripts/build_speaker_embedding.py`` (Phase 5
    deliverable). The hermetic test suite only exercises the loader.
    """
    raise NotImplementedError(
        "compute_from_audio is not yet implemented in the runtime "
        "module. Use scripts/build_speaker_embedding.py to generate "
        "an embedding NPY from a WAV recording, then load it with "
        "load_embedding(path)."
    )


__all__ = [
    "DEFAULT_FIXTURE_FILENAME",
    "SPEAKER_EMBEDDING_DIM",
    "SPEAKER_ENCODER_HANDLE",
    "compute_from_audio",
    "default_fixture_path",
    "load_default_embedding",
    "load_embedding",
    "save_embedding",
]
