# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Logical-name → XML path resolution for the MiniCPM-o 4.5 IR layout.

Pure stdlib at import time. Used by the native runtime loader to
resolve a short logical name (e.g. ``"language_model"``) to a concrete
filesystem path under the converted IR directory.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Union

from ..minicpm_o45_model_layout import (
    logical_model_name_map,
    verify_model_layout,
)
from .errors import OVRuntimeLayoutError

PathLike = Union[str, Path]


_CORE_LOGICAL_NAMES: tuple = (
    "embedding_model",
    "language_model",
    "vision_model",
    "resampler_model",
    "audio_encoder_model",
    "audio_projection_model",
)


@dataclass(frozen=True)
class MiniCPMO45ModelPaths:
    """Resolved on-disk paths for the MiniCPM-o 4.5 IR sub-models.

    Use ``MiniCPMO45ModelPaths.from_model_dir(...)`` to construct;
    that classmethod runs the layout verifier and raises
    ``OVRuntimeLayoutError`` on any missing required file.
    """

    model_dir: Path
    paths: Dict[str, Path] = field(default_factory=dict)
    has_tts: bool = False
    has_token2wav: bool = False

    @classmethod
    def from_model_dir(
        cls,
        model_dir: PathLike,
        require_tts: bool = False,
        require_token2wav: bool = False,
    ) -> "MiniCPMO45ModelPaths":
        root = Path(model_dir).expanduser()
        result = verify_model_layout(
            root,
            include_tts=require_tts,
            include_token2wav=require_token2wav,
        )
        if not result["exists"]:
            raise OVRuntimeLayoutError(
                f"Model directory does not exist: {root}"
            )
        if not result["is_complete"]:
            raise OVRuntimeLayoutError(
                "Required model files are missing under "
                f"{root}: {result['missing_files']}"
            )
        # Map every logical name whose file is present to a Path.
        # Optional groups (TTS / token2wav) are silently absent if their
        # files were not produced by the converter.
        name_map = logical_model_name_map()
        paths: Dict[str, Path] = {}
        for logical, filename in name_map.items():
            xml_path = root / filename
            if xml_path.is_file():
                paths[logical] = xml_path
        has_tts = all(
            (root / fname).is_file()
            for fname in (
                "openvino_tts_embedding_model.xml",
                "openvino_tts_language_model.xml",
            )
        )
        has_token2wav = all(
            (root / fname).is_file()
            for fname in (
                "openvino_flow_embeddings_model.xml",
                "openvino_hift_model.xml",
            )
        )
        return cls(
            model_dir=root,
            paths=paths,
            has_tts=has_tts,
            has_token2wav=has_token2wav,
        )

    def get(self, logical_name: str) -> Path:
        if logical_name not in self.paths:
            raise KeyError(
                f"Unknown logical model name: {logical_name!r}. "
                f"Available: {sorted(self.paths)}"
            )
        return self.paths[logical_name]

    def core_names(self) -> List[str]:
        return list(_CORE_LOGICAL_NAMES)

    def as_dict(self) -> Dict[str, str]:
        return {k: str(v) for k, v in self.paths.items()}


__all__ = ["MiniCPMO45ModelPaths", "PathLike"]
