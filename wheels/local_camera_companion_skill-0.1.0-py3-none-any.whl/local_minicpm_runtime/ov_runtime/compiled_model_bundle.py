# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Compiled-model bundle for the MiniCPM-o 4.5 native runtime.

Holds the compiled OpenVINO sub-model handles produced by the
runtime factory's compile loop. The bundle is a passive container —
the runtime objects (``MiniCPMO45TextRuntime`` etc.) consume it via
``get(name)`` and ``runtime_info()``.

Sub-models can be registered eagerly (already compiled) or lazily
(a zero-arg factory that compiles + returns the handle on first
access). Lazy sub-models stay resident once materialized — there is
no eviction. This lets ``free_talk --text`` skip vision / audio / TTS
compile cost until those modes are actually invoked.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

PathLike = Union[str, Path]
logger = logging.getLogger(__name__)


class CompiledModelBundle:
    """Compiled OpenVINO sub-model handles + metadata.

    Holds two parallel maps:

    - ``_compiled[name]``: already-materialized compiled handles.
    - ``_lazy[name]``: zero-arg factory callable; invoked on first
      ``get(name)``. The result is moved to ``_compiled`` and the
      lazy entry is dropped.

    ``has(name)`` / ``names()`` reflect the union of both maps so
    callers can probe registration without forcing a compile.
    """

    def __init__(
        self,
        model_dir: PathLike,
        active_device: str,
        fallback_used: bool,
        compiled_models: Optional[Dict[str, Any]] = None,
        lazy_factories: Optional[Dict[str, Callable[[], Any]]] = None,
        cache_dir: Optional[PathLike] = None,
    ) -> None:
        self.model_dir = Path(model_dir)
        self.active_device = active_device
        self.fallback_used = bool(fallback_used)
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self._compiled: Dict[str, Any] = dict(compiled_models or {})
        self._lazy: Dict[str, Callable[[], Any]] = dict(
            lazy_factories or {}
        )

    def get(self, name: str) -> Any:
        if name in self._compiled:
            return self._compiled[name]
        if name in self._lazy:
            logger.info(
                "Lazy-compiling sub-model %r (first access)", name
            )
            handle = self._lazy[name]()
            self._compiled[name] = handle
            del self._lazy[name]
            return handle
        raise KeyError(
            f"No compiled model named {name!r}. Available: "
            f"{sorted(self.names())}"
        )

    def names(self) -> List[str]:
        return sorted(set(self._compiled) | set(self._lazy))

    def has(self, name: str) -> bool:
        return name in self._compiled or name in self._lazy

    def is_materialized(self, name: str) -> bool:
        """Return True if the sub-model has actually been compiled.

        ``has(name) and not is_materialized(name)`` means a lazy factory
        is registered but has not yet run. Useful for tests + telemetry.
        """
        return name in self._compiled

    def runtime_info(self) -> Dict[str, Any]:
        return {
            "model_dir": str(self.model_dir),
            "active_device": self.active_device,
            "fallback_used": self.fallback_used,
            "compiled_models": self.names(),
            "materialized_models": sorted(self._compiled),
            "cache_dir": str(self.cache_dir) if self.cache_dir else None,
        }


__all__ = ["CompiledModelBundle", "PathLike"]
