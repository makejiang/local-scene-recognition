# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Filesystem-only verifier for the MiniCPM-o 4.5 OpenVINO sub-model layout.

Pure stdlib. Reused by ``scripts/verify_ov_model_layout.py`` and (in later
tasks) by the model loader to fail fast with a clear diagnostic when the
user has not yet run, or has only partially run, the OpenVINO conversion
notebook.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Tuple, Union

PathLike = Union[str, Path]

CORE_FILES: Tuple[str, ...] = (
    "openvino_llm_embedding_model.xml",
    "openvino_llm_language_model.xml",
    "openvino_vision_model.xml",
    "openvino_resampler_model.xml",
    "openvino_audio_encoder_model.xml",
    "openvino_audio_projection_model.xml",
)

TTS_FILES: Tuple[str, ...] = (
    "openvino_tts_embedding_model.xml",
    "openvino_tts_language_model.xml",
    "openvino_tts_projector_spk_model.xml",
    "openvino_tts_projector_semantic_model.xml",
    "openvino_tts_code_embedding_model.xml",
    "openvino_tts_code_head_model.xml",
)

TOKEN2WAV_FILES: Tuple[str, ...] = (
    "openvino_flow_embeddings_model.xml",
    "openvino_flow_encoder_chunk_model.xml",
    "openvino_flow_estimator_chunk_model.xml",
    "openvino_hift_model.xml",
)

# Speaker-encoder + speech-tokenizer IR files. The MiniCPM-o-4.5
# upstream ships these as ONNX (``campplus.onnx``,
# ``speech_tokenizer_v2_25hz.onnx``); the Skill converts them to
# OpenVINO IR at conversion time so the runtime can stay OV-only
# (no onnxruntime dependency on the AI PC). Required for native TTS
# but optional from a layout perspective — operators who only want
# text generation can skip the ``--convert-tts-deps`` flag.
TTS_DEPS_FILES: Tuple[str, ...] = (
    "openvino_speaker_encoder_model.xml",
    "openvino_speech_tokenizer_model.xml",
)


def expected_model_files(
    include_tts: bool = True,
    include_token2wav: bool = True,
    include_tts_deps: bool = False,
) -> List[str]:
    """Return the list of expected ``.xml`` filenames for the configured set.

    Order is stable: core files, then TTS files (if requested), then
    token2wav files (if requested), then TTS-deps files (if requested).
    A new list is returned on each call so callers can mutate it freely.

    ``include_tts_deps`` defaults to False so existing operators with
    converted models that don't yet have the speaker-encoder /
    speech-tokenizer IR files don't get layout-validation errors. The
    native TTS pipeline gates itself on bundle.has(...) of those names
    rather than on layout completeness.
    """
    files: List[str] = list(CORE_FILES)
    if include_tts:
        files.extend(TTS_FILES)
    if include_token2wav:
        files.extend(TOKEN2WAV_FILES)
    if include_tts_deps:
        files.extend(TTS_DEPS_FILES)
    return files


def logical_model_name_map() -> Dict[str, str]:
    """Return ``{logical_short_name: xml_filename}`` for every IR sub-model.

    Logical names are stable, lowercase, and underscore-separated. Used
    by the native runtime loader (`ov_runtime.model_paths`) to resolve
    short identifiers to filesystem paths under ``model_dir``.
    """
    return {
        # Core (6)
        "embedding_model": "openvino_llm_embedding_model.xml",
        "language_model": "openvino_llm_language_model.xml",
        "vision_model": "openvino_vision_model.xml",
        "resampler_model": "openvino_resampler_model.xml",
        "audio_encoder_model": "openvino_audio_encoder_model.xml",
        "audio_projection_model": "openvino_audio_projection_model.xml",
        # TTS (6)
        "tts_embedding_model": "openvino_tts_embedding_model.xml",
        "tts_language_model": "openvino_tts_language_model.xml",
        "tts_projector_spk_model": "openvino_tts_projector_spk_model.xml",
        "tts_projector_semantic_model": (
            "openvino_tts_projector_semantic_model.xml"
        ),
        "tts_code_embedding_model": "openvino_tts_code_embedding_model.xml",
        "tts_code_head_model": "openvino_tts_code_head_model.xml",
        # Token2Wav (4)
        "flow_embeddings_model": "openvino_flow_embeddings_model.xml",
        "flow_encoder_chunk_model": "openvino_flow_encoder_chunk_model.xml",
        "flow_estimator_chunk_model": (
            "openvino_flow_estimator_chunk_model.xml"
        ),
        "hift_model": "openvino_hift_model.xml",
        # TTS deps (2) — converted from upstream ONNX at conversion time.
        "speaker_encoder_model": "openvino_speaker_encoder_model.xml",
        "speech_tokenizer_model": "openvino_speech_tokenizer_model.xml",
    }


def verify_model_layout(
    model_dir: PathLike,
    include_tts: bool = True,
    include_token2wav: bool = True,
    include_tts_deps: bool = False,
) -> Dict[str, Any]:
    """Inspect ``model_dir`` and report which expected files are present.

    Returns a dict with keys:
      - ``model_dir``: string form of the input path.
      - ``exists``: True when the path is an existing directory.
      - ``missing_files``: expected filenames that are not present.
      - ``present_files``: expected filenames that are present.
      - ``is_complete``: True when ``exists`` and ``missing_files`` is empty.
    """
    root = Path(model_dir).expanduser()
    expected = expected_model_files(
        include_tts=include_tts,
        include_token2wav=include_token2wav,
        include_tts_deps=include_tts_deps,
    )
    exists = root.is_dir()

    if exists:
        present_files: List[str] = []
        missing_files: List[str] = []
        for name in expected:
            (present_files if (root / name).is_file() else missing_files).append(name)
    else:
        present_files = []
        missing_files = list(expected)

    return {
        "model_dir": str(root),
        "exists": exists,
        "missing_files": missing_files,
        "present_files": present_files,
        "is_complete": exists and not missing_files,
    }


__all__ = [
    "CORE_FILES",
    "TTS_FILES",
    "TOKEN2WAV_FILES",
    "TTS_DEPS_FILES",
    "expected_model_files",
    "logical_model_name_map",
    "verify_model_layout",
]
