# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""local_minicpm_runtime — local OpenVINO runtime for MiniCPM-o 4.5.

This package owns the multimodal pipeline: OpenVINO compile lifecycle,
language model step, audio encoder, vision encoder, Token2Wav, and the
adapter shims that the upper-level ``local_camera_companion_skill``
consumes.

Renamed from ``local_english_tutor_skill`` (the original project was
an English tutor; the camera companion was built on top of the same
OpenVINO runtime). Back-compat env vars
(``LOCAL_ENGLISH_TUTOR_*``) are honoured with a one-shot
``DeprecationWarning`` from ``local_camera_companion_skill.env_vars``.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]
