# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Real-runtime adapter interfaces for MiniCPM-o 4.5 OpenVINO inference.

Importing this package is **safe without OpenVINO installed**. Native
OpenVINO inference is loaded lazily via
``ov_runtime.runtime_factory``. The upstream OpenVINO Notebook helper
is reference only and is **not** used at runtime.

See ``docs/real_model_adapter_design.md`` for the design rationale.
"""

from __future__ import annotations

from .base import OmniModelAdapter, PathLike, Token2WavAdapter
from .minicpm_o45_adapter import OpenVINOMiniCPMO45Adapter
from .token2wav_adapter import OpenVINOToken2WavAdapter

__all__ = [
    "OmniModelAdapter",
    "Token2WavAdapter",
    "PathLike",
    "OpenVINOMiniCPMO45Adapter",
    "OpenVINOToken2WavAdapter",
]
