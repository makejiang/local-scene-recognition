# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Abstract adapter interfaces for real MiniCPM-o 4.5 OpenVINO inference.

Stdlib only. Never imports OpenVINO, transformers, torch, or any heavy
real-runtime dep. Concrete adapters (``OpenVINOMiniCPMO45Adapter``,
``OpenVINOToken2WavAdapter``) lazy-import their heavy deps inside
``load()``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional, Protocol, Union, runtime_checkable

PathLike = Union[str, Path]


@runtime_checkable
class OmniModelAdapter(Protocol):
    """Adapter to MiniCPM-o 4.5 multimodal generation."""

    def load(self) -> None: ...
    def is_loaded(self) -> bool: ...
    def unload(self) -> None: ...

    def generate_text(
        self, prompt: str, max_new_tokens: int = 512
    ) -> str: ...

    def generate_from_audio(
        self,
        prompt: str,
        audio_path: PathLike,
        max_new_tokens: int = 512,
    ) -> str: ...

    def generate_from_image(
        self,
        prompt: str,
        image_path: PathLike,
        max_new_tokens: int = 512,
    ) -> str: ...

    def generate_from_mixed(
        self,
        prompt: str,
        text: Optional[str] = None,
        audio_path: Optional[PathLike] = None,
        image_path: Optional[PathLike] = None,
        max_new_tokens: int = 512,
    ) -> str: ...

    def generate_from_vision_audio(
        self,
        prompt: str,
        image_path: PathLike,
        audio_path: Optional[PathLike] = None,
        max_new_tokens: int = 512,
    ) -> str: ...

    def stream_audio_chunk(
        self, chunk: bytes, session_id: str
    ) -> Dict[str, Any]: ...

    def extract_textbook_text(self, image_path: PathLike) -> str:
        """Run an OCR-style prompt on a textbook page image.

        Implementations may return ``""`` for unreadable pages so that
        callers can fall back to a polite "couldn't find readable text"
        feedback instead of raising.
        """
        ...


@runtime_checkable
class Token2WavAdapter(Protocol):
    """Adapter to MiniCPM-o 4.5 token-to-wav TTS synthesis."""

    def load(self) -> None: ...
    def is_loaded(self) -> bool: ...
    def unload(self) -> None: ...
    def synthesize(self, text: str, output_path: PathLike) -> Path: ...


__all__ = ["OmniModelAdapter", "Token2WavAdapter", "PathLike"]
