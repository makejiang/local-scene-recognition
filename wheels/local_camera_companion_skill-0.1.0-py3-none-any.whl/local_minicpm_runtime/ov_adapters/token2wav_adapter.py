# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""OpenVINO adapter for MiniCPM-o 4.5 token2wav TTS.

This module is safe to import without OpenVINO installed. The native
runtime is loaded lazily inside :meth:`_instantiate_real_model` via
``ov_runtime.runtime_factory.create_token2wav_runtime``. The Skill
does **not** import or require any OpenVINO Notebook helper module;
the Notebook is reference material only. Real-runtime work flows
through ``_prepare_tts_input`` → ``_call_token2wav`` →
``_validate_wav_output``. Tests monkeypatch ``_instantiate_real_model``
or ``_call_token2wav`` to write a deterministic silent WAV.

The adapter pins a speaker embedding on first load so the synthesised
voice stays stable across calls. Resolution order:

  1. Explicit ``speaker_embedding_path`` constructor kwarg.
  2. ``LOCAL_CAMERA_TTS_SPEAKER`` environment variable (path to .npy).
  3. Bundled fixture
     (``local_minicpm_runtime/config/default_speaker_embedding.npy``).
  4. None (silent fallback to runtime defaults — voice may drift
     between utterances; this is the byte-fallback / zero-conditioning
     case).

See ``docs/real_tts.md`` and ``docs/real_model_adapter_design.md``.
"""

from __future__ import annotations

import logging
import os
import wave
from pathlib import Path
from typing import Any, Dict, Optional, Union

from ..minicpm_o45_model_layout import verify_model_layout

PathLike = Union[str, Path]

logger = logging.getLogger(__name__)

_SPEAKER_ENV_VAR = "LOCAL_CAMERA_TTS_SPEAKER"


class OpenVINOToken2WavAdapter:
    """Real OpenVINO token2wav TTS adapter."""

    def __init__(
        self,
        model_dir: PathLike,
        device: str = "GPU",
        fallback_device: str = "CPU",
        cache_dir: Optional[PathLike] = None,
        speaker_embedding_path: Optional[PathLike] = None,
    ) -> None:
        self.model_dir = Path(model_dir)
        self.device = device
        self.fallback_device = fallback_device
        self.cache_dir = (
            Path(cache_dir) if cache_dir is not None else None
        )
        self.speaker_embedding_path = (
            Path(speaker_embedding_path)
            if speaker_embedding_path is not None
            else None
        )
        self._loaded: bool = False
        self._tts_model: Any = None
        self._active_device: Optional[str] = None
        self._fallback_used: bool = False
        # Resolved + cached on first ``load()``. None means we couldn't
        # find one and the runtime's own defaults will be used.
        self._speaker_embedding: Any = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def load(self) -> None:
        """Validate IR layout, then build the native OpenVINO runtime.

        Task 41: self-cleaning on failure — if layout validation or
        :meth:`_instantiate_real_model` raises, every runtime attribute
        is cleared before the exception propagates. The pipeline-level
        rollback (which calls ``unload()`` on the failing adapter)
        sees a clean slate.

        Raises:
            FileNotFoundError: if the IR layout is missing or incomplete.
            RuntimeError: if the native runtime factory raises (e.g. the
                native loader is not implemented yet, or both primary
                and fallback devices fail).
        """
        try:
            result = verify_model_layout(
                self.model_dir, include_tts=True, include_token2wav=True
            )
            if not result["exists"]:
                raise FileNotFoundError(
                    f"Model directory does not exist: {self.model_dir}"
                )
            if not result["is_complete"]:
                raise FileNotFoundError(
                    "MiniCPM-o 4.5 OpenVINO TTS layout is incomplete. "
                    f"Missing files: {result['missing_files']}"
                )
            self._instantiate_real_model()
            self._resolve_and_pin_speaker_embedding()
        except BaseException:
            self._loaded = False
            self._tts_model = None
            self._active_device = None
            self._fallback_used = False
            self._speaker_embedding = None
            raise
        self._loaded = True

    def _resolve_and_pin_speaker_embedding(self) -> None:
        """Resolve a speaker embedding (CLI arg → env var → fixture)
        and pin it onto ``self._tts_model`` if the runtime exposes a
        ``pin_speaker_embedding`` method.

        Failure to load a speaker embedding is logged at INFO and
        does not raise — the runtime falls back to its existing
        default behavior (voice may drift, but synthesis still works).
        """
        from ..ov_runtime.speaker_embedding import (
            load_default_embedding,
            load_embedding,
        )

        emb: Any = None
        source: str = ""
        try:
            if self.speaker_embedding_path is not None:
                emb = load_embedding(self.speaker_embedding_path)
                source = f"explicit path {self.speaker_embedding_path.name}"
            else:
                env_val = (os.environ.get(_SPEAKER_ENV_VAR) or "").strip()
                if env_val:
                    emb = load_embedding(env_val)
                    source = f"${_SPEAKER_ENV_VAR}"
                else:
                    emb = load_default_embedding(fallback_to_zeros=False)
                    source = "bundled fixture"
        except Exception as exc:  # noqa: BLE001
            logger.info(
                "Speaker embedding could not be loaded (%s); the "
                "Token2Wav runtime will use its default conditioning. "
                "TTS voice may drift between utterances.",
                exc,
            )
            return

        self._speaker_embedding = emb
        pin = getattr(self._tts_model, "pin_speaker_embedding", None)
        if not callable(pin):
            logger.info(
                "Token2Wav runtime exposes no pin_speaker_embedding "
                "method; falling back to its default voice. Source "
                "of unused embedding: %s.",
                source,
            )
            return
        try:
            pin(emb)
            logger.info(
                "Pinned Token2Wav speaker embedding (source: %s).",
                source,
            )
        except Exception as exc:  # noqa: BLE001
            logger.info(
                "Failed to pin Token2Wav speaker embedding (%s); "
                "runtime will use its default conditioning.",
                exc,
            )

    def _instantiate_real_model(self) -> None:
        """Lazy-build the native OpenVINO Token2Wav runtime via the factory.

        Sets ``self._tts_model``, ``self._active_device``, and
        ``self._fallback_used``. Tries ``self.device`` first; on
        failure, falls back to ``self.fallback_device``. Tests
        monkeypatch this method to inject a fake ``_tts_model`` handle.
        """
        from ..ov_runtime.errors import OVRuntimeNotImplementedError
        from ..ov_runtime.runtime_factory import create_token2wav_runtime

        seen: set[str] = set()
        last_exc: Optional[Exception] = None
        for device in (self.device, self.fallback_device):
            if device is None or device in seen:
                continue
            seen.add(device)
            try:
                self._tts_model = create_token2wav_runtime(
                    model_dir=self.model_dir,
                    device=device,
                    fallback_device=self.fallback_device,
                    cache_dir=self.cache_dir,
                )
                self._active_device = device
                self._fallback_used = device != self.device
                logger.info(
                    "OpenVINOToken2WavAdapter loaded on device=%s "
                    "(fallback_used=%s)",
                    device,
                    self._fallback_used,
                )
                return
            except Exception as exc:
                last_exc = exc
                logger.warning(
                    "Native OpenVINO TTS load failed on device=%s: %s",
                    device,
                    exc,
                )

        # Surface the placeholder error directly so callers can catch it
        # as NotImplementedError. For other failure modes, wrap in a
        # readable RuntimeError.
        if isinstance(last_exc, OVRuntimeNotImplementedError):
            raise last_exc
        raise RuntimeError(
            "Failed to build native OpenVINO Token2Wav runtime on any of: "
            f"{[self.device, self.fallback_device]}. Last error: {last_exc}"
        ) from last_exc

    def is_loaded(self) -> bool:
        return self._loaded

    def unload(self) -> None:
        self._loaded = False
        self._tts_model = None
        self._active_device = None
        self._fallback_used = False
        self._speaker_embedding = None

    def runtime_info(self) -> Dict[str, Any]:
        return {
            "active_device": self._active_device,
            "model_dir": str(self.model_dir),
            "loaded": self._loaded,
            "fallback_used": self._fallback_used,
        }

    # ------------------------------------------------------------------
    # Synthesis
    # ------------------------------------------------------------------

    def synthesize(
        self, text: str, output_path: PathLike, base_seed: int = 0
    ) -> Path:
        """Synthesize ``text`` to a WAV file at ``output_path``.

        Pipeline: ``_prepare_tts_input`` → ``_call_token2wav`` →
        ``_validate_wav_output``. Returns the resolved output path on
        success. ``base_seed`` offsets the sampling seed (content-verify
        re-synthesis).

        Raises:
            RuntimeError: if not loaded.
            ValueError: for empty / unusable text.
            RuntimeError: if the produced file is missing or invalid.
        """
        self._require_loaded()
        prepared = self._prepare_tts_input(text)
        out = Path(output_path).expanduser().resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        self._call_token2wav(prepared, out, base_seed=base_seed)
        self._validate_wav_output(out)
        return out

    # ------------------------------------------------------------------
    # Internal helpers (testable seams)
    # ------------------------------------------------------------------

    def _require_loaded(self) -> None:
        if not self._loaded or self._tts_model is None:
            raise RuntimeError(
                "OpenVINOToken2WavAdapter is not loaded — call load() first."
            )

    def _prepare_tts_input(self, text: str) -> str:
        """Validate and lightly normalize input text for the TTS model.

        Rules:
          - empty / whitespace-only → ``ValueError``.
          - collapses internal whitespace.
        """
        if text is None or not str(text).strip():
            raise ValueError(
                "OpenVINOToken2WavAdapter.synthesize: text must be non-empty."
            )
        return " ".join(str(text).split())

    def _call_token2wav(  # pragma: no cover - real path
        self, prepared_input: str, output_path: Path, base_seed: int = 0
    ) -> None:
        """Invoke the native runtime handle. Tests monkeypatch this.

        The handle is created by ``ov_runtime.runtime_factory`` and
        exposes ``synthesize(text, output_path, base_seed)``.
        """
        if self._tts_model is None:
            raise RuntimeError("Adapter has no loaded _tts_model.")
        self._tts_model.synthesize(
            prepared_input, str(output_path), base_seed=base_seed
        )

    def _validate_wav_output(self, output_path: Path) -> None:
        """Re-open the file with ``wave`` to confirm it's a real WAV.

        Catches the failure mode where the helper silently writes 0
        bytes or produces a non-WAV payload.
        """
        if not output_path.is_file() or output_path.stat().st_size == 0:
            raise RuntimeError(
                f"TTS output is empty or missing: {output_path}"
            )
        try:
            with wave.open(str(output_path), "rb") as wf:
                if wf.getnframes() <= 0:
                    raise RuntimeError(
                        f"TTS output WAV has no audio frames: {output_path}"
                    )
        except wave.Error as exc:
            raise RuntimeError(
                f"TTS output is not a valid WAV: {output_path} ({exc})"
            ) from exc


__all__ = ["OpenVINOToken2WavAdapter"]
