# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""OpenVINO adapter for MiniCPM-o 4.5 multimodal generation.

This module is safe to import without OpenVINO installed. The native
runtime is loaded lazily inside :meth:`_instantiate_real_model` via
``ov_runtime.runtime_factory.create_minicpm_o45_runtime``. The Skill
does **not** import or require any OpenVINO Notebook helper module;
the Notebook is reference material only. Tests monkeypatch
``_instantiate_real_model`` to inject a fake ``_ov_model`` so the
adapter contract is exercised without OpenVINO.

See ``docs/real_generation.md`` and
``docs/real_model_adapter_design.md``.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Union

from ..minicpm_o45_model_layout import verify_model_layout

PathLike = Union[str, Path]

logger = logging.getLogger(__name__)


class OpenVINOMiniCPMO45Adapter:
    """Real MiniCPM-o 4.5 OpenVINO adapter.

    Constructor only stores config. ``load()`` validates the IR layout
    then calls :meth:`_instantiate_real_model` which is the only place
    the native OpenVINO runtime is built (via
    ``ov_runtime.runtime_factory``).
    """

    def __init__(
        self,
        model_dir: PathLike,
        device: str = "GPU",
        fallback_device: str = "CPU",
        cache_dir: Optional[PathLike] = None,
        enable_tts_layout: bool = True,
        *,
        vision_text_model_dir: Optional[PathLike] = None,
        vision_text_device: str = "CPU",
        audio_encoder_device: str = "auto",
    ) -> None:
        self.model_dir = Path(model_dir)
        self.device = device
        self.fallback_device = fallback_device
        self.cache_dir = (
            Path(cache_dir) if cache_dir is not None else None
        )
        self.enable_tts_layout = enable_tts_layout
        # Optional: separate model dir in optimum-intel's 6-file layout.
        # When provided, vision+text inference (OCR / generate_from_image
        # / generate_text) routes through OVModelForVisualCausalLM
        # instead of the legacy custom path. Audio + TTS still use the
        # 18-file custom layout. See docs/ocr_runtime_preprocessing_bug.md.
        self.vision_text_model_dir = (
            Path(vision_text_model_dir)
            if vision_text_model_dir is not None
            else None
        )
        self.vision_text_device = vision_text_device
        # Optional NPU offload for the audio encoder. When ``"NPU"``
        # the runtime resolves the ``audio_encoder_model_npu`` bundle
        # twin (registered by runtime_factory) and the encoder runs
        # there. Frees ~0.6 GB shared GPU memory on integrated Arc
        # systems. Default ``"auto"`` keeps existing behaviour.
        self.audio_encoder_device = audio_encoder_device

        self._loaded: bool = False
        self._ov_model: Any = None
        self._active_device: Optional[str] = None
        self._fallback_used: bool = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def load(self) -> None:
        """Validate layout and build the native OpenVINO runtime.

        Task 41: this method is *self-cleaning* on failure. If layout
        validation or :meth:`_instantiate_real_model` raises, every
        runtime attribute is cleared before the exception propagates
        so the pipeline-level rollback (which calls ``unload()`` on
        the failing adapter) sees a clean slate and a retry can
        succeed.

        Raises:
            FileNotFoundError: if the IR layout is missing or incomplete.
            RuntimeError: if the native runtime factory raises (e.g.
                both primary and fallback devices fail to compile, or
                a missing optional dependency surfaces).
        """
        try:
            result = verify_model_layout(
                self.model_dir,
                include_tts=self.enable_tts_layout,
                include_token2wav=self.enable_tts_layout,
            )
            if not result["exists"]:
                raise FileNotFoundError(
                    f"Model directory does not exist: {self.model_dir}"
                )
            if not result["is_complete"]:
                raise FileNotFoundError(
                    "MiniCPM-o 4.5 OpenVINO model layout is incomplete. "
                    f"Missing files: {result['missing_files']}"
                )

            self._instantiate_real_model()
        except BaseException:
            # Drop any partial native handles before re-raising.
            self._loaded = False
            self._ov_model = None
            self._active_device = None
            self._fallback_used = False
            raise
        self._loaded = True

    def _instantiate_real_model(self) -> None:
        """Lazy-build the native OpenVINO runtime via the repository factory.

        Sets ``self._ov_model``, ``self._active_device``, and
        ``self._fallback_used``. Tries ``self.device`` first; on any
        exception, falls back to ``self.fallback_device``. Tests
        monkeypatch this method to inject a fake ``_ov_model``
        directly.
        """
        from ..ov_runtime.errors import OVRuntimeNotImplementedError
        from ..ov_runtime.runtime_factory import create_minicpm_o45_runtime

        seen: set[str] = set()
        last_exc: Optional[Exception] = None
        for device in (self.device, self.fallback_device):
            if device is None or device in seen:
                continue
            seen.add(device)
            try:
                self._ov_model = create_minicpm_o45_runtime(
                    model_dir=self.model_dir,
                    device=device,
                    fallback_device=self.fallback_device,
                    cache_dir=self.cache_dir,
                    optimum_model_dir=self.vision_text_model_dir,
                    optimum_device=self.vision_text_device,
                    audio_encoder_device=self.audio_encoder_device,
                )
                self._active_device = device
                self._fallback_used = device != self.device
                logger.info(
                    "OpenVINOMiniCPMO45Adapter loaded on device=%s "
                    "(fallback_used=%s)",
                    device,
                    self._fallback_used,
                )
                return
            except Exception as exc:
                last_exc = exc
                logger.warning(
                    "Native OpenVINO load failed on device=%s: %s. "
                    "Trying next device.",
                    device,
                    exc,
                )

        # Surface the placeholder error directly so callers can catch it
        # as NotImplementedError. For other failure modes, wrap in a
        # readable RuntimeError that includes the device list tried.
        if isinstance(last_exc, OVRuntimeNotImplementedError):
            raise last_exc
        raise RuntimeError(
            "Failed to build native OpenVINO MiniCPM-o 4.5 runtime "
            f"on any of: {[self.device, self.fallback_device]}. "
            f"Last error: {last_exc}"
        ) from last_exc

    def is_loaded(self) -> bool:
        return self._loaded

    def unload(self) -> None:
        self._loaded = False
        self._ov_model = None
        self._active_device = None
        self._fallback_used = False

    def runtime_info(self) -> Dict[str, Any]:
        return {
            "active_device": self._active_device,
            "model_dir": str(self.model_dir),
            "loaded": self._loaded,
            "fallback_used": self._fallback_used,
        }

    # ------------------------------------------------------------------
    # Generation
    # ------------------------------------------------------------------

    def generate_text(
        self,
        prompt: str,
        max_new_tokens: int = 512,
        *,
        token_callback: Optional[Callable[[str], None]] = None,
    ) -> str:
        self._require_loaded()
        # Direct call: the native runtime exposes generate_text(prompt, ...).
        # Non-text modalities below still funnel through _call_real_model
        # → runtime.chat(...), which raises OVRuntimeNotImplementedError
        # for non-text content blocks until follow-up tasks land.
        # Forward ``token_callback`` only when set so test fakes that
        # predate token streaming keep accepting the call unchanged.
        kwargs: Dict[str, Any] = {"max_new_tokens": max_new_tokens}
        if token_callback is not None:
            kwargs["token_callback"] = token_callback
        return self._ov_model.generate_text(prompt, **kwargs)

    def generate_from_audio(
        self,
        prompt: str,
        audio_path: PathLike,
        max_new_tokens: int = 512,
        *,
        audio_offload: bool = True,
    ) -> str:
        self._require_loaded()
        return self._ov_model.generate_from_audio(
            prompt,
            audio_path,
            max_new_tokens=max_new_tokens,
            audio_offload=audio_offload,
        )

    def generate_from_image(
        self,
        prompt: str,
        image_path: PathLike,
        max_new_tokens: int = 512,
        *,
        token_callback: Optional[Callable[[str], None]] = None,
    ) -> str:
        self._require_loaded()
        kwargs: Dict[str, Any] = {"max_new_tokens": max_new_tokens}
        if token_callback is not None:
            kwargs["token_callback"] = token_callback
        return self._ov_model.generate_from_image(
            prompt, image_path, **kwargs
        )

    def generate_from_mixed(
        self,
        prompt: str,
        text: Optional[str] = None,
        audio_path: Optional[PathLike] = None,
        image_path: Optional[PathLike] = None,
        max_new_tokens: int = 512,
        *,
        token_callback: Optional[Callable[[str], None]] = None,
    ) -> str:
        self._require_loaded()
        if not text and not audio_path and not image_path:
            raise ValueError(
                "generate_from_mixed requires at least one of: text, "
                "audio_path, image_path."
            )
        kwargs: Dict[str, Any] = {
            "text": text,
            "image_path": image_path,
            "audio_path": audio_path,
            "max_new_tokens": max_new_tokens,
        }
        if token_callback is not None:
            kwargs["token_callback"] = token_callback
        return self._ov_model.generate_from_mixed(prompt, **kwargs)

    def generate_from_vision_audio(
        self,
        prompt: str,
        image_path: PathLike,
        audio_path: Optional[PathLike] = None,
        max_new_tokens: int = 512,
    ) -> str:
        self._require_loaded()
        return self._ov_model.generate_from_vision_audio(
            prompt,
            image_path,
            audio_path,
            max_new_tokens=max_new_tokens,
        )

    def stream_audio_chunk(
        self, chunk: bytes, session_id: str
    ) -> Dict[str, Any]:
        raise NotImplementedError(
            "Real-mode stream_audio_chunk is not implemented yet. "
            "See docs/real_generation.md and Task 29."
        )

    def extract_textbook_text(self, image_path: PathLike) -> str:
        """Run a textbook-OCR prompt on the page image.

        Delegates to the native multimodal runtime, which validates the
        image, encodes it, builds the OCR prompt, runs the text
        generation loop, and returns the transcribed text. **Returns
        an empty string on any failure** so the Skill's existing
        empty-extraction path can emit a polite "couldn't find
        readable text" feedback instead of raising.
        """
        self._require_loaded()
        return self._ov_model.extract_textbook_text(image_path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _require_loaded(self) -> None:
        if not self._loaded or self._ov_model is None:
            raise RuntimeError(
                "OpenVINOMiniCPMO45Adapter is not loaded — call load() first."
            )


__all__ = ["OpenVINOMiniCPMO45Adapter"]
