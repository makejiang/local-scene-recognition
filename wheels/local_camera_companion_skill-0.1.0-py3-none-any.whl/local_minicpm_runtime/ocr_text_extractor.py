# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""OCR text extraction utilities.

Pure stdlib at import time — no PIL or OCR engine touched. The mock
extractor returns deterministic textbook-style content so the rest of
the Skill can be exercised end-to-end without a real OCR engine. The
canonical mock block is exposed as :data:`MOCK_TEXTBOOK_BLOCK` so the
multimodal pipeline mock can stay in sync.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import List, Union

PathLike = Union[str, Path]

logger = logging.getLogger(__name__)


MOCK_TEXTBOOK_BLOCK = (
    "Chapter 3: The Water Cycle\n"
    "\n"
    "Water moves through the environment in a continuous cycle. "
    "The sun heats water in oceans and lakes, causing evaporation. "
    "Water vapor rises into the atmosphere and condenses into clouds. "
    "When clouds become heavy, they release water as rain or snow. "
    "This is how the water cycle keeps our planet's water in motion."
)


_WS_RE = re.compile(r"\s+")
_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")


class OCRTextExtractor:
    """Filesystem-light OCR helper.

    Mock mode returns deterministic textbook content (used by tests and
    by ``MiniCPMO45Pipeline`` mock). Real mode is intentionally a stub —
    a future task can lazy-import a real OCR engine inside
    :meth:`extract_text_from_image`.
    """

    def __init__(self, mock: bool = True) -> None:
        self.mock = bool(mock)

    # ------------------------------------------------------------------
    # Extraction
    # ------------------------------------------------------------------

    def extract_text_from_image(self, image_path: PathLike) -> str:
        # Resolve defensively but never validate (CameraInputHandler does that).
        Path(image_path).expanduser()
        if self.mock:
            return MOCK_TEXTBOOK_BLOCK
        # TODO(future): lazy-import pytesseract or paddleocr for real OCR.
        raise NotImplementedError(
            "Real-mode OCR is not implemented yet. Use OCRTextExtractor(mock=True) "
            "or wire in a real engine in a later task."
        )

    # ------------------------------------------------------------------
    # Cleaning / splitting
    # ------------------------------------------------------------------

    def clean_ocr_text(self, text: str) -> str:
        if not text:
            return ""
        return _WS_RE.sub(" ", text).strip()

    def split_into_sentences(self, text: str) -> List[str]:
        cleaned = self.clean_ocr_text(text)
        if not cleaned:
            return []
        parts = _SENTENCE_SPLIT_RE.split(cleaned)
        return [p.strip() for p in parts if p.strip()]

    def extract_reading_candidates(self, text: str) -> List[str]:
        sentences = self.split_into_sentences(text)
        if not sentences:
            return []
        candidates = [
            s for s in sentences
            if 5 <= len(s.split()) and len(s) <= 200
        ]
        return candidates if candidates else sentences


__all__ = ["OCRTextExtractor", "MOCK_TEXTBOOK_BLOCK"]
