# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Camera and image input gatekeeper for the Skill.

Validates uploaded textbook image files before they reach the model
wrapper. Optionally captures a single frame from a local PC camera via
OpenCV (``cv2``); ``cv2`` is imported lazily inside ``capture_from_camera``
so the package imports cleanly on machines without it.

Pillow is a hard dependency because the Issue lists "PIL can open image"
as a validation rule.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Union

from PIL import Image, UnidentifiedImageError

PathLike = Union[str, Path]

logger = logging.getLogger(__name__)

DEFAULT_ALLOWED_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp")
DEFAULT_MAX_IMAGE_SIZE_MB = 20
DEFAULT_CAMERA_INDEX = 0


class CameraInputHandler:
    """Validates image files and (optionally) captures from a PC camera."""

    def __init__(
        self,
        allowed_extensions: Sequence[str] = DEFAULT_ALLOWED_EXTENSIONS,
        max_image_size_mb: float = DEFAULT_MAX_IMAGE_SIZE_MB,
        camera_index: int = DEFAULT_CAMERA_INDEX,
        strict_validation: bool = True,
    ) -> None:
        self.allowed_extensions = tuple(
            (ext if ext.startswith(".") else f".{ext}").lower()
            for ext in allowed_extensions
        )
        self.max_image_size_mb = float(max_image_size_mb)
        self.camera_index = int(camera_index)
        self.strict_validation = bool(strict_validation)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_image_file(self, path: PathLike) -> Path:
        """Return the resolved Path if the file passes all checks.

        Raises:
            FileNotFoundError: when the file does not exist.
            ValueError: for unsupported extension, empty file, oversized
                file, or (when strict) an image that PIL cannot open.
        """
        p = Path(path).expanduser()
        if not p.is_file():
            raise FileNotFoundError(f"Image file not found: {p}")

        ext = p.suffix.lower()
        if ext not in self.allowed_extensions:
            raise ValueError(
                f"Unsupported image extension: {ext!r}; "
                f"allowed: {sorted(self.allowed_extensions)}"
            )

        size_bytes = p.stat().st_size
        if size_bytes <= 0:
            raise ValueError(f"Image file is empty: {p}")

        size_mb = size_bytes / (1024 * 1024)
        if size_mb > self.max_image_size_mb:
            raise ValueError(
                f"Image too large: {size_mb:.2f} MB > "
                f"limit {self.max_image_size_mb} MB ({p})"
            )

        if self.strict_validation:
            try:
                with Image.open(p) as img:
                    img.verify()
            except (UnidentifiedImageError, OSError) as exc:
                raise ValueError(
                    f"Image cannot be opened by PIL: {p} ({exc})"
                ) from exc

        return p

    def prepare_image_for_model(self, path: PathLike) -> Path:
        """Validate the file and return its resolved path.

        Decoding / resizing is intentionally left to the model wrapper.
        """
        return self.validate_image_file(path)

    def get_image_metadata(self, path: PathLike) -> Dict[str, Any]:
        """Return basic image metadata after validation."""
        p = self.validate_image_file(path)
        size_bytes = p.stat().st_size
        size_mb = size_bytes / (1024 * 1024)
        # `verify()` consumed the file in validate_image_file; reopen here.
        with Image.open(p) as img:
            metadata: Dict[str, Any] = {
                "path": str(p),
                "size_bytes": size_bytes,
                "size_mb": round(size_mb, 6),
                "format": img.format,
                "mode": img.mode,
                "width": img.width,
                "height": img.height,
            }
        return metadata

    # ------------------------------------------------------------------
    # Optional camera capture
    # ------------------------------------------------------------------

    def capture_from_camera(
        self,
        output_path: PathLike,
        camera_index: Optional[int] = None,
    ) -> Path:
        """Capture a single frame from the local camera.

        ``cv2`` is imported lazily; if it isn't installed we raise a
        clear ``RuntimeError`` pointing the user at ``pip install opencv-python``.
        Hardware-dependent failures (no camera attached, can't open
        device, frame read failed) also raise ``RuntimeError``.
        """
        idx = self.camera_index if camera_index is None else int(camera_index)

        out = Path(output_path).expanduser()
        if out.parent and not out.parent.exists():
            out.parent.mkdir(parents=True, exist_ok=True)

        try:
            import cv2  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "Camera capture requires the optional 'opencv-python' "
                "package (cv2). Install it with `pip install opencv-python`."
            ) from exc

        # pragma: no cover - everything below requires real hardware
        cap = cv2.VideoCapture(idx)
        try:
            if not cap.isOpened():
                raise RuntimeError(
                    f"Could not open camera at index {idx}"
                )
            ok, frame = cap.read()
            if not ok or frame is None:
                raise RuntimeError(
                    "Failed to read a frame from the camera"
                )
            if not cv2.imwrite(str(out), frame):
                raise RuntimeError(
                    f"Failed to write captured frame to {out}"
                )
        finally:
            cap.release()

        return out

    def capture_frames(
        self,
        output_dir: PathLike,
        count: int,
        *,
        name_prefix: str = "frame",
        extension: str = ".png",
        delay_seconds: float = 0.0,
        camera_index: Optional[int] = None,
    ) -> List[Path]:
        """Capture ``count`` frames into ``output_dir``.

        Convenience wrapper for the auto-capture controller; equivalent
        to calling :meth:`capture_from_camera` ``count`` times with
        ``delay_seconds`` between calls. Hardware-only — covered by the
        same lazy-cv2 import path as :meth:`capture_from_camera`.

        Returns the list of saved frame paths in capture order.
        """

        if int(count) <= 0:
            raise ValueError(f"count must be >= 1, got {count!r}")

        out_dir = Path(output_dir).expanduser()
        out_dir.mkdir(parents=True, exist_ok=True)

        ext = extension if extension.startswith(".") else f".{extension}"

        # pragma: no cover - hardware path delegated to capture_from_camera
        paths: List[Path] = []
        for i in range(1, int(count) + 1):
            frame_path = out_dir / f"{name_prefix}_{i:03d}{ext}"
            self.capture_from_camera(frame_path, camera_index=camera_index)
            paths.append(frame_path)
            if i < int(count) and delay_seconds > 0:
                time.sleep(float(delay_seconds))
        return paths


__all__ = [
    "CameraInputHandler",
    "DEFAULT_ALLOWED_EXTENSIONS",
    "DEFAULT_MAX_IMAGE_SIZE_MB",
    "DEFAULT_CAMERA_INDEX",
]
