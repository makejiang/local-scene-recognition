# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Mockable wrapper around the MiniCPM-o 4.5 OpenVINO pipeline.

Mock mode is fully deterministic and never imports OpenVINO,
transformers, torch, audio I/O, or anything heavy. Real mode delegates
to ``ov_adapters``; the adapters in turn call the repository-owned
native OpenVINO runtime in ``ov_runtime/runtime_factory.py``. The
OpenVINO Notebook helper is reference only and is not imported by the
Skill (see the upstream Notebook for reference material:
https://github.com/openvinotoolkit/openvino_notebooks/blob/latest/notebooks/minicpm-o-4.5/minicpm-o-4.5.ipynb).

The module's top-level imports are stdlib + this package only, so
``import local_minicpm_runtime.minicpm_o45_pipeline`` works on a
machine without OpenVINO installed.
"""

from __future__ import annotations

import logging
import os
import wave
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Union

from .minicpm_o45_model_layout import verify_model_layout
from .ocr_text_extractor import MOCK_TEXTBOOK_BLOCK

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .ov_adapters.base import OmniModelAdapter, Token2WavAdapter

PathLike = Union[str, Path]

logger = logging.getLogger(__name__)


# Default token budget if neither the env var nor an explicit kwarg is
# given. 512 matches the upstream MiniCPM-o 4.5 reference behaviour.
DEFAULT_MAX_NEW_TOKENS = 512

# Operators on memory-constrained AI PCs (e.g. integrated Intel GPUs)
# can lower the budget at runtime by setting this env var. The value
# is read once at module import. See docs/gpu_memory_optimization.md.
# The canonical name is ``LOCAL_CAMERA_COMPANION_MAX_NEW_TOKENS``; the
# legacy ``LOCAL_ENGLISH_TUTOR_MAX_NEW_TOKENS`` is honoured with a
# one-shot DeprecationWarning so existing operator shells keep working.
from local_camera_companion_skill.env_vars import (  # noqa: E402
    ENV_MAX_NEW_TOKENS,
    get_env,
)

MAX_NEW_TOKENS_ENV = ENV_MAX_NEW_TOKENS

# Lower bound below which any Camera Companion reply genuinely risks
# truncating mid-sentence. The slow-path JSON envelope (scene_summary
# / visible_objects / observable_cues / apparent_emotion) consumes
# ~250-350 tokens before the ``answer`` key is even reached — so the
# slow path's old practical floor was ~384. Fast mode (``--fast-mode``)
# drops the envelope entirely and the reply is one plain-text sentence
# (~50-150 tokens), so anything down to ~128 is safe in that mode.
# To avoid plumbing a ``fast_mode`` kwarg through every caller, the
# threshold is lowered to 128 — the genuine truncation floor for
# plain text in any mode. The warning now only fires on values that
# would truncate even a Fast-mode reply.
_MAX_NEW_TOKENS_TRUNCATION_THRESHOLD = 128


def resolve_default_max_new_tokens() -> int:
    """Return the default ``max_new_tokens`` budget.

    Order:
      1. ``LOCAL_CAMERA_COMPANION_MAX_NEW_TOKENS`` env var (positive
         int) — or the legacy ``LOCAL_ENGLISH_TUTOR_MAX_NEW_TOKENS``
         alias, which emits a one-shot DeprecationWarning.
      2. ``DEFAULT_MAX_NEW_TOKENS`` (512).

    Invalid values (non-int, zero, negative) log a warning and fall
    back to the default. Used by ``MiniCPMO45Pipeline``'s
    ``generate_*`` methods when their ``max_new_tokens`` kwarg is None.
    """
    raw = (get_env(MAX_NEW_TOKENS_ENV) or "").strip()
    if not raw:
        return DEFAULT_MAX_NEW_TOKENS
    try:
        value = int(raw)
    except ValueError:
        logger.warning(
            "%s=%r is not an integer; falling back to %d.",
            MAX_NEW_TOKENS_ENV,
            raw,
            DEFAULT_MAX_NEW_TOKENS,
        )
        return DEFAULT_MAX_NEW_TOKENS
    if value <= 0:
        logger.warning(
            "%s=%d must be positive; falling back to %d.",
            MAX_NEW_TOKENS_ENV,
            value,
            DEFAULT_MAX_NEW_TOKENS,
        )
        return DEFAULT_MAX_NEW_TOKENS
    if value < _MAX_NEW_TOKENS_TRUNCATION_THRESHOLD:
        logger.warning(
            "%s=%d is below the safe minimum (%d) for Camera "
            "Companion's plain-text replies. Even a one-sentence "
            "answer may truncate at this budget. Recommended: keep "
            "the default (%d) or use ``--fast-mode`` with at least "
            "%d tokens.",
            MAX_NEW_TOKENS_ENV,
            value,
            _MAX_NEW_TOKENS_TRUNCATION_THRESHOLD,
            DEFAULT_MAX_NEW_TOKENS,
            _MAX_NEW_TOKENS_TRUNCATION_THRESHOLD,
        )
    return value


_MOCK_BLOCK_BASE = (
    "Teacher:\n"
    "Nice job! Let's keep practicing English together.\n"
    "中文解释:\n"
    "继续练习，你可以的！这次表达整体很自然。\n"
    "Correction:\n"
    "(no correction needed)\n"
    "Natural Expression:\n"
    "You're doing great.\n"
    "Pronunciation Tip:\n"
    "(none)\n"
    "Fluency Tip:\n"
    "Try speaking a little slower for clarity.\n"
    "Practice Again:\n"
    "I am practicing English every day.\n"
    "Your Turn:\n"
    "What would you like to talk about next?\n"
)


def _safe_name(path: Optional[PathLike]) -> str:
    """Return only the file basename — never an absolute path."""
    if path is None:
        return "(none)"
    return Path(path).name


def _accepts_token_callback(callable_obj: Any) -> bool:
    """Return True iff ``callable_obj`` declares a ``token_callback``
    parameter or accepts ``**kwargs``.

    Older adapter fakes (and the legacy ``OmniModelAdapter`` Protocol)
    don't expose the kwarg and would raise ``TypeError`` on an
    unexpected keyword argument. The pipeline introspects the target
    once per call to keep token streaming opt-in at the protocol level.
    """
    try:
        import inspect

        sig = inspect.signature(callable_obj)
    except (TypeError, ValueError):
        return False
    params = sig.parameters
    if "token_callback" in params:
        return True
    return any(
        p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values()
    )


class MiniCPMO45Pipeline:
    """Stateful wrapper around MiniCPM-o 4.5.

    Use ``mock=True`` for tests and CI: the wrapper produces deterministic
    tutor-style output and never touches OpenVINO. ``mock=False`` requires
    a converted OpenVINO model directory; that path is intentionally a
    stub at this stage and will be filled in by later tasks.
    """

    def __init__(
        self,
        model_dir: PathLike,
        device: str = "GPU",
        fallback_device: str = "CPU",
        tts_device: str = "GPU",
        tts_fallback_device: str = "CPU",
        cache_dir: Optional[PathLike] = None,
        mock: bool = False,
        enable_tts: bool = True,
        strict_layout_validation: bool = True,
        omni_adapter: Optional["OmniModelAdapter"] = None,
        token2wav_adapter: Optional["Token2WavAdapter"] = None,
        *,
        vision_text_model_dir: Optional[PathLike] = None,
        vision_text_device: str = "CPU",
        audio_encoder_device: str = "auto",
    ) -> None:
        self.model_dir = Path(model_dir)
        self.device = device
        self.fallback_device = fallback_device
        self.tts_device = tts_device
        self.tts_fallback_device = tts_fallback_device
        self.cache_dir = Path(cache_dir) if cache_dir is not None else None
        self.mock = mock
        self.enable_tts = enable_tts
        self.strict_layout_validation = strict_layout_validation
        self.vision_text_model_dir = (
            Path(vision_text_model_dir)
            if vision_text_model_dir is not None
            else None
        )
        self.vision_text_device = vision_text_device
        self.audio_encoder_device = audio_encoder_device

        self._loaded: bool = False
        self._ov_model: Any = None
        self._tts_model: Any = None
        # Adapter slots for real-mode delegation. See
        # docs/real_model_adapter_design.md.
        self._omni_adapter: Optional["OmniModelAdapter"] = omni_adapter
        self._token2wav_adapter: Optional["Token2WavAdapter"] = token2wav_adapter

        if not self.mock and self.strict_layout_validation:
            self._validate_layout()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _validate_layout(self) -> None:
        result = verify_model_layout(
            self.model_dir,
            include_tts=self.enable_tts,
            include_token2wav=self.enable_tts,
        )
        if not result["exists"]:
            raise FileNotFoundError(
                f"Model directory does not exist: {self.model_dir}"
            )
        if not result["is_complete"]:
            raise FileNotFoundError(
                "MiniCPM-o 4.5 OpenVINO model layout is incomplete. "
                f"Missing files: {result['missing_files']}"
            )

    def load(self) -> None:
        """Initialize the underlying backend (mock or real).

        Mock mode is unchanged. Real mode delegates to ``self._omni_adapter``
        (and, when ``enable_tts`` is True, ``self._token2wav_adapter``). If
        no adapter was injected, the default OpenVINO adapters are
        constructed lazily — the ``ov_adapters`` subpackage is safe to
        import without OpenVINO; only ``adapter.load()`` actually pulls
        OpenVINO in.
        """
        if self.mock:
            logger.info("MiniCPMO45Pipeline.load() in mock mode — no model loaded.")
            self._loaded = True
            return

        # Real path — defensive re-validation.
        self._validate_layout()

        # Build default adapters lazily IF none were injected. The
        # ov_adapters subpackage's __init__ does NOT import openvino.
        if self._omni_adapter is None:
            from .ov_adapters import OpenVINOMiniCPMO45Adapter

            self._omni_adapter = OpenVINOMiniCPMO45Adapter(
                model_dir=self.model_dir,
                device=self.device,
                fallback_device=self.fallback_device,
                cache_dir=self.cache_dir,
                enable_tts_layout=self.enable_tts,
                vision_text_model_dir=self.vision_text_model_dir,
                vision_text_device=self.vision_text_device,
                audio_encoder_device=self.audio_encoder_device,
            )
        if self.enable_tts and self._token2wav_adapter is None:
            from .ov_adapters import OpenVINOToken2WavAdapter

            self._token2wav_adapter = OpenVINOToken2WavAdapter(
                model_dir=self.model_dir,
                device=self.tts_device,
                fallback_device=self.tts_fallback_device,
                cache_dir=self.cache_dir,
            )

        # Task 41: fully transactional adapter load. Strengthens the
        # Task 36 contract. When any adapter's ``load()`` raises:
        #   1. that *failing* adapter's own ``unload()`` runs first
        #      (best-effort) so its partial OpenVINO handles are
        #      released — even though it never returned cleanly;
        #   2. every adapter that already loaded successfully is then
        #      unloaded in strict reverse acquisition order;
        #   3. the original load exception propagates unchanged.
        # ``BaseException`` is intentional so KeyboardInterrupt /
        # SystemExit during a long native compile still trigger the
        # cleanup path before propagating. ``self._loaded`` stays
        # ``False`` unless every adapter loaded successfully.
        loaded_in_order: List[Any] = []
        try:
            try:
                self._omni_adapter.load()
            except BaseException:
                # Failing adapter: best-effort self-unload first.
                try:
                    self._omni_adapter.unload()
                except Exception:
                    pass
                raise
            loaded_in_order.append(self._omni_adapter)

            if self._token2wav_adapter is not None:
                try:
                    self._token2wav_adapter.load()
                except BaseException:
                    try:
                        self._token2wav_adapter.unload()
                    except Exception:
                        pass
                    raise
                loaded_in_order.append(self._token2wav_adapter)
        except BaseException:
            for adapter in reversed(loaded_in_order):
                try:
                    adapter.unload()
                except Exception:
                    # Swallow per-adapter unload errors so one bad
                    # rollback doesn't mask the original cause.
                    pass
            raise
        self._loaded = True

    def is_loaded(self) -> bool:
        return self._loaded

    def runtime_info(self) -> Dict[str, Any]:
        """Return a flat dict of the pipeline's device + adapter state.

        Used by ``runtime_benchmark.build_device_report``. Never raises —
        adapter ``runtime_info()`` failures are swallowed to ``{}`` so
        reporting can run even on a partially-loaded pipeline.
        """
        omni_info: Dict[str, Any] = {}
        tts_info: Dict[str, Any] = {}
        if self._omni_adapter is not None and hasattr(
            self._omni_adapter, "runtime_info"
        ):
            try:
                omni_info = self._omni_adapter.runtime_info() or {}
            except Exception:  # noqa: BLE001 - reporting must never crash
                omni_info = {}
        if self._token2wav_adapter is not None and hasattr(
            self._token2wav_adapter, "runtime_info"
        ):
            try:
                tts_info = self._token2wav_adapter.runtime_info() or {}
            except Exception:  # noqa: BLE001
                tts_info = {}
        return {
            "requested_device": self.device,
            "fallback_device": self.fallback_device,
            "active_device": omni_info.get("active_device"),
            "fallback_used": omni_info.get("fallback_used"),
            "tts_device": self.tts_device,
            "tts_fallback_device": self.tts_fallback_device,
            "tts_active_device": tts_info.get("active_device"),
            "tts_fallback_used": tts_info.get("fallback_used"),
            "model_dir": str(self.model_dir),
            "loaded": self._loaded,
            "mock": self.mock,
            "enable_tts": self.enable_tts,
        }

    def unload(self) -> None:
        """Release every loaded adapter (Task 36).

        Each adapter is unloaded in reverse-load order. Per-adapter
        ``unload()`` failures are swallowed so one bad adapter
        cannot block the other. Idempotent: ``self._loaded`` is set
        to False on the first call; subsequent calls still walk the
        adapter list (real adapters track their own load state and
        are no-ops once unloaded).
        """
        for adapter in (self._token2wav_adapter, self._omni_adapter):
            if adapter is None:
                continue
            try:
                adapter.unload()
            except Exception:
                # Swallow; the next adapter must still be attempted.
                pass
        self._loaded = False
        self._ov_model = None
        self._tts_model = None

    # ------------------------------------------------------------------
    # Mock helpers
    # ------------------------------------------------------------------

    def _build_mock_output(
        self,
        *,
        mode_label: str,
        learner_text: Optional[str] = None,
        audio_hint: Optional[PathLike] = None,
        image_hint: Optional[PathLike] = None,
    ) -> str:
        teacher_lines = [f"(mock {mode_label}) Nice job! Let's keep practicing."]
        if learner_text:
            teacher_lines.append(f'You said: "{learner_text.strip()}"')
        if image_hint is not None:
            teacher_lines.append(
                f"This looks like Chapter 3, page 12 from the textbook ({_safe_name(image_hint)})."
            )
        if audio_hint is not None:
            teacher_lines.append(
                f"I heard your audio clip ({_safe_name(audio_hint)}); great effort."
            )
        teacher_block = " ".join(teacher_lines)

        if audio_hint is not None or mode_label.startswith("audio"):
            pron_tip = "Stress 'practice' on the first syllable: PRAC-tice."
        else:
            pron_tip = "(none)"

        if image_hint is not None or "image" in mode_label or "vision" in mode_label:
            practice = "I read the textbook every evening before bed."
            follow_up = "Can you read the first sentence of this paragraph aloud?"
        else:
            practice = "I am practicing English every day."
            follow_up = "What would you like to talk about next?"

        return (
            "Teacher:\n"
            f"{teacher_block}\n"
            "中文解释:\n"
            "继续练习，你可以的！这次表达整体很自然。\n"
            "Correction:\n"
            "(no correction needed)\n"
            "Natural Expression:\n"
            "You're doing great.\n"
            "Pronunciation Tip:\n"
            f"{pron_tip}\n"
            "Fluency Tip:\n"
            "Try speaking a little slower for clarity.\n"
            "Practice Again:\n"
            f"{practice}\n"
            "Your Turn:\n"
            f"{follow_up}\n"
        )

    def _require_loaded(self) -> None:
        if not self._loaded:
            raise RuntimeError("MiniCPMO45Pipeline is not loaded — call load() first.")

    def _require_real_adapter_loaded(self) -> None:
        """Real-mode preflight: there must be a loaded OmniModelAdapter."""
        if self._omni_adapter is None or not self._omni_adapter.is_loaded():
            raise RuntimeError(
                "Real-mode pipeline requires a loaded OmniModelAdapter. "
                "Call MiniCPMO45Pipeline.load() first or inject and load "
                "an adapter explicitly. See docs/real_generation.md."
            )

    def _require_real_tts_adapter_loaded(self) -> None:
        """Real-mode TTS preflight: there must be a loaded Token2WavAdapter."""
        if (
            self._token2wav_adapter is None
            or not self._token2wav_adapter.is_loaded()
        ):
            raise RuntimeError(
                "Real-mode synthesize_speech requires a loaded "
                "Token2WavAdapter. Either inject one via "
                "MiniCPMO45Pipeline(token2wav_adapter=...) and call "
                ".load(), or enable the default OpenVINOToken2WavAdapter "
                "via enable_tts=True. See docs/real_tts.md."
            )

    # ------------------------------------------------------------------
    # Generation methods
    # ------------------------------------------------------------------

    def generate_text(
        self, prompt: str, max_new_tokens: Optional[int] = None
    ) -> str:
        budget = (
            max_new_tokens
            if max_new_tokens is not None
            else resolve_default_max_new_tokens()
        )
        self._require_loaded()
        if self.mock:
            return self._build_mock_output(mode_label="text", learner_text=None)
        self._require_real_adapter_loaded()
        assert self._omni_adapter is not None  # narrowed by preflight
        return self._omni_adapter.generate_text(
            prompt, max_new_tokens=budget
        )

    @property
    def last_audio_timings(self) -> Dict[str, int]:
        """Per-call sub-timings from the last ``generate_from_audio``
        call. Walks to ``self._omni_adapter._ov_model.last_audio_timings``
        when present; returns an empty dict otherwise (mock pipelines,
        not-yet-loaded real pipelines).
        """
        adapter = getattr(self, "_omni_adapter", None)
        if adapter is None:
            return {}
        model = getattr(adapter, "_ov_model", None)
        if model is None:
            return {}
        timings = getattr(model, "last_audio_timings", None)
        if not isinstance(timings, dict):
            return {}
        return dict(timings)

    def generate_from_audio(
        self,
        prompt: str,
        audio_path: PathLike,
        max_new_tokens: Optional[int] = None,
        *,
        audio_offload: bool = True,
    ) -> str:
        budget = (
            max_new_tokens
            if max_new_tokens is not None
            else resolve_default_max_new_tokens()
        )
        self._require_loaded()
        if self.mock:
            return self._build_mock_output(mode_label="audio", audio_hint=audio_path)
        self._require_real_adapter_loaded()
        assert self._omni_adapter is not None  # narrowed by preflight
        return self._omni_adapter.generate_from_audio(
            prompt, audio_path, max_new_tokens=budget, audio_offload=audio_offload
        )

    def generate_from_image(
        self,
        prompt: str,
        image_path: PathLike,
        max_new_tokens: Optional[int] = None,
    ) -> str:
        budget = (
            max_new_tokens
            if max_new_tokens is not None
            else resolve_default_max_new_tokens()
        )
        self._require_loaded()
        if self.mock:
            return self._build_mock_output(mode_label="image", image_hint=image_path)
        self._require_real_adapter_loaded()
        assert self._omni_adapter is not None  # narrowed by preflight
        return self._omni_adapter.generate_from_image(
            prompt, image_path, max_new_tokens=budget
        )

    def generate_from_mixed(
        self,
        prompt: str,
        text: Optional[str] = None,
        audio_path: Optional[PathLike] = None,
        image_path: Optional[PathLike] = None,
        max_new_tokens: Optional[int] = None,
        *,
        token_callback: Optional[Callable[[str], None]] = None,
    ) -> str:
        budget = (
            max_new_tokens
            if max_new_tokens is not None
            else resolve_default_max_new_tokens()
        )
        self._require_loaded()
        if self.mock:
            mock_output = self._build_mock_output(
                mode_label="mixed",
                learner_text=text,
                audio_hint=audio_path,
                image_hint=image_path,
            )
            # Mock-mode token_callback parity: emit the whole mock
            # reply as a single delta so callers exercising the
            # streaming code path without the real model still get
            # an end-to-end signal. Real-mode delegates to the
            # adapter where the loop emits per-token deltas.
            if token_callback is not None:
                try:
                    token_callback(mock_output)
                except Exception:  # noqa: BLE001 - opportunistic
                    pass
            return mock_output
        self._require_real_adapter_loaded()
        assert self._omni_adapter is not None  # narrowed by preflight
        # Forward ``token_callback`` only when set AND the adapter's
        # signature accepts it. Older adapter fakes (and the legacy
        # protocol) don't expose the kwarg, and they treat unknown
        # kwargs as TypeError.
        kwargs: Dict[str, Any] = {
            "text": text,
            "audio_path": audio_path,
            "image_path": image_path,
            "max_new_tokens": budget,
        }
        if token_callback is not None and _accepts_token_callback(
            self._omni_adapter.generate_from_mixed
        ):
            kwargs["token_callback"] = token_callback
        return self._omni_adapter.generate_from_mixed(prompt, **kwargs)

    def generate_from_vision_audio(
        self,
        prompt: str,
        image_path: PathLike,
        audio_path: Optional[PathLike] = None,
        max_new_tokens: Optional[int] = None,
    ) -> str:
        budget = (
            max_new_tokens
            if max_new_tokens is not None
            else resolve_default_max_new_tokens()
        )
        self._require_loaded()
        if self.mock:
            return self._build_mock_output(
                mode_label="vision_audio",
                audio_hint=audio_path,
                image_hint=image_path,
            )
        self._require_real_adapter_loaded()
        assert self._omni_adapter is not None  # narrowed by preflight
        return self._omni_adapter.generate_from_vision_audio(
            prompt, image_path, audio_path=audio_path, max_new_tokens=budget
        )

    # ------------------------------------------------------------------
    # TTS
    # ------------------------------------------------------------------

    def synthesize_speech(
        self,
        text: str,
        output_path: Optional[PathLike] = None,
        base_seed: int = 0,
    ) -> Optional[Path]:
        if not self.enable_tts:
            if self.mock:
                logger.warning(
                    "TTS is disabled; synthesize_speech returning None."
                )
                return None
            raise RuntimeError(
                "Real-mode synthesize_speech called but enable_tts=False. "
                "Enable TTS at construction or use mock mode. "
                "See docs/real_tts.md."
            )
        self._require_loaded()
        if self.mock:
            if output_path is None:
                return None
            out = Path(output_path)
            out.parent.mkdir(parents=True, exist_ok=True)
            # Write a tiny but valid mono 16 kHz / 16-bit silent WAV.
            with wave.open(str(out), "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(16000)
                wf.writeframes(b"\x00\x00" * 160)  # ~10 ms of silence
            return out
        self._require_real_tts_adapter_loaded()
        if output_path is None:
            raise ValueError(
                "Real-mode synthesize_speech requires an explicit output_path."
            )
        return self._token2wav_adapter.synthesize(
            text, output_path, base_seed=base_seed
        )

    # ------------------------------------------------------------------
    # Textbook OCR (mock + real-mode stub)
    # ------------------------------------------------------------------

    def extract_textbook_text(self, image_path: PathLike) -> str:
        """Return textbook-style text extracted from a textbook page image.

        Mock mode returns the canonical block defined in
        :mod:`ocr_text_extractor`. Real mode is a TODO stub.
        """
        self._require_loaded()
        # Resolve defensively but do not validate; CameraInputHandler is the
        # validator. We only normalize so the basename is available later.
        Path(image_path).expanduser()
        if self.mock:
            return MOCK_TEXTBOOK_BLOCK
        # Real-mode textbook OCR delegates to the omni adapter, which
        # validates the image, builds an OCR prompt, and dispatches
        # through _call_real_model. On any failure the adapter returns
        # an empty string so the Skill's empty-extraction path can emit
        # a polite "couldn't find readable text" feedback. See
        # docs/real_textbook_ocr.md.
        self._require_real_adapter_loaded()
        assert self._omni_adapter is not None  # narrowed by preflight
        return self._omni_adapter.extract_textbook_text(image_path)

    # ------------------------------------------------------------------
    # Streaming
    # ------------------------------------------------------------------

    def stream_audio_chunk(self, chunk: bytes, session_id: str) -> Dict[str, Any]:
        self._require_loaded()
        if self.mock:
            return {
                "session_id": session_id,
                "partial_transcript": "I am practi...",
                "evaluation": "(mock) keep going, your pace is good.",
                "is_final": False,
                "chunk_bytes": len(chunk or b""),
            }
        self._require_real_adapter_loaded()
        assert self._omni_adapter is not None  # narrowed by preflight
        return self._omni_adapter.stream_audio_chunk(chunk, session_id)


__all__ = ["MiniCPMO45Pipeline"]
