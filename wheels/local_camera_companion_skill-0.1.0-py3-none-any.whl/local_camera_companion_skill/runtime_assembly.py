# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Unified real-runtime assembly for Camera Companion runners (Task 38).

Today four runner scripts each build the real-runtime stack their own
way — divergent pipeline types, optional vs. missing ASR / TTS / recorder
wiring, ad-hoc lifecycle handling. This module is the single source of
truth they all share.

Public API:

- :class:`BuildOptions`: structured input for every runner.
- :class:`RealRuntimeResources`: bundle returned by the builder; owns
  cleanup ordering. Aliased back as ``_LiveResources`` from the live
  demo for backwards compatibility.
- :func:`build_real_runtime`: composes the runtime in a strict,
  rollback-safe order. Pipeline loads through
  :class:`RuntimeLifecycle` BEFORE any hardware open.
- :func:`resolve_asr_backend`: maps ``--asr-backend`` (auto / mock /
  minicpm_audio / whisper_cpp) to a concrete backend, rejecting
  ``whisper_cpp`` consistently across runners.
- :class:`_ImagePathPreviewController` and :func:`_synthetic_image_path`:
  shared still-image helpers (deduplicated from runners).

All heavy runtime imports (OpenVINO, cv2, sounddevice, torch,
transformers, numpy) are lazy: this module's top-level import never
pulls them in. Default factories import their heavy targets only inside
their function body.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Literal, Optional, Union

logger = logging.getLogger(__name__)


__all__ = [
    "BuildOptions",
    "RealRuntimeResources",
    "build_real_runtime",
    "resolve_asr_backend",
    "_ImagePathPreviewController",
    "_synthetic_image_path",
    "_default_pipeline_factory",
    "_default_preview_factory",
    "_default_recorder_factory",
    "_default_asr_factory",
    "_default_tts_engine_factory",
]


PathLike = Union[str, Path]
CameraMode = Literal["continuous", "still_image", "preview_image", "none"]


# ---------------------------------------------------------------------------
# Image-path preview controller (cv2-free still-image preview)
# ---------------------------------------------------------------------------


class _ImagePathPreviewController:
    """Returns a fixed image path as the latest frame. No cv2.

    Drop-in replacement for ``CameraPreviewController`` for runners
    that operate on a single still image (smoke runner, mock paths).
    """

    def __init__(self, frame_path: PathLike) -> None:
        self._frame_path = Path(frame_path)
        self._running: bool = False

    def start(self, camera_index: int = 0) -> None:
        self._running = True

    def stop(self) -> None:
        self._running = False

    def is_running(self) -> bool:
        return self._running

    def save_latest_frame(self, filename: Optional[str] = None) -> Path:
        return self._frame_path

    def status(self) -> Dict[str, Any]:
        return {
            "running": self._running,
            "has_frame": True,
            "last_saved_basename": self._frame_path.name,
        }


def _synthetic_image_path(target_dir: Optional[Path] = None) -> Path:
    """Return a stdlib-only 1x1 PNG, written once and reused.

    ``target_dir`` defaults to ``model_cache/camera_companion/synth``
    under the repository root so all runners share one PNG.
    """
    import struct
    import zlib

    root = Path(__file__).resolve().parent.parent.parent
    if target_dir is None:
        target_dir = (
            root / "model_cache" / "camera_companion" / "synth"
        )
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / "synthetic_frame.png"
    if not target.exists():

        def _chunk(tag: bytes, data: bytes) -> bytes:
            return (
                struct.pack(">I", len(data))
                + tag
                + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
            )

        signature = b"\x89PNG\r\n\x1a\n"
        ihdr = struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0)
        idat_data = zlib.compress(b"\x00\x00\x00\x00")
        png_bytes = (
            signature
            + _chunk(b"IHDR", ihdr)
            + _chunk(b"IDAT", idat_data)
            + _chunk(b"IEND", b"")
        )
        target.write_bytes(png_bytes)
    return target


# ---------------------------------------------------------------------------
# ASR-backend resolution
# ---------------------------------------------------------------------------


def resolve_asr_backend(*, mock: bool, asr_backend: str) -> str:
    """Resolve the configured ASR backend choice into a concrete name.

    - ``mock=True`` always wins → ``"mock"``.
    - ``"auto"`` resolves to ``"mock"`` in mock mode (already handled
      by the previous branch) and ``"minicpm_audio"`` in real mode.
    - ``"whisper_cpp"`` is reserved and not implemented; we raise the
      same NotImplementedError ``create_asr_adapter`` would emit, so
      runners get the consistent error message before construction.
    - ``"mock"`` and ``"minicpm_audio"`` are returned verbatim.
    - Anything else → ``"minicpm_audio"`` (the safe real-mode default).
    """
    raw = (asr_backend or "auto").strip().lower()
    if mock:
        return "mock"
    if raw == "whisper_cpp":
        raise NotImplementedError(
            "ASR backend 'whisper_cpp' is reserved but not yet "
            "implemented. Use 'mock' or 'minicpm_audio' for now."
        )
    if raw in ("auto", ""):
        return "minicpm_audio"
    if raw == "mock":
        return "mock"
    if raw == "minicpm_audio":
        return "minicpm_audio"
    return "minicpm_audio"


# ---------------------------------------------------------------------------
# Default factories (lazy heavy imports)
# ---------------------------------------------------------------------------


def _default_pipeline_factory(
    model_dir: str,
    device: str,
    *,
    enable_tts: bool = True,
    vision_text_model_dir: Optional[str] = None,
    vision_text_device: str = "CPU",
    audio_encoder_device: str = "auto",
) -> Any:
    """Construct a composed :class:`MiniCPMO45Pipeline`.

    Returns the composition class — NOT the raw OpenVINO Omni adapter
    (Task 33). Layout validation is deferred to ``load()`` so the
    factory is cheap and tests can construct against an empty tmp
    directory. ``enable_tts=False`` skips Token2Wav layout validation
    and load entirely.

    When ``vision_text_model_dir`` is set, the pipeline routes
    vision+text inference (no audio) through ``OVModelForVisualCausalLM``
    instead of the legacy native vision_runtime + text_runtime path.
    Empirical A/B (local_calibration/verify_optimum_vs_native.py)
    showed the native path systematically miscounts visible people on
    Camera Companion frames; the optimum path uses the upstream
    HuggingFace processor's preprocessing and gets the count right.
    See PR #134 + docs/ocr_runtime_preprocessing_bug.md for the
    underlying SigLIP IR / preprocessing mismatch.
    """
    from local_minicpm_runtime.minicpm_o45_pipeline import (
        MiniCPMO45Pipeline,
    )

    return MiniCPMO45Pipeline(
        model_dir=str(model_dir),
        device=str(device),
        enable_tts=bool(enable_tts),
        strict_layout_validation=False,
        vision_text_model_dir=(
            str(vision_text_model_dir)
            if vision_text_model_dir
            else None
        ),
        vision_text_device=str(vision_text_device),
        audio_encoder_device=str(audio_encoder_device),
    )


def _default_preview_factory(
    *, output_dir: Path, mode: str = "continuous"
) -> Any:
    """Construct a real :class:`CameraPreviewController`.

    Lazy-imports ``cv2`` only when actually starting the preview, not
    at module import or factory call time.
    """
    from local_camera_companion_skill.camera_preview import (
        CameraPreviewController,
    )

    return CameraPreviewController(output_dir=output_dir, mode=mode)


def _default_recorder_factory(*, output_dir: Path) -> Any:
    """Construct a :class:`SoundDeviceAudioRecorder`. Lazy sounddevice."""
    from local_camera_companion_skill.audio_capture import (
        create_audio_recorder,
    )

    return create_audio_recorder(
        "sounddevice", output_dir=str(output_dir)
    )


def _minicpm_language_label(asr_language: str) -> Optional[str]:
    """Map a Camera Companion ``asr_language`` value to the human-
    readable label embedded in the MiniCPM-o transcription prompt.

    ``"auto"`` returns ``None`` so the adapter omits the language hint
    line and lets the model auto-detect.
    """
    value = (asr_language or "auto").strip().lower()
    if value == "zh":
        return "Chinese"
    if value == "en":
        return "English"
    return None


def _default_asr_factory(
    backend: str,
    pipeline: Any,
    *,
    language: Optional[str] = None,
) -> Any:
    """Construct an ASR adapter for the resolved backend.

    Task 45: ``language`` is a MiniCPM-style hint label
    (``"Chinese"`` / ``"English"`` / ``None``). It is forwarded to
    both the mock and real backends because both accept the keyword.
    """
    from local_camera_companion_skill.asr_adapter import create_asr_adapter

    if backend == "mock":
        return create_asr_adapter("mock", language=language)
    return create_asr_adapter(
        backend, pipeline=pipeline, language=language
    )


def _default_tts_engine_factory(
    pipeline: Any,
    output_dir: Path,
    content_verifier: Optional[Callable[..., bool]] = None,
) -> Any:
    """Construct the MiniCPM-o-backed TTS playback engine."""
    from local_camera_companion_skill.tts_playback import (
        MiniCPMTTSPlaybackEngine,
    )

    return MiniCPMTTSPlaybackEngine(
        pipeline=pipeline,
        output_dir=output_dir,
        content_verifier=content_verifier,
    )


def _content_verify_enabled() -> bool:
    """ASR content-verify is on by default; set
    ``LOCAL_CAMERA_COMPANION_TTS_VERIFY=0`` (e.g. via ``extra_env``) to disable."""
    import os

    return os.environ.get("LOCAL_CAMERA_COMPANION_TTS_VERIFY", "1").strip() != "0"


def _make_content_verifier(
    asr_adapter: Any, threshold: float = 0.45
) -> Callable[[Any, str], bool]:
    """Build a ``verifier(wav_path, intended_text) -> bool`` over the loaded
    ASR adapter: transcribe the synthesized WAV and accept it when it is
    text-similar enough to the intended text. Wrong-phoneme garble transcribes
    to something far off and scores below ``threshold``."""
    from local_camera_companion_skill.tts_playback import text_similarity

    def _verify(wav_path: Any, intended_text: str) -> bool:
        result = asr_adapter.transcribe(wav_path)
        heard = getattr(result, "text", "") or ""
        return text_similarity(heard, intended_text) >= threshold

    return _verify


# ---------------------------------------------------------------------------
# Build options and resource bundle
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BuildOptions:
    """Structured input for :func:`build_real_runtime`.

    All runners produce one of these from their CLI arguments. The
    same ``BuildOptions`` shape is consumed by the simple CLI, smoke
    runner, Gradio runner, and live demo.
    """

    model_dir: str
    device: str = "GPU"
    enable_tts: bool = True
    enable_voice: bool = False
    asr_backend: str = "auto"
    camera_mode: CameraMode = "continuous"
    frame_path: Optional[Path] = None
    camera_index: int = 0
    preview_output_dir: Optional[Path] = None
    tts_output_dir: Optional[Path] = None
    recorder_output_dir: Optional[Path] = None
    mock: bool = False  # for resolve_asr_backend()
    # Task 45: language controls. ``"auto"`` preserves prior behavior
    # (CJK-detected response language; no MiniCPM ASR language hint).
    response_language: str = "auto"
    asr_language: str = "auto"

    def validate(self) -> None:
        """Reject obvious misconfigurations before any heavy work."""
        if not self.model_dir:
            raise RuntimeError(
                "BuildOptions.model_dir is required for real runtime"
            )
        if self.camera_mode == "still_image" and not self.frame_path:
            raise RuntimeError(
                "BuildOptions.frame_path is required when "
                "camera_mode='still_image'"
            )
        # Surfaces the same NotImplementedError as create_asr_adapter
        # so callers see one consistent message.
        if self.enable_voice:
            resolve_asr_backend(
                mock=self.mock, asr_backend=self.asr_backend
            )


class RealRuntimeResources:
    """Bundle of all real-runtime objects + deterministic cleanup.

    Cleanup order: ``recorder.stop`` → ``tts_engine.stop`` →
    ``preview.stop`` → ``lifecycle.release``. Each step runs in its
    own ``try/except`` so one failure cannot block the rest.

    Idempotent: each slot is cleared after best-effort stop so a
    second :meth:`cleanup` call is a no-op.

    Aliased back to ``_LiveResources`` by the live demo runner so
    existing tests calling ``cli._LiveResources(...)`` continue to
    work unchanged.
    """

    __slots__ = (
        "skill",
        "lifecycle",
        "pipeline",
        "recorder",
        "asr_adapter",
        "tts_engine",
        "preview",
        "window",
        "frame",
    )

    def __init__(
        self,
        *,
        skill: Any = None,
        lifecycle: Optional[Any] = None,
        pipeline: Optional[Any] = None,
        recorder: Optional[Any] = None,
        asr_adapter: Optional[Any] = None,
        tts_engine: Optional[Any] = None,
        preview: Optional[Any] = None,
        window: Optional[Any] = None,
        frame: Optional[Path] = None,
    ) -> None:
        self.skill = skill
        self.lifecycle = lifecycle
        self.pipeline = pipeline
        self.recorder = recorder
        self.asr_adapter = asr_adapter
        self.tts_engine = tts_engine
        self.preview = preview
        # ``window`` is the optional live-demo CameraPreviewWindow that
        # was opened early to host the status-banner overlay. Stopped
        # before ``lifecycle`` so the cv2 destroyWindow runs before any
        # pipeline release that might block on the GPU.
        self.window = window
        self.frame = frame

    def cleanup(self) -> None:
        if self.recorder is not None:
            try:
                self.recorder.stop()
            except Exception:
                pass
            self.recorder = None
        if self.tts_engine is not None:
            try:
                self.tts_engine.stop()
            except Exception:
                pass
            self.tts_engine = None
        if self.preview is not None:
            try:
                self.preview.stop()
            except Exception:
                pass
            self.preview = None
        if self.window is not None:
            try:
                self.window.stop()
            except Exception:
                pass
            self.window = None
        if self.lifecycle is not None:
            try:
                self.lifecycle.release()
            except Exception:
                pass
            self.lifecycle = None


# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------


def build_real_runtime(
    *,
    options: BuildOptions,
    pipeline_factory: Optional[Callable[..., Any]] = None,
    preview_factory: Optional[Callable[..., Any]] = None,
    recorder_factory: Optional[Callable[..., Any]] = None,
    asr_factory: Optional[Callable[..., Any]] = None,
    tts_engine_factory: Optional[Callable[..., Any]] = None,
    config_factory: Optional[Callable[..., Any]] = None,
    skill_factory: Optional[Callable[..., Any]] = None,
) -> RealRuntimeResources:
    """Compose one real Camera Companion runtime.

    Build order is strict so hardware never opens before the
    pipeline is loaded:

    1. construct ``MiniCPMO45Pipeline`` (lazy heavy import)
    2. wrap with ``RuntimeLifecycle`` and call ``ensure_loaded()``
    3. on load failure → ``SystemExit`` (no camera, no mic, no TTS)
    4. construct optional voice components (recorder + ASR) when
       ``options.enable_voice`` is True
    5. construct optional TTS engine when ``options.enable_tts`` is
       True
    6. construct camera preview based on ``options.camera_mode``
    7. assemble ``CameraCompanionSkill`` with all wired components

    Any failure during steps 4-7 releases every resource that was
    already acquired, in reverse order, before the original
    exception propagates.
    """
    options.validate()

    # Lazy heavy imports inside the function body keep the module's
    # top-level import light.
    from local_camera_companion_skill import CameraCompanionConfig
    from local_camera_companion_skill.environment_skill import (
        CameraCompanionSkill,
    )
    from local_camera_companion_skill.runtime_lifecycle import (
        RuntimeLifecycle,
    )

    pf = pipeline_factory or _default_pipeline_factory
    pvf = preview_factory or _default_preview_factory
    rf = recorder_factory or _default_recorder_factory
    af = asr_factory or _default_asr_factory
    tf = tts_engine_factory or _default_tts_engine_factory
    cf = config_factory or CameraCompanionConfig.from_dict
    sf = skill_factory or CameraCompanionSkill

    # Step 1: pipeline (test factories accept either (model_dir,
    # device) or (model_dir, device, *, enable_tts)). Detect via
    # introspection so old smoke-runner stubs don't break.
    pipeline = _call_pipeline_factory(
        pf,
        model_dir=options.model_dir,
        device=options.device,
        enable_tts=options.enable_tts,
    )

    # Step 2-3: load through the lifecycle BEFORE opening hardware.
    lifecycle = RuntimeLifecycle(pipeline, model_dir=str(options.model_dir))
    load_event = lifecycle.ensure_loaded()
    if not load_event.ok:
        # No further resources have been acquired yet, so nothing to
        # release. ``RuntimeLifecycle.ensure_loaded()`` already made a
        # best-effort partial cleanup of the pipeline (Task 36).
        raise SystemExit(
            "ERROR: pipeline load failed: "
            f"{load_event.detail or load_event.reason}"
        )

    # Step 4-7: build optional voice + TTS + preview + skill under
    # one transactional scope.
    recorder: Optional[Any] = None
    asr_adapter: Optional[Any] = None
    tts_engine: Optional[Any] = None
    preview: Optional[Any] = None
    try:
        if options.enable_voice:
            if options.recorder_output_dir is None:
                raise RuntimeError(
                    "BuildOptions.recorder_output_dir is required when "
                    "enable_voice=True"
                )
            recorder = rf(output_dir=options.recorder_output_dir)
            backend = resolve_asr_backend(
                mock=options.mock, asr_backend=options.asr_backend
            )
            language_hint = _minicpm_language_label(options.asr_language)
            try:
                asr_adapter = af(
                    backend, pipeline, language=language_hint
                )
            except TypeError:
                # Backwards-compat for legacy test factories that use
                # the original ``(backend, pipeline)`` signature. The
                # language hint is silently dropped because the older
                # factory cannot route it; this only affects tests
                # that don't care about ASR language.
                asr_adapter = af(backend, pipeline)

        if options.enable_tts:
            if options.tts_output_dir is None:
                raise RuntimeError(
                    "BuildOptions.tts_output_dir is required when "
                    "enable_tts=True"
                )
            # Wire ASR content-verify when a real ASR adapter is available:
            # the TTS engine transcribes short replies and re-synthesizes at a
            # fresh seed if the audio doesn't match the text (catches
            # wrong-phoneme garble that duration checks miss).
            verifier = None
            if asr_adapter is not None and _content_verify_enabled():
                verifier = _make_content_verifier(asr_adapter)
            try:
                tts_engine = tf(
                    pipeline,
                    options.tts_output_dir,
                    content_verifier=verifier,
                )
            except TypeError:
                # Legacy/custom factories with the (pipeline, output_dir)
                # signature — verify is simply not wired for them.
                tts_engine = tf(pipeline, options.tts_output_dir)

        preview = _build_preview(
            options=options, preview_factory=pvf
        )

        cfg_dict: Dict[str, Any] = {
            "runtime": {
                "model_dir": str(options.model_dir),
                "device": str(options.device),
            },
            "vision": {"camera_index": int(options.camera_index)},
            # Task 45: thread the language options into the
            # interaction config so ``CameraCompanionSkill`` and
            # ``ScenePromptBuilder`` can read them at scene-QA time.
            "interaction": {
                "response_language": str(options.response_language),
                "asr_language": str(options.asr_language),
            },
        }
        if not options.enable_tts:
            cfg_dict["tts"] = {"enabled": False}
        config = cf(cfg_dict)

        skill = sf(
            config=config,
            pipeline=pipeline,
            preview_controller=preview,
            audio_recorder=recorder,
            asr_adapter=asr_adapter,
            tts_engine=tts_engine,
        )
    except Exception:
        # Reverse-order rollback. Each step is best-effort so one
        # failure must not block the others. The original cause
        # propagates.
        if preview is not None:
            try:
                preview.stop()
            except Exception:
                pass
        if tts_engine is not None:
            try:
                tts_engine.stop()
            except Exception:
                pass
        if recorder is not None:
            try:
                recorder.stop()
            except Exception:
                pass
        try:
            lifecycle.release()
        except Exception:
            pass
        raise

    return RealRuntimeResources(
        skill=skill,
        lifecycle=lifecycle,
        pipeline=pipeline,
        recorder=recorder,
        asr_adapter=asr_adapter,
        tts_engine=tts_engine,
        preview=preview,
        frame=options.frame_path,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _call_pipeline_factory(
    factory: Callable[..., Any],
    *,
    model_dir: str,
    device: str,
    enable_tts: bool,
) -> Any:
    """Invoke a pipeline factory tolerating both old and new signatures.

    Old runners (and some test stubs) defined ``factory(model_dir,
    device)``. The unified default is ``factory(model_dir, device, *,
    enable_tts=...)``. We try the new shape first; if the factory
    raises ``TypeError`` for the unexpected kwarg, fall back to the
    two-arg call. This keeps existing smoke-runner test fakes
    working without modification.
    """
    try:
        return factory(model_dir, device, enable_tts=enable_tts)
    except TypeError as exc:
        msg = str(exc)
        if "enable_tts" not in msg and "unexpected keyword" not in msg:
            raise
        return factory(model_dir, device)


def _build_preview(
    *,
    options: BuildOptions,
    preview_factory: Callable[..., Any],
) -> Optional[Any]:
    if options.camera_mode == "none":
        return None
    if options.camera_mode == "still_image":
        if options.frame_path is None:
            raise RuntimeError(
                "BuildOptions.frame_path is required when "
                "camera_mode='still_image'"
            )
        return _ImagePathPreviewController(options.frame_path)
    # ``continuous`` / ``preview_image``: real CameraPreviewController
    # (lazy cv2 inside the controller's start()).
    if options.preview_output_dir is None:
        raise RuntimeError(
            "BuildOptions.preview_output_dir is required when "
            f"camera_mode={options.camera_mode!r}"
        )
    return preview_factory(
        output_dir=options.preview_output_dir,
        mode=options.camera_mode,
    )


# Silence "unused import" lints for stdlib imports kept for clarity.
_ = field
_ = List
