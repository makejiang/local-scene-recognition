# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Dataclass-based configuration for the Camera Companion Skill.

Mirrors the lightweight, stdlib-only configuration style used by
``local_minicpm_runtime.schemas`` so the package can be imported
without OpenVINO, cv2, sounddevice, torch, transformers, or any model
dependency.

The ``_ConfigBase`` mixin is intentionally re-implemented locally rather
than imported from the English Tutor package: the Camera Companion
package is meant to be independently testable and eventually extractable
into its own repository.
"""

from __future__ import annotations

from dataclasses import dataclass, field, fields
from typing import Any, ClassVar, Dict, Optional, Type, TypeVar

from . import constants

T = TypeVar("T", bound="_ConfigBase")


class _ConfigBase:
    """Mixin providing a tolerant ``from_dict`` for dataclasses."""

    @classmethod
    def from_dict(cls: Type[T], data: Dict[str, Any] | None) -> T:
        if data is None:
            return cls()  # type: ignore[call-arg]
        if not isinstance(data, dict):
            raise TypeError(
                f"{cls.__name__}.from_dict expected dict, got {type(data).__name__}"
            )
        allowed = {f.name for f in fields(cls)}  # type: ignore[arg-type]
        filtered = {k: v for k, v in data.items() if k in allowed}
        return cls(**filtered)  # type: ignore[call-arg]


@dataclass
class CameraCompanionRuntimeConfig(_ConfigBase):
    model_dir: str = constants.DEFAULT_MODEL_DIR
    device: str = constants.DEFAULT_DEVICE
    fallback_device: str = constants.DEFAULT_FALLBACK_DEVICE
    cache_dir: str = constants.DEFAULT_CACHE_DIR


@dataclass
class CameraCompanionVisionConfig(_ConfigBase):
    camera_index: int = constants.DEFAULT_CAMERA_INDEX
    frame_output_dir: str = constants.DEFAULT_FRAME_OUTPUT_DIR
    max_image_size_mb: int = constants.DEFAULT_MAX_IMAGE_SIZE_MB
    preview_enabled: bool = constants.DEFAULT_PREVIEW_ENABLED
    preview_mode: str = constants.DEFAULT_PREVIEW_MODE
    frame_interval_seconds: float = constants.DEFAULT_FRAME_INTERVAL_SECONDS
    max_background_errors: int = constants.DEFAULT_MAX_BACKGROUND_ERRORS


@dataclass
class CameraCompanionAudioConfig(_ConfigBase):
    asr_backend: str = constants.DEFAULT_ASR_BACKEND
    max_record_seconds: int = constants.DEFAULT_MAX_RECORD_SECONDS
    input_sample_rate: int = constants.DEFAULT_INPUT_SAMPLE_RATE


@dataclass
class CameraCompanionTTSConfig(_ConfigBase):
    enabled: bool = constants.DEFAULT_TTS_ENABLED
    max_text_length: int = constants.DEFAULT_MAX_TTS_TEXT_LENGTH


@dataclass
class CameraCompanionVADConfig(_ConfigBase):
    enabled: bool = constants.DEFAULT_VAD_ENABLED
    model_path: str = constants.DEFAULT_VAD_MODEL_PATH
    threshold: float = constants.DEFAULT_VAD_THRESHOLD
    min_speech_duration_ms: int = constants.DEFAULT_VAD_MIN_SPEECH_MS
    silence_hangover_ms: int = constants.DEFAULT_VAD_SILENCE_HANGOVER_MS
    post_tts_suppression_ms: int = constants.DEFAULT_VAD_POST_TTS_SUPPRESSION_MS


@dataclass
class CameraCompanionInteractionConfig(_ConfigBase):
    default_persona: str = constants.DEFAULT_PERSONA
    emotion_uncertainty_required: bool = (
        constants.DEFAULT_EMOTION_UNCERTAINTY_REQUIRED
    )
    # Task 45: response language for scene QA + suggested interaction
    # text. ``"auto"`` keeps the prior behavior of letting the prompt
    # ask MiniCPM-o to answer in the user's apparent language.
    # ``"en"`` and ``"zh"`` force the user-facing values into English
    # or Simplified Chinese, regardless of the question language.
    response_language: str = "auto"
    # Task 45: ASR language hint passed to MiniCPM-o native audio
    # transcription. ``"auto"`` sends no hint (the model auto-detects).
    # ``"en"`` and ``"zh"`` map to ``"English"`` / ``"Chinese"``
    # transcription hints in the prompt.
    asr_language: str = "auto"
    # Sentence-level streaming TTS: when True (default), the skill
    # routes ``reply_text`` through ``TTSReplyController.prepare_and_speak_streaming``,
    # which splits the reply on sentence punctuation and starts
    # playing sentence #1 while sentences #2+ are still synthesizing.
    # First-audio latency drops from ~full-reply to ~one-sentence.
    # Set to False to force the legacy one-shot ``speak(full_text)``
    # path.
    streaming_tts_enabled: bool = True
    # Token-level LLM streaming: when True (default) AND
    # ``streaming_tts_enabled`` is True, the skill attaches a
    # ``StreamingAnswerExtractor`` to ``pipeline.generate_from_mixed``
    # so sentences from the model's ``"answer"`` field are enqueued to
    # the TTS engine *during* token decode (not after). First-audio
    # latency drops from ~full-decode to ~first-decoded-sentence.
    # When the model fails to emit a parseable ``"answer"`` field
    # (markdown garbage, missing key, etc.), the skill falls back to
    # the existing post-decode batch TTS path. Set to False via
    # ``--no-token-streaming`` to A/B compare against the
    # sentence-streaming-only baseline.
    llm_token_streaming_enabled: bool = True
    # Continuous voice mode (--continuous-voice). When True, the runner
    # uses VADTurnTaker to detect end-of-speech instead of press-Enter-
    # to-stop. Off by default; the CLI flag flips it on per-run.
    continuous_voice_enabled: bool = constants.DEFAULT_CONTINUOUS_VOICE_ENABLED
    # Fast mode (--fast-mode). When True, the scene-QA prompt drops the
    # JSON 'COT' envelope (scene_summary / visible_objects /
    # observable_cues / apparent_emotion) and the model emits a single
    # plain-text sentence as the answer. Halves first-audio latency on
    # memory-constrained AI PCs by skipping 90-140 tokens of
    # scaffolding before TTS streaming can start. Emotion policy +
    # session scene-history operate on empty payloads in this mode.
    fast_mode: bool = False
    # Post-ASR acknowledgment clip ("好的，知道了。"). When enabled
    # (default), the skill plays a pre-rendered Chinese WAV on a
    # background thread between ASR completion and TTS reply playback
    # so the user gets audible feedback during the LLM + TTS-synth
    # wait. ``ack_clip_path`` overrides the default fixture path
    # (``<package>/local_minicpm_runtime/config/ack_zh.wav``) for
    # tests / non-default deployments. The clip is skipped on
    # English-pinned sessions, empty transcripts, missing WAVs, and
    # when TTS is globally disabled.
    ack_clip_enabled: bool = True
    ack_clip_path: Optional[str] = None


@dataclass
class CameraCompanionConfig:
    """Top-level config aggregating all sub-configs."""

    runtime: CameraCompanionRuntimeConfig = field(
        default_factory=CameraCompanionRuntimeConfig
    )
    vision: CameraCompanionVisionConfig = field(
        default_factory=CameraCompanionVisionConfig
    )
    audio: CameraCompanionAudioConfig = field(
        default_factory=CameraCompanionAudioConfig
    )
    tts: CameraCompanionTTSConfig = field(
        default_factory=CameraCompanionTTSConfig
    )
    interaction: CameraCompanionInteractionConfig = field(
        default_factory=CameraCompanionInteractionConfig
    )
    vad: CameraCompanionVADConfig = field(
        default_factory=CameraCompanionVADConfig
    )

    _SECTIONS: ClassVar[Dict[str, Type[_ConfigBase]]] = {
        "runtime": CameraCompanionRuntimeConfig,
        "vision": CameraCompanionVisionConfig,
        "audio": CameraCompanionAudioConfig,
        "tts": CameraCompanionTTSConfig,
        "interaction": CameraCompanionInteractionConfig,
        "vad": CameraCompanionVADConfig,
    }

    @classmethod
    def from_dict(cls, data: Dict[str, Any] | None) -> "CameraCompanionConfig":
        if data is None:
            data = {}
        if not isinstance(data, dict):
            raise TypeError(
                f"CameraCompanionConfig.from_dict expected dict, got "
                f"{type(data).__name__}"
            )
        kwargs: Dict[str, Any] = {}
        for key, model in cls._SECTIONS.items():
            kwargs[key] = model.from_dict(data.get(key))
        return cls(**kwargs)
