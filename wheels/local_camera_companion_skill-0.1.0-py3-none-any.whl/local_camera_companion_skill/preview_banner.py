# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""PIL+numpy banner-rendering helpers for the camera preview window.

Renders Chinese status banners onto BGR frames before they reach
``cv2.imshow``. cv2 is **not** imported anywhere in this module: the
helpers operate on numpy arrays and PIL images so the module-load side
remains lazy-import safe (the camera companion's hardware-free import
contract).

Two slots are supported:

- **top-center** — opaque colored banner used for the four lifecycle
  states (loading / ready / listening / answering).
- **bottom-left** — translucent persistent prompt (``按Enter结束，按ESC
  取消``).

CJK glyph rendering needs a TrueType font; we probe a small list of
system locations (Microsoft YaHei, SimHei, Noto Sans CJK, PingFang).
When none is found we fall back to PIL's default font and substitute
romanized labels so the demo keeps running on exotic hosts.
"""

from __future__ import annotations

import logging
import os
import sys
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

__all__ = [
    "draw_banner",
    "draw_banners",
    "make_black_placeholder",
]


_FONT_CANDIDATES = (
    # Windows — Microsoft YaHei ships on every Win10/11 install.
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\msyh.ttf",
    r"C:\Windows\Fonts\simhei.ttf",
    # Linux — Noto Sans CJK is the standard package on Ubuntu/Debian.
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
    # macOS.
    "/System/Library/Fonts/PingFang.ttc",
    "/Library/Fonts/Arial Unicode.ttf",
)


_ROMANIZED_FALLBACK: Dict[str, str] = {
    "启动中...": "Loading...",
    "启动完成，按Enter键开始": "Ready - press Enter",
    "请说话": "Listening...",
    "正在回答": "Answering...",
    "按Enter结束，按ESC取消": "Enter=stop  Esc=cancel",
}


# Cache for ``_get_cjk_font``. Keyed by ``font_size``. Value is the
# tuple ``(font, is_cjk_capable)``. Cleared per-process on import.
_FONT_CACHE: Dict[int, Tuple[Any, bool]] = {}


def _get_cjk_font(size: int) -> Tuple[Any, bool]:
    """Return ``(PIL ImageFont, is_cjk_capable)`` for the requested size.

    Memoized per size. When no CJK-capable system font is found the
    second tuple element is ``False`` and the caller is expected to
    substitute a romanized label.
    """
    cached = _FONT_CACHE.get(int(size))
    if cached is not None:
        return cached

    from PIL import ImageFont  # type: ignore

    for path in _FONT_CANDIDATES:
        try:
            if not os.path.isfile(path):
                continue
            font = ImageFont.truetype(path, int(size))
            _FONT_CACHE[int(size)] = (font, True)
            return _FONT_CACHE[int(size)]
        except Exception:  # pragma: no cover - defensive
            continue

    # No CJK font available. Fall back to the bundled default and let
    # the caller swap to a romanized label.
    fallback = ImageFont.load_default()
    _FONT_CACHE[int(size)] = (fallback, False)
    logger.warning(
        "preview_banner: no CJK system font found (tried %s). Banner "
        "text will fall back to romanized labels.",
        len(_FONT_CANDIDATES),
    )
    return _FONT_CACHE[int(size)]


def make_black_placeholder(width: int, height: int) -> Any:
    """Return an HxWx3 uint8 BGR ndarray of zeros.

    Used to seed the preview window with a solid black frame before the
    camera feed starts, so the loading banner is visible on top of a
    consistent surface (cv2 paints an unpredictable white-then-redraw
    flash on Windows otherwise).
    """
    import numpy as np  # type: ignore

    w = max(1, int(width))
    h = max(1, int(height))
    return np.zeros((h, w, 3), dtype=np.uint8)


def _bgr_tuple_to_rgb(bgr: Tuple[int, int, int]) -> Tuple[int, int, int]:
    """Reverse a single BGR color triple to RGB for PIL drawing."""
    b, g, r = bgr
    return (int(r), int(g), int(b))


def _measure_text(font: Any, text: str) -> Tuple[int, int]:
    """Return ``(text_w, text_h)`` for the given font + text.

    Uses ``font.getbbox`` (PIL >= 9.2). Falls back to ``font.getsize``
    on older versions, though pillow>=10.0 is pinned in pyproject so
    the fallback is only there for the offline test environments that
    happen to install an older PIL.
    """
    try:
        l, t, r, b = font.getbbox(text)
        return (r - l, b - t)
    except AttributeError:  # pragma: no cover - PIL < 9.2
        return font.getsize(text)  # type: ignore[attr-defined]


def _resolve_text_for_render(text: str, is_cjk_capable: bool) -> str:
    """If the system font cannot draw CJK, substitute a romanized label.

    Falls through to the original text when the romanized table has no
    entry — that's safer than printing question-mark boxes for an
    unrecognized phrase.
    """
    if is_cjk_capable:
        return text
    return _ROMANIZED_FALLBACK.get(text, text)


def draw_banner(
    bgr_frame: Any,
    *,
    text: str,
    bg_color: Tuple[int, int, int],
    fg_color: Tuple[int, int, int],
    position: str,
    bg_alpha: float = 1.0,
    padding_px: int = 12,
    font_size: int = 28,
) -> Any:
    """Composite a banner onto a copy of ``bgr_frame`` and return it.

    Parameters
    ----------
    bgr_frame
        HxWx3 uint8 BGR ndarray (the same shape cv2.imshow accepts).
    text
        Chinese text. When the host has no CJK font installed, the
        helper substitutes a romanized label.
    bg_color, fg_color
        BGR triples (matching the BGR frame format).
    position
        ``"top-center"`` or ``"bottom-left"``.
    bg_alpha
        ``1.0`` paints an opaque rectangle; ``< 1.0`` paints a
        translucent overlay (used for the persistent idle prompt).
    """
    import numpy as np  # type: ignore
    from PIL import Image, ImageDraw  # type: ignore

    font, is_cjk_capable = _get_cjk_font(font_size)
    text_to_render = _resolve_text_for_render(text, is_cjk_capable)

    # BGR -> RGB for PIL.
    rgb = bgr_frame[..., ::-1]
    base = Image.fromarray(rgb, mode="RGB").convert("RGBA")
    width, height = base.size

    text_w, text_h = _measure_text(font, text_to_render)
    pad = max(2, int(padding_px))

    if position == "top-center":
        tx = max(pad, (width - text_w) // 2)
        ty = pad
        rect = (
            max(0, tx - pad),
            0,
            min(width, tx + text_w + pad),
            ty + text_h + pad,
        )
    elif position == "bottom-left":
        tx = pad
        ty = max(0, height - text_h - pad - 6)
        rect = (
            0,
            max(0, ty - 6),
            min(width, tx + text_w + pad * 2),
            height,
        )
    else:
        raise ValueError(
            f"unknown banner position {position!r}; expected "
            f"'top-center' or 'bottom-left'"
        )

    rgb_bg = _bgr_tuple_to_rgb(bg_color)
    rgb_fg = _bgr_tuple_to_rgb(fg_color)

    if bg_alpha >= 1.0:
        draw = ImageDraw.Draw(base)
        draw.rectangle(rect, fill=(rgb_bg[0], rgb_bg[1], rgb_bg[2], 255))
        draw.text((tx, ty), text_to_render, font=font, fill=rgb_fg)
        composited = base
    else:
        alpha = max(0, min(255, int(round(float(bg_alpha) * 255))))
        overlay = Image.new("RGBA", base.size, (0, 0, 0, 0))
        odraw = ImageDraw.Draw(overlay)
        odraw.rectangle(rect, fill=(rgb_bg[0], rgb_bg[1], rgb_bg[2], alpha))
        odraw.text((tx, ty), text_to_render, font=font, fill=rgb_fg)
        composited = Image.alpha_composite(base, overlay)

    # Back to BGR ndarray.
    rgba = np.asarray(composited)
    rgb_out = rgba[..., :3]
    bgr_out = rgb_out[..., ::-1].copy()
    return bgr_out


def draw_banners(bgr_frame: Any, snapshot: Any) -> Any:
    """Render the state banner + idle prompt onto a copy of ``bgr_frame``.

    Skips the PIL round-trip and returns the input unchanged when the
    snapshot is fully empty — keeps the no-banner pump path on its
    pre-feature cost.
    """
    kind: Optional[str] = getattr(snapshot, "kind", None)
    idle_prompt: Optional[str] = getattr(snapshot, "idle_prompt", None)

    has_state = bool(kind) and kind != "none"
    has_prompt = bool(idle_prompt)
    if not has_state and not has_prompt:
        return bgr_frame

    out = bgr_frame
    if has_prompt:
        out = draw_banner(
            out,
            text=str(idle_prompt),
            bg_color=(0, 0, 0),
            fg_color=(255, 255, 255),
            position="bottom-left",
            bg_alpha=0.45,
            font_size=22,
        )
    if has_state:
        text = getattr(snapshot, "text", "") or ""
        bg = getattr(snapshot, "bg_color", None) or (0, 0, 0)
        fg = getattr(snapshot, "fg_color", None) or (255, 255, 255)
        out = draw_banner(
            out,
            text=str(text),
            bg_color=bg,
            fg_color=fg,
            position="top-center",
            bg_alpha=1.0,
            font_size=28,
        )
    return out


# Silence unused-import lints for guard hints kept for clarity.
_ = sys
