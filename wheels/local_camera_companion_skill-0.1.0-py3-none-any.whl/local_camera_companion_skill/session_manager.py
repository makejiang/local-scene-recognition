# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""In-memory session manager for the Camera Companion Skill.

Keeps per-session state — active flag, latest scene summary, latest
captured frame id, dialogue history, turn count — so the rest of the
skill can stitch together turns without persistent storage.

Stdlib only at import time (``time``, ``uuid``, ``typing``). No cv2,
OpenVINO, sounddevice, torch, transformers, numpy, or PIL imports are
introduced here.
"""

from __future__ import annotations

import time
import uuid
from typing import Any, Callable, ClassVar, Dict, Optional

from .exceptions import CameraSessionInactiveError
from .schemas import CompanionPersona, CompanionSessionState

__all__ = [
    "CameraCompanionSessionManager",
]


class CameraCompanionSessionManager:
    """In-memory store of :class:`CompanionSessionState` instances."""

    DEFAULT_MAX_HISTORY_ITEMS: ClassVar[int] = 20

    def __init__(
        self,
        *,
        max_history_items: int = DEFAULT_MAX_HISTORY_ITEMS,
        clock: Optional[Callable[[], float]] = None,
    ) -> None:
        if isinstance(max_history_items, bool) or not isinstance(max_history_items, int):
            raise TypeError(
                f"max_history_items must be a positive int, got "
                f"{type(max_history_items).__name__}"
            )
        if max_history_items < 1:
            raise ValueError(
                f"max_history_items must be >= 1, got {max_history_items}"
            )
        self._max_history_items: int = max_history_items
        self._clock: Callable[[], float] = clock if clock is not None else time.time
        self._sessions: Dict[str, CompanionSessionState] = {}

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def create_session(
        self,
        *,
        persona: CompanionPersona = CompanionPersona.warm,
    ) -> CompanionSessionState:
        sid = uuid.uuid4().hex
        state = CompanionSessionState(
            session_id=sid,
            started_at=float(self._clock()),
            persona=persona,
        )
        self._sessions[sid] = state
        return state

    def stop_session(self, session_id: str) -> CompanionSessionState:
        """Mark the session inactive and stamp ``stopped_at``.

        Idempotent: calling stop on an already-stopped session is
        permitted and updates ``stopped_at`` to the latest clock
        reading. Raises :class:`KeyError` only when ``session_id`` is
        unknown.
        """
        state = self.require_session(session_id)
        state.active = False
        state.stopped_at = float(self._clock())
        return state

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def get_session(self, session_id: str) -> Optional[CompanionSessionState]:
        return self._sessions.get(session_id)

    def require_session(self, session_id: str) -> CompanionSessionState:
        state = self._sessions.get(session_id)
        if state is None:
            raise KeyError(session_id)
        return state

    def require_active_session(
        self, session_id: str
    ) -> CompanionSessionState:
        """Return the session iff it exists and ``active is True``.

        Raises :class:`KeyError` for unknown session ids and
        :class:`CameraSessionInactiveError` for ids that resolve to a
        stopped session. Used by Task 39 to reject text/audio/describe
        calls against stopped sessions while keeping the unknown-id
        and inactive-id error paths distinguishable.
        """
        state = self.require_session(session_id)
        if not state.active:
            raise CameraSessionInactiveError(session_id)
        return state

    # ------------------------------------------------------------------
    # Mutations
    # ------------------------------------------------------------------

    def update_latest_frame(
        self,
        session_id: str,
        frame_id: Optional[str],
    ) -> None:
        state = self.require_session(session_id)
        state.latest_frame_id = frame_id

    def update_scene_summary(
        self,
        session_id: str,
        summary: Optional[str],
    ) -> None:
        state = self.require_session(session_id)
        if summary is None or not summary.strip():
            state.last_scene_summary = None
        else:
            state.last_scene_summary = summary

    def update_after_turn(
        self,
        session_id: str,
        *,
        question: str,
        answer: str,
        scene_summary: Optional[str] = None,
    ) -> None:
        state = self.require_session(session_id)
        now = float(self._clock())

        state.turn_count += 1
        state.last_question = question
        state.last_answer = answer
        state.last_question_at = now

        if scene_summary is not None and scene_summary.strip():
            state.last_scene_summary = scene_summary

        entry: Dict[str, Any] = {
            "question": question,
            "answer": answer,
            "scene_summary": scene_summary,
            "ts": now,
        }
        state.history.append(entry)
        while len(state.history) > self._max_history_items:
            state.history.pop(0)
