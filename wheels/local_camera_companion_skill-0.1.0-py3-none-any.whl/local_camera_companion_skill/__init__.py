# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Local Camera Companion Skill — isolated, lightweight package scaffold.

This package is intentionally light to import: it must not require cv2,
OpenVINO, sounddevice, torch, transformers, or any model files. Heavy
dependencies will be lazy-imported only inside real-runtime paths added
by later tasks.
"""

from __future__ import annotations

from .config import (
    CameraCompanionAudioConfig,
    CameraCompanionConfig,
    CameraCompanionInteractionConfig,
    CameraCompanionRuntimeConfig,
    CameraCompanionTTSConfig,
    CameraCompanionVisionConfig,
)
from .exceptions import (
    CameraSessionError,
    CameraSessionInactiveError,
    CameraSessionStartupError,
)
from .schemas import (
    CameraCompanionRequest,
    CameraCompanionResponse,
    CompanionPersona,
    CompanionSessionState,
    EmotionConfidence,
    SceneQuestionType,
    SceneUnderstanding,
)
from .tts_playback import (
    MiniCPMTTSPlaybackEngine,
    MiniCPMTTSPlaybackError,
)

__version__ = "0.1.0"

__all__ = [
    "__version__",
    # Config dataclasses
    "CameraCompanionConfig",
    "CameraCompanionRuntimeConfig",
    "CameraCompanionVisionConfig",
    "CameraCompanionAudioConfig",
    "CameraCompanionTTSConfig",
    "CameraCompanionInteractionConfig",
    # Enums
    "CompanionPersona",
    "SceneQuestionType",
    "EmotionConfidence",
    # Request / response / session dataclasses
    "CompanionSessionState",
    "CameraCompanionRequest",
    "SceneUnderstanding",
    "CameraCompanionResponse",
    # TTS playback bridge (Task 29)
    "MiniCPMTTSPlaybackEngine",
    "MiniCPMTTSPlaybackError",
    # Session-lifecycle exceptions (Task 39)
    "CameraSessionError",
    "CameraSessionInactiveError",
    "CameraSessionStartupError",
]
