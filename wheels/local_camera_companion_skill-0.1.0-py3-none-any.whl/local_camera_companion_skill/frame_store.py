# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Recent-frame store for the Camera Companion Skill.

A small ring-buffer that keeps the most recent ``capacity`` saved camera
frames, keyed by stable unique IDs, so later steps can pick "the right
frame" to send to the multimodal model. The store does not read frame
file contents — it just records ``Path`` references and metadata.

Stdlib only (``dataclasses``, ``pathlib``, ``time``, ``uuid``,
``collections.OrderedDict``, ``typing``). No cv2, OpenVINO, sounddevice,
torch, transformers, numpy, or PIL imports are introduced here.

``debug_snapshot()`` deliberately exposes basenames only — absolute
filesystem paths must not leak into user-facing or debug payloads.
"""

from __future__ import annotations

import time
import uuid
from collections import OrderedDict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Union

__all__ = [
    "StoredFrame",
    "FrameStore",
]


PathLike = Union[str, Path]


@dataclass
class StoredFrame:
    """One entry in the :class:`FrameStore`."""

    frame_id: str
    path: Path
    created_at: float
    source: str = "preview"
    metadata: Dict[str, Any] = field(default_factory=dict)


def _validate_capacity(capacity: Any) -> int:
    """Return ``capacity`` as a positive int or raise."""

    # ``bool`` is an ``int`` subclass — reject it explicitly.
    if isinstance(capacity, bool) or not isinstance(capacity, int):
        raise TypeError(
            f"capacity must be a positive int, got {type(capacity).__name__}"
        )
    if capacity < 1:
        raise ValueError(f"capacity must be >= 1, got {capacity}")
    return capacity


class FrameStore:
    """Ring-buffer of recently-saved camera frames."""

    def __init__(
        self,
        capacity: int = 5,
        *,
        clock: Optional[Callable[[], float]] = None,
    ) -> None:
        self._capacity: int = _validate_capacity(capacity)
        self._clock: Callable[[], float] = clock if clock is not None else time.time
        self._buffer: "OrderedDict[str, StoredFrame]" = OrderedDict()

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------

    def add_frame(
        self,
        path: PathLike,
        *,
        source: str = "preview",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> StoredFrame:
        """Record a new frame and return its :class:`StoredFrame`.

        The file at ``path`` is **not** read; existence is not checked.
        """

        frame_id = uuid.uuid4().hex
        stored = StoredFrame(
            frame_id=frame_id,
            path=Path(path),
            created_at=float(self._clock()),
            source=str(source),
            # Shallow-copy the caller's dict so future caller mutations
            # cannot corrupt the stored entry.
            metadata=dict(metadata) if metadata else {},
        )

        self._buffer[frame_id] = stored
        while len(self._buffer) > self._capacity:
            self._buffer.popitem(last=False)
        return stored

    def clear(self) -> None:
        self._buffer.clear()

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def latest(self) -> Optional[StoredFrame]:
        if not self._buffer:
            return None
        # OrderedDict preserves insertion order; the last key is newest.
        last_key = next(reversed(self._buffer))
        return self._buffer[last_key]

    def get(self, frame_id: str) -> Optional[StoredFrame]:
        return self._buffer.get(frame_id)

    def select_for_question(
        self,
        question_text: Optional[str] = None,
    ) -> Optional[StoredFrame]:
        """Return the frame to send for ``question_text``.

        Currently always returns :meth:`latest`. ``question_text`` is
        accepted as a documented seam so future tasks can plug in a
        smarter selection (e.g. pick the highest-quality recent frame
        for OCR-style questions) without an API break.
        """

        del question_text  # reserved for future heuristics
        return self.latest()

    # ------------------------------------------------------------------
    # Debug
    # ------------------------------------------------------------------

    def debug_snapshot(self) -> Dict[str, Any]:
        """Return a debug payload using basenames only — never absolute paths."""

        return {
            "capacity": self._capacity,
            "size": len(self._buffer),
            "frame_ids": list(self._buffer.keys()),
            "frames": [
                {
                    "frame_id": f.frame_id,
                    "path_basename": f.path.name,
                    "created_at": f.created_at,
                    "source": f.source,
                    "metadata": dict(f.metadata),
                }
                for f in self._buffer.values()
            ],
        }
