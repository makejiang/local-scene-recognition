# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Default constants for the Camera Companion Skill package.

These values back the dataclass defaults defined in
:mod:`local_camera_companion_skill.config`. Keeping them here gives the
package a single source of truth and lets tests assert on the literal
defaults without importing the dataclasses.

The module is stdlib-only and must remain free of third-party imports so
``import local_camera_companion_skill.constants`` stays cheap.
"""

from __future__ import annotations

PACKAGE_NAME = "local_camera_companion_skill"

# Runtime defaults
DEFAULT_MODEL_DIR = "./models/MiniCPM-o-4_5-OV"
DEFAULT_DEVICE = "GPU"
DEFAULT_FALLBACK_DEVICE = "CPU"
DEFAULT_CACHE_DIR = "./model_cache"

# Vision defaults
DEFAULT_CAMERA_INDEX = 0
DEFAULT_FRAME_OUTPUT_DIR = "./model_cache/camera_companion/frames"
DEFAULT_MAX_IMAGE_SIZE_MB = 20
DEFAULT_PREVIEW_ENABLED = True
DEFAULT_PREVIEW_MODE = "single_shot"
DEFAULT_FRAME_INTERVAL_SECONDS = 0.2
DEFAULT_MAX_BACKGROUND_ERRORS = 1

# Audio defaults
DEFAULT_ASR_BACKEND = "mock"
DEFAULT_MAX_RECORD_SECONDS = 30
DEFAULT_INPUT_SAMPLE_RATE = 16000

# TTS defaults
DEFAULT_TTS_ENABLED = True
DEFAULT_MAX_TTS_TEXT_LENGTH = 800

# Interaction defaults
DEFAULT_PERSONA = "warm"
DEFAULT_EMOTION_UNCERTAINTY_REQUIRED = True

# VAD defaults (Silero-VAD via OpenVINO)
DEFAULT_VAD_ENABLED = True
DEFAULT_VAD_THRESHOLD = 0.5
DEFAULT_VAD_MIN_SPEECH_MS = 250
DEFAULT_VAD_SILENCE_HANGOVER_MS = 400
DEFAULT_VAD_POST_TTS_SUPPRESSION_MS = 200
DEFAULT_VAD_MODEL_PATH = ""

# Continuous-voice toggle
DEFAULT_CONTINUOUS_VOICE_ENABLED = False
