# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Domain-specific exceptions for the Camera Companion Skill (Task 39).

These exceptions disambiguate the two camera-session lifecycle failure
modes that prior code conflated with bare ``RuntimeError`` /
``KeyError``:

- :class:`CameraSessionStartupError` — preview/session startup failed
  transactionally; no session was committed and the preview is closed.
- :class:`CameraSessionInactiveError` — a turn was attempted against a
  session that exists but has been stopped.

Both error messages route through :func:`sanitize_message` so absolute
filesystem paths from the underlying preview source can never leak
into runner stderr, JSON payloads, or Gradio answer panes.
"""

from __future__ import annotations

from typing import Optional

from .privacy import sanitize_message

__all__ = [
    "CameraSessionError",
    "CameraSessionStartupError",
    "CameraSessionInactiveError",
]


class CameraSessionError(RuntimeError):
    """Base class for Camera Companion session lifecycle errors."""


class CameraSessionStartupError(CameraSessionError):
    """Raised when ``start_camera_session`` cannot commit a session.

    Carries structured fields so runners can distinguish failure stages
    in their debug output without parsing the human-readable message.
    The ``reason`` is sanitized via :func:`sanitize_message` so any
    underlying absolute path (typical of cv2 / V4L2 errors) is reduced
    to a basename before it reaches the caller.
    """

    def __init__(
        self,
        reason: str,
        *,
        stage: str,
        preview_running: bool = False,
        preview_has_frame: bool = False,
    ) -> None:
        sanitized = sanitize_message(reason) if reason else ""
        self.reason: str = sanitized
        self.stage: str = stage
        self.preview_running: bool = bool(preview_running)
        self.preview_has_frame: bool = bool(preview_has_frame)
        super().__init__(sanitized or stage)

    def __str__(self) -> str:
        return self.reason or self.stage


class CameraSessionInactiveError(CameraSessionError):
    """Raised when a turn is attempted against a stopped session.

    Distinct from ``KeyError`` (unknown session id) so callers and
    tests can disambiguate the two lookup failure modes.
    """

    def __init__(self, session_id: Optional[str]) -> None:
        self.session_id: Optional[str] = session_id
        super().__init__(
            f"session is no longer active: {session_id}"
        )
