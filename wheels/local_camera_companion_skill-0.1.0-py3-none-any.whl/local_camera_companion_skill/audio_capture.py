# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Microphone recording abstraction for the Camera Companion Skill.

Defines the typed result, the Protocol every recorder satisfies, a
working :class:`MockAudioRecorder` that writes a tiny but valid mono
PCM-16 WAV with the stdlib ``wave`` module only, and a
:class:`SoundDeviceAudioRecorder` that lazy-imports ``sounddevice``
only inside :meth:`SoundDeviceAudioRecorder.record` and
:meth:`SoundDeviceAudioRecorder.stop`.

Heavy dependencies — ``sounddevice``, ``soundfile``, ``numpy``,
``torch``, ``transformers``, ``cv2`` — must not be imported at module
load time.

Debug payloads expose **basenames only**; absolute filesystem paths must
not leak.
"""

from __future__ import annotations

import array
import os
import time
import wave
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Protocol, Union, runtime_checkable

from .privacy import sanitize_message

__all__ = [
    "AudioRecordingResult",
    "AudioRecorder",
    "MockAudioRecorder",
    "SoundDeviceAudioRecorder",
    "create_audio_recorder",
]


PathLike = Union[str, Path]


@dataclass
class AudioRecordingResult:
    """Structured result of one recording call."""

    audio_path: Path
    duration_seconds: float
    sample_rate: int
    metadata: Dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class AudioRecorder(Protocol):
    """Common interface every audio recorder must satisfy.

    The legacy fixed-duration API (``record(duration_seconds)``) is
    required for back-compat with existing tests and the
    ``--once --voice`` mode in the live demo.

    The interactive press-Enter-to-stop API (``start_recording`` /
    ``stop_recording``) is *optional*. Concrete recorders that
    implement it expose press-Enter UX in the live demo's main
    voice loop. Older fakes that don't implement these methods
    still work via the legacy ``record()`` path.
    """

    def record(
        self,
        duration_seconds: float,
        filename: Optional[str] = None,
    ) -> AudioRecordingResult: ...

    def stop(self) -> None: ...

    # Optional press-Enter-to-stop API (Camera Companion live demo).
    # Concrete recorders implement these; ``hasattr`` checks gate the
    # interactive path.
    def start_recording(self, filename: Optional[str] = None) -> None: ...

    def stop_recording(self) -> AudioRecordingResult: ...


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _validate_sample_rate(sample_rate: Any) -> int:
    if isinstance(sample_rate, bool) or not isinstance(sample_rate, int):
        raise TypeError(
            f"sample_rate must be a positive int, got {type(sample_rate).__name__}"
        )
    if sample_rate < 1:
        raise ValueError(f"sample_rate must be >= 1, got {sample_rate}")
    return sample_rate


def _safe_basename(filename: Optional[str]) -> str:
    """Return a basename-only filename ending in ``.wav``."""

    if filename is None or not str(filename).strip():
        candidate = f"recording_{int(time.time() * 1000)}.wav"
    else:
        candidate = os.path.basename(str(filename)) or f"recording_{int(time.time() * 1000)}.wav"
    if not candidate.lower().endswith(".wav"):
        candidate += ".wav"
    return candidate


def _samples_to_int16_bytes(samples: Any, *, channels: int = 1) -> bytes:
    """Convert a sequence of float samples to PCM-16 bytes (little-endian).

    Accepts:
    - numpy-like 1-D or 2-D arrays of floats (real ``sounddevice`` output)
    - plain Python lists / tuples (mono ``[float, float, ...]`` or
      multi-channel ``[[float, float], ...]``)

    Floats are clamped to ``[-1.0, 1.0]`` before scaling to int16.
    """

    flat: List[float] = []

    if hasattr(samples, "flatten") and callable(samples.flatten):
        try:
            flat_iter = samples.flatten().tolist()
            flat.extend(float(v) for v in flat_iter)
        except Exception:
            flat = []

    if not flat:
        if isinstance(samples, (list, tuple)):
            for entry in samples:
                if isinstance(entry, (list, tuple)):
                    for v in entry:
                        flat.append(float(v))
                else:
                    flat.append(float(entry))
        elif samples is None:
            flat = []
        else:
            try:
                for entry in samples:
                    if isinstance(entry, (list, tuple)):
                        for v in entry:
                            flat.append(float(v))
                    else:
                        flat.append(float(entry))
            except TypeError:
                flat = []

    int16_array = array.array("h")
    for v in flat:
        if v < -1.0:
            v = -1.0
        elif v > 1.0:
            v = 1.0
        int16_array.append(int(round(v * 32767.0)))

    return int16_array.tobytes()


# ---------------------------------------------------------------------------
# Mock recorder
# ---------------------------------------------------------------------------


class MockAudioRecorder:
    """Deterministic recorder used by default tests.

    Writes a mono PCM-16 WAV of silence using the stdlib ``wave`` module.
    Does not require ``sounddevice``, ``soundfile``, or ``numpy``.
    """

    def __init__(
        self,
        output_dir: PathLike = "./model_cache/camera_companion/audio",
        sample_rate: int = 16000,
    ) -> None:
        self._output_dir: Path = Path(output_dir)
        self._sample_rate: int = _validate_sample_rate(sample_rate)
        self._last_audio_basename: Optional[str] = None
        # Press-Enter-to-stop state (only used by start/stop_recording).
        self._open_session_filename: Optional[str] = None
        self._open_session_started: Optional[float] = None

    def record(
        self,
        duration_seconds: float,
        filename: Optional[str] = None,
    ) -> AudioRecordingResult:
        if not isinstance(duration_seconds, (int, float)) or isinstance(duration_seconds, bool):
            raise ValueError(
                f"duration_seconds must be a positive number, got {duration_seconds!r}"
            )
        if duration_seconds <= 0:
            raise ValueError(
                f"duration_seconds must be > 0, got {duration_seconds}"
            )

        safe_name = _safe_basename(filename)
        self._output_dir.mkdir(parents=True, exist_ok=True)
        target = self._output_dir / safe_name

        n_frames = max(1, int(float(duration_seconds) * self._sample_rate))
        # PCM-16 mono silence: each frame is two zero bytes.
        silence = b"\x00\x00" * n_frames

        with wave.open(str(target), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(self._sample_rate)
            wf.writeframes(silence)

        self._last_audio_basename = safe_name
        return AudioRecordingResult(
            audio_path=target,
            duration_seconds=float(duration_seconds),
            sample_rate=self._sample_rate,
            metadata={
                "backend": "mock",
                "audio_basename": safe_name,
            },
        )

    def start_recording(self, filename: Optional[str] = None) -> None:
        """Begin an open-ended recording session.

        Records wall-clock time only — no real audio capture happens.
        ``stop_recording`` writes a silent WAV whose duration matches
        the elapsed time. The mock-mode press-Enter UX uses this to
        exercise the live-demo loop end-to-end without a microphone.
        """
        if self._open_session_started is not None:
            raise RuntimeError(
                "MockAudioRecorder.start_recording: a recording session "
                "is already open. Call stop_recording() first."
            )
        self._open_session_filename = filename
        self._open_session_started = time.monotonic()

    def stop_recording(self) -> AudioRecordingResult:
        if self._open_session_started is None:
            raise RuntimeError(
                "MockAudioRecorder.stop_recording called without a "
                "matching start_recording()."
            )
        elapsed = max(0.001, time.monotonic() - self._open_session_started)
        filename = self._open_session_filename
        self._open_session_started = None
        self._open_session_filename = None
        return self.record(duration_seconds=elapsed, filename=filename)

    def stop(self) -> None:
        # Synchronous mock recorder; nothing to stop.
        return None

    def debug_snapshot(self) -> Dict[str, Any]:
        return {
            "kind": "mock",
            "output_dir_basename": self._output_dir.name,
            "last_audio_basename": self._last_audio_basename,
            "sample_rate": self._sample_rate,
        }


# ---------------------------------------------------------------------------
# Real recorder placeholder — lazy imports sounddevice in record()
# ---------------------------------------------------------------------------


class SoundDeviceAudioRecorder:
    """Hardware-backed recorder.

    ``sounddevice`` is imported inside :meth:`record` and :meth:`stop`
    so the rest of the module imports cleanly on machines without it.
    Default tests inject a fake ``sounddevice`` module via
    ``sys.modules`` and exercise the full capture path; no real
    microphone is required.
    """

    def __init__(
        self,
        output_dir: PathLike = "./model_cache/camera_companion/audio",
        sample_rate: int = 16000,
    ) -> None:
        self._output_dir: Path = Path(output_dir)
        self._sample_rate: int = _validate_sample_rate(sample_rate)
        self._last_audio_basename: Optional[str] = None
        # Press-Enter-to-stop session state. ``_open_stream`` is the
        # ``sounddevice.InputStream`` while a session is open;
        # ``_open_buffer`` accumulates int16 PCM bytes appended by the
        # callback. Both are reset to None / empty on stop_recording.
        self._open_stream: Any = None
        self._open_buffer: List[bytes] = []
        self._open_filename: Optional[str] = None
        self._open_started: Optional[float] = None
        self._open_error: Optional[str] = None

    def record(
        self,
        duration_seconds: float,
        filename: Optional[str] = None,
    ) -> AudioRecordingResult:
        if not isinstance(duration_seconds, (int, float)) or isinstance(duration_seconds, bool):
            raise ValueError(
                f"duration_seconds must be a positive number, got {duration_seconds!r}"
            )
        if duration_seconds <= 0:
            raise ValueError(
                f"duration_seconds must be > 0, got {duration_seconds}"
            )

        try:
            import sounddevice  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "Microphone capture requires the optional 'sounddevice' "
                "package. Install it with `pip install sounddevice`."
            ) from exc

        n_frames = max(1, int(round(float(duration_seconds) * self._sample_rate)))

        try:
            samples = sounddevice.rec(
                n_frames,
                samplerate=self._sample_rate,
                channels=1,
                dtype="float32",
            )
            sounddevice.wait()
        except Exception as exc:
            # Sanitize the downstream sounddevice/PortAudio message
            # before re-raising. Some PortAudio errors include device
            # backend paths (Task 32).
            raise RuntimeError(
                f"Microphone capture failed: {sanitize_message(str(exc))}"
            ) from exc

        pcm_bytes = _samples_to_int16_bytes(samples, channels=1)

        safe_name = _safe_basename(filename)
        self._output_dir.mkdir(parents=True, exist_ok=True)
        target = self._output_dir / safe_name

        with wave.open(str(target), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(self._sample_rate)
            wf.writeframes(pcm_bytes)

        self._last_audio_basename = safe_name
        return AudioRecordingResult(
            audio_path=target,
            duration_seconds=float(duration_seconds),
            sample_rate=self._sample_rate,
            metadata={
                "backend": "sounddevice",
                "audio_basename": safe_name,
            },
        )

    def start_recording(self, filename: Optional[str] = None) -> None:
        """Begin an open-ended press-Enter-to-stop recording session.

        Opens a ``sounddevice.InputStream`` whose callback appends
        int16 PCM frames to ``self._open_buffer``. The stream stays
        open until :meth:`stop_recording` closes it. Errors raised
        by ``sounddevice`` are sanitized so device paths cannot
        leak into the caller's terminal (Task 32).
        """
        if self._open_stream is not None:
            raise RuntimeError(
                "SoundDeviceAudioRecorder.start_recording: a recording "
                "session is already open. Call stop_recording() first."
            )

        try:
            import sounddevice  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "Microphone capture requires the optional 'sounddevice' "
                "package. Install it with `pip install sounddevice`."
            ) from exc

        self._open_buffer = []
        self._open_filename = filename
        self._open_error = None

        sample_rate = self._sample_rate

        def _callback(indata: Any, frames: int, time_info: Any, status: Any) -> None:
            # ``status`` is non-empty when overrun/underrun occurs;
            # we record the warning but don't drop frames — the user
            # would rather have a glitchy clip than nothing.
            if status:
                try:
                    self._open_error = sanitize_message(str(status))
                except Exception:
                    self._open_error = "input stream status flag set"
            try:
                self._open_buffer.append(
                    _samples_to_int16_bytes(indata, channels=1)
                )
            except Exception as exc:  # pragma: no cover - defensive
                self._open_error = sanitize_message(str(exc))

        try:
            stream = sounddevice.InputStream(
                samplerate=sample_rate,
                channels=1,
                dtype="float32",
                callback=_callback,
            )
            stream.start()
        except Exception as exc:
            raise RuntimeError(
                "Microphone capture failed: "
                f"{sanitize_message(str(exc))}"
            ) from exc

        self._open_stream = stream
        self._open_started = time.monotonic()

    def stop_recording(self) -> AudioRecordingResult:
        if self._open_stream is None:
            raise RuntimeError(
                "SoundDeviceAudioRecorder.stop_recording called without a "
                "matching start_recording()."
            )

        stream = self._open_stream
        self._open_stream = None
        started = self._open_started or time.monotonic()
        self._open_started = None
        filename = self._open_filename
        self._open_filename = None

        try:
            stream.stop()
        except Exception as exc:  # pragma: no cover - defensive
            self._open_error = sanitize_message(str(exc))
        try:
            stream.close()
        except Exception:  # pragma: no cover - defensive
            pass

        elapsed = max(0.001, time.monotonic() - started)
        pcm_bytes = b"".join(self._open_buffer)
        self._open_buffer = []
        if not pcm_bytes:
            # No frames were captured (extremely short session or
            # stream never delivered data). Emit a tiny silent WAV
            # so downstream ASR doesn't crash on a zero-byte file.
            pcm_bytes = b"\x00\x00"

        safe_name = _safe_basename(filename)
        self._output_dir.mkdir(parents=True, exist_ok=True)
        target = self._output_dir / safe_name
        with wave.open(str(target), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(self._sample_rate)
            wf.writeframes(pcm_bytes)

        self._last_audio_basename = safe_name
        metadata: Dict[str, Any] = {
            "backend": "sounddevice",
            "audio_basename": safe_name,
            "press_to_stop": True,
        }
        if self._open_error:
            metadata["last_error"] = self._open_error
            self._open_error = None
        return AudioRecordingResult(
            audio_path=target,
            duration_seconds=float(elapsed),
            sample_rate=self._sample_rate,
            metadata=metadata,
        )

    def stop(self) -> None:
        try:
            import sounddevice  # type: ignore
        except ImportError:
            return None
        stop_fn = getattr(sounddevice, "stop", None)
        if callable(stop_fn):
            try:
                stop_fn()
            except Exception:
                pass
        return None

    def debug_snapshot(self) -> Dict[str, Any]:
        return {
            "kind": "sounddevice",
            "output_dir_basename": self._output_dir.name,
            "last_audio_basename": self._last_audio_basename,
            "sample_rate": self._sample_rate,
        }


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_audio_recorder(kind: str = "mock", **kwargs: Any) -> AudioRecorder:
    """Construct an audio recorder for the requested ``kind``."""

    name = str(kind).strip().lower()

    if name == "mock":
        return MockAudioRecorder(**kwargs)

    if name == "sounddevice":
        return SoundDeviceAudioRecorder(**kwargs)

    raise ValueError(f"unknown audio recorder kind: {kind!r}")
