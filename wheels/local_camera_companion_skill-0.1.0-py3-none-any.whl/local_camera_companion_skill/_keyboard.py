# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Cross-platform raw-mode key reader for the Camera Companion live demo.

Stdlib-only. Provides two helpers:

- :func:`require_tty` — raises ``RuntimeError`` when ``sys.stdin``
  is not a TTY, used to gate the press-Enter-to-stop voice flow.
- :func:`wait_for_key` — blocks until the user presses one of the
  ``stop_keys`` (default Enter or ESC). Returns the literal key
  name. Cross-platform: ``msvcrt`` on Windows, ``termios`` + ``tty``
  + ``select`` on POSIX.

This module is **runner-only** — the library API never sees raw key
input. Heavy guards on platform-specific imports keep the module safe
to import everywhere (Windows, Linux, CI containers).

The poll interval is small (50 ms) so the cv2 preview window thread
(if running) gets CPU and the OS message pump stays responsive on
Windows.
"""

from __future__ import annotations

import logging
import sys
import threading
import time
from typing import Any, Iterable, Optional

logger = logging.getLogger(__name__)

__all__ = [
    "KEY_ENTER",
    "KEY_ESCAPE",
    "require_tty",
    "wait_for_key",
    "wait_for_key_combined",
]


KEY_ENTER = "enter"
KEY_ESCAPE = "escape"


_POLL_INTERVAL_SECONDS = 0.05


# ---------------------------------------------------------------------------
# Platform-specific imports (best-effort)
# ---------------------------------------------------------------------------


_msvcrt: Optional[object] = None
_termios: Optional[object] = None
_tty: Optional[object] = None
_select: Optional[object] = None

try:  # pragma: no cover - import guard
    import msvcrt as _msvcrt_module  # type: ignore

    _msvcrt = _msvcrt_module
except Exception:  # pragma: no cover - non-Windows
    _msvcrt = None

try:  # pragma: no cover - non-Windows
    import termios as _termios_module
    import tty as _tty_module
    import select as _select_module

    _termios = _termios_module
    _tty = _tty_module
    _select = _select_module
except Exception:  # pragma: no cover - Windows path
    _termios = None
    _tty = None
    _select = None


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------


def require_tty() -> None:
    """Raise ``RuntimeError`` if ``sys.stdin`` is not connected to a TTY.

    The press-Enter-to-stop voice flow needs raw-mode key input,
    which requires a real terminal. CI runs (redirected stdin),
    pipes, and ``Popen`` invocations should fall back to
    ``--once --voice --record-seconds`` instead.
    """
    isatty_fn = getattr(sys.stdin, "isatty", None)
    if callable(isatty_fn):
        try:
            if isatty_fn():
                return
        except Exception:  # pragma: no cover - defensive
            pass
    raise RuntimeError(
        "Interactive voice recording (press Enter to start/stop, ESC "
        "to cancel) requires a TTY on stdin. Use "
        "`--once --voice --record-seconds N` for non-interactive "
        "(piped or scripted) runs."
    )


def wait_for_key(
    stop_keys: Iterable[str] = (KEY_ENTER, KEY_ESCAPE),
    *,
    cv2_source: Optional[Any] = None,
    stop_event: Optional[threading.Event] = None,
) -> str:
    """Block until one of ``stop_keys`` arrives from stdin or cv2.

    Returns the literal key name (``"enter"`` or ``"escape"``).
    ``KeyboardInterrupt`` propagates so callers can preserve the
    Ctrl-C graceful-exit semantics of the surrounding loop.

    With ``cv2_source=None`` (default) this is the legacy stdin-only
    wait. Pass a ``CameraPreviewWindow``-like ``cv2_source`` to also
    accept Enter / ESC from the cv2 preview window — whichever
    source fires first wins. ``stop_event``, when set externally,
    returns :data:`KEY_ESCAPE` immediately.

    Both kwargs are additive: any caller (or test) using the legacy
    positional-only signature continues to work unchanged.
    """
    return wait_for_key_combined(
        stop_keys, cv2_source=cv2_source, stop_event=stop_event
    )


def wait_for_key_combined(
    stop_keys: Iterable[str] = (KEY_ENTER, KEY_ESCAPE),
    *,
    cv2_source: Optional[Any] = None,
    stop_event: Optional[threading.Event] = None,
) -> str:
    """Block until one of ``stop_keys`` arrives from stdin **or** from
    the supplied ``cv2_source``.

    Both inputs are polled on every 50 ms tick; whichever fires first
    wins. ``cv2_source`` is any object exposing
    ``pop_key(timeout=0.0) -> Optional[str]`` returning one of
    ``"enter"`` / ``"escape"`` / ``None`` — typically a
    :class:`CameraPreviewWindow`. Pass ``None`` for the legacy
    stdin-only behaviour.

    ``stop_event`` is optional. When the event is set externally
    (e.g., by the live demo's global ESC watcher) this function
    returns :data:`KEY_ESCAPE` immediately so the surrounding
    key-wait can unwind cleanly.

    ``KeyboardInterrupt`` propagates from the stdin path.
    """
    accept = {k.strip().lower() for k in stop_keys}
    if not accept:
        accept = {KEY_ENTER, KEY_ESCAPE}

    if _msvcrt is not None:
        return _wait_for_key_windows(accept, cv2_source, stop_event)
    if _termios is not None and _tty is not None and _select is not None:
        return _wait_for_key_posix(accept, cv2_source, stop_event)
    # Final fallback for exotic platforms (no msvcrt, no termios/select).
    # When a cv2 source is supplied AND no stdin is available in raw
    # mode, we poll the cv2 queue on a slow tick. The stop_event is
    # honoured. Readline is the very last resort and BLOCKS — only
    # reachable when both cv2_source is None AND no platform helper
    # is available.
    if cv2_source is not None or stop_event is not None:
        while True:
            if stop_event is not None and stop_event.is_set():
                return KEY_ESCAPE
            cv2_key = _poll_cv2(cv2_source, accept)
            if cv2_key is not None:
                return cv2_key
            time.sleep(_POLL_INTERVAL_SECONDS)
    raw = sys.stdin.readline()
    if not raw:
        raise KeyboardInterrupt
    if raw.strip().lower() in {"esc", "escape"} and KEY_ESCAPE in accept:
        return KEY_ESCAPE
    if KEY_ENTER in accept:
        return KEY_ENTER
    # No matching key produced from the readline — re-raise as if
    # the stream closed; caller treats this as graceful exit.
    raise KeyboardInterrupt


# ---------------------------------------------------------------------------
# Cv2 polling helper (shared across platforms)
# ---------------------------------------------------------------------------


def _poll_cv2(
    cv2_source: Optional[Any], accept: set
) -> Optional[str]:
    """One non-blocking poll of ``cv2_source.pop_key`` filtered by
    ``accept``. Returns the matching key name or ``None``.

    Any exception raised by ``pop_key`` is swallowed — a broken cv2
    source must never break the stdin path."""
    if cv2_source is None:
        return None
    try:
        key = cv2_source.pop_key(0.0)
    except Exception:
        return None
    if key is None:
        return None
    name = str(key).strip().lower()
    if name in accept:
        return name
    return None


# ---------------------------------------------------------------------------
# Platform implementations (single-tick poll, used by the combined waiter)
# ---------------------------------------------------------------------------


def _wait_for_key_windows(
    accept: set,
    cv2_source: Optional[Any],
    stop_event: Optional[threading.Event],
) -> str:  # pragma: no cover - Windows
    assert _msvcrt is not None
    while True:
        if stop_event is not None and stop_event.is_set():
            return KEY_ESCAPE
        # Cv2 source first — instant short-circuit if a key is already
        # queued from the camera window. Polling stdin is otherwise
        # cheap; the explicit order matters only for testability
        # (tests can assert cv2 short-circuits without touching stdin).
        cv2_key = _poll_cv2(cv2_source, accept)
        if cv2_key is not None:
            return cv2_key
        if _msvcrt.kbhit():  # type: ignore[attr-defined]
            ch = _msvcrt.getwch()  # type: ignore[attr-defined]
            if ch == "\x03":
                # Ctrl-C — preserve graceful-exit behavior.
                raise KeyboardInterrupt
            if ch in ("\r", "\n") and KEY_ENTER in accept:
                return KEY_ENTER
            if ch == "\x1b" and KEY_ESCAPE in accept:
                return KEY_ESCAPE
            # Any other key is ignored — we only watch for the
            # configured stop keys.
            continue
        time.sleep(_POLL_INTERVAL_SECONDS)


def _wait_for_key_posix(
    accept: set,
    cv2_source: Optional[Any],
    stop_event: Optional[threading.Event],
) -> str:  # pragma: no cover - POSIX
    assert _termios is not None
    assert _tty is not None
    assert _select is not None
    fd = sys.stdin.fileno()
    old_settings = _termios.tcgetattr(fd)  # type: ignore[attr-defined]
    try:
        _tty.setcbreak(fd)  # type: ignore[attr-defined]
        while True:
            if stop_event is not None and stop_event.is_set():
                return KEY_ESCAPE
            cv2_key = _poll_cv2(cv2_source, accept)
            if cv2_key is not None:
                return cv2_key
            ready, _, _ = _select.select(  # type: ignore[attr-defined]
                [sys.stdin], [], [], _POLL_INTERVAL_SECONDS
            )
            if not ready:
                continue
            ch = sys.stdin.read(1)
            if not ch:
                # Stream closed — treat as EOF / Ctrl-D.
                raise KeyboardInterrupt
            if ch == "\x03":
                raise KeyboardInterrupt
            if ch in ("\r", "\n") and KEY_ENTER in accept:
                return KEY_ENTER
            if ch == "\x1b" and KEY_ESCAPE in accept:
                return KEY_ESCAPE
            # Other keys ignored.
    finally:
        _termios.tcsetattr(  # type: ignore[attr-defined]
            fd, _termios.TCSADRAIN, old_settings  # type: ignore[attr-defined]
        )
