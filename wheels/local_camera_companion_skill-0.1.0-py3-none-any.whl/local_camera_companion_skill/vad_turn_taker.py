# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""VAD state machine + event emission for the continuous-voice loop.

Pulls float32 frames from a ``ContinuousAudioCapture`` (or any
``iter_frames(chunk_samples, timeout)`` provider), passes them to a
``SileroVADAdapter`` (or any ``process_chunk(samples) -> float``
provider), runs a 3-state machine, and emits events via a callback:

    IDLE  --(prob >= threshold)-->  SPEAKING
    SPEAKING --(prob >= threshold)--> SPEAKING       (extends utterance)
    SPEAKING --(prob < threshold)-->  HANGOVER
    HANGOVER --(prob >= threshold)--> SPEAKING       (resume)
    HANGOVER --(silence_hangover_ms elapsed)--> END_OF_SPEECH -> IDLE

Events:
    ("start_of_speech", {"frame_index": int})
    ("end_of_speech",   {"audio_path": str, "duration_ms": int})

Event semantics:
    * ``start_of_speech`` fires when IDLE → SPEAKING. The runner uses
      it to drive barge-in.
    * ``end_of_speech`` fires when HANGOVER → END_OF_SPEECH provided
      the cumulative SPEAKING duration meets ``min_speech_duration_ms``.
      Otherwise the segment is silently dropped (noise-burst gate).
    * The captured float samples for each accepted utterance are
      handed to ``wav_writer(samples, path_hint=...)``, which the
      runner implements to emit a real 16 kHz mono PCM WAV.

Post-TTS self-trigger suppression:
    * ``note_tts_finished()`` records ``time.monotonic()``. While the
      next ``post_tts_suppression_ms`` of frames flow through, the
      machine stays in IDLE regardless of VAD probability.

This module is stdlib-only. No numpy, no openvino, no sounddevice.
The injected VAD and capture handle those dependencies.
"""

from __future__ import annotations

import logging
import threading
from typing import Any, Callable, List, Optional

logger = logging.getLogger(__name__)

__all__ = ["VADTurnTaker"]


# State labels (strings, not enum, to keep the test fixture readable).
_IDLE = "idle"
_SPEAKING = "speaking"
_HANGOVER = "hangover"


EventCallback = Callable[[str, dict], None]
WavWriter = Callable[..., str]


class VADTurnTaker:
    def __init__(
        self,
        *,
        vad: Any,
        capture: Any,
        wav_writer: WavWriter,
        threshold: float = 0.5,
        min_speech_duration_ms: int = 250,
        silence_hangover_ms: int = 400,
        post_tts_suppression_ms: int = 200,
        frame_duration_ms: int = 32,
        chunk_samples: int = 512,
    ) -> None:
        self._vad = vad
        self._capture = capture
        self._wav_writer = wav_writer
        self._threshold = float(threshold)
        self._min_speech_ms = int(min_speech_duration_ms)
        self._hangover_ms = int(silence_hangover_ms)
        self._post_tts_ms = int(post_tts_suppression_ms)
        self._frame_ms = int(frame_duration_ms)
        self._chunk_samples = int(chunk_samples)

        self._state = _IDLE
        self._stop_flag = threading.Event()
        self._event_cb: Optional[EventCallback] = None
        self._frame_cb: Optional[Callable[[], None]] = None

        # Per-utterance buffers and timers.
        self._utterance_samples: List[float] = []
        self._speech_frames_count = 0
        self._hangover_frames_count = 0

        # Post-TTS suppression (frame count).
        self._suppression_frames_remaining = 0
        self._utterance_index = 0

        # Error rate-limiter: VAD inference can fail every frame (e.g.
        # ONNX/OpenVINO version mismatch). Log the first occurrence with
        # full detail, then suppress duplicates so the console doesn't
        # flood. The flag resets if a future frame succeeds, so transient
        # failures still surface.
        self._vad_error_logged = False

        # External gating. The runner sets this False while a TTS reply
        # is being played back, so the mic can keep capturing (the
        # ``ContinuousAudioCapture`` queue keeps draining) but VAD
        # events do NOT fire. Prevents speaker-leak self-trigger during
        # the entire reply, not just the post-suppression window.
        self._vad_enabled = True

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def set_event_callback(self, cb: EventCallback) -> None:
        self._event_cb = cb

    def set_frame_callback(self, cb: Callable[[], None]) -> None:
        """Optional per-frame tap. Used by tests; no production caller."""
        self._frame_cb = cb

    def set_vad_enabled(self, enabled: bool) -> None:
        """Enable or disable VAD inference + event emission.

        While disabled, every frame is treated as silence (no VAD call,
        no state machine progression, no events). The capture queue
        keeps draining, so re-enabling resumes from the live frame
        rather than stale ones.
        """
        self._vad_enabled = bool(enabled)

    def note_tts_finished(self) -> None:
        """Mark the moment a TTS sentence/reply finished playing.

        The next ``post_tts_suppression_ms`` worth of frames are forced
        into IDLE regardless of VAD probability, mitigating
        speaker-leak self-trigger.
        """
        if self._post_tts_ms <= 0:
            return
        self._suppression_frames_remaining = self._ms_to_frames(self._post_tts_ms)

    def stop(self) -> None:
        self._stop_flag.set()

    def run_until_stopped(self) -> None:
        """Pull frames, run VAD, drive the state machine until stop()."""
        for frame in self._capture.iter_frames(
            chunk_samples=self._chunk_samples, timeout=0.5
        ):
            if self._stop_flag.is_set():
                return
            self._handle_frame(frame)
            if self._frame_cb is not None:
                self._frame_cb()
            if self._stop_flag.is_set():
                return

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _emit(self, kind: str, payload: dict) -> None:
        cb = self._event_cb
        if cb is None:
            return
        try:
            cb(kind, payload)
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("VADTurnTaker event callback raised: %s", exc)

    def _is_suppressed(self) -> bool:
        return self._suppression_frames_remaining > 0

    def _frames_to_ms(self, n_frames: int) -> int:
        return n_frames * self._frame_ms

    def _ms_to_frames(self, ms: int) -> int:
        if self._frame_ms <= 0:
            return 0
        return max(0, ms // self._frame_ms)

    def _handle_frame(self, frame: List[float]) -> None:
        if not self._vad_enabled:
            # VAD is gated off (typically because TTS is playing back a
            # reply). Skip inference entirely; the state machine stays
            # where it is. Resuming after re-enable picks up from live
            # audio, not buffered TTS leakage.
            return
        try:
            prob = float(self._vad.process_chunk(frame))
        except Exception as exc:
            if not self._vad_error_logged:
                # First failure: log the full error so the user can fix
                # the root cause (typically a Silero v5+ ONNX vs older
                # OpenVINO mismatch — see SileroVADAdapter._ensure_loaded).
                logger.warning(
                    "VAD process_chunk failed; treating frames as silence "
                    "until VAD recovers. Further per-frame errors will be "
                    "suppressed. Error: %s",
                    exc,
                )
                self._vad_error_logged = True
            prob = 0.0
        else:
            # Successful frame: reset the rate-limiter so a new failure
            # later in the session is logged once again.
            if self._vad_error_logged:
                self._vad_error_logged = False

        # Post-TTS suppression: pin to IDLE.
        if self._is_suppressed():
            self._suppression_frames_remaining -= 1
            self._state = _IDLE
            self._utterance_samples = []
            self._speech_frames_count = 0
            self._hangover_frames_count = 0
            return

        is_speech = prob >= self._threshold

        if self._state == _IDLE:
            if is_speech:
                self._state = _SPEAKING
                self._utterance_samples = list(frame)
                self._speech_frames_count = 1
                self._hangover_frames_count = 0
                self._emit("start_of_speech", {"frame_index": self._speech_frames_count})

        elif self._state == _SPEAKING:
            self._utterance_samples.extend(frame)
            if is_speech:
                self._speech_frames_count += 1
            else:
                self._state = _HANGOVER
                self._hangover_frames_count = 1

        elif self._state == _HANGOVER:
            self._utterance_samples.extend(frame)
            if is_speech:
                self._state = _SPEAKING
                self._speech_frames_count += 1 + self._hangover_frames_count
                self._hangover_frames_count = 0
            else:
                self._hangover_frames_count += 1
                hangover_elapsed_ms = self._frames_to_ms(self._hangover_frames_count)
                if hangover_elapsed_ms >= self._hangover_ms:
                    speech_ms = self._frames_to_ms(self._speech_frames_count)
                    if speech_ms >= self._min_speech_ms:
                        self._utterance_index += 1
                        path = self._wav_writer(
                            self._utterance_samples,
                            path_hint=f"vad_utt_{self._utterance_index}",
                        )
                        self._emit(
                            "end_of_speech",
                            {"audio_path": path, "duration_ms": speech_ms},
                        )
                    # Reset to IDLE either way.
                    self._state = _IDLE
                    self._utterance_samples = []
                    self._speech_frames_count = 0
                    self._hangover_frames_count = 0
