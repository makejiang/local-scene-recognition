# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Apparent-emotion cue policy for the Camera Companion Skill (Task 11).

Stdlib-only post-processor that scrubs scene-understanding output of
diagnostic claims, sensitive-trait inferences, and missing-uncertainty
emotion phrases. Returns new dataclass instances; inputs are never
mutated. Both public methods are idempotent.

Heavy dependencies (cv2, OpenVINO, sounddevice, torch, transformers,
PIL, numpy) are not imported.
"""

from __future__ import annotations

import re
from dataclasses import replace
from typing import Optional, Pattern, Tuple

from .schemas import EmotionConfidence, SceneUnderstanding
from .scene_response_parser import CameraCompanionResponsePayload

__all__ = ["EmotionCuePolicy"]


_UNCERTAINTY_HEDGES: Tuple[str, ...] = (
    "appears",
    "seems",
    "may",
    "might",
    "possibly",
    "based on visible cues",
    "looks like",
)


_DIAGNOSTIC_PATTERNS: Tuple[Tuple[Pattern[str], str], ...] = (
    (
        re.compile(r"\bis\s+depressed\b", re.IGNORECASE),
        "may appear sad based on visible cues",
    ),
    (
        re.compile(r"\bhas\s+depression\b", re.IGNORECASE),
        "may appear sad based on visible cues",
    ),
    (
        re.compile(r"\bhas\s+anxiety\b", re.IGNORECASE),
        "may appear uneasy based on visible cues",
    ),
    (
        re.compile(r"\bis\s+anxious\b", re.IGNORECASE),
        "may appear uneasy based on visible cues",
    ),
    (
        re.compile(r"\bis\s+mentally\s+ill\b", re.IGNORECASE),
        "I cannot determine their mental state",
    ),
    (
        re.compile(
            r"\bis\s+(?:bipolar|schizophrenic|psychotic|autistic|adhd)\b",
            re.IGNORECASE,
        ),
        "I cannot diagnose them",
    ),
)


_SENSITIVE_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(r"\bis\s+dangerous\b", re.IGNORECASE),
    re.compile(r"\bis\s+a\s+(?:criminal|terrorist|threat)\b", re.IGNORECASE),
    re.compile(
        r"\bis\s+(?:gay|straight|lesbian|trans|transgender)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bis\s+(?:muslim|christian|jewish|hindu|buddhist|atheist)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bis\s+(?:black|white|asian|hispanic|latino|arab)\b",
        re.IGNORECASE,
    ),
)


# ---------------------------------------------------------------------------
# Suggested-interaction safety policy (Task 31)
#
# An "unsafe" suggestion is one that encourages any of:
#   - non-consensual physical contact;
#   - invasion of personal space (cornering, blocking, looming, staring);
#   - pressuring or coercing a person to reveal feelings;
#   - repeated / coercive questioning;
#   - identity / sensitive-trait assumption;
#   - diagnostic / mental-health assumption.
#
# The policy:
#   - normalizes whitespace + casing for matching only (the *original*
#     suggestion text is preserved when it is safe; nothing is mutated
#     in-place);
#   - uses word-boundary patterns to avoid trivial false positives
#     such as "touch the table" or "touch the screen";
#   - distinguishes consent-aware wording: e.g. "Ask whether they
#     would like a hug, and respect their answer" is safe, while
#     "Hug them" is not.
#
# When a suggestion matches any unsafe category, it is **dropped**
# (replaced with ``None``). This is the documented stable behavior;
# idempotency is trivial because dropped suggestions stay dropped.
# ---------------------------------------------------------------------------


# Personal-contact verbs *aimed at a person*. Matched only when the
# verb's object is a personal pronoun, "their <body part>", "the
# person", "the child", etc. — not impersonal objects like "the
# table" or "the screen".
_CONTACT_VERBS: Tuple[str, ...] = (
    "touch",
    "tap",
    "pat",
    "stroke",
    "caress",
    "hug",
    "embrace",
    "cuddle",
    "kiss",
    "hold",
    "grab",
    "grip",
    "squeeze",
    "pull",
    "push",
    "shove",
    "nudge",
    "lean against",
    "lean on",
    "rest against",
    "shake hands with",
    "high five",
    "fist bump",
)

# Targets that mean "a person" or "their body part". Matching these
# keeps the policy from firing on "touch the table" / "tap the
# screen" / "hold the door".
_PERSON_TARGET_RE = (
    r"(?:"
    r"them|him|her|me|us|someone|anyone|the (?:child|kid|baby|man|woman|girl|boy|person|student|teacher|user)|"
    r"this (?:child|kid|baby|man|woman|girl|boy|person|student|teacher|user)|"
    r"that (?:child|kid|baby|man|woman|girl|boy|person|student|teacher|user)|"
    r"(?:his|her|their|the) "
    r"(?:hand|hands|shoulder|shoulders|arm|arms|elbow|elbows|wrist|wrists|"
    r"knee|knees|leg|legs|foot|feet|hair|cheek|cheeks|chin|chest|back|"
    r"face|head|finger|fingers|waist|hip|hips|neck)"
    r")"
)


def _build_contact_pattern() -> Pattern[str]:
    verbs_alt = "|".join(re.escape(v) for v in _CONTACT_VERBS)
    # ``\b`` boundary, contact verb, then optional adverb / modifier
    # words BEFORE the person target. The intermediate slot accepts
    # only adverbs (``gently``, ``softly``, ``firmly``...), articles
    # / determiners that introduce a person target, or punctuation —
    # but NOT a non-personal direct object like ``the door``. That
    # is what lets us skip "Hold the door for them and smile" while
    # still catching "Touch their shoulder gently".
    safe_modifier = (
        r"(?:"
        r"gently|softly|firmly|carefully|calmly|warmly|briefly|"
        r"slowly|tightly|reassuringly|kindly"
        r")"
    )
    sep = r"[\s,;:!?.\-]+"
    pattern = (
        rf"\b(?:{verbs_alt})\b"
        rf"{sep}"
        rf"(?:{safe_modifier}{sep})?"
        rf"{_PERSON_TARGET_RE}"
    )
    return re.compile(pattern, re.IGNORECASE)


_CONTACT_PATTERN: Pattern[str] = _build_contact_pattern()


# Indirect / semantic contact phrases (Task 40). These match the same
# kind of physical contact as ``_CONTACT_PATTERN`` but with non-direct
# verb-object structures that the original list does not catch:
# "give them a hug", "put your arm around them", "place your hand on
# their shoulder", "massage their shoulders", "take their hand", "sit
# on their lap". They participate in the same clause-aware consent
# gating as ``_CONTACT_PATTERN`` (see ``_is_consent_bypass``).
#
# Each pattern requires either an explicit person pronoun or a
# possessive ("their|his|her") that governs a body part, so generic
# offers like "Offer a hug if they want one." (no person pronoun
# governing the noun directly) and non-person object actions like
# "Place your hand on the table to demonstrate." remain unmatched.
_INDIRECT_CONTACT_PATTERNS: Tuple[Pattern[str], ...] = (
    # 1. "give them a hug", "give the child a kiss", "give him a
    #    long warm hug" — verb + person target + (a|an|the) +
    #    optional adjective(s) + contact-noun.
    re.compile(
        r"\b(?:give|gives|giving)\s+"
        r"(?:them|him|her|the\s+(?:child|kid|baby|man|woman|girl|boy|"
        r"person|student|teacher|user)|"
        r"this\s+(?:child|kid|baby|man|woman|girl|boy|person|student|teacher|user)|"
        r"that\s+(?:child|kid|baby|man|woman|girl|boy|person|student|teacher|user))"
        r"(?:\s+[a-z]+){0,3}\s+"
        r"(?:a|an|the|another|one)\s+"
        r"(?:[a-z]+\s+){0,3}"  # up to 3 modifying adjectives
        r"(?:hug|kiss|cuddle|squeeze|smooch|peck|"
        r"shoulder\s+rub|back\s+rub|massage)\b",
        re.IGNORECASE,
    ),
    # 2. "put/place/rest/lay your hand on their shoulder/back/...".
    re.compile(
        r"\b(?:put|puts|putting|place|places|placing|rest|rests|"
        r"resting|lay|lays|laying)\s+"
        r"(?:your|a|one|the|my|his|her)\s+"
        r"(?:hand|hands|fingers?|palm|palms)\s+"
        r"(?:gently|softly|firmly|warmly|reassuringly)?\s*"
        r"(?:on|onto|against)\s+"
        r"(?:their|his|her|the\s+(?:child|kid|baby|man|woman|girl|"
        r"boy|person|student|teacher|user)'?s?)\s+"
        r"(?:shoulder|shoulders|arm|arms|back|chest|leg|legs|"
        r"knee|knees|hand|hands|head|hair|cheek|cheeks|chin|"
        r"neck|waist|hip|hips|thigh|thighs|face)\b",
        re.IGNORECASE,
    ),
    # 3. "put/wrap/throw/sling your arm(s) around them / their
    #    shoulders / their waist".
    re.compile(
        r"\b(?:put|puts|putting|place|places|placing|wrap|wraps|"
        r"wrapping|throw|throws|throwing|sling|slings|slinging|"
        r"drape|drapes|draping)\s+"
        r"(?:your|an|one|both|the|my|his|her)\s+"
        r"arms?\s+"
        r"(?:gently|softly|warmly|reassuringly|tightly)?\s*"
        r"around\s+"
        r"(?:them|him|her|the\s+(?:child|kid|baby|man|woman|girl|boy|"
        r"person|student|teacher|user)|"
        r"(?:their|his|her)\s+"
        r"(?:shoulder|shoulders|waist|neck|body|frame))\b",
        re.IGNORECASE,
    ),
    # 4. "massage / rub / knead their shoulders / back / neck / ...".
    re.compile(
        r"\b(?:massage|massages|massaging|"
        r"rub|rubs|rubbing|"
        r"knead|kneads|kneading)\s+"
        r"(?:gently|softly|firmly|warmly)?\s*"
        r"(?:their|his|her|the\s+(?:child|kid|baby|man|woman|girl|"
        r"boy|person|student|teacher|user)'?s?)\s+"
        r"(?:shoulder|shoulders|back|neck|arms?|hands?|feet|foot|"
        r"scalp|temples?|legs?|calves?)\b",
        re.IGNORECASE,
    ),
    # 5. "take/grasp their hand". (``hold`` is already covered by
    #    ``_CONTACT_PATTERN``; ``take`` and ``grasp`` are not.)
    re.compile(
        r"\b(?:take|takes|taking|grasp|grasps|grasping|clasp|clasps|"
        r"clasping)\s+"
        r"(?:gently|softly|firmly|warmly)?\s*"
        r"(?:their|his|her|the\s+(?:child|kid|baby|man|woman|girl|"
        r"boy|person|student|teacher|user)'?s?)\s+"
        r"(?:hand|hands|wrist|wrists|fingers?|arm|arms)\b",
        re.IGNORECASE,
    ),
    # 6. Lap contact — "sit on their lap", "climb onto her lap", and
    #    the inviting form "let them sit on your lap".
    re.compile(
        r"\b(?:sit|sits|sitting|climb|climbs|climbing|jump|jumps|"
        r"jumping|crawl|crawls|crawling|hop|hops|hopping|"
        r"plop|plops|plopping)\s+"
        r"(?:down\s+)?"
        r"(?:on|onto|in|into)\s+"
        r"(?:their|his|her|the\s+(?:child|kid|baby|man|woman|girl|boy|"
        r"person|student|teacher|user)'?s?)\s+lap\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:invite|invites|inviting|let|lets|letting|tell|tells|"
        r"telling|encourage|encourages|encouraging|have)\s+"
        r"(?:them|him|her|the\s+(?:child|kid|baby|man|woman|girl|boy|"
        r"person|student|teacher|user))\s+"
        r"(?:to\s+)?"
        r"(?:sit|climb|crawl|hop|jump|plop)\s+"
        r"(?:down\s+)?"
        r"(?:on|onto|in|into)\s+"
        r"(?:your|my|the)\s+lap\b",
        re.IGNORECASE,
    ),
)


# Prohibition / avoidance prefixes (Task 40). When a clause begins
# with one of these, any contact phrasing inside the clause is a
# *guardrail*, not a directive, so the consent gate must not treat
# it as unsafe. Examples: "Do not hug them.", "Avoid putting your
# arm around them.", "Never massage their shoulders.", "Refrain
# from taking their hand.", "Instead of placing your hand on their
# shoulder, ask first."
_PROHIBITION_PREFIX_RE: Pattern[str] = re.compile(
    r"^(?:"
    r"do\s+not(?:\s+ever)?"
    r"|don'?t(?:\s+ever)?"
    r"|never"
    r"|avoid"
    r"|refrain\s+from"
    r"|do\s+not\s+attempt\s+to"
    r"|instead\s+of"
    r"|rather\s+than"
    r")\b",
    re.IGNORECASE,
)


# Personal-space / surveillance-style invasions. These do not need a
# person target — the verb itself is the violation.
_PERSONAL_SPACE_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(r"\bapproach(?:\s+(?:them|him|her|the\s+\w+))?\s+closely\b", re.IGNORECASE),
    re.compile(r"\bget\s+(?:up\s+)?close(?:r)?\s+to\s+(?:them|him|her|the\s+\w+)\b", re.IGNORECASE),
    re.compile(r"\bmove\s+closer\s+to\s+(?:them|him|her|the\s+\w+)\b", re.IGNORECASE),
    re.compile(r"\bstand\s+over\s+(?:them|him|her|the\s+\w+)\b", re.IGNORECASE),
    re.compile(r"\blean\s+over\s+(?:them|him|her|the\s+\w+)\b", re.IGNORECASE),
    re.compile(r"\bcorner\s+(?:them|him|her|the\s+\w+)\b", re.IGNORECASE),
    re.compile(r"\bblock\s+(?:their|his|her|the\s+\w+\'?s)\s+(?:path|way|exit)\b", re.IGNORECASE),
    re.compile(r"\bfollow\s+(?:them|him|her|the\s+\w+)\b", re.IGNORECASE),
    re.compile(r"\bstare\s+at\s+(?:them|him|her|the\s+\w+)\b", re.IGNORECASE),
    re.compile(r"\bloom\s+over\s+(?:them|him|her|the\s+\w+)\b", re.IGNORECASE),
    re.compile(r"\binvad(?:e|ing)\s+(?:their|his|her)\s+(?:personal\s+)?space\b", re.IGNORECASE),
)


# Pressuring / coercing language about feelings, emotions, or
# disclosures. Matches "demand they tell ...", "force them to share
# their feelings", "pressure them to open up", etc.
_PRESSURE_VERBS = (
    "demand",
    "insist",
    "pressure",
    "force",
    "coerce",
    "make",
    "compel",
    "guilt",
)
_DISCLOSE_TARGETS = (
    "feelings",
    "emotions",
    "thoughts",
    "secrets",
    "what they(?:'re| are)\\s+thinking",
    "what they(?:'re| are)\\s+feeling",
    "what(?:'s| is)\\s+wrong",
    "why they(?:'re| are)\\s+upset",
    "why they(?:'re| are)\\s+sad",
    "what happened",
)


def _build_pressure_pattern() -> Pattern[str]:
    verbs_alt = "|".join(_PRESSURE_VERBS)
    targets_alt = "|".join(_DISCLOSE_TARGETS)
    pattern = (
        rf"\b(?:{verbs_alt})\b"
        rf"\s+(?:them|him|her|the\s+\w+)\s+to\s+"
        rf"(?:tell|share|reveal|explain|admit|confess|disclose|open\s+up\s+about|talk\s+about)"
        rf"\s+(?:[a-z'\- ]{{0,40}}?\b(?:{targets_alt})\b)"
    )
    return re.compile(pattern, re.IGNORECASE)


_PRESSURE_PATTERN: Pattern[str] = _build_pressure_pattern()


# Generic "open up about their feelings" pressure phrasing without
# explicit verb (e.g. "Push them to open up about how they feel").
_PRESSURE_ALT_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(
        r"\b(?:push|press|pressure|force|guilt)\s+(?:them|him|her|the\s+\w+)\s+(?:in)?to\s+"
        r"(?:open\s+up|talk|tell\s+(?:you|us)|sharing|share|admit|admitting|confess|confessing|reveal|revealing)\b",
        re.IGNORECASE,
    ),
    # "Demand/insist/make/coerce/compel they/them ... tell/share/admit"
    # — short-circuits the longer ``_PRESSURE_PATTERN`` for cases
    # where there is no explicit "feelings" target.
    re.compile(
        r"\b(?:demand|insist)\s+(?:they|he|she)\s+"
        r"(?:tell|share|reveal|explain|admit|confess|disclose)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:make|force|coerce|compel)\s+(?:them|him|her)\s+"
        r"(?:to\s+)?(?:tell|share|reveal|explain|admit|confess|disclose)\b",
        re.IGNORECASE,
    ),
    # "Don't take no for an answer" / "Won't take no" / "Refuse to
    # accept no". Catches the imperative form as well.
    re.compile(
        r"\b(?:do(?:es)?n'?t|don'?t|won'?t|refuse\s+to)\s+"
        r"(?:take|accept)\s+(?:no|a\s+no|their\s+no)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bdon'?t\s+(?:let|allow)\s+(?:them|him|her)\s+(?:say|answer)\s+no\b",
        re.IGNORECASE,
    ),
)


# Repeated / coercive questioning.
_COERCIVE_QUESTION_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(
        r"\b(?:keep|continue)\s+asking\s+(?:them|him|her|the\s+\w+)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bask\s+(?:them|him|her|the\s+\w+)\s+(?:again\s+and\s+again|repeatedly|over\s+and\s+over)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:repeatedly|persistently)\s+ask\s+(?:them|him|her|the\s+\w+)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\binterrogat(?:e|ing)\s+(?:them|him|her|the\s+\w+)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bgrill\s+(?:them|him|her|the\s+\w+)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\buntil\s+(?:they|he|she)\s+(?:answer|tell|talk|admit|confess|give\s+in)s?\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bask\s+(?:them|him|her)\s+\d+\s+times\b",
        re.IGNORECASE,
    ),
)


# Identity / sensitive-trait assumption (suggested-interaction-flavored).
# These complement the `_SENSITIVE_PATTERNS` list, which only blocks
# "X is gay/Muslim/...". Here we block *suggestions* that act on an
# assumption: "Treat them as a Muslim", "Speak to them as a man", etc.
_IDENTITY_ASSUMPTION_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(
        r"\b(?:treat|address|approach|speak\s+to|talk\s+to)\s+"
        r"(?:them|him|her|the\s+\w+)\s+(?:as|like)\s+(?:a|an|the)\s+"
        r"(?:gay|straight|lesbian|trans|transgender|"
        r"muslim|christian|jewish|hindu|buddhist|atheist|"
        r"black|white|asian|hispanic|latino|arab|"
        r"man|woman|boy|girl|male|female|"
        r"criminal|terrorist|threat)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:assum|presum)(?:e|ing)\s+(?:they|he|she)\s+(?:is|are)\s+"
        r"(?:gay|straight|lesbian|trans|transgender|"
        r"muslim|christian|jewish|hindu|buddhist|atheist|"
        r"black|white|asian|hispanic|latino|arab|"
        r"depressed|anxious|autistic|adhd|bipolar|schizophrenic|"
        r"dangerous|a\s+criminal|a\s+terrorist|a\s+threat)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bbecause\s+(?:they|he|she)\s+"
        r"(?:is|are|looks?\s+like)\s+(?:a|an|the)?\s*"
        r"(?:gay|straight|lesbian|trans|transgender|"
        r"muslim|christian|jewish|hindu|buddhist|atheist|"
        r"black|white|asian|hispanic|latino|arab)\b",
        re.IGNORECASE,
    ),
)


# Diagnostic / mental-health assumption phrased as a suggestion.
# Includes both nominal forms ("as depression", "with anxiety") and
# adjectival forms ("as depressed", "as anxious").
_DIAGNOSTIC_SUGGESTION_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(
        r"\b(?:diagnose|treat)\s+(?:them|him|her|the\s+\w+)\s+(?:as|with|for)\s+"
        r"(?:depression|anxiety|adhd|autism|bipolar|schizophrenia|psychosis|"
        r"depressed|anxious|autistic|psychotic|schizophrenic|"
        r"mentally\s+ill)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\btell\s+(?:them|him|her)\s+(?:they|he|she)\s+(?:has|have|is|are)\s+"
        r"(?:depression|anxiety|adhd|autism|bipolar|schizophrenia|psychosis|"
        r"depressed|anxious|autistic|psychotic|schizophrenic|"
        r"mentally\s+ill)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bbecause\s+(?:they|he|she)\s+(?:has|have|is|are)\s+"
        r"(?:depression|anxiety|adhd|autism|bipolar|schizophrenic|"
        r"psychotic|mentally\s+ill|depressed|anxious|autistic)\b",
        re.IGNORECASE,
    ),
)


# Consent-aware patterns (legacy, retained for backwards compatibility).
# The Task-34 clause-aware logic below replaces this whole-string
# check. These patterns are now consulted only by ``_has_consent_signal``,
# which the contact gate no longer calls. Removing them risks
# breaking downstream importers that introspect the module, so they
# stay in place but are not the authority.
_CONSENT_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(
        r"\bask\s+(?:if|whether)\s+(?:they|he|she)\s+(?:would|'d)\s+"
        r"(?:like|want)\s+(?:a\s+)?"
        r"(?:hug|handshake|high\s*five|fist\s*bump|to\s+talk)",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bif\s+they\s+(?:say|answer)\s+yes\b", re.IGNORECASE
    ),
    re.compile(
        r"\bonly\s+if\s+(?:they|he|she)\s+(?:agrees?|consents?|wants?\s+to)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:respect|accept|honor)\s+(?:no|their\s+answer|their\s+(?:no|response|decision|choice|boundary|boundaries))\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:with|after|once you have)\s+(?:their\s+)?(?:explicit\s+|prior\s+)?consent\b",
        re.IGNORECASE,
    ),
)


# ---------------------------------------------------------------------------
# Clause-aware consent gating (Task 34)
#
# A consent phrase in one clause must not authorize an unsafe action
# in another clause. Two layers cooperate:
#
#   - ``_CONSENT_OVERRIDE_PATTERNS`` always block, regardless of any
#     consent wording elsewhere. They cover refusal-bypass language
#     ("even if they say no", "regardless of their response",
#     "without waiting", "assume silence means yes", "ignore their
#     refusal", "override their consent", "do it anyway").
#
#   - For each clause that performs contact against a person, the
#     clause itself must contain a local affirmative-yes gate, or the
#     immediately-preceding clause must be a consent predicate
#     ("if they say yes", "only if they agree"). Predicate scope
#     extends to the next clause only — never further.
#
# The text is split into clauses on sentence punctuation and
# conjunctions. Clause splitting runs on the lowercased *original*
# suggestion so punctuation/conjunctions survive long enough to
# identify boundaries that the existing punctuation-stripping
# normalizer would have erased.
# ---------------------------------------------------------------------------


_CONSENT_OVERRIDE_PATTERNS: Tuple[Pattern[str], ...] = (
    # "even if they say no" / "even if they're saying no" / "even if
    # they answer no"
    re.compile(
        r"\beven\s+if\s+(?:they|he|she)\s+"
        r"(?:say|says|saying|answer|answers|answering|are|is|'re)\s+"
        r"(?:saying\s+)?no\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bregardless\s+of\s+(?:their|his|her|the\s+person'?s)\s+"
        r"(?:answer|response|reply|wishes?|consent|decision|no)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bwithout\s+(?:waiting|asking|consent|permission|"
        r"their\s+(?:permission|consent|answer|response|reply|approval))\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:do(?:es)?\s+not|don'?t|won'?t|do\s+not)\s+"
        r"wait\s+for\s+(?:an?\s+)?(?:answer|response|reply|consent|permission)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bassume\s+(?:silence|no\s+response|they)\s+"
        r"(?:means?\s+|=\s*|is\s+)?yes\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:do(?:es)?\s+it|do\s+it|just\s+do\s+it)\s+anyway\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bproceed\s+(?:anyway|regardless|"
        r"without\s+(?:waiting|asking|consent|permission|their))\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bignore\s+(?:their|his|her|the\s+person'?s)\s+"
        r"(?:refusal|boundaries|boundary|no|response|wishes?|"
        r"hesitation|silence|protests?|reply)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:override|overrule|revoke|cancel|undo|disregard)\s+"
        r"(?:their|his|her)\s+"
        r"(?:consent|answer|wishes?|no|decision|boundaries?|"
        r"refusal|response|reply)\b",
        re.IGNORECASE,
    ),
    # Standalone "anyway" tied to a contact-style action: catches
    # "hug them anyway", "touch their arm anyway", and (Task 40)
    # indirect performers like "give them a hug anyway",
    # "massage their shoulders anyway", "put your arm around them
    # anyway".
    re.compile(
        r"\b(?:touch|tap|pat|stroke|hug|embrace|hold|grab|grip|"
        r"squeeze|kiss|cuddle|nudge|give|deliver|put|place|rest|"
        r"lay|wrap|throw|sling|drape|massage|rub|knead|take|grasp|"
        r"clasp|sit\s+on)\s+"
        r"(?:them|him|her|the\s+\w+|their\s+\w+|his\s+\w+)"
        r"(?:\s+[a-z]+){0,5}\s+anyway\b",
        re.IGNORECASE,
    ),
    # "hug them now without checking", "touch them now without asking"
    re.compile(
        r"\bnow\s+without\s+(?:checking|asking|waiting|consent|permission)\b",
        re.IGNORECASE,
    ),
)


# Per-clause local consent gate. A contact-performing clause must
# itself contain at least one of these patterns, OR the preceding
# clause must be a consent predicate (see below).
_LOCAL_CONSENT_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(
        r"\bif\s+(?:they|he|she)\s+(?:say|says|answer|answers)\s+yes\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bonly\s+(?:if|after|when)\s+(?:they|he|she)\s+"
        r"(?:[a-z]+\s+){0,2}"
        r"(?:agrees?|consents?|wants?\s+to|says?\s+yes|answers?\s+yes)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bafter\s+(?:they|he|she)\s+"
        r"(?:[a-z]+\s+){0,2}"
        r"(?:agree|agrees?|consent|consents?|say\s+yes|"
        r"says?\s+yes|answer\s+yes|answers?\s+yes)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bafter\s+(?:they|he|she)\s+(?:have\s+|has\s+)?"
        r"(?:agreed|consented|said\s+yes|answered\s+yes)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bwith\s+(?:their\s+)?(?:explicit\s+|prior\s+)?consent\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:when|once)\s+(?:they|he|she)\s+"
        r"(?:agrees?|consents?|says?\s+yes|answers?\s+yes)\b",
        re.IGNORECASE,
    ),
)


# Predicate-extending patterns. A clause that *only* establishes a
# consent predicate (e.g. "if they say yes,") extends affirmative
# scope to the *immediately following* clause. Predicate scope never
# carries past a single clause.
_CONSENT_PREDICATE_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(
        r"\bif\s+(?:they|he|she)\s+(?:say|says|answer|answers)\s+yes\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bif\s+(?:they|he|she)\s+(?:[a-z]+\s+){0,2}"
        r"(?:agrees?|consents?)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bonly\s+(?:if|after|when)\s+(?:they|he|she)\s+"
        r"(?:[a-z]+\s+){0,2}"
        r"(?:agrees?|consents?|says?\s+yes|answers?\s+yes)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\b(?:when|once|after)\s+(?:they|he|she)\s+"
        r"(?:agrees?|consents?|says?\s+yes|answers?\s+yes|"
        r"have\s+agreed|has\s+agreed|have\s+consented|has\s+consented)\b",
        re.IGNORECASE,
    ),
    # Task 40: "with (their) (explicit/prior) consent" as a leading
    # predicate clause extends affirmative scope to the next clause.
    re.compile(
        r"^\s*with\s+(?:their\s+)?(?:explicit\s+|prior\s+)?consent\b",
        re.IGNORECASE,
    ),
)


# Clause split markers. Run on the original text before
# punctuation-stripping so we can find boundaries.
#
# Task 40 additions: ``instead of`` and ``rather than`` introduce a
# guardrail clause whose body describes what NOT to do; splitting at
# those tokens lets the prohibition-prefix detector see the
# guardrail clause start with one of those keywords.
_CLAUSE_SPLIT_RE = re.compile(
    r"[.;:!?]+"
    r"|—"
    r"|--"
    r"|,"
    r"|\bbut\s+then\b"
    r"|\band\s+then\b"
    r"|\bbut\b"
    r"|\bthen\b"
    r"|(?=\binstead\s+of\b)"
    r"|(?=\brather\s+than\b)",
    re.IGNORECASE,
)


def _split_into_clauses(text: str) -> List[str]:
    """Split ``text`` (raw, possibly mixed-case) into trimmed clauses.

    Clause boundaries: sentence punctuation (``. ; : ! ?``), commas,
    em-dashes, and the conjunctions ``then``, ``but``, ``and then``,
    ``but then``.
    """
    parts = _CLAUSE_SPLIT_RE.split(text)
    out: List[str] = []
    for p in parts:
        if p is None:
            continue
        s = p.strip()
        if s:
            out.append(s)
    return out


def _is_consent_bypass(original_text: str) -> bool:
    """Return True when a contact-performing clause is not legitimately
    consent-gated, OR when an override pattern appears anywhere.

    Operates on the *original* text (preserving punctuation and
    conjunctions) so clause boundaries survive long enough to be
    meaningful. Inside each clause :func:`_normalize_for_match` is
    applied so the contact-pattern and local-consent regexes see the
    same shape they expect.
    """
    if not original_text or not original_text.strip():
        return False

    # 1. Override always blocks, regardless of consent wording elsewhere.
    norm_full = _normalize_for_match(original_text)
    if any(p.search(norm_full) for p in _CONSENT_OVERRIDE_PATTERNS):
        return True

    # 2. Per-clause consent gate.
    clauses = _split_into_clauses(original_text)
    if not clauses:
        return False
    predicate_active = False
    saw_clause_level_contact = False
    # Task 40: track when contact text exists *only* inside
    # prohibition / avoidance clauses ("Do not hug them.",
    # "Avoid putting your arm around them.", "Instead of placing
    # your hand on their shoulder, ..."). The fallback below must
    # not flag those — they are guardrails, not directives.
    saw_contact_in_prohibition_only = False
    for clause in clauses:
        norm = _normalize_for_match(clause)
        # Task 40: indirect-contact patterns participate in the same
        # clause-aware gate.
        raw_contact = (
            bool(_CONTACT_PATTERN.search(norm))
            or any(p.search(norm) for p in _INVASIVE_INTERACTION_PATTERNS)
            or any(p.search(norm) for p in _INDIRECT_CONTACT_PATTERNS)
        )
        in_prohibition = bool(_PROHIBITION_PREFIX_RE.match(norm))
        contact_here = raw_contact and not in_prohibition
        if raw_contact and in_prohibition:
            saw_contact_in_prohibition_only = True
        if contact_here:
            saw_clause_level_contact = True
            local_gate = any(
                p.search(norm) for p in _LOCAL_CONSENT_PATTERNS
            )
            if not (local_gate or predicate_active):
                return True
        # A predicate clause that *also* performs contact does not
        # extend predicate scope further — the predicate has been
        # consumed by this clause.
        is_predicate = any(
            p.search(norm) for p in _CONSENT_PREDICATE_PATTERNS
        )
        predicate_active = is_predicate and not contact_here

    # 3. Fallback: punctuation-bypass attacks like "Hug,  them." split
    # the contact verb away from the person target across clauses.
    # If the *whole-text* contact pattern fires but no clause did,
    # treat it as unsafe — clause-level consent gating cannot apply
    # because the action verb and its target are in different
    # clauses, so neither clause has a meaningful local consent gate.
    # Task 40 exception: if every contact match landed inside a
    # prohibition clause, the fallback must NOT fire.
    if (
        not saw_clause_level_contact
        and not saw_contact_in_prohibition_only
        and (
            _CONTACT_PATTERN.search(norm_full)
            or any(p.search(norm_full) for p in _INVASIVE_INTERACTION_PATTERNS)
            or any(p.search(norm_full) for p in _INDIRECT_CONTACT_PATTERNS)
        )
    ):
        return True

    return False


# ---------------------------------------------------------------------------
# Task 45: Chinese-language safety coverage.
#
# Chinese text doesn't have word boundaries (``\b`` is a no-op against
# CJK characters), so these patterns identify unsafe phrasings via
# substring matching. They run *in parallel* with the English pattern
# set — every English contract is preserved unchanged.
# ---------------------------------------------------------------------------

# A person target in Chinese: pronouns, generic nouns, or relational
# nouns the user might suggest interacting with.
_PERSON_TARGET_ZH = (
    "他", "她", "它", "你", "您",
    "他们", "她们", "你们", "您们",
    "这个人", "那个人", "对方", "这人", "那人",
    "小孩", "孩子", "小朋友", "宝宝", "婴儿",
    "男人", "女人", "男生", "女生", "男士", "女士",
    "学生", "老师", "用户", "用户朋友",
    "他/她",
)
_PERSON_RE_ZH = "(?:" + "|".join(_PERSON_TARGET_ZH) + ")"

# Body parts referenced in possessive form ``他/她/对方的X``.
_BODY_PART_ZH = (
    "头", "脸", "脖子", "肩", "肩膀", "肩头",
    "背", "后背", "腰", "胳膊", "手", "手臂",
    "腿", "膝盖", "脚", "脚踝",
    "怀", "怀里", "腿上", "膝上",
)
_BODY_RE_ZH = "(?:" + "|".join(_BODY_PART_ZH) + ")"

# Diagnostic Chinese terms (must be softened or dropped from
# apparent_emotion / answer_text).
_DIAGNOSTIC_PATTERNS_ZH: Tuple[Tuple[Pattern[str], str], ...] = (
    # ``他很抑郁`` / ``她很抑郁`` / ``这个人很抑郁`` — direct claim of
    # depression. Reduce to hedged phrasing.
    (
        re.compile(rf"{_PERSON_RE_ZH}(?:很|非常|十分)?(?:抑郁|忧郁)"),
        "看起来情绪低落（基于可见线索）",
    ),
    (
        re.compile(rf"{_PERSON_RE_ZH}(?:有|患有|得了)?抑郁症"),
        "看起来情绪低落（基于可见线索）",
    ),
    (
        re.compile(rf"{_PERSON_RE_ZH}(?:很|非常)?(?:焦虑|紧张)"),
        "看起来略显紧张（基于可见线索）",
    ),
    (
        re.compile(rf"{_PERSON_RE_ZH}(?:有|患有|得了)?焦虑症"),
        "看起来略显紧张（基于可见线索）",
    ),
    (
        re.compile(
            rf"{_PERSON_RE_ZH}(?:有|患有|得了)?"
            r"(?:精神病|多动症|自闭症|双相情感障碍|"
            r"精神分裂症|强迫症|创伤后应激)"
        ),
        "无法判断对方的心理状态",
    ),
    (
        re.compile(
            rf"{_PERSON_RE_ZH}(?:一定|肯定|必然|必定)(?:很|非常)?"
            r"(?:生气|愤怒|难过|伤心|悲伤|害怕|恐惧)"
        ),
        "看起来情绪有些波动（基于可见线索）",
    ),
)

# Sensitive Chinese trait assumptions (sexual orientation, religion,
# ethnicity, nationality, disability). Scrubbed from any field.
_SENSITIVE_PATTERNS_ZH: Tuple[Pattern[str], ...] = (
    re.compile(
        rf"{_PERSON_RE_ZH}(?:是|肯定是|应该是|看起来是|可能是|"
        r"显然是)?(?:同性恋|异性恋|双性恋|跨性别)"
    ),
    re.compile(
        rf"{_PERSON_RE_ZH}(?:是|肯定是|应该是|可能是)?"
        r"(?:穆斯林|基督徒|犹太人|佛教徒|印度教徒|天主教徒|无神论者)"
    ),
    re.compile(
        rf"{_PERSON_RE_ZH}(?:是|肯定是|应该是|可能是)?"
        r"(?:黑人|白人|亚洲人|拉丁人|阿拉伯人|外国人)"
    ),
    re.compile(
        rf"{_PERSON_RE_ZH}(?:是|肯定是|应该是|可能是)?"
        r"(?:残疾人|有残疾|身体不便|智力障碍|精神障碍)"
    ),
    re.compile(
        rf"{_PERSON_RE_ZH}(?:是|肯定是|应该是|可能是)?"
        r"(?:罪犯|恐怖分子|危险人物)"
    ),
    # ``因为他是同性恋,所以...`` — causal-justification phrasing
    # asserts a sensitive trait without observation.
    re.compile(
        rf"因为\s*{_PERSON_RE_ZH}\s*是\s*"
        r"(?:同性恋|异性恋|双性恋|跨性别|穆斯林|基督徒|"
        r"犹太人|黑人|白人|亚洲人|外国人|残疾人)"
    ),
    # ``把他当作残疾人/抑郁症患者来对待`` — sensitive-trait
    # assumption used as an interaction justification.
    re.compile(
        rf"(?:把|对|对待|看待)\s*{_PERSON_RE_ZH}\s*"
        r"(?:当作|当成|看作|视为|看做|看成).*?"
        r"(?:同性恋|跨性别|穆斯林|犹太人|黑人|白人|外国人|"
        r"残疾人|智力障碍|精神障碍|抑郁症|焦虑症|"
        r"精神病|多动症|自闭症)"
    ),
    re.compile(
        rf"因为\s*{_PERSON_RE_ZH}\s*是\s*残疾人"
    ),
)

# Unsafe contact verbs in Chinese — touching, hugging, patting,
# stroking, kissing, holding, taking, etc. The verb must be followed
# (within a few characters) by a person target.
_CONTACT_PATTERNS_ZH: Tuple[Pattern[str], ...] = (
    # ``抱他``, ``抱抱她``, ``抱一下她``, ``给他一个拥抱``,
    # ``拥抱她``.
    re.compile(
        rf"(?:抱抱|抱一下|抱住|抱|拥抱|搂|搂住|搂着|搂抱)\s*{_PERSON_RE_ZH}"
    ),
    re.compile(
        rf"给\s*{_PERSON_RE_ZH}\s*(?:一个|来个|来一个)?"
        r"(?:拥抱|抱抱|抱一下|亲吻|亲一下|亲|吻|按摩)"
    ),
    # ``拍拍他``, ``拍他的肩``, ``摸摸头``, ``摸他``, ``捏他的脸``.
    re.compile(
        rf"(?:拍|拍拍|摸|摸摸|捏|捏一下|戳|戳一下)\s*"
        rf"(?:{_PERSON_RE_ZH}|{_PERSON_RE_ZH}的{_BODY_RE_ZH}|{_BODY_RE_ZH})"
    ),
    # ``牵他的手``, ``握他的手``, ``挽她的胳膊``, ``扶他``.
    re.compile(
        rf"(?:牵|握|握住|拉|拉住|挽|挽着|扶|扶住|搭|搭着)\s*"
        rf"{_PERSON_RE_ZH}(?:的{_BODY_RE_ZH})?"
    ),
    re.compile(
        rf"(?:把手放在|把胳膊放在|把头靠在)\s*{_PERSON_RE_ZH}(?:的{_BODY_RE_ZH})?"
    ),
    # ``坐在他腿上``, ``靠在她肩上``, ``趴在他怀里``.
    re.compile(
        rf"(?:坐|趴|靠|躺|蜷|窝)在\s*{_PERSON_RE_ZH}(?:的)?{_BODY_RE_ZH}(?:上|里)"
    ),
    re.compile(
        rf"(?:让|叫|请|邀|哄)\s*{_PERSON_RE_ZH}\s*坐"
        r"(?:在|到)?(?:你|我)的?(?:腿|怀|身)上"
    ),
    # ``亲她``, ``吻她``, ``亲一下他``.
    re.compile(rf"(?:亲|亲一下|亲亲|吻|吻一下)\s*{_PERSON_RE_ZH}"),
    re.compile(rf"按摩\s*{_PERSON_RE_ZH}(?:的{_BODY_RE_ZH})?"),
)

# Personal-space invasion in Chinese — looming, cornering, following.
_PERSONAL_SPACE_PATTERNS_ZH: Tuple[Pattern[str], ...] = (
    re.compile(
        rf"(?:靠近|凑近|挨近|逼近|接近)\s*{_PERSON_RE_ZH}"
    ),
    re.compile(rf"(?:挡|挡住|挡在)\s*{_PERSON_RE_ZH}(?:的)?(?:路|去路|前面)"),
    re.compile(rf"(?:跟|跟着|跟住|尾随)\s*{_PERSON_RE_ZH}"),
    re.compile(rf"(?:站|站在|站到)\s*{_PERSON_RE_ZH}(?:的)?(?:身后|背后|旁边)"),
    re.compile(rf"(?:盯|盯着|紧盯|盯住|死盯)\s*{_PERSON_RE_ZH}"),
    re.compile(rf"(?:逼|堵)在(?:角落|墙角)"),
)

# Pressure-to-reveal-feelings in Chinese.
_PRESSURE_PATTERNS_ZH: Tuple[Pattern[str], ...] = (
    re.compile(
        rf"(?:逼|强迫|要求|施压|压|让)\s*{_PERSON_RE_ZH}"
        r"\s*(?:说出|讲出|告诉|分享|承认|交代|交待|坦白)"
        r"(?:.*?)(?:感受|情绪|想法|秘密|心事|真相)"
    ),
    re.compile(
        rf"(?:不停地|一直|反复|持续地|连续)?(?:追问|盘问|质问|审问)\s*{_PERSON_RE_ZH}"
    ),
    re.compile(rf"(?:必须|一定要)\s*{_PERSON_RE_ZH}\s*(?:回答|说出|讲出)"),
    re.compile(r"不\s*回答\s*就\s*不\s*行"),
    re.compile(r"(?:不停地|一直|反复)\s*问"),
    re.compile(rf"问到\s*{_PERSON_RE_ZH}?\s*回答(?:为止|才停)"),
)

# Refusal-bypass / override Chinese patterns. Always block regardless
# of any consent wording elsewhere.
_OVERRIDE_PATTERNS_ZH: Tuple[Pattern[str], ...] = (
    re.compile(r"即使.{0,5}(?:说不|拒绝|不愿意|不同意).{0,8}也(?:要|得|得要)"),
    re.compile(r"无视(?:他|她|对方|他们|她们)?(?:的)?(?:拒绝|意愿|回答|反对)"),
    re.compile(r"不管.{0,5}(?:说什么|怎么说|怎么想)"),
    re.compile(r"(?:无论如何|不管怎样).{0,5}(?:都要|也要)"),
    re.compile(r"不\s*征求.{0,3}(?:同意|意见)"),
    re.compile(r"不问.{0,3}(?:就|直接)"),
    re.compile(r"不等.{0,3}(?:回答|答复|同意)"),
)

# Consent predicates that, when they precede an unsafe-looking phrase,
# preserve the suggestion (mirrors English "if they say yes" /
# "with their consent" semantics).
_CONSENT_PREDICATES_ZH: Tuple[Pattern[str], ...] = (
    re.compile(r"(?:如果|要是|假如|若).{0,8}(?:同意|愿意|说好|说可以|答应)"),
    re.compile(r"(?:征得|取得|获得|得到).{0,5}(?:同意|许可)"),
    re.compile(r"(?:在.{0,5}(?:同意|许可|允许)的?(?:前提|条件|情况)下)"),
    re.compile(r"(?:经|经过).{0,5}(?:同意|许可|允许)"),
    re.compile(r"在.{0,5}(?:愿意|同意).{0,5}的?情况下"),
)

# Prohibition / avoidance prefix in Chinese. When a clause STARTS with
# any of these, treat the contact phrase that follows as a guardrail
# (preserved), not a directive to perform contact.
_PROHIBITION_PREFIX_ZH = re.compile(
    r"^\s*(?:不要|不可以|不可|请勿|切勿|避免|严禁|禁止|"
    r"不应|不该)"
)

# "Offer / ask" Chinese forms that are inherently safe even when they
# mention contact nouns — they propose asking, not performing.
_OFFER_ASK_PATTERNS_ZH: Tuple[Pattern[str], ...] = (
    re.compile(
        r"(?:可以)?(?:问问|询问|问一下|问下|向.{0,5}问).{0,8}"
        r"(?:是否|要不要|想不想|愿不愿意|能否|可不可以)"
    ),
    re.compile(
        r"(?:可以)?(?:用|以)?(?:温和的|友好的|轻柔的|平和的)语气"
    ),
    re.compile(r"(?:可以)?(?:友好地|温和地|礼貌地)?\s*(?:打招呼|问候)"),
    re.compile(r"(?:可以)?(?:邀请|建议).{0,5}(?:聊聊|谈谈|说说)"),
)

# Coarse "any Chinese contact-related verb" probe used to gate the
# consent-aware path.
_ANY_CONTACT_PROBE_ZH = re.compile(
    r"(?:抱|拥抱|搂|搂抱|拍|摸|捏|戳|牵|握|拉|挽|扶|搭|"
    r"按摩|亲|吻|坐在.{0,3}腿|坐在.{0,3}怀|趴在.{0,3}怀|"
    r"靠在.{0,3}肩|靠近|凑近|挨近|跟着|盯着)"
)


def _has_consent_signal_zh(text: str) -> bool:
    return any(p.search(text) for p in _CONSENT_PREDICATES_ZH)


def _is_consent_bypass_zh(text: str) -> bool:
    """Return True iff the Chinese suggestion's contact phrase is
    *not* protected by a consent predicate.

    Uses a coarser model than the English clause splitter because
    Chinese sentence structure varies more around the verb. We split
    on Chinese clause separators (``，``, ``。``, ``；``, ``、`` plus
    ASCII variants) and check each clause:

      - if the clause begins with a prohibition prefix, it's a
        guardrail — skip;
      - if the clause matches an "offer/ask" preserved form, skip;
      - if the clause contains a contact phrase AND no consent
        predicate (in this clause or the immediately preceding one),
        return True (= unsafe).
    """
    if not text:
        return False
    if any(p.search(text) for p in _OVERRIDE_PATTERNS_ZH):
        return True
    # Chinese clause separators.
    parts = re.split(r"[，。；、,;.]+", text)
    saw_predicate = False
    for raw in parts:
        clause = raw.strip()
        if not clause:
            continue
        if _PROHIBITION_PREFIX_ZH.match(clause):
            saw_predicate = False  # prefix-only clause, drop predicate
            continue
        if any(p.search(clause) for p in _OFFER_ASK_PATTERNS_ZH) and not (
            _ANY_CONTACT_PROBE_ZH.search(clause)
            and any(p.search(clause) for p in _CONTACT_PATTERNS_ZH)
        ):
            saw_predicate = False
            continue
        clause_has_contact = (
            any(p.search(clause) for p in _CONTACT_PATTERNS_ZH)
            or any(p.search(clause) for p in _PERSONAL_SPACE_PATTERNS_ZH)
        )
        clause_predicate = _has_consent_signal_zh(clause)
        if clause_has_contact and not (saw_predicate or clause_predicate):
            return True
        saw_predicate = clause_predicate
    return False


def _matches_unsafe_category_zh(text: str) -> Optional[str]:
    """Return the matched Chinese unsafe category, or None."""
    if not text:
        return None
    # Refusal-bypass overrides everything.
    if any(p.search(text) for p in _OVERRIDE_PATTERNS_ZH):
        return "consent_override"
    if any(p.search(text) for p in _PRESSURE_PATTERNS_ZH):
        return "pressure"
    if any(p.search(text) for p in _SENSITIVE_PATTERNS_ZH):
        return "identity_assumption"
    # Diagnostic *suggestions* (e.g. "treat them as depressed") are
    # blocked at the suggestion gate. Diagnostic *emotion claims*
    # (e.g. "他很抑郁") are softened by ``_soften_diagnostic_zh``
    # rather than blocked, so we don't flag them here.
    if (
        any(p.search(text) for p in _CONTACT_PATTERNS_ZH)
        or any(p.search(text) for p in _PERSONAL_SPACE_PATTERNS_ZH)
    ):
        if _is_consent_bypass_zh(text):
            return "non_consensual_contact"
    return None


def _soften_diagnostic_zh(text: str) -> str:
    out = text
    for pat, replacement in _DIAGNOSTIC_PATTERNS_ZH:
        out = pat.sub(replacement, out)
    return out


def _scrub_sensitive_zh(text: str) -> str:
    out = text
    for pat in _SENSITIVE_PATTERNS_ZH:
        out = pat.sub("", out)
    return out.strip()


_INVASIVE_INTERACTION_PATTERNS: Tuple[Pattern[str], ...] = (
    # Legacy patterns retained for backwards-compat / catch-all.
    re.compile(r"\bgrab\s+(?:them|him|her|the\s+\w+|their\s+\w+|his\s+\w+|her\s+\w+)\b", re.IGNORECASE),
    re.compile(r"\bapproach\s+closely\b", re.IGNORECASE),
)


_PUNCT_NORMALIZE_RE = re.compile(r"[,;:!?\.\-]+")


def _normalize_for_match(text: str) -> str:
    """Whitespace + punctuation normalization + casefold.

    Punctuation between words ("Hug, them.") is converted to spaces
    so word-boundary regexes can fire even on heavily punctuated
    inputs. Original text is never mutated; this string is used for
    matching only.
    """
    out = _PUNCT_NORMALIZE_RE.sub(" ", text)
    return _collapse_whitespace(out).casefold()


def _has_consent_signal(text: str) -> bool:
    """True iff the suggestion contains explicit consent-aware wording.

    Used to gate contact verbs that would otherwise be unsafe.
    """
    return any(p.search(text) for p in _CONSENT_PATTERNS)


def _matches_unsafe_category(
    text: str,
    *,
    original_text: Optional[str] = None,
) -> Optional[str]:
    """Return the first matched unsafe category, or None.

    The order is: pressure -> coercive questioning -> identity ->
    diagnostic -> personal-space -> contact (clause-aware consent
    check) -> legacy invasive. The category name is returned for
    tests; the skill itself does not need it.

    ``text`` is the punctuation-stripped, casefolded suggestion used
    by the existing non-contact patterns. ``original_text`` is the
    raw suggestion (with punctuation and conjunctions intact) used
    by the clause-aware contact gate. When ``original_text`` is None
    the clause logic falls back to ``text`` — giving callers from
    older code paths the same behavior they always had.
    """
    if any(p.search(text) for p in _PRESSURE_ALT_PATTERNS):
        return "pressure"
    if _PRESSURE_PATTERN.search(text):
        return "pressure"
    if any(p.search(text) for p in _COERCIVE_QUESTION_PATTERNS):
        return "coercive_questioning"
    if any(p.search(text) for p in _IDENTITY_ASSUMPTION_PATTERNS):
        return "identity_assumption"
    if any(p.search(text) for p in _DIAGNOSTIC_SUGGESTION_PATTERNS):
        return "diagnostic_assumption"
    if any(p.search(text) for p in _PERSONAL_SPACE_PATTERNS):
        return "personal_space"
    # Task 34: refusal-bypass language is unsafe regardless of which
    # action it accompanies. "Offer a handshake and proceed
    # regardless of their response." has no contact verb against a
    # person, but the phrase itself signals coercive intent.
    if any(p.search(text) for p in _CONSENT_OVERRIDE_PATTERNS):
        return "consent_override"
    if _CONTACT_PATTERN.search(text):
        # Task 34: clause-aware consent check on the original
        # (punctuation-preserving) text. A consent phrase in one
        # clause does not authorize contact in another.
        gate_input = original_text if original_text is not None else text
        if _is_consent_bypass(gate_input):
            return "non_consensual_contact"
    # Task 40: indirect / semantic contact phrases route through the
    # same clause-aware gate.
    if any(p.search(text) for p in _INDIRECT_CONTACT_PATTERNS):
        gate_input = original_text if original_text is not None else text
        if _is_consent_bypass(gate_input):
            return "non_consensual_contact"
    if any(p.search(text) for p in _INVASIVE_INTERACTION_PATTERNS):
        return "invasive_legacy"
    return None


def _collapse_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _has_hedge(text: str) -> bool:
    lower = text.lower()
    return any(h in lower for h in _UNCERTAINTY_HEDGES)


def _ensure_hedge(text: str) -> str:
    t = text.strip()
    if not t:
        return t
    if _has_hedge(t):
        return t
    # Decapitalize first letter only when it's a normal sentence start
    # (single capital followed by lowercase) so proper nouns survive.
    if t[0].isupper() and (len(t) < 2 or not t[1].isupper()):
        t = t[0].lower() + t[1:]
    return f"Based on visible cues, {t}"


def _scrub_sensitive(text: str) -> str:
    out = text
    for pat in _SENSITIVE_PATTERNS:
        out = pat.sub("", out)
    return _collapse_whitespace(out)


def _soften_diagnostic(text: str) -> str:
    out = text
    for pat, replacement in _DIAGNOSTIC_PATTERNS:
        out = pat.sub(replacement, out)
    return out


class EmotionCuePolicy:
    """Deterministic post-processor for scene-understanding output."""

    def apply(self, scene: SceneUnderstanding) -> SceneUnderstanding:
        emotion = scene.apparent_emotion
        new_emotion: Optional[str]

        if emotion is None or not emotion.strip():
            new_emotion = None
        else:
            cleaned = _soften_diagnostic(emotion)
            cleaned = _soften_diagnostic_zh(cleaned)
            cleaned = _scrub_sensitive(cleaned)
            cleaned = _scrub_sensitive_zh(cleaned)
            cleaned = cleaned.strip()
            if not cleaned:
                new_emotion = None
            else:
                # Chinese hedged forms already include 看起来/可能/
                # 从可见线索看; only force the English "Based on
                # visible cues" prefix for English text.
                if any(0x4E00 <= ord(ch) <= 0x9FFF for ch in cleaned):
                    new_emotion = cleaned
                else:
                    new_emotion = _ensure_hedge(cleaned)

        if new_emotion is None or not new_emotion.strip():
            new_confidence = EmotionConfidence.unknown
        else:
            new_confidence = scene.emotion_confidence

        return replace(
            scene,
            apparent_emotion=new_emotion,
            emotion_confidence=new_confidence,
        )

    def apply_payload(
        self,
        payload: CameraCompanionResponsePayload,
    ) -> CameraCompanionResponsePayload:
        new_scene = self.apply(payload.scene)

        # Cue-driven confidence downgrade.
        cues_present = any(
            isinstance(c, str) and c.strip() for c in payload.observable_cues
        )
        emotion_present = bool(
            new_scene.apparent_emotion and new_scene.apparent_emotion.strip()
        )
        if (
            emotion_present
            and not cues_present
            and new_scene.emotion_confidence
            in (EmotionConfidence.medium, EmotionConfidence.high)
        ):
            new_scene = replace(new_scene, emotion_confidence=EmotionConfidence.low)

        # Sanitize answer_text (diagnostic + sensitive substitutions; no hedge prefix).
        new_answer = payload.answer_text
        if isinstance(new_answer, str) and new_answer.strip():
            new_answer = _soften_diagnostic(new_answer)
            new_answer = _soften_diagnostic_zh(new_answer)
            new_answer = _scrub_sensitive(new_answer)
            new_answer = _scrub_sensitive_zh(new_answer)

        # Sanitize suggested_interaction.
        #
        # Strategy:
        #   1. If empty, drop.
        #   2. Run the hardened safety policy on the *original*
        #      suggestion. Matching the original text avoids letting
        #      the diagnostic-softening step ("has depression" ->
        #      hedged phrase) hide an unsafe category from the
        #      detector.
        #   3. If unsafe, drop entirely. Documented stable behavior;
        #      idempotent because dropped stays dropped.
        #   4. Otherwise soften diagnostic wording and scrub
        #      sensitive-trait claims. If the result is non-empty,
        #      return it; if rewriting emptied the string, drop.
        suggestion = payload.suggested_interaction
        new_suggestion: Optional[str]
        if suggestion is None or not suggestion.strip():
            new_suggestion = None
        elif _matches_unsafe_category(
            _normalize_for_match(suggestion),
            original_text=suggestion,
        ):
            new_suggestion = None
        elif _matches_unsafe_category_zh(suggestion):
            # Task 45: Chinese-language unsafe categories — dropped
            # with the same drop-then-stay-dropped contract.
            new_suggestion = None
        else:
            cleaned = _soften_diagnostic(suggestion)
            cleaned = _soften_diagnostic_zh(cleaned)
            cleaned = _scrub_sensitive(cleaned)
            cleaned = _scrub_sensitive_zh(cleaned)
            cleaned = cleaned.strip()
            if not cleaned:
                new_suggestion = None
            else:
                new_suggestion = cleaned

        return replace(
            payload,
            scene=new_scene,
            answer_text=new_answer,
            suggested_interaction=new_suggestion,
        )
