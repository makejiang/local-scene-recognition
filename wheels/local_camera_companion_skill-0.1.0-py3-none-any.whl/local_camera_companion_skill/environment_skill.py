# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Public CameraCompanionSkill orchestrator (Task 09).

Stitches together the already-built collaborators (config, session
manager, preview controller, prompt builder, scene parser) for the
"text question + current camera frame" path.

Heavy dependencies (cv2, OpenVINO, sounddevice, torch, transformers)
are never imported here. The optional pipeline / camera handler / TTS
engine are dependency-injected; default tests pass fakes.
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .asr_adapter import ASRAdapter
from .audio_capture import AudioRecorder
from .camera_preview import CameraPreviewController
from .config import CameraCompanionConfig
from .emotion_cue_policy import EmotionCuePolicy
from .exceptions import (
    CameraSessionInactiveError,
    CameraSessionStartupError,
)
from .privacy import sanitize_message, sanitize_metadata, sanitize_response_payload
from .schemas import (
    CameraCompanionResponse,
    CompanionPersona,
    CompanionSessionState,
    SceneQuestionType,
)
from .scene_prompt_builder import ScenePromptBuilder
from .scene_question_classifier import infer_scene_question_type
from .scene_response_parser import (
    CameraCompanionResponsePayload,
    parse_scene_model_output,
    strip_think_tags,
)
from .session_manager import CameraCompanionSessionManager
from .tts_reply import TTSReplyController, TTSReplyResult
from .ack_player import AckPlayer, AckPlayerConfig

logger = logging.getLogger(__name__)

__all__ = ["CameraCompanionSkill"]


# Flashcard mode emits a single English word (or "UNKNOWN") via the
# fast-mode prompt. We wrap that bare word in a fixed English carrier
# sentence so MiniCPM-o's TTS — which infers language from the text
# itself — pronounces it cleanly in English instead of stumbling on
# an unframed token.
_FLASHCARD_CARRIER = "The English word is: {word}."
_FLASHCARD_UNKNOWN_REPLY = "Sorry, I cannot tell what's on the card."

# Bare acknowledgments / fillers MiniCPM-o sometimes emits when the
# vision encoder can't recognise the card content. Treating them as
# legitimate "English words" would produce nonsense like "The English
# word is: ok." — which actually happened in field session
# 2026-06-29 21:04. Route them to the UNKNOWN fallback instead.
_FLASHCARD_FILLER_ANSWERS = frozenset(
    {
        # English
        "ok", "okay", "sure", "yes", "no", "yeah", "nope",
        "hi", "hello", "hey", "thanks", "thank you",
        # Chinese
        "好的", "当然", "是", "是的", "对", "对的", "不", "不是",
        "你好", "嗨", "谢谢",
    }
)


def _wrap_flashcard_answer(raw_word: str) -> str:
    """Wrap the model's bare word/UNKNOWN sentinel in an English
    carrier sentence suitable for TTS. Strips quotes, trailing
    punctuation, and case-normalises so noisy model output still
    produces a clean reply.

    Field session 19:06: model occasionally ignored the "ONLY the
    English word" rule and emitted multi-line / multi-sentence output
    like ``"backpack\\nThe card depicts a school bag."``. Before
    formatting the carrier sentence we collapse the model output to
    its FIRST line and FIRST sentence fragment so multi-sentence
    drift cannot escape into TTS.
    """
    text = (raw_word or "").strip()
    if not text:
        return _FLASHCARD_UNKNOWN_REPLY
    # Take only the first non-empty line — the model was asked for
    # a single word so anything past a newline is drift.
    first_line = next(
        (line for line in text.splitlines() if line.strip()), ""
    )
    # Within that line, stop at the first sentence boundary.
    for terminator in (". ", "。", "！", "!", "？", "?", ";", "；"):
        idx = first_line.find(terminator)
        if idx > 0:
            first_line = first_line[:idx]
    cleaned = first_line.strip()
    cleaned = cleaned.strip("\"'`“”‘’.,!?。，！？")
    cleaned = cleaned.strip()
    if not cleaned or cleaned.upper() == "UNKNOWN":
        return _FLASHCARD_UNKNOWN_REPLY
    # Acknowledgment-style filler answers ("OK", "好的", etc.) are
    # the model's way of saying "I didn't really process this"; speak
    # the fallback instead of pronouncing the filler verbatim.
    if cleaned.lower() in _FLASHCARD_FILLER_ANSWERS:
        return _FLASHCARD_UNKNOWN_REPLY
    # Lowercase looks more natural in the carrier ("The English word
    # is: apple.") and matches how the prompt asked the model to reply.
    # Multi-word phrases like "school bag" are preserved.
    return _FLASHCARD_CARRIER.format(word=cleaned.lower())


def _flashcard_filler_match(raw_word: str) -> Optional[str]:
    """Return the matched filler string (lowercased) if ``raw_word``
    would be rejected by ``_wrap_flashcard_answer`` as an
    acknowledgment, otherwise ``None``.

    Used by the call site to surface the rejection reason in the
    response debug payload without re-running the full wrap logic.
    """
    text = (raw_word or "").strip()
    if not text:
        return None
    first_line = next(
        (line for line in text.splitlines() if line.strip()), ""
    )
    for terminator in (". ", "。", "！", "!", "？", "?", ";", "；"):
        idx = first_line.find(terminator)
        if idx > 0:
            first_line = first_line[:idx]
    cleaned = first_line.strip()
    cleaned = cleaned.strip("\"'`“”‘’.,!?。，！？")
    cleaned = cleaned.strip()
    if not cleaned:
        return None
    low = cleaned.lower()
    if low in _FLASHCARD_FILLER_ANSWERS:
        return low
    return None

# ---------------------------------------------------------------------------
# Multilingual flashcard mode: target-language carriers, Chinese fallback,
# per-language filler tables, and parameterised wrap/match helpers. The
# English helpers above are intentionally NOT refactored to share the
# parameterised body so the English code path stays byte-for-byte
# unchanged from PR #13.
# ---------------------------------------------------------------------------

_FLASHCARD_FR_CARRIER = "Le mot français est : {word}."
_FLASHCARD_JA_CARRIER = "日本語では「{word}」です。"
_FLASHCARD_DE_CARRIER = "Das deutsche Wort ist: {word}."

# Single shared fallback for all three foreign-language paths. The user
# asked in Chinese; we respond in Chinese when we cannot read the card.
_FLASHCARD_FOREIGN_UNKNOWN_REPLY = "抱歉，我认不出卡片上的内容。"


# Per-language filler tables. Each one carries the target-language
# acknowledgments the model might emit when it can't read the card,
# plus the same Chinese fillers the English filler table catches —
# MiniCPM-o sometimes drops back to Chinese under uncertainty.

_FLASHCARD_FR_FILLER_ANSWERS = frozenset(
    {
        # French acknowledgments
        "oui", "non", "d'accord", "ok", "okay", "salut", "bonjour", "merci",
        # Chinese acknowledgments (shared with the English path)
        "好的", "当然", "是", "是的", "对", "对的", "不", "不是",
        "你好", "嗨", "谢谢",
    }
)

_FLASHCARD_JA_FILLER_ANSWERS = frozenset(
    {
        # Japanese acknowledgments
        "はい", "いいえ", "うん", "ええ", "もちろん",
        "こんにちは", "やあ", "ありがとう",
        # Chinese acknowledgments
        "好的", "当然", "是", "是的", "对", "对的", "不", "不是",
        "你好", "嗨", "谢谢",
    }
)

_FLASHCARD_DE_FILLER_ANSWERS = frozenset(
    {
        # German acknowledgments — note "ja" overlaps with German "yes";
        # when emitted bare for a flashcard, treat as acknowledgment.
        "ja", "nein", "okay", "ok", "klar", "natürlich",
        "hallo", "hi", "danke",
        # Chinese acknowledgments
        "好的", "当然", "是", "是的", "对", "对的", "不", "不是",
        "你好", "嗨", "谢谢",
    }
)


def _wrap_flashcard_answer_foreign(
    raw_word: str,
    *,
    carrier: str,
    fillers: frozenset,
    lowercase: bool,
) -> str:
    """Parameterised wrap shared by the FR / JA / DE flashcard paths.

    Same shape as ``_wrap_flashcard_answer`` (the English path): collapse
    multi-line drift to the first sentence fragment, strip quotes and
    trailing punctuation, route ``UNKNOWN`` / empty / filler answers to
    the shared Chinese fallback. ``lowercase=True`` lowercases the
    cleaned word before slotting it into the carrier (French
    convention); ``lowercase=False`` preserves the model's case
    (German proper-noun capitalisation; Japanese has no case).
    """
    text = (raw_word or "").strip()
    if not text:
        return _FLASHCARD_FOREIGN_UNKNOWN_REPLY
    first_line = next(
        (line for line in text.splitlines() if line.strip()), ""
    )
    for terminator in (". ", "。", "！", "!", "？", "?", ";", "；"):
        idx = first_line.find(terminator)
        if idx > 0:
            first_line = first_line[:idx]
    cleaned = first_line.strip()
    cleaned = cleaned.strip("\"'`""''.,!?。，！？")
    cleaned = cleaned.strip()
    if not cleaned or cleaned.upper() == "UNKNOWN":
        return _FLASHCARD_FOREIGN_UNKNOWN_REPLY
    if cleaned.lower() in fillers:
        return _FLASHCARD_FOREIGN_UNKNOWN_REPLY
    out = cleaned.lower() if lowercase else cleaned
    return carrier.format(word=out)


def _wrap_flashcard_answer_fr(raw_word: str) -> str:
    return _wrap_flashcard_answer_foreign(
        raw_word,
        carrier=_FLASHCARD_FR_CARRIER,
        fillers=_FLASHCARD_FR_FILLER_ANSWERS,
        lowercase=True,
    )


def _wrap_flashcard_answer_ja(raw_word: str) -> str:
    return _wrap_flashcard_answer_foreign(
        raw_word,
        carrier=_FLASHCARD_JA_CARRIER,
        fillers=_FLASHCARD_JA_FILLER_ANSWERS,
        lowercase=False,
    )


def _wrap_flashcard_answer_de(raw_word: str) -> str:
    return _wrap_flashcard_answer_foreign(
        raw_word,
        carrier=_FLASHCARD_DE_CARRIER,
        fillers=_FLASHCARD_DE_FILLER_ANSWERS,
        lowercase=False,
    )


def _flashcard_filler_match_foreign(
    raw_word: str, *, fillers: frozenset
) -> Optional[str]:
    """Return the matched filler string (lowercased) if ``raw_word``
    would be rejected by ``_wrap_flashcard_answer_foreign`` as an
    acknowledgment, otherwise ``None``. Used by the call site to
    surface the rejection reason in the response debug payload."""
    text = (raw_word or "").strip()
    if not text:
        return None
    first_line = next(
        (line for line in text.splitlines() if line.strip()), ""
    )
    for terminator in (". ", "。", "！", "!", "？", "?", ";", "；"):
        idx = first_line.find(terminator)
        if idx > 0:
            first_line = first_line[:idx]
    cleaned = first_line.strip()
    cleaned = cleaned.strip("\"'`""''.,!?。，！？")
    cleaned = cleaned.strip()
    if not cleaned:
        return None
    low = cleaned.lower()
    if low in fillers:
        return low
    return None


def _flashcard_filler_match_fr(raw_word: str) -> Optional[str]:
    return _flashcard_filler_match_foreign(
        raw_word, fillers=_FLASHCARD_FR_FILLER_ANSWERS
    )


def _flashcard_filler_match_ja(raw_word: str) -> Optional[str]:
    return _flashcard_filler_match_foreign(
        raw_word, fillers=_FLASHCARD_JA_FILLER_ANSWERS
    )


def _flashcard_filler_match_de(raw_word: str) -> Optional[str]:
    return _flashcard_filler_match_foreign(
        raw_word, fillers=_FLASHCARD_DE_FILLER_ANSWERS
    )


# Dispatch tables consulted by ``_run_scene_qa_after_frame``. The
# English entry points at the unmodified English helpers; the new
# entries point at the foreign-language helpers added in Task 5.
_FLASHCARD_TYPES = frozenset({
    SceneQuestionType.flashcard,
    SceneQuestionType.flashcard_fr,
    SceneQuestionType.flashcard_ja,
    SceneQuestionType.flashcard_de,
})

_FLASHCARD_WRAP_DISPATCH = {
    SceneQuestionType.flashcard:    (_wrap_flashcard_answer,    _flashcard_filler_match),
    SceneQuestionType.flashcard_fr: (_wrap_flashcard_answer_fr, _flashcard_filler_match_fr),
    SceneQuestionType.flashcard_ja: (_wrap_flashcard_answer_ja, _flashcard_filler_match_ja),
    SceneQuestionType.flashcard_de: (_wrap_flashcard_answer_de, _flashcard_filler_match_de),
}


_MOCK_JSON = json.dumps(
    {
        "scene_summary": "A simple indoor scene captured from the camera.",
        "visible_objects": ["table", "book"],
        "visible_people_count": 0,
        "observable_cues": [],
        "apparent_emotion": "",
        "emotion_confidence": "unknown",
        "answer": "I see a table with a book on it.",
        "suggested_interaction": "",
        "safety_note": "",
    }
)


class _MockPipeline:
    """Deterministic stand-in for an OmniModelAdapter used when ``mock_model=True``."""

    def __init__(self) -> None:
        self.calls: List[Dict[str, Any]] = []

    def generate_from_mixed(
        self,
        prompt: str,
        *,
        text: Optional[str] = None,
        audio_path: Optional[Any] = None,
        image_path: Optional[Any] = None,
        max_new_tokens: int = 512,
    ) -> str:
        self.calls.append(
            {
                "prompt": prompt,
                "text": text,
                "image_path": str(image_path) if image_path is not None else None,
            }
        )
        return _MOCK_JSON


def _coerce_persona(value: Union[CompanionPersona, str, None]) -> CompanionPersona:
    if value is None:
        return CompanionPersona.warm
    if isinstance(value, CompanionPersona):
        return value
    try:
        return CompanionPersona(str(value))
    except ValueError:
        return CompanionPersona.warm


def _coerce_config(
    value: Union[CameraCompanionConfig, dict, None],
) -> CameraCompanionConfig:
    if value is None:
        return CameraCompanionConfig()
    if isinstance(value, CameraCompanionConfig):
        return value
    if isinstance(value, dict):
        return CameraCompanionConfig.from_dict(value)
    raise TypeError(
        f"config must be CameraCompanionConfig, dict, or None; got {type(value).__name__}"
    )


class CameraCompanionSkill:
    """Public skill class wiring scene QA over a single camera frame."""

    def __init__(
        self,
        *,
        config: Union[CameraCompanionConfig, dict, None] = None,
        pipeline: Any = None,
        preview_controller: Optional[CameraPreviewController] = None,
        camera_handler: Any = None,
        session_manager: Optional[CameraCompanionSessionManager] = None,
        prompt_builder: Optional[ScenePromptBuilder] = None,
        tts_engine: Any = None,
        asr_adapter: Optional[ASRAdapter] = None,
        audio_recorder: Optional[AudioRecorder] = None,
        emotion_policy: Optional[EmotionCuePolicy] = None,
        tts_reply_controller: Optional[TTSReplyController] = None,
        debug_raw_model_output: bool = False,
        mock_model: bool = False,
    ) -> None:
        self._config: CameraCompanionConfig = _coerce_config(config)
        self._sessions: CameraCompanionSessionManager = (
            session_manager or CameraCompanionSessionManager()
        )
        self._prompt_builder: ScenePromptBuilder = (
            prompt_builder or ScenePromptBuilder()
        )
        self._preview: CameraPreviewController = preview_controller or CameraPreviewController(
            output_dir=self._config.vision.frame_output_dir,
            mode=self._config.vision.preview_mode,
            frame_interval_seconds=self._config.vision.frame_interval_seconds,
            max_background_errors=self._config.vision.max_background_errors,
        )
        self._camera_handler: Any = camera_handler
        self._tts_engine: Any = tts_engine
        self._asr_adapter: Optional[ASRAdapter] = asr_adapter
        self._audio_recorder: Optional[AudioRecorder] = audio_recorder
        self._emotion_policy: EmotionCuePolicy = emotion_policy or EmotionCuePolicy()
        self._tts_reply_controller: Optional[TTSReplyController] = tts_reply_controller
        # Post-ASR acknowledgment clip. Resolves the bundled WAV
        # fixture path unless overridden in
        # config.interaction.ack_clip_path. AckPlayer's skip
        # predicates handle the missing-file case so this never
        # crashes when the fixture isn't installed.
        ack_path_override = getattr(
            self._config.interaction, "ack_clip_path", None
        )
        if ack_path_override:
            _ack_wav_path = Path(str(ack_path_override))
        else:
            _ack_wav_path = (
                Path(__file__).resolve().parent.parent
                / "local_minicpm_runtime"
                / "config"
                / "ack_zh.wav"
            )
        self._ack_player: AckPlayer = AckPlayer(
            AckPlayerConfig(
                enabled=bool(
                    getattr(
                        self._config.interaction, "ack_clip_enabled", True
                    )
                ),
                wav_path=_ack_wav_path,
                response_language=str(
                    getattr(
                        self._config.interaction, "response_language", "auto"
                    )
                ),
                # Round-9: 2-second silent pause on the ACK thread
                # BEFORE the WAV starts, measured from the moment the
                # transcript is displayed. During those 2 seconds the
                # LLM is already computing (wait() was moved out of
                # the pre-LLM anchor), so ACK+delay overlaps LLM.
                delay_before_play_s=2.0,
            )
        )
        self._debug_raw_model_output: bool = bool(debug_raw_model_output)

        if pipeline is None and mock_model:
            self._pipeline: Any = _MockPipeline()
        else:
            self._pipeline = pipeline

        # ASR cold-start tracking. The MiniCPM-o audio encoder
        # compiles lazily on the first transcribe; without this gate
        # the first turn's ``asr_ms`` lumps compile + encode + decode
        # together (110 s on a 32 GB Intel Arc B390 cold start). The
        # live demo calls :meth:`warmup_asr` during the startup banner;
        # the voice path is also a defensive last-resort warmup so
        # programmatic callers don't pay it inside turn 1.
        self._asr_warm: bool = False
        self._asr_last_compile_ms: int = 0

    # ------------------------------------------------------------------
    # Public accessors
    # ------------------------------------------------------------------

    def warmup_asr(self) -> Dict[str, Any]:
        """Pre-compile the ASR audio encoder.

        OpenVINO compiles the MiniCPM-o ``audio_encoder_model`` lazily
        on the first ``transcribe()``. On Intel integrated GPUs that
        compile + VRAM upload can take a minute or more, which
        previously landed inside turn 1's ``asr_ms``. Voice-mode
        callers (live demo, smoke runners) should call this method
        during their startup banner so the first real turn pays only
        the per-utterance inference cost.

        Returns ``{"compile_ms": int, "skipped": bool,
        "reason": Optional[str]}`` for caller-side logging. Idempotent
        — a second call returns ``skipped=True``. Best-effort: any
        failure (no adapter, mock pipeline without an audio runtime,
        OpenVINO compile error) is captured in ``reason`` rather than
        raised.
        """
        if self._asr_warm:
            return {
                "compile_ms": self._asr_last_compile_ms,
                "skipped": True,
                "reason": "already_warm",
            }
        if self._asr_adapter is None:
            self._asr_warm = True
            return {"compile_ms": 0, "skipped": True, "reason": "no_asr_adapter"}
        warmup = getattr(self._asr_adapter, "warmup", None)
        if not callable(warmup):
            self._asr_warm = True
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": "warmup_unavailable",
            }
        try:
            info = warmup()
        except Exception as exc:  # noqa: BLE001 - best effort
            self._asr_warm = True
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": f"{type(exc).__name__}: {exc}",
            }
        self._asr_warm = True
        if not isinstance(info, dict):
            return {"compile_ms": 0, "skipped": True, "reason": "bad_return"}
        self._asr_last_compile_ms = int(info.get("compile_ms", 0) or 0)
        # Pass through sub-timings if the adapter exposed them so the
        # live-demo banner can print encoder + LM CPU twin separately.
        return {
            "compile_ms": self._asr_last_compile_ms,
            "skipped": bool(info.get("skipped", False)),
            "reason": info.get("reason"),
            "encoder_compile_ms": int(info.get("encoder_compile_ms", 0) or 0),
            "lm_cpu_twin_compile_ms": int(
                info.get("lm_cpu_twin_compile_ms", 0) or 0
            ),
        }

    @property
    def config(self) -> CameraCompanionConfig:
        """Read-only access to the loaded configuration.

        Exposed so external runners (live demo, smoke runners) can
        thread per-section settings (e.g. ``config.vad``) into the
        components they own — VAD turn-taker, audio recorder, etc.
        Mutating the returned object is supported but undefined; the
        skill itself does not re-read it after construction.
        """
        return self._config

    # ------------------------------------------------------------------
    # Public methods (filled in by later commits)
    # ------------------------------------------------------------------

    def start_camera_session(
        self,
        camera_index: Optional[int] = None,
        persona: Union[CompanionPersona, str] = CompanionPersona.warm,
    ) -> CameraCompanionResponse:
        """Start the camera preview transactionally and commit a session.

        Task 39: a session is only committed after the preview reports
        ``running=True`` AND ``has_frame=True``. Any failure raises
        :class:`CameraSessionStartupError` (basename-safe message) and
        guarantees that no session was registered with the manager
        and that the preview has been closed.
        """
        persona_enum = _coerce_persona(persona)
        effective_index = (
            int(camera_index)
            if camera_index is not None
            else int(self._config.vision.camera_index)
        )

        # Step 1: open preview first. ``start()`` is documented to
        # never raise, but custom controllers may; treat both as a
        # startup failure.
        try:
            self._preview.start(camera_index=effective_index)
        except Exception as exc:
            self._best_effort_stop_preview()
            raise CameraSessionStartupError(
                str(exc) or exc.__class__.__name__,
                stage="preview_start_raised",
                preview_running=False,
                preview_has_frame=False,
            ) from exc

        # Step 2: inspect preview state. ``start()`` may have returned
        # silently after recording an internal error. We only treat
        # ``has_frame`` as authoritative when the controller actually
        # reports it; absent ``has_frame`` is interpreted as "running
        # implies usable" so minimal fakes that don't track first
        # frames continue to pass.
        preview_status = self._safe_preview_status()
        running = bool(preview_status.get("running"))
        has_frame_value = preview_status.get("has_frame")
        has_frame_explicit = has_frame_value is not None
        has_frame_ok = (
            bool(has_frame_value) if has_frame_explicit else running
        )
        last_error = preview_status.get("last_error") or preview_status.get(
            "error"
        )
        if not running:
            self._best_effort_stop_preview()
            raise CameraSessionStartupError(
                str(last_error) if last_error else "preview did not start",
                stage="preview_not_running",
                preview_running=False,
                preview_has_frame=bool(has_frame_value),
            )
        if has_frame_explicit and not has_frame_ok:
            self._best_effort_stop_preview()
            raise CameraSessionStartupError(
                str(last_error)
                if last_error
                else "preview reported no first frame",
                stage="no_first_frame",
                preview_running=False,
                preview_has_frame=False,
            )

        # Step 3: commit the session. Roll back the preview if session
        # creation itself fails so we never leak hardware.
        try:
            state = self._sessions.create_session(persona=persona_enum)
        except Exception as exc:
            self._best_effort_stop_preview()
            raise CameraSessionStartupError(
                str(exc) or exc.__class__.__name__,
                stage="session_create_failed",
                preview_running=running,
                preview_has_frame=has_frame_ok,
            ) from exc

        return CameraCompanionResponse(
            session_id=state.session_id,
            question_type=SceneQuestionType.general,
            reply_text="Camera session started.",
            scene=None,
            should_play_tts=False,
            debug={
                "action": "start_camera_session",
                "camera_index": effective_index,
                "preview_running": self._preview.is_running(),
            },
        )

    def stop_camera_session(self, session_id: str) -> CameraCompanionResponse:
        """Stop the session and the preview.

        Task 39: idempotent on already-stopped sessions. ``KeyError``
        is raised only for unknown session ids; calling stop a second
        time on the same session returns a successful response with
        ``debug["repeat_stop"] is True``. The underlying
        ``CameraPreviewController.stop()`` is itself idempotent, so a
        repeated stop is safe.
        """
        # Raises KeyError on unknown session — propagated to caller.
        existing = self._sessions.require_session(session_id)
        repeat_stop = not existing.active
        if not repeat_stop:
            state = self._sessions.stop_session(session_id)
        else:
            state = existing
        try:
            self._preview.stop()
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning(
                "preview_controller.stop() raised: %s",
                sanitize_message(exc),
            )
        return CameraCompanionResponse(
            session_id=state.session_id,
            question_type=SceneQuestionType.general,
            reply_text="Camera session stopped.",
            scene=None,
            should_play_tts=False,
            debug={
                "action": "stop_camera_session",
                "preview_running": self._preview.is_running(),
                "repeat_stop": repeat_stop,
            },
        )

    # ------------------------------------------------------------------
    # Startup helpers (Task 39)
    # ------------------------------------------------------------------

    def _best_effort_stop_preview(self) -> None:
        """Stop the preview, swallowing any errors.

        Used by ``start_camera_session`` to roll back partial
        preview state on every failure path.
        """
        try:
            self._preview.stop()
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning(
                "preview_controller.stop() during startup rollback "
                "raised: %s",
                sanitize_message(exc),
            )

    def _safe_preview_status(self) -> Dict[str, Any]:
        """Return ``preview.status()`` or an inferred dict if it raises.

        ``status()`` is part of the controller protocol but not all
        custom controllers implement it. Fall back to the
        ``is_running`` boolean so the transactional check still
        works against minimal fakes.
        """
        status_fn = getattr(self._preview, "status", None)
        if callable(status_fn):
            try:
                result = status_fn()
            except Exception as exc:  # pragma: no cover - defensive
                logger.debug(
                    "preview.status() raised: %s", sanitize_message(exc)
                )
                result = None
            if isinstance(result, dict):
                return result
        running = False
        try:
            running = bool(self._preview.is_running())
        except Exception:  # pragma: no cover - defensive
            running = False
        return {
            "running": running,
            "has_frame": running,
            "last_error": None,
        }

    def describe_current_view(self, session_id: str) -> CameraCompanionResponse:
        return self.ask_about_current_view(
            session_id,
            "Please describe what you see in the current camera view.",
            question_type=SceneQuestionType.general,
            capture_fresh_frame=False,
        )

    def ask_about_current_view(
        self,
        session_id: str,
        question_text: str,
        *,
        question_type: SceneQuestionType = SceneQuestionType.general,
        capture_fresh_frame: bool = False,
        custom_rules: Optional[str] = None,
        reasoning: bool = False,
    ) -> CameraCompanionResponse:
        # KeyError for unknown id; CameraSessionInactiveError for stopped.
        state = self._sessions.require_active_session(session_id)
        # Auto-classify only when the caller passed the default
        # ``general`` AND no custom prompt is in effect. Explicit caller
        # intent (an explicit type or a custom prompt) always wins. The
        # live demo's text mode hardcodes general just like the voice
        # path, so this surfaces objects-aware prompts on questions like
        # "画面中有电视吗" without needing an upstream change.
        text_extra: Dict[str, Any] = {}
        if not (custom_rules or "").strip() and (
            question_type == SceneQuestionType.general
        ):
            inferred = infer_scene_question_type(question_text)
            if inferred != SceneQuestionType.general:
                question_type = inferred
                text_extra["question_type_inferred"] = inferred.value
        frame_or_safe = self._acquire_frame_or_safe_response(
            state,
            capture_fresh_frame,
            question_type,
            action="ask_about_current_view",
        )
        if isinstance(frame_or_safe, CameraCompanionResponse):
            if text_extra:
                frame_or_safe.debug.update(text_extra)
            return frame_or_safe
        return self._run_scene_qa_after_frame(
            state,
            question_text,
            question_type,
            frame_or_safe,
            action="ask_about_current_view",
            extra_debug=text_extra or None,
            custom_rules=custom_rules,
            reasoning=reasoning,
        )

    def ask_about_current_view_audio(
        self,
        session_id: str,
        *,
        audio_path: Optional[Union[str, Path]] = None,
        record_seconds: Optional[float] = None,
        question_type: SceneQuestionType = SceneQuestionType.general,
        capture_fresh_frame: bool = False,
        custom_rules: Optional[str] = None,
        reasoning: bool = False,
    ) -> CameraCompanionResponse:
        action = "ask_about_current_view_audio"
        # KeyError for unknown id; CameraSessionInactiveError for stopped.
        state = self._sessions.require_active_session(session_id)

        # ---- audio acquisition ----
        used_audio: Path
        if audio_path is not None:
            used_audio = Path(audio_path)
        else:
            if self._audio_recorder is None:
                return self._safe_response(
                    state.session_id,
                    question_type,
                    action=action,
                    reason="no_audio_recorder",
                )
            try:
                duration = (
                    float(record_seconds)
                    if record_seconds is not None
                    else float(self._config.audio.max_record_seconds)
                )
                rec_result = self._audio_recorder.record(duration)
                used_audio = Path(rec_result.audio_path)
            except Exception as exc:
                logger.warning(
                    "audio_recorder.record() failed: %s",
                    sanitize_message(exc),
                )
                return self._safe_response(
                    state.session_id,
                    question_type,
                    action=action,
                    reason="audio_record_failed",
                )

        audio_extra: Dict[str, Any] = {"audio_name": used_audio.name}

        # ---- transcribe ----
        if self._asr_adapter is None:
            return self._safe_response(
                state.session_id,
                question_type,
                action=action,
                reason="no_asr_adapter",
                extra_debug=audio_extra,
            )
        # Defensive warmup. The live demo calls ``warmup_asr`` during
        # its startup banner so this branch is usually a no-op; for
        # programmatic callers (smoke runners, tests with a real
        # pipeline) it shifts the OpenVINO cold compile out of the
        # turn-1 ``asr_ms`` window.
        asr_compile_ms = 0
        if not self._asr_warm:
            warm_info = self.warmup_asr()
            asr_compile_ms = int(warm_info.get("compile_ms", 0) or 0)
        audio_extra["asr_compile_ms"] = asr_compile_ms
        asr_t0 = time.monotonic()
        try:
            asr_result = self._asr_adapter.transcribe(used_audio)
        except Exception as exc:
            audio_extra["asr_ms"] = int((time.monotonic() - asr_t0) * 1000)
            logger.warning(
                "asr_adapter.transcribe() failed: %s",
                sanitize_message(exc),
            )
            return self._safe_response(
                state.session_id,
                question_type,
                action=action,
                reason="asr_failed",
                extra_debug=audio_extra,
            )
        audio_extra["asr_ms"] = int((time.monotonic() - asr_t0) * 1000)

        # MiniCPM-o's audio LM occasionally emits a ``<think>...</think>``
        # reasoning block before the transcription itself. Strip it
        # before the transcript is used either for routing
        # (``infer_scene_question_type``) or for UI display — otherwise
        # leading reasoning text both hides the user's actual phrase and
        # leaks into the on-screen TRANSCRIPT panel.
        transcript = strip_think_tags(asr_result.text or "").strip()
        asr_backend: Optional[str] = None
        if isinstance(asr_result.metadata, dict):
            backend = asr_result.metadata.get("backend")
            if isinstance(backend, str):
                asr_backend = backend
        audio_extra["asr_backend"] = asr_backend
        # Task 30: surface the transcript so callers and UIs can show
        # the actual spoken question instead of "(voice)".
        audio_extra["transcript"] = transcript

        if not transcript:
            return self._safe_response(
                state.session_id,
                question_type,
                action=action,
                reason="empty_transcript",
                reply_text="Sorry, I didn't catch that. Could you say it again?",
                extra_debug=audio_extra,
            )

        # Post-ASR acknowledgment: fire the pre-rendered Chinese
        # "好的，知道了。" clip on a background thread so the user
        # hears feedback during the LLM forward + TTS-synth wait.
        # Skip predicates inside AckPlayer handle TTS-disabled,
        # English-pinned, and missing-fixture cases.
        ack_decision = self._ack_player.maybe_start_async(
            transcript=transcript
        )
        audio_extra["ack_started"] = ack_decision.started
        if ack_decision.skip_reason:
            audio_extra["ack_skip_reason"] = ack_decision.skip_reason

        # Auto-classify the transcript only when the caller passed
        # the default ``general`` AND no custom prompt is in effect.
        # Explicit caller intent (an explicit scenario or a custom
        # prompt) always wins. The live demo never passes question_type,
        # so without this voice queries like "画面中有电视吗" land on the
        # general prompt and the model misses clearly-visible objects
        # (root cause of the PR-#234 retest failure).
        if not (custom_rules or "").strip() and (
            question_type == SceneQuestionType.general
        ):
            inferred = infer_scene_question_type(transcript)
            if inferred != SceneQuestionType.general:
                question_type = inferred
                audio_extra["question_type_inferred"] = inferred.value

        # ---- frame acquisition ----
        frame_or_safe = self._acquire_frame_or_safe_response(
            state,
            capture_fresh_frame,
            question_type,
            action=action,
        )
        if isinstance(frame_or_safe, CameraCompanionResponse):
            # Augment debug with audio context for observability.
            frame_or_safe.debug.update(audio_extra)
            return frame_or_safe

        return self._run_scene_qa_after_frame(
            state,
            transcript,
            question_type,
            frame_or_safe,
            action=action,
            extra_debug=audio_extra,
            custom_rules=custom_rules,
            reasoning=reasoning,
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _safe_response(
        self,
        session_id: Optional[str],
        question_type: SceneQuestionType,
        *,
        action: str,
        reason: str,
        reply_text: str = "Sorry, I can't see the camera view right now.",
        extra_debug: Optional[Dict[str, Any]] = None,
    ) -> CameraCompanionResponse:
        debug: Dict[str, Any] = {
            "action": action,
            "reason": reason,
            "frame_output_dir_basename": Path(
                self._config.vision.frame_output_dir
            ).name,
        }
        if extra_debug:
            debug.update(extra_debug)
        debug = sanitize_metadata(debug)
        return CameraCompanionResponse(
            session_id=session_id,
            question_type=question_type,
            reply_text=reply_text,
            scene=None,
            should_play_tts=False,
            debug=debug,
        )

    def _acquire_frame_or_safe_response(
        self,
        state: CompanionSessionState,
        capture_fresh_frame: bool,
        question_type: SceneQuestionType,
        *,
        action: str,
    ) -> Union[Path, CameraCompanionResponse]:
        if capture_fresh_frame:
            if self._camera_handler is None:
                return self._safe_response(
                    state.session_id,
                    question_type,
                    action=action,
                    reason="no_camera_handler",
                )
            try:
                target = (
                    Path(self._config.vision.frame_output_dir)
                    / f"frame_{int(time.time() * 1000)}.png"
                )
                returned = self._camera_handler.capture_from_camera(
                    target,
                    camera_index=int(self._config.vision.camera_index),
                )
                return Path(returned)
            except Exception as exc:
                logger.warning(
                    "camera_handler.capture_from_camera failed: %s",
                    sanitize_message(exc),
                )
                return self._safe_response(
                    state.session_id,
                    question_type,
                    action=action,
                    reason="capture_failed",
                )
        else:
            try:
                return Path(self._preview.save_latest_frame())
            except RuntimeError as exc:
                logger.info(
                    "no preview frame yet: %s", sanitize_message(exc)
                )
                return self._safe_response(
                    state.session_id,
                    question_type,
                    action=action,
                    reason="no_frame_available",
                )

    def _run_scene_qa_after_frame(
        self,
        state: CompanionSessionState,
        question_text: str,
        question_type: SceneQuestionType,
        frame_path: Path,
        *,
        action: str,
        extra_debug: Optional[Dict[str, Any]] = None,
        custom_rules: Optional[str] = None,
        reasoning: bool = False,
    ) -> CameraCompanionResponse:
        if self._pipeline is None:
            return self._safe_response(
                state.session_id,
                question_type,
                action=action,
                reason="no_pipeline",
                extra_debug=extra_debug,
            )

        # Always drop both prior text-side anchors (scene summary
        # AND recent dialogue) before each turn. In continuous-voice
        # mode the camera moves between turns, and dense recent text
        # becomes a textual anchor that overrides the new image —
        # the model rephrases the cache instead of looking at the
        # frame. Real-machine session 578be2a6... showed the LM
        # regurgitating turn 1's "answer" verbatim for turns 3, 4,
        # 5 (different questions) because emotion phrasing like
        # "我心情怎么样" doesn't match any refresh-intent pattern,
        # so the cached scene summary stayed in the prompt and
        # dominated the answer. Inverting the default — always drop
        # — covers every shape of question without needing a
        # per-phrase whitelist.
        #
        # The trade-off is that genuine follow-up phrasing ("zoom
        # in on the laptop you mentioned") loses its prior context.
        # This is acceptable because (a) the follow-up case was
        # hypothetical — real voice sessions are dominated by
        # current-frame questions, and (b) the LLM still has the
        # current frame to ground every answer. ``infer_scene_
        # refresh_intent`` is left in place so a future hybrid
        # mode can re-introduce a referential-continuity allow-list
        # without reworking the classifier.
        #
        # Performance: dropping the cache also REDUCES LLM prefill
        # tokens by ~75-200 each turn, so this is neutral-to-faster
        # rather than a speed cost.
        prior_summary = None
        recent_dialogue = self._recent_dialogue(state)
        prior_dialogue = None
        if state.last_scene_summary:
            extra_debug = dict(extra_debug or {})
            extra_debug["scene_summary_dropped"] = True
        if recent_dialogue:
            extra_debug = dict(extra_debug or {})
            extra_debug["dialogue_history_dropped"] = True

        # ``reasoning`` forces the slow (JSON) path even when fast mode is the
        # configured default, so the model can fill scaffolding fields and
        # deliberate before answering (used by the time preset for clocks).
        fast_mode = bool(
            getattr(self._config.interaction, "fast_mode", False)
        ) and not reasoning
        prompt = self._prompt_builder.build_prompt(
            user_question=question_text,
            question_type=question_type,
            persona=state.persona,
            previous_scene_summary=prior_summary,
            previous_dialogue=prior_dialogue,
            response_language=self._config.interaction.response_language,
            fast_mode=fast_mode,
            custom_rules=custom_rules,
        )
        max_chars = max(int(self._config.tts.max_text_length), 1)

        # Token-level LLM streaming: when enabled in interaction
        # config AND the TTS engine exposes the queue API, attach a
        # ``StreamingAnswerExtractor`` to the LLM call so sentences
        # of the JSON ``"answer"`` field are enqueued to the TTS
        # worker as soon as they're produced by the model — first
        # audio plays during decode rather than after.
        token_streaming_enabled = bool(
            getattr(
                self._config.interaction,
                "llm_token_streaming_enabled",
                True,
            )
        ) and bool(
            getattr(
                self._config.interaction, "streaming_tts_enabled", True
            )
        )
        # Flashcard mode emits one bare word; streaming the un-wrapped
        # word straight to TTS would skip the carrier sentence and
        # risk wrong-language pronunciation. Force the post-decode
        # path so the wrap step below runs before TTS — applies to
        # all four flashcard variants (English + FR/JA/DE).
        if question_type in _FLASHCARD_TYPES:
            token_streaming_enabled = False
        engine_supports_queue = (
            self._tts_engine is not None
            and hasattr(self._tts_engine, "enqueue_sentence")
            and hasattr(self._tts_engine, "flush_and_wait")
        )
        # Probe the pipeline's ``generate_from_mixed`` signature for
        # ``token_callback`` support so test fakes / older real
        # adapters that predate token streaming aren't accidentally
        # called with an unsupported kwarg. Use ``inspect`` over a
        # try/except retry so we never run the model call twice.
        pipeline_supports_token_callback = False
        if token_streaming_enabled and engine_supports_queue:
            try:
                import inspect

                sig = inspect.signature(self._pipeline.generate_from_mixed)
                params = sig.parameters
                pipeline_supports_token_callback = (
                    "token_callback" in params
                    or any(
                        p.kind is inspect.Parameter.VAR_KEYWORD
                        for p in params.values()
                    )
                )
            except (TypeError, ValueError):
                # Builtin / C-implemented callable; assume no support.
                pipeline_supports_token_callback = False
        token_streaming_active = (
            token_streaming_enabled
            and engine_supports_queue
            and pipeline_supports_token_callback
        )
        # Round-9: if the ACK clip is still playing at the top of the
        # LLM setup, force this turn onto the post-decode batch TTS
        # path so no sentence gets played while ACK is still audible.
        # Token-streaming would otherwise enqueue sentence #1 during
        # ``generate_from_mixed`` via ``token_callback`` and play it
        # immediately — overlapping the ACK. Cost: this one turn loses
        # the first-sentence-during-decode latency benefit, which is
        # the right trade because the ACK itself IS the first audio
        # feedback the user hears.
        ack_still_playing = self._ack_player.is_playing
        if ack_still_playing and token_streaming_active:
            logger.info(
                "TTS token-streaming disabled for this turn: ACK "
                "clip still playing"
            )
            token_streaming_active = False
        token_extractor: Optional[Any] = None
        token_callback: Optional[Any] = None
        # Per-turn timing: stamp the moment the first sentence is
        # handed to the TTS queue so we can report
        # ``llm_first_sentence_ms``. Initialised here so the post-
        # generate timing math runs unconditionally.
        first_sentence_at: Dict[str, Optional[float]] = {"t": None}
        if token_streaming_active:
            from .streaming_answer_extractor import (
                PassthroughSentenceStreamer,
                StreamingAnswerExtractor,
            )

            try:
                self._tts_engine.start_streaming_session()
            except Exception:  # noqa: BLE001 - opportunistic
                logger.exception(
                    "tts_engine.start_streaming_session() raised; "
                    "disabling token streaming for this turn"
                )
                token_streaming_active = False
            if token_streaming_active:
                def _on_sentence(text: str) -> None:
                    if first_sentence_at["t"] is None:
                        first_sentence_at["t"] = time.monotonic()
                    self._tts_engine.enqueue_sentence(text)

                # Fast mode: the model emits plain text, so the
                # passthrough streamer feeds sentences without a JSON
                # state machine. Saves ~90-140 pre-answer tokens of
                # latency before the first TTS sentence.
                if fast_mode:
                    token_extractor = PassthroughSentenceStreamer(
                        on_sentence=_on_sentence,
                        max_chars=max_chars,
                    )
                else:
                    token_extractor = StreamingAnswerExtractor(
                        on_sentence=_on_sentence,
                        max_chars=max_chars,
                    )
                token_callback = token_extractor.feed

        # When token streaming isn't active, skip the kwarg entirely so
        # legacy / test pipeline fakes that don't accept ``token_callback``
        # keep working unchanged.
        generate_kwargs: Dict[str, Any] = {
            "text": question_text,
            "image_path": str(frame_path),
        }
        if token_callback is not None:
            generate_kwargs["token_callback"] = token_callback
        llm_t0 = time.monotonic()
        llm_first_sentence_ms: Optional[int] = None
        try:
            raw = self._pipeline.generate_from_mixed(
                prompt, **generate_kwargs
            )
        except Exception as exc:
            logger.warning(
                "pipeline.generate_from_mixed failed: %s",
                sanitize_message(exc),
            )
            if token_streaming_active and token_extractor is not None:
                # Drop in-flight TTS state so a subsequent turn
                # starts clean.
                try:
                    token_extractor.flush()
                except Exception:
                    pass
                try:
                    self._tts_engine.flush_and_wait(timeout=1.0)
                except Exception:
                    pass
            extra_debug = dict(extra_debug or {})
            extra_debug["llm_total_ms"] = int(
                (time.monotonic() - llm_t0) * 1000
            )
            return self._safe_response(
                state.session_id,
                question_type,
                action=action,
                reason="model_call_failed",
                extra_debug=extra_debug,
            )

        llm_total_ms = int((time.monotonic() - llm_t0) * 1000)
        if first_sentence_at["t"] is not None:
            llm_first_sentence_ms = int(
                (first_sentence_at["t"] - llm_t0) * 1000
            )

        if token_streaming_active and token_extractor is not None:
            try:
                token_extractor.flush()
            except Exception:  # noqa: BLE001 - opportunistic
                logger.exception(
                    "StreamingAnswerExtractor.flush() raised"
                )
        if fast_mode:
            # Fast-mode model output is plain text (no JSON envelope).
            # ``parse_plain_text_output`` wraps the raw reply in a
            # payload with ``is_fallback=False`` so the truncated-JSON
            # TTS-skip guard below doesn't fire on a legitimate
            # Fast-mode reply.
            from .scene_response_parser import parse_plain_text_output

            payload: CameraCompanionResponsePayload = parse_plain_text_output(
                raw, max_answer_chars=max_chars
            )
        else:
            payload = parse_scene_model_output(
                raw, max_answer_chars=max_chars
            )

        # Flashcard mode: the model emitted a single English word (or
        # the literal "UNKNOWN" sentinel). Wrap it in a fixed English
        # carrier sentence so MiniCPM-o TTS pronounces the reply in
        # English. Done after parsing so both fast-mode plain text and
        # slow-path JSON ``answer`` strings flow through the same
        # wrap step.
        #
        # Surface the pre-wrap and post-wrap text in the debug payload
        # unconditionally so on-device field reports can correlate the
        # on-screen text with what TTS was asked to speak. Both fields
        # are truncated to 200 chars to keep the debug payload tight.
        if question_type in _FLASHCARD_TYPES:
            pre_wrap = (payload.answer_text or "")[:200]
            wrap_fn, match_fn = _FLASHCARD_WRAP_DISPATCH[question_type]
            filler = match_fn(payload.answer_text or "")
            payload.answer_text = wrap_fn(payload.answer_text)
            extra_debug = dict(extra_debug or {})
            extra_debug["flashcard_pre_wrap"] = pre_wrap
            extra_debug["flashcard_wrapped"] = (payload.answer_text or "")[:200]
            if filler is not None:
                extra_debug["flashcard_rejected_filler"] = filler

        # Apply emotion cue guardrails. Never trust raw model phrasing.
        try:
            payload = self._emotion_policy.apply_payload(payload)
        except Exception as exc:
            logger.warning(
                "EmotionCuePolicy.apply_payload failed: %s",
                sanitize_message(exc),
            )
            return self._safe_response(
                state.session_id,
                question_type,
                action=action,
                reason="emotion_policy_failed",
                extra_debug=extra_debug,
            )

        # Task 35: single response-level sanitization boundary. Any
        # absolute filesystem path (POSIX, Windows, UNC, file://) the
        # model embedded in answer_text, the scene fields, or the
        # suggested interaction is reduced to a basename **before**
        # the rest of the orchestrator sees it. This guarantees that
        # session history, TTS, the response, and every runner read
        # only sanitized content. URLs and ordinary slashed prose
        # are preserved.
        payload = sanitize_response_payload(payload)

        self._sessions.update_latest_frame(state.session_id, frame_path.name)
        scene_summary_for_session = (
            payload.scene.description.strip()
            if payload.scene and payload.scene.description
            else None
        )
        self._sessions.update_after_turn(
            state.session_id,
            question=question_text,
            answer=payload.answer_text,
            scene_summary=scene_summary_for_session,
        )

        tts_controller = self._get_tts_controller_for_call()
        # When the parser fell into the malformed_json fallback
        # AND the surfaced reply text looks like raw JSON
        # (typically because LOCAL_CAMERA_COMPANION_MAX_NEW_TOKENS was
        # too low and the model truncated mid-``answer`` field),
        # ``payload.answer_text`` is just the truncated raw JSON.
        # TTS-ing it produces gibberish and a strange voice. Skip
        # TTS entirely and surface a user-visible notification so
        # the operator knows why this turn was silent.
        #
        # We only skip when the reply text actually looks like JSON
        # (starts with ``{`` or contains ``"answer":``). Other
        # malformed_json cases — e.g. the model emits free-form
        # prose without JSON structure — still go through TTS so
        # the user hears *something* rather than nothing.
        _stripped_for_json = (payload.answer_text or "").lstrip()
        _looks_like_truncated_json = (
            payload.is_fallback
            and payload.fallback_reason == "malformed_json"
            and (
                _stripped_for_json.startswith("{")
                or '"answer"' in _stripped_for_json
            )
        )
        if _looks_like_truncated_json:
            # If token streaming was active, it has already been
            # piping partial JSON characters into the queue while
            # the LM decoded. Drop everything in flight.
            if (
                self._tts_engine is not None
                and hasattr(self._tts_engine, "interrupt")
            ):
                try:
                    self._tts_engine.interrupt()
                except Exception:  # noqa: BLE001 - best effort
                    pass
            try:
                print(
                    "[runtime] TTS skipped: model output was not "
                    "valid JSON (typically caused by "
                    "LOCAL_CAMERA_COMPANION_MAX_NEW_TOKENS being too "
                    "low — see startup warning).",
                    flush=True,
                )
            except Exception:  # noqa: BLE001
                pass
            tts_result = TTSReplyResult(
                tts_text=payload.answer_text,
                should_play_tts=False,
                metadata={
                    "reason": "skipped_malformed_json",
                    "streaming": False,
                    "token_streamed": bool(
                        token_streaming_active
                        and token_extractor is not None
                    ),
                },
            )
            should_speak = False
            debug: Dict[str, Any] = {
                "action": action,
                "frame_basename": frame_path.name,
                "is_fallback": payload.is_fallback,
                "fallback_reason": payload.fallback_reason,
                "preview_running": self._preview.is_running(),
                "frame_output_dir_basename": Path(
                    self._config.vision.frame_output_dir
                ).name,
                "tts": dict(tts_result.metadata),
                "llm_total_ms": llm_total_ms,
            }
            if llm_first_sentence_ms is not None:
                debug["llm_first_sentence_ms"] = llm_first_sentence_ms
            if self._debug_raw_model_output:
                debug["raw_model_output"] = raw[:2000]
            if extra_debug:
                debug.update(extra_debug)
            debug = sanitize_metadata(debug)
            return CameraCompanionResponse(
                session_id=state.session_id,
                question_type=question_type,
                reply_text=payload.answer_text,
                scene=payload.scene,
                should_play_tts=False,
                debug=debug,
                suggested_interaction=payload.suggested_interaction,
            )
        # Round-9: wait for the ACK clip to finish BEFORE the TTS
        # reply plays. The wait() was moved from the pre-LLM anchor
        # (round-8's location, which blocked LLM behind ACK) to here
        # so ACK+delay and LLM prefill actually run in parallel. If
        # the LLM finished before the ACK-plus-delay window, this
        # wait() blocks until the ACK ends; if the LLM took longer,
        # this is a fast no-op. The ``ack_still_playing`` gate above
        # additionally disabled token-streaming for this turn so
        # sentence #1 wasn't played during the LLM call.
        self._ack_player.wait()

        # TTS dispatch — three paths:
        #   1. Token-level streaming was active AND the extractor
        #      found the answer field: the worker has been speaking
        #      sentences during decode. Just flush the queue.
        #   2. Sentence-level streaming (post-decode split + enqueue)
        #      via ``prepare_and_speak_streaming``.
        #   3. Legacy one-shot ``prepare_and_speak``.
        streaming_enabled = bool(
            getattr(
                self._config.interaction, "streaming_tts_enabled", True
            )
        )
        used_token_streaming = (
            token_streaming_active
            and token_extractor is not None
            and token_extractor.found_answer
        )
        if used_token_streaming:
            try:
                self._tts_engine.flush_and_wait()
            except Exception as exc:  # noqa: BLE001 - opportunistic
                logger.warning(
                    "tts_engine.flush_and_wait() raised: %s",
                    sanitize_message(exc),
                )
                tts_result = TTSReplyResult(
                    tts_text=payload.answer_text,
                    should_play_tts=False,
                    metadata={
                        "reason": "error",
                        "error": sanitize_message(repr(exc)),
                        "error_class": exc.__class__.__name__,
                        "streaming": True,
                        "token_streamed": True,
                    },
                )
            else:
                tts_result = TTSReplyResult(
                    tts_text=payload.answer_text,
                    should_play_tts=True,
                    metadata={
                        "streaming": True,
                        "token_streamed": True,
                    },
                )
        elif token_streaming_active and token_extractor is not None:
            # Token streaming was attempted but never found the
            # answer field (malformed JSON). Drain anything queued
            # and fall back to post-decode batch TTS.
            try:
                self._tts_engine.flush_and_wait(timeout=1.0)
            except Exception:
                pass
            tts_result = (
                tts_controller.prepare_and_speak_streaming(
                    payload.answer_text
                )
                if streaming_enabled
                and hasattr(tts_controller, "prepare_and_speak_streaming")
                else tts_controller.prepare_and_speak(payload.answer_text)
            )
            tts_result.metadata.setdefault(
                "token_streaming_fallback", "answer_field_not_found"
            )
        elif streaming_enabled and hasattr(
            tts_controller, "prepare_and_speak_streaming"
        ):
            tts_result: TTSReplyResult = (
                tts_controller.prepare_and_speak_streaming(
                    payload.answer_text
                )
            )
        else:
            tts_result = tts_controller.prepare_and_speak(
                payload.answer_text
            )
        should_speak = tts_result.should_play_tts

        debug: Dict[str, Any] = {
            "action": action,
            "frame_basename": frame_path.name,
            "is_fallback": payload.is_fallback,
            "fallback_reason": payload.fallback_reason,
            "preview_running": self._preview.is_running(),
            "frame_output_dir_basename": Path(
                self._config.vision.frame_output_dir
            ).name,
            "tts": dict(tts_result.metadata),
            "llm_total_ms": llm_total_ms,
        }
        if llm_first_sentence_ms is not None:
            debug["llm_first_sentence_ms"] = llm_first_sentence_ms
        if self._debug_raw_model_output:
            debug["raw_model_output"] = raw[:2000]
        if extra_debug:
            debug.update(extra_debug)
        # Final defense: recursively sanitize the entire debug payload
        # before it leaves the skill. Subsystem-level sanitization
        # (ASR / TTS / camera) runs first, but this catches any new
        # fields a future contributor adds without remembering to
        # sanitize them locally (Task 32).
        debug = sanitize_metadata(debug)

        return CameraCompanionResponse(
            session_id=state.session_id,
            question_type=question_type,
            reply_text=payload.answer_text,
            scene=payload.scene,
            should_play_tts=should_speak,
            debug=debug,
            suggested_interaction=payload.suggested_interaction,
        )

    def _get_tts_controller_for_call(self) -> TTSReplyController:
        if self._tts_reply_controller is not None:
            return self._tts_reply_controller
        return TTSReplyController(
            tts_engine=self._tts_engine,
            enabled=bool(self._config.tts.enabled),
            max_text_length=int(self._config.tts.max_text_length),
            soft_fail=True,
        )

    @staticmethod
    def _recent_dialogue(state: CompanionSessionState) -> List[Dict[str, str]]:
        history = list(state.history)[-4:]
        out: List[Dict[str, str]] = []
        for entry in history:
            q = entry.get("question")
            a = entry.get("answer")
            if isinstance(q, str) and q.strip():
                out.append({"role": "user", "content": q.strip()})
            if isinstance(a, str) and a.strip():
                out.append({"role": "assistant", "content": a.strip()})
        return out
