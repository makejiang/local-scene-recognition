# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Mockable camera preview controller for the Camera Companion Skill.

The :class:`CameraPreviewController` keeps the latest captured frame in
memory and saves it on demand. It accepts an injected
:class:`FrameSourceProtocol` so default tests do not need a real camera
or ``cv2``. If no source is injected, a lazy ``cv2``-backed default
source is constructed on :meth:`CameraPreviewController.start`; ``cv2``
is never imported at module-import time.

Status / debug payloads expose **basenames only** — absolute filesystem
paths must not leak into user-facing or debug data.

Stdlib + Pillow only at import time. No cv2, OpenVINO, sounddevice,
torch, or transformers imports are introduced here.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional, Protocol, Union

from .privacy import sanitize_message

logger = logging.getLogger(__name__)

__all__ = [
    "FrameSourceProtocol",
    "CameraPreviewController",
    "_bgr_to_rgb",
    "_rgb_to_bgr",
]


PathLike = Union[str, Path]


def _env_int(name: str, default: int) -> int:
    """Read a positive int from the environment, falling back to
    ``default`` on unset/blank/invalid/<1 values."""
    raw = os.environ.get(name)
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        return default
    return value if value >= 1 else default


def _env_float(name: str, default: float) -> float:
    """Read a non-negative float from the environment, falling back to
    ``default`` on unset/blank/invalid/negative values."""
    raw = os.environ.get(name)
    if not raw:
        return default
    try:
        value = float(raw)
    except ValueError:
        return default
    return value if value >= 0.0 else default


# Bounded retry for the first-frame read on start(). The Marvis
# hot-reload race frees the camera within ~500ms, but on some hardware
# MSMF stays in MF_E_HW_MFT_FAILED_START_STREAMING for a few seconds
# after another process releases the device (real-machine session
# 20260702-120020). Six attempts × 500ms, combined with the
# per-attempt backend fallback inside ``_LazyCv2FrameSource.open`` (see
# below), gives the OS time to recover before we declare the camera
# unavailable. Both knobs are overridable via env for field tuning.
_START_READ_MAX_ATTEMPTS = 6
_START_READ_RETRY_DELAY_S = 0.5
_ENV_START_ATTEMPTS = "LOCAL_CAMERA_COMPANION_CAMERA_START_ATTEMPTS"
_ENV_START_RETRY_DELAY = "LOCAL_CAMERA_COMPANION_CAMERA_START_RETRY_DELAY_S"


class FrameSourceProtocol(Protocol):
    """Minimal frame source interface."""

    def open(self) -> None: ...

    def read(self) -> Any: ...

    def close(self) -> None: ...


# ---------------------------------------------------------------------------
# Lazy cv2 default source — never exercised by default tests.
# ---------------------------------------------------------------------------


# Windows MSMF (cv2's default on Windows) intermittently fails the
# first frame grab with error -1072875772
# (MF_E_HW_MFT_FAILED_START_STREAMING) when the camera was just
# released by another process. DirectShow (DSHOW) is the standard
# fallback; CAP_ANY lets OpenCV pick anything left. The order is
# overridable via LOCAL_CAMERA_COMPANION_CAMERA_BACKEND (msmf|dshow|any)
# for hardware that prefers a specific backend.
_DEFAULT_BACKEND_ORDER = ("msmf", "dshow", "any")
_ENV_CAMERA_BACKEND = "LOCAL_CAMERA_COMPANION_CAMERA_BACKEND"

# Some UVC webcams return ok==False for the first frame or two right
# after open() even when healthy. Grab-and-discard for a short budget
# before declaring an opened backend unusable.
_OPEN_WARMUP_READS = 5
_OPEN_WARMUP_DELAY_S = 0.1


def _resolve_backend_order() -> tuple:
    """Backend attempt order, honoring the env override."""
    choice = (os.environ.get(_ENV_CAMERA_BACKEND) or "").strip().lower()
    if choice in ("msmf", "dshow", "any"):
        return (choice,)
    return _DEFAULT_BACKEND_ORDER


def _open_capture(camera_index: int, backend: str) -> Any:  # pragma: no cover - hardware path
    """Create a ``cv2.VideoCapture`` for ``camera_index`` using the named
    backend ('msmf'|'dshow'|'any'). ``cv2`` is imported lazily so the
    module stays importable without OpenCV; ``ImportError`` propagates so
    the caller can surface an actionable message. Factored out as a
    monkeypatch seam for hardware-free tests."""
    import cv2  # type: ignore

    flag = {
        "msmf": getattr(cv2, "CAP_MSMF", 0),
        "dshow": getattr(cv2, "CAP_DSHOW", 0),
        "any": getattr(cv2, "CAP_ANY", 0),
    }.get(backend, getattr(cv2, "CAP_ANY", 0))
    return cv2.VideoCapture(camera_index, flag)


def _release_capture(cap: Any) -> None:  # pragma: no cover - hardware path
    """Release a cv2 capture, swallowing any error."""
    if cap is None:
        return
    try:
        cap.release()
    except Exception:
        pass


def _warmup_capture(cap: Any) -> bool:  # pragma: no cover - hardware path
    """Grab-and-discard up to ``_OPEN_WARMUP_READS`` frames; return True
    once one reads successfully. Absorbs cameras that need a moment to
    start streaming after open()."""
    for _ in range(max(1, _OPEN_WARMUP_READS)):
        try:
            ok, _frame = cap.read()
        except Exception:
            ok = False
        if ok:
            return True
        time.sleep(_OPEN_WARMUP_DELAY_S)
    return False


class _LazyCv2FrameSource:  # pragma: no cover - hardware path
    """Default frame source backed by OpenCV.

    ``cv2`` is imported inside :func:`_open_capture` so the parent module
    stays importable on machines without OpenCV. The whole class body is
    excluded from coverage because hermetic tests do not touch it.
    """

    def __init__(self, camera_index: int = 0) -> None:
        self._camera_index = int(camera_index)
        self._capture: Any = None
        self._backend: Optional[str] = None

    def open(self) -> None:
        errors = []
        for backend in _resolve_backend_order():
            try:
                cap = _open_capture(self._camera_index, backend)
            except ImportError as exc:
                # No OpenCV → no backend can work; fail fast with the
                # actionable install hint rather than looping.
                raise RuntimeError(
                    "Camera capture requires the optional 'opencv-python' "
                    "package (cv2). Install it with `pip install opencv-python`."
                ) from exc
            except Exception as exc:  # noqa: BLE001 - try the next backend
                errors.append(f"{backend}: open raised {exc}")
                continue
            if not cap or not cap.isOpened():
                errors.append(f"{backend}: isOpened() returned False")
                _release_capture(cap)
                continue
            if _warmup_capture(cap):
                self._capture = cap
                self._backend = backend
                logger.info(
                    "camera opened on backend '%s' at index %d",
                    backend, self._camera_index,
                )
                return
            errors.append(f"{backend}: no frame within warm-up budget")
            _release_capture(cap)
        raise RuntimeError(
            f"Failed to open camera at index {self._camera_index} on any "
            f"backend ({'; '.join(errors)})."
        )

    def read(self) -> Any:
        if self._capture is None:
            raise RuntimeError("Frame source is not open.")
        ok, frame = self._capture.read()
        if not ok:
            raise RuntimeError("Camera read failed.")
        # cv2.VideoCapture returns BGR. Convert here so every consumer
        # in the codebase (PIL save, vision encoder, screenshot) sees
        # RGB. The preview window converts back to BGR right before
        # imshow.
        return _bgr_to_rgb(frame)

    def close(self) -> None:
        cap = self._capture
        self._capture = None
        if cap is not None:
            try:
                cap.release()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Frame helpers


def _bgr_to_rgb(frame: Any) -> Any:
    """Reverse the channel axis of an HxWx3 BGR array → RGB.

    cv2.VideoCapture returns frames in BGR order. PIL.Image.fromarray
    treats arrays as RGB by default, so writing a raw cv2 frame to PNG
    swaps red and blue. This helper is the single conversion point —
    apply it at the source so every consumer (save, model, screenshot)
    works with RGB. Conversely, the preview's imshow path converts
    RGB→BGR right before display via :func:`_rgb_to_bgr`.

    Frames that aren't 3-channel ndarrays are returned unchanged so
    PIL inputs, bytes payloads, and grayscale captures pass through.
    """
    if frame is None:
        return None
    arr = getattr(frame, "shape", None)
    if arr is None:
        return frame
    if len(arr) != 3 or arr[2] != 3:
        return frame
    # ``frame[..., ::-1]`` is a numpy view; ``ascontiguousarray`` makes
    # the result laid out in C order so downstream PIL / IR encoders
    # don't choke on the reversed-stride slice. Safe for non-numpy
    # arrays that don't expose ascontiguousarray (we attempt and fall
    # back to a manual copy via ``.copy()``).
    reversed_view = frame[..., ::-1]
    try:
        import numpy as np  # local import — kept off module-import path

        return np.ascontiguousarray(reversed_view)
    except ImportError:
        copy = getattr(reversed_view, "copy", None)
        return copy() if callable(copy) else reversed_view


def _rgb_to_bgr(frame: Any) -> Any:
    """Inverse of :func:`_bgr_to_rgb`. Same semantics — present as a
    named helper so the imshow call site reads naturally."""
    return _bgr_to_rgb(frame)
# ---------------------------------------------------------------------------


def _is_pil_image(frame: Any) -> bool:
    # Duck-typed to avoid importing PIL at module load if it ever moves.
    return (
        hasattr(frame, "save")
        and hasattr(frame, "size")
        and hasattr(frame, "mode")
        and hasattr(frame, "copy")
    )


def _safe_copy(frame: Any) -> Any:
    """Return a copy / safe reference of ``frame``.

    - PIL Image: ``.copy()``
    - bytes: returned as-is (immutable).
    - numpy-like (has ``copy`` method): ``.copy()``
    - anything else: returned as-is.
    """

    if frame is None:
        return None
    if isinstance(frame, (bytes, bytearray)):
        return bytes(frame)
    if _is_pil_image(frame):
        return frame.copy()
    if hasattr(frame, "copy") and callable(frame.copy):
        try:
            return frame.copy()
        except Exception:
            return frame
    return frame


def _save_frame_to_disk(
    frame: Any,
    target: Path,
    frame_source: Optional[FrameSourceProtocol] = None,
) -> None:
    """Best-effort persistence of ``frame`` to ``target``.

    Dispatches by type. PIL → ``.save``; bytes → ``write_bytes``;
    numpy-like → delegate to a ``save`` helper on the frame source if
    available, otherwise fall back to ``PIL.Image.fromarray``.
    """

    if frame is None:
        raise RuntimeError("No frame captured yet; cannot save.")

    if _is_pil_image(frame):
        frame.save(target)
        return

    if isinstance(frame, (bytes, bytearray)):
        target.write_bytes(bytes(frame))
        return

    save_helper = getattr(frame_source, "save", None) if frame_source else None
    if callable(save_helper):
        save_helper(frame, target)
        return

    try:
        from PIL import Image  # noqa: WPS433 - lazy import is intentional
    except ImportError as exc:  # pragma: no cover - PIL is a hard dep
        raise RuntimeError(
            "Cannot save numpy-like frame: PIL is not available and the "
            "frame source provided no save() helper."
        ) from exc

    try:
        Image.fromarray(frame).save(target)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to save frame of type {type(frame).__name__} to disk."
        ) from exc


# ---------------------------------------------------------------------------
# Controller
# ---------------------------------------------------------------------------


class CameraPreviewController:
    """Holds the latest camera frame and persists it on demand."""

    def __init__(
        self,
        frame_source: Optional[FrameSourceProtocol] = None,
        output_dir: PathLike = "./model_cache/camera_companion/frames",
        *,
        mode: str = "single_shot",
        frame_interval_seconds: float = 0.2,
        max_background_errors: int = 1,
    ) -> None:
        self._injected_source: Optional[FrameSourceProtocol] = frame_source
        self._frame_source: Optional[FrameSourceProtocol] = frame_source
        self._output_dir: Path = Path(output_dir)
        self._latest_frame: Any = None
        self._running: bool = False
        # Tracks whether we currently own a successful ``open()`` on the
        # active source. This is independent from ``_running`` so that
        # the terminal background-error path (which sets _running=False
        # itself) and a subsequent ``stop()`` can still cooperate to
        # close the source exactly once.
        self._source_opened: bool = False
        self._error: Optional[str] = None
        self._camera_index: int = 0
        self._last_saved_basename: Optional[str] = None
        self._lock = threading.Lock()

        # Continuous-mode state.
        self._mode: str = (
            "continuous"
            if str(mode).strip().lower() == "continuous"
            else "single_shot"
        )
        self._frame_interval_seconds: float = max(0.0, float(frame_interval_seconds))
        self._max_background_errors: int = max(1, int(max_background_errors))
        self._frames_read: int = 0
        self._stop_event: Optional[threading.Event] = None
        self._thread: Optional[threading.Thread] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _close_source_locked(self) -> bool:
        """Close the active frame source exactly once.

        Caller must hold ``self._lock``. Idempotent: subsequent calls
        do nothing because ``_source_opened`` has already been cleared.
        Returns True iff a real close was performed. Never raises.
        """
        if not self._source_opened:
            return False
        source = self._frame_source
        self._source_opened = False
        if source is None:
            return False
        try:
            source.close()
        except Exception as exc:
            logger.debug("frame source close raised: %s", exc)
        return True

    def start(self, camera_index: int = 0) -> None:
        with self._lock:
            if self._running:
                return  # idempotent
            # Reap any leftover thread/event from a prior failed run so
            # restart-after-failure works deterministically.
            self._thread = None
            self._stop_event = None
            self._camera_index = int(camera_index)
            self._error = None

            if self._frame_source is None:
                self._frame_source = _LazyCv2FrameSource(  # pragma: no cover
                    camera_index=self._camera_index
                )

            # Phase 1: open(). If this raises, no close() is required —
            # the source never reported success.
            try:
                self._frame_source.open()
            except Exception as exc:
                self._error = str(exc) or exc.__class__.__name__
                logger.warning("CameraPreviewController.start open failed: %s", exc)
                self._source_opened = False
                self._frame_source = self._injected_source
                self._running = False
                return

            # open() succeeded — we now own a single close().
            self._source_opened = True

            # Phase 2: first read, with bounded retry. Absorbs the
            # "previous server process still holds the camera" race on
            # Marvis hot-reload — real-machine sessions surfaced OpenCV
            # MSMF error -1072875772 (MF_E_HW_MFT_FAILED_START_STREAMING)
            # for several seconds. The camera typically frees within
            # ~500ms; we retry up to ``max_attempts`` times with
            # ``retry_delay`` between attempts (both env-overridable). On
            # each retry, close the source and re-open so the OS gets a
            # fresh capture handle — and, for the default cv2 source, a
            # fresh backend-fallback sweep.
            max_attempts = _env_int(_ENV_START_ATTEMPTS, _START_READ_MAX_ATTEMPTS)
            retry_delay = _env_float(_ENV_START_RETRY_DELAY, _START_READ_RETRY_DELAY_S)
            frame = None
            last_exc: Optional[BaseException] = None
            for attempt in range(max_attempts):
                try:
                    frame = self._frame_source.read()
                    last_exc = None
                    break
                except Exception as exc:
                    last_exc = exc
                    logger.warning(
                        "CameraPreviewController.start read failed "
                        "(attempt %d/%d): %s",
                        attempt + 1,
                        max_attempts,
                        exc,
                    )
                    if attempt + 1 >= max_attempts:
                        break
                    # Close + re-open between attempts. Failure to
                    # close is non-fatal here — the next open() will
                    # acquire a fresh handle (cv2.VideoCapture is
                    # idempotent on a closed source).
                    self._close_source_locked()
                    self._source_opened = False
                    time.sleep(retry_delay)
                    try:
                        self._frame_source.open()
                        self._source_opened = True
                    except Exception as open_exc:
                        last_exc = open_exc
                        logger.warning(
                            "CameraPreviewController.start re-open "
                            "failed (attempt %d/%d): %s",
                            attempt + 2,
                            max_attempts,
                            open_exc,
                        )
                        break

            if last_exc is not None:
                self._error = str(last_exc) or last_exc.__class__.__name__
                if self._source_opened:
                    self._close_source_locked()
                self._frame_source = self._injected_source
                self._running = False
                return

            if frame is None:
                self._error = "frame source returned no frame on start()"
                self._close_source_locked()
                self._frame_source = self._injected_source
                self._running = False
                return

            self._latest_frame = frame
            self._frames_read = 1
            self._running = True

            if self._mode == "continuous":
                self._stop_event = threading.Event()
                self._thread = threading.Thread(
                    target=self._continuous_loop,
                    name="CameraPreviewController",
                    daemon=True,
                )
                self._thread.start()

    def _continuous_loop(self) -> None:
        """Background frame-grab loop. Exits on stop_event or error budget."""
        stop = self._stop_event
        if stop is None:  # pragma: no cover - guarded by start()
            return

        consecutive_errors = 0
        interval = self._frame_interval_seconds
        while not stop.is_set():
            # Cooperative sleep. wait() returns True when the event fires.
            if interval > 0 and stop.wait(timeout=interval):
                break

            # Snapshot the frame source under the lock to avoid racing stop().
            with self._lock:
                source = self._frame_source
                running = self._running
            if source is None or not running:
                break

            try:
                frame = source.read()
            except Exception as exc:
                consecutive_errors += 1
                with self._lock:
                    self._error = str(exc) or exc.__class__.__name__
                if consecutive_errors > self._max_background_errors:
                    with self._lock:
                        self._running = False
                        # The loop owns the close on terminal failure.
                        # ``stop()`` will see ``_source_opened == False``
                        # and skip the redundant close.
                        self._close_source_locked()
                        self._frame_source = self._injected_source
                    break
                continue

            if frame is None:
                consecutive_errors += 1
                with self._lock:
                    self._error = "frame source returned None"
                if consecutive_errors > self._max_background_errors:
                    with self._lock:
                        self._running = False
                        self._close_source_locked()
                        self._frame_source = self._injected_source
                    break
                continue

            consecutive_errors = 0
            with self._lock:
                self._latest_frame = frame
                self._frames_read += 1
                # Successful read clears any prior transient error.
                self._error = None

    def stop(self) -> None:
        with self._lock:
            self._running = False
            thread = self._thread
            stop_event = self._stop_event

        if stop_event is not None:
            stop_event.set()
        if thread is not None and thread.is_alive():
            thread.join(timeout=2.0)

        with self._lock:
            # Single close path. If the loop already cleaned up,
            # ``_source_opened`` is False here and this is a no-op.
            self._close_source_locked()
            self._thread = None
            self._stop_event = None
            # Reset to the originally-injected source so a future start()
            # behaves the same as the first one.
            self._frame_source = self._injected_source

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def is_running(self) -> bool:
        return self._running

    def read_latest_frame(self) -> Any:
        with self._lock:
            return _safe_copy(self._latest_frame)

    def status(self) -> Dict[str, Any]:
        with self._lock:
            # Stored ``self._error`` is whatever ``str(exc)`` produced
            # — possibly with absolute paths. Sanitize before exposing
            # via either alias (Task 32).
            sanitized_error = (
                sanitize_message(self._error) if self._error else None
            )
            return {
                "running": self._running,
                "has_frame": self._latest_frame is not None,
                "error": sanitized_error,        # legacy alias
                "last_error": sanitized_error,   # canonical name (Task 28)
                "camera_index": self._camera_index,
                "output_dir_basename": self._output_dir.name,
                "last_saved_basename": self._last_saved_basename,
                "mode": self._mode,
                "frames_read": self._frames_read,
            }

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save_latest_frame(self, filename: Optional[str] = None) -> Path:
        with self._lock:
            frame = self._latest_frame
            source = self._frame_source

        if frame is None:
            raise RuntimeError("No frame captured yet; cannot save.")

        self._output_dir.mkdir(parents=True, exist_ok=True)

        if filename is None:
            filename = f"frame_{int(time.time() * 1000)}.png"
        # Strip any directory components callers might pass in.
        safe_name = os.path.basename(str(filename)) or "frame.png"
        target = self._output_dir / safe_name

        _save_frame_to_disk(frame, target, frame_source=source)

        self._last_saved_basename = safe_name
        return target
