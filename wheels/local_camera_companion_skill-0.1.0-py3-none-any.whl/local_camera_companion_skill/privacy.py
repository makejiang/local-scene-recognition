# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Centralized path-privacy sanitization (Task 32).

Reusable, stdlib-only helpers that prevent absolute filesystem paths
from leaking through error messages, debug payloads, and JSON / JSONL
logs. Three surfaces are sanitized:

* :func:`sanitize_message` — replaces path-like substrings inside a
  free-form string (typically an exception message) with basenames.
* :func:`sanitize_metadata` — walks a nested dict / list / tuple
  payload and sanitizes string values recursively. Non-string scalars
  (``None``, ``bool``, ``int``, ``float``, ``Enum``) are preserved
  verbatim.
* :func:`merged_metadata` — merges caller-provided extra metadata
  under a fixed reserved-key map without letting extras overwrite the
  authoritative fields (``backend``, ``audio_basename``, ``mode``,
  ``language``, etc.).

The sanitizer recognizes:

* POSIX absolute paths (``/var/run/foo``)
* Windows drive paths (``C:\\Users\\foo`` or ``C:/Users/foo``)
* UNC paths (``\\\\server\\share\\file`` or ``//server/share/file``)
* :class:`pathlib.Path` instances

It deliberately does NOT mangle:

* URLs (``http://``, ``https://``, ``file://`` …)
* Ratios such as ``"3/4"``, ``"1/2"``
* Ordinary prose containing slashes (``"and/or"``)
* Single bare filenames

so transcribed user speech and command-line examples in error
messages survive untouched.

The library API is **basename-safe by default**. There is no global
"verbose paths" toggle — that is a presentation-layer concern and
lives only in the runner scripts (``--verbose-paths``). Callers who
need the full path must read the original :class:`Exception` /
:class:`Path` object themselves; nothing in this module ever returns
an absolute path that the input did not already provide.

Heavy dependencies (``cv2``, OpenVINO, ``sounddevice``, ``torch``,
``transformers``, ``numpy``) are not imported.
"""

from __future__ import annotations

import os
import re
from enum import Enum
from pathlib import Path
from typing import Any, Dict, FrozenSet, Mapping, Optional, Union

__all__ = [
    "PathLike",
    "RESERVED_ASR_KEYS",
    "looks_like_path",
    "merged_metadata",
    "path_to_basename",
    "sanitize_message",
    "sanitize_metadata",
    "sanitize_response_payload",
]


PathLike = Union[str, Path]


# Reserved metadata keys that authoritative fields use. Callers that
# pass ``metadata={"backend": "x"}`` or ``metadata={"audio_basename":
# "y"}`` MUST NOT overwrite these — :func:`merged_metadata` enforces
# the precedence by writing the reserved values *after* the caller's.
RESERVED_ASR_KEYS: FrozenSet[str] = frozenset(
    {"backend", "audio_basename", "mode", "language"}
)

# Keys that always carry a path or path-like value. Any string value
# under one of these keys is sanitized to its basename even if the
# string does not contain a separator (e.g. a bare filename stays a
# bare filename, but ``./foo`` collapses to ``foo``).
_PATH_DESIGNATED_KEYS: FrozenSet[str] = frozenset(
    {
        "audio_path",
        "audio_basename",
        "frame_path",
        "frame_basename",
        "image_path",
        "model_dir",
        "model_path",
        "output_path",
        "output_dir",
        "wav_path",
        "last_audio_basename",
        "last_wav_basename",
        "last_saved_basename",
        "frame_output_dir_basename",
        "output_dir_basename",
        "model_dir_basename",
    }
)

# A token is anything not split by whitespace. We consider a token a
# path if it begins with one of the recognized path prefixes and
# contains a separator. URL tokens are deliberately excluded.
#
# Note: ``file://`` URIs are NOT treated as URLs here. Task 35 treats
# any ``file://`` reference as a local filesystem path because the
# tail invariably names a real file on the producing machine. They
# are detected separately via ``_FILE_URI_RE`` and reduced to the
# trailing basename.
_URL_PREFIXES = (
    "http://",
    "https://",
    "ftp://",
    "ftps://",
    "ws://",
    "wss://",
    "git+",
    "ssh://",
    "data:",
    "mailto:",
)

_FILE_URI_RE = re.compile(r"^file://", re.IGNORECASE)

# Windows drive: optional quote, then ``X:`` followed by ``/`` or ``\``.
_WINDOWS_DRIVE_RE = re.compile(r"^[A-Za-z]:[\\/]")
# UNC: ``\\server\share\...`` or ``//server/share/...``.
_UNC_RE = re.compile(r"^(?:\\\\|//)[^\\/][^\\/]*[\\/].")
# POSIX absolute: starts with ``/`` and contains another ``/``. We
# require at least two segments so single-slash strings like ``/`` or
# numeric ratios ``"a/b"`` (which don't start with ``/``) don't match.
_POSIX_ABS_RE = re.compile(r"^/[^/\s]+/")
# Task 42: root-level POSIX file (``/secret.txt``, ``/model.bin``).
# Single-segment absolute paths slip through ``_POSIX_ABS_RE`` because
# it requires a second separator. We narrow the catch to filenames
# bearing an extension so ``/etc`` (likely prose) stays untouched but
# ``/secret.txt`` is reduced.
_POSIX_ABS_FILE_RE = re.compile(
    r"^/[^/\s]+\.[A-Za-z0-9_]{1,16}\b"
)


# Common surrounding punctuation we strip before deciding whether a
# token is a path. Trailing punctuation like ``"/usr/foo,"`` should
# still be classified as a path; the trailing comma stays attached to
# the resulting basename so the message remains readable.
_LEADING_TRIM = "([{<\"'`"
_TRAILING_TRIM = ")]}>,.;:!?\"'`"


def _is_url(token: str) -> bool:
    lowered = token.lower()
    return any(lowered.startswith(prefix) for prefix in _URL_PREFIXES)


def looks_like_path(value: Any) -> bool:
    """Return True iff ``value`` looks like a local filesystem path.

    Strings only — non-strings always return False. URLs return False.
    ``file://`` URIs return True because their tail always names a
    local file (Task 35).
    """
    if not isinstance(value, str):
        return False
    s = value.strip()
    if not s:
        return False
    if _FILE_URI_RE.match(s):
        return True
    if _is_url(s):
        return False
    # Strip a single layer of surrounding punctuation so paths embedded
    # in error messages like ``open '/var/foo': bad`` are recognized.
    if s and s[0] in _LEADING_TRIM:
        s = s[1:]
    if s and s[-1] in _TRAILING_TRIM:
        s = s[:-1]
    if _WINDOWS_DRIVE_RE.match(s):
        return True
    if _UNC_RE.match(s):
        return True
    if _POSIX_ABS_RE.match(s):
        return True
    if _POSIX_ABS_FILE_RE.match(s):
        return True
    return False


def path_to_basename(value: PathLike) -> str:
    """Reduce a known path / Path-like to its basename string.

    Accepts both forward-slash and backslash separators on every
    platform. Returns the input unchanged if it has no separator.
    """
    if isinstance(value, Path):
        return value.name or str(value)
    s = str(value)
    if not s:
        return s
    # Normalize backslashes to forward slashes for splitting; this is
    # safe because we only return the trailing segment.
    last = s.replace("\\", "/").rstrip("/").rsplit("/", 1)[-1]
    return last or s


# ---------------------------------------------------------------------------
# Message sanitization
# ---------------------------------------------------------------------------


# Path tokens may contain either separator. We split on whitespace
# only — punctuation stays attached so we can re-glue tokens back into
# the message exactly as the caller wrote them.
_TOKEN_RE = re.compile(r"\S+")

# Task 42: quoted path-with-spaces pre-pass. ``_TOKEN_RE`` splits on
# whitespace, so ``'/home/foo bar/file.txt'`` would be broken in two
# tokens that neither alone looks like a path. This regex finds a
# matching pair of quotes whose body contains a path separator and
# captures the body so the helper below can decide whether to reduce
# it to a basename.
_QUOTED_PATH_RE = re.compile(
    r"""(?P<q>['"])(?P<body>[^'"]*?(?:[/\\][^'"]*)+)(?P=q)"""
)


def _sanitize_token(token: str) -> str:
    """Reduce a single whitespace-delimited token to a basename if it
    looks like a path. Surrounding punctuation is preserved.

    ``file://`` URIs are treated as local paths (Task 35). The
    ``file://`` prefix is stripped along with any leading slashes so
    POSIX (``file:///etc/passwd``) and Windows
    (``file:///C:/Users/foo`` / ``file://C:/Users/foo``) variants
    both reduce to their trailing basename.
    """
    if not token:
        return token
    if _is_url(token):
        return token

    # Peel one leading / trailing punctuation char so paths embedded in
    # messages like ``'/etc/passwd':`` or ``(/var/foo)`` are recognized.
    leading = ""
    trailing = ""
    body = token
    if body and body[0] in _LEADING_TRIM:
        leading, body = body[0], body[1:]
    if body and body[-1] in _TRAILING_TRIM:
        body, trailing = body[:-1], body[-1]

    # Task 35: file:// URIs always carry a local path. Strip the
    # scheme + leading slashes and reduce to the trailing basename.
    if _FILE_URI_RE.match(body):
        inner = _FILE_URI_RE.sub("", body).lstrip("/")
        # Windows absolute embedded as file:///C:/foo/bar — leave the
        # drive intact for path_to_basename to walk.
        return f"{leading}{path_to_basename(inner) or 'redacted'}{trailing}"

    if not (
        _WINDOWS_DRIVE_RE.match(body)
        or _UNC_RE.match(body)
        or _POSIX_ABS_RE.match(body)
        or _POSIX_ABS_FILE_RE.match(body)
    ):
        return token

    # Strip an optional matching pair of surrounding quotes inside the
    # body (e.g. ``"/etc/passwd"``).
    if (
        len(body) >= 2
        and body[0] in "\"'"
        and body[-1] == body[0]
    ):
        inner = body[1:-1]
        return f"{leading}{body[0]}{path_to_basename(inner)}{body[0]}{trailing}"

    return f"{leading}{path_to_basename(body)}{trailing}"


def _sanitize_quoted_paths(text: str) -> str:
    """Reduce quoted, space-bearing absolute paths to quoted basenames.

    Pre-pass for :func:`sanitize_message`. The whitespace tokenizer
    cannot see a path that lives *inside* a single quoted run such as
    ``'/home/foo bar/file.txt'`` because the space breaks the run into
    two tokens. This helper rewrites such quoted runs to
    ``'file.txt'`` (or `"file.txt"` for double-quote forms) before the
    tokenizer runs. Non-path quoted strings (transcripts, ratios) are
    left alone because their body never matches the path predicates.
    """

    def _replace(match: "re.Match[str]") -> str:
        quote = match.group("q")
        body = match.group("body")
        # Strip a single ``file://`` scheme so the inner path is
        # subjected to the usual predicates. Keep leading slashes —
        # ``file:///etc/foo`` becomes ``/etc/foo`` which matches
        # ``_POSIX_ABS_RE``.
        probe = body.lstrip()
        if _FILE_URI_RE.match(probe):
            probe = _FILE_URI_RE.sub("", probe)
            # ``file:///C:/foo`` → ``/C:/foo``: strip a single leading
            # slash so ``_WINDOWS_DRIVE_RE`` can still match.
            if (
                len(probe) > 2
                and probe[0] == "/"
                and probe[1].isalpha()
                and probe[2] == ":"
            ):
                probe = probe[1:]
        if not (
            _WINDOWS_DRIVE_RE.match(probe)
            or _UNC_RE.match(probe)
            or _POSIX_ABS_RE.match(probe)
            or _POSIX_ABS_FILE_RE.match(probe)
        ):
            return match.group(0)
        return f"{quote}{path_to_basename(probe)}{quote}"

    return _QUOTED_PATH_RE.sub(_replace, text)


def sanitize_message(message: Any) -> str:
    """Replace path-like tokens in ``message`` with basenames.

    Idempotent. Preserves URLs, ratios, plain prose, and surrounding
    punctuation. Non-string inputs are converted to ``str`` first, so
    callers can pass an exception object directly.
    """
    if message is None:
        return ""
    text = str(message)
    if not text:
        return text
    # Task 42: handle quoted paths-with-spaces before the whitespace
    # tokenizer breaks them apart.
    text = _sanitize_quoted_paths(text)
    return _TOKEN_RE.sub(lambda m: _sanitize_token(m.group(0)), text)


# ---------------------------------------------------------------------------
# Metadata sanitization
# ---------------------------------------------------------------------------


def _sanitize_string_value(value: str, *, key: Optional[str]) -> str:
    """Sanitize a single string value.

    When ``key`` is in ``_PATH_DESIGNATED_KEYS`` the value is reduced
    to a basename even if it does not look path-like (e.g.
    ``audio_path: "./foo.wav"`` becomes ``"foo.wav"``). Otherwise the
    string is run through :func:`sanitize_message` so embedded paths
    inside larger free-form text are reduced.
    """
    if key is not None and key in _PATH_DESIGNATED_KEYS and value:
        return path_to_basename(value)
    return sanitize_message(value)


def sanitize_metadata(value: Any, *, key: Optional[str] = None) -> Any:
    """Recursively sanitize a metadata payload.

    Supported container types: :class:`dict`, :class:`list`,
    :class:`tuple`. Scalars (``None``, ``bool``, ``int``, ``float``,
    :class:`Enum`) are returned verbatim. :class:`pathlib.Path` is
    reduced to its basename string. Strings are sanitized via
    :func:`sanitize_message`; if ``key`` (the dict key the value
    sits under) is in the path-designated set, the string is treated
    as a path and reduced unconditionally.

    Idempotent: applying twice yields the same value as applying once.
    """
    if value is None:
        return None
    if isinstance(value, bool):
        return value  # ``bool`` must be checked before ``int``.
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, Enum):
        return value
    if isinstance(value, Path):
        return path_to_basename(value)
    if isinstance(value, str):
        return _sanitize_string_value(value, key=key)
    if isinstance(value, dict):
        return {
            k: sanitize_metadata(v, key=k if isinstance(k, str) else None)
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [sanitize_metadata(v, key=key) for v in value]
    if isinstance(value, tuple):
        return tuple(sanitize_metadata(v, key=key) for v in value)
    # Unknown types: stringify and sanitize. This catches custom
    # exceptions, dataclasses without __str__, etc. without leaking
    # their repr-form paths.
    try:
        return sanitize_message(str(value))
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Reserved-key merge
# ---------------------------------------------------------------------------


def merged_metadata(
    reserved: Mapping[str, Any],
    extra: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    """Merge caller-provided ``extra`` under ``reserved`` *without*
    letting ``extra`` overwrite reserved keys.

    The values in ``reserved`` always win. The ``extra`` payload is
    sanitized recursively before being merged so caller-provided
    paths are stripped.

    Keys from ``extra`` that collide with ``reserved`` are silently
    dropped (the authoritative value stays). This protects fields
    like ``backend`` and ``audio_basename`` from being clobbered by
    untrusted callers.
    """
    out: Dict[str, Any] = {}
    if extra:
        cleaned = sanitize_metadata(dict(extra))
        if isinstance(cleaned, dict):
            for k, v in cleaned.items():
                if k in reserved:
                    continue
                out[k] = v
    # Reserved fields are written last. We sanitize them too so that a
    # path leaking through a reserved field still gets reduced.
    cleaned_reserved = sanitize_metadata(dict(reserved))
    if isinstance(cleaned_reserved, dict):
        out.update(cleaned_reserved)
    return out


# ---------------------------------------------------------------------------
# Response-level sanitization (Task 35)
# ---------------------------------------------------------------------------


def sanitize_response_payload(payload: Any) -> Any:
    """Return a sanitized copy of a ``CameraCompanionResponsePayload``.

    Replaces every user-visible / spoken string field with the
    output of :func:`sanitize_message`, including:

    - ``answer_text``;
    - the ``scene`` dataclass: ``description``, ``objects`` (per
      element), ``apparent_emotion``, ``safety_notes`` (per element);
    - ``observable_cues`` (per element);
    - ``suggested_interaction``.

    ``payload.is_fallback`` and ``payload.fallback_reason`` are not
    altered. The original payload is never mutated; ``dataclasses.replace``
    builds a new instance. Idempotent: a second call returns an equal
    payload.

    Lazy-imports the payload type to avoid a circular import.
    """
    from dataclasses import replace as _dc_replace

    from .scene_response_parser import CameraCompanionResponsePayload
    from .schemas import SceneUnderstanding

    if not isinstance(payload, CameraCompanionResponsePayload):
        return payload

    new_answer = sanitize_message(payload.answer_text)
    new_suggestion = (
        sanitize_message(payload.suggested_interaction)
        if payload.suggested_interaction
        else payload.suggested_interaction
    )
    new_cues = [
        sanitize_message(c) if isinstance(c, str) else c
        for c in (payload.observable_cues or [])
    ]

    scene = payload.scene
    if isinstance(scene, SceneUnderstanding):
        new_scene = _dc_replace(
            scene,
            description=sanitize_message(scene.description or ""),
            objects=[
                sanitize_message(o) if isinstance(o, str) else o
                for o in (scene.objects or [])
            ],
            apparent_emotion=(
                sanitize_message(scene.apparent_emotion)
                if scene.apparent_emotion
                else scene.apparent_emotion
            ),
            safety_notes=[
                sanitize_message(n) if isinstance(n, str) else n
                for n in (scene.safety_notes or [])
            ],
        )
    else:
        new_scene = scene

    return _dc_replace(
        payload,
        answer_text=new_answer,
        scene=new_scene,
        suggested_interaction=new_suggestion,
        observable_cues=new_cues,
    )


# Allow ``os.fspath`` use sites to keep working without importing this
# module's ``Path`` symbol.
_ = os  # silence lints when os.fspath is added later
