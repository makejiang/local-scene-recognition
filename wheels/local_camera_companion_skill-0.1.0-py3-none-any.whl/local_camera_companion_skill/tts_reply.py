# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""TTS reply helper for the Camera Companion Skill (Task 13).

Stdlib-only wrapper around a duck-typed TTS engine. Provides three
behaviors that the rest of the skill should never duplicate:

* enable / disable gating
* answer-text length capping
* soft-fail vs. strict-fail policy on engine exceptions

Heavy dependencies (sounddevice, soundfile, openvino, torch, transformers,
cv2) are not imported at module load time.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .privacy import sanitize_message

logger = logging.getLogger(__name__)

__all__ = [
    "TTSReplyController",
    "TTSReplyResult",
    "split_into_sentences",
]


# Sentence terminators for the streaming-TTS splitter. Includes
# Chinese (full-width) and English (ASCII) end punctuation, plus
# semicolons and ellipses that the model frequently uses to cap one
# semantic unit. The regex captures the punctuation so we can stitch
# it back onto the preceding sentence.
_SENTENCE_END_RE = re.compile(r"([。！？!?；;\.\n]+)")


def split_into_sentences(
    text: str, *, max_chars: int = 800
) -> List[str]:
    """Split ``text`` on Chinese + English sentence punctuation.

    - Each sentence keeps its trailing punctuation (so playback
      sounds natural).
    - Empty / whitespace-only fragments are dropped.
    - The total spoken length is capped at ``max_chars``; sentences
      past the cap are dropped.
    - Returns ``[text]`` when the input contains no sentence
      boundary at all (e.g. a single short Chinese phrase) so the
      streaming worker still has one item to speak.
    """
    if not isinstance(text, str):
        return []
    stripped = text.strip()
    if not stripped:
        return []

    parts = _SENTENCE_END_RE.split(stripped)
    sentences: List[str] = []
    buffer = ""
    for piece in parts:
        if not piece:
            continue
        if _SENTENCE_END_RE.fullmatch(piece):
            buffer = (buffer + piece).strip()
            if buffer:
                sentences.append(buffer)
                buffer = ""
        else:
            buffer = (buffer + piece).strip()
    if buffer:
        sentences.append(buffer)

    # Drop empty fragments and apply the cap.
    out: List[str] = []
    used = 0
    cap = max(1, int(max_chars))
    for s in sentences:
        if not s:
            continue
        if used >= cap:
            break
        room = cap - used
        if len(s) > room:
            out.append(s[:room])
            used = cap
            break
        out.append(s)
        used += len(s)
    if not out:
        # No splittable boundary; return the full (capped) text so
        # callers always get at least one item.
        return [stripped[:cap]]
    return out


@dataclass
class TTSReplyResult:
    """Outcome of a single TTS attempt.

    ``tts_text`` is what the controller intended to speak (post-truncation).
    ``should_play_tts`` is True only if the engine accepted the call without
    raising. ``metadata`` always carries either a ``reason`` key (when
    ``should_play_tts`` is False) or the ``spoken_length`` / ``truncated``
    keys (when True).
    """

    tts_text: Optional[str]
    should_play_tts: bool
    metadata: Dict[str, Any] = field(default_factory=dict)


class TTSReplyController:
    """Disable/length-cap/soft-fail wrapper around a duck-typed TTS engine."""

    def __init__(
        self,
        tts_engine: Any = None,
        *,
        enabled: bool = True,
        max_text_length: int = 800,
        soft_fail: bool = True,
    ) -> None:
        self._tts_engine: Any = tts_engine
        self._enabled: bool = bool(enabled)
        self._max_text_length: int = max(1, int(max_text_length))
        self._soft_fail: bool = bool(soft_fail)

    def prepare_and_speak(self, answer_text: Optional[str]) -> TTSReplyResult:
        if not self._enabled:
            return TTSReplyResult(
                tts_text=None,
                should_play_tts=False,
                metadata={"reason": "disabled"},
            )

        stripped = answer_text.strip() if isinstance(answer_text, str) else ""
        if not stripped:
            return TTSReplyResult(
                tts_text=None,
                should_play_tts=False,
                metadata={"reason": "empty_answer"},
            )

        if self._tts_engine is None:
            return TTSReplyResult(
                tts_text=None,
                should_play_tts=False,
                metadata={"reason": "no_engine"},
            )

        original_len = len(stripped)
        tts_text = stripped[: self._max_text_length]
        truncated = original_len > self._max_text_length

        metadata: Dict[str, Any] = {
            "spoken_length": len(tts_text),
            "truncated": truncated,
        }
        if truncated:
            metadata["original_length"] = original_len

        try:
            self._tts_engine.speak(tts_text)
        except Exception as exc:
            logger.warning("tts engine.speak() raised: %s", exc)
            if not self._soft_fail:
                raise
            # Strip absolute paths from both ``repr(exc)`` and the
            # plain message before they escape into debug metadata
            # (Task 32). ``error_class`` is just a class name and
            # cannot leak.
            metadata["reason"] = "error"
            metadata["error"] = sanitize_message(repr(exc))
            metadata["error_class"] = exc.__class__.__name__
            return TTSReplyResult(
                tts_text=tts_text,
                should_play_tts=False,
                metadata=metadata,
            )

        return TTSReplyResult(
            tts_text=tts_text,
            should_play_tts=True,
            metadata=metadata,
        )

    def prepare_and_speak_streaming(
        self, answer_text: Optional[str]
    ) -> TTSReplyResult:
        """Sentence-level streaming variant of :meth:`prepare_and_speak`.

        Splits ``answer_text`` via :func:`split_into_sentences`,
        enqueues each sentence to the engine, then flushes so the
        function only returns once playback finishes. First-audio
        latency drops to roughly the cost of synthesizing one
        sentence (vs. the full reply for the legacy path).

        Falls back to the non-streaming :meth:`prepare_and_speak`
        path under any of the following conditions:

        - the engine doesn't expose ``enqueue_sentence`` /
          ``flush_and_wait`` (older fakes / stub engines);
        - the engine slot is None (controller has no engine);
        - the controller is disabled (``enabled=False``).

        Routing through ``prepare_and_speak`` for every fallback
        path lets subclasses that override ``prepare_and_speak``
        keep their behavior — including disabled / empty-answer
        gating — without having to override ``prepare_and_speak_streaming``
        too.
        """
        # Engine-capability gate: when the engine cannot stream, OR
        # the controller has no engine at all, OR is disabled, route
        # through the legacy path so subclasses with custom
        # ``prepare_and_speak`` keep working unchanged.
        engine = self._tts_engine
        has_queue = (
            engine is not None
            and hasattr(engine, "enqueue_sentence")
            and hasattr(engine, "flush_and_wait")
        )
        if not self._enabled or engine is None or not has_queue:
            return self.prepare_and_speak(answer_text)

        stripped = answer_text.strip() if isinstance(answer_text, str) else ""
        if not stripped:
            return TTSReplyResult(
                tts_text=None,
                should_play_tts=False,
                metadata={"reason": "empty_answer"},
            )

        original_len = len(stripped)
        truncated = original_len > self._max_text_length
        sentences = split_into_sentences(
            stripped, max_chars=self._max_text_length
        )
        tts_text = "".join(sentences)
        metadata: Dict[str, Any] = {
            "spoken_length": len(tts_text),
            "truncated": truncated,
            "streaming": True,
            "sentence_count": len(sentences),
        }
        if truncated:
            metadata["original_length"] = original_len

        try:
            for sentence in sentences:
                self._tts_engine.enqueue_sentence(sentence)
            self._tts_engine.flush_and_wait()
        except Exception as exc:
            logger.warning(
                "tts engine streaming flush_and_wait raised: %s", exc
            )
            if not self._soft_fail:
                raise
            metadata["reason"] = "error"
            metadata["error"] = sanitize_message(repr(exc))
            metadata["error_class"] = exc.__class__.__name__
            # Field debugging: capture what TTS was actually asked to
            # speak, even on error, so a partial reply that already
            # played is visible in the response payload.
            popped = self._pop_engine_enqueued_texts()
            if popped is not None:
                metadata["tts_sentences_enqueued"] = popped
            return TTSReplyResult(
                tts_text=tts_text,
                should_play_tts=False,
                metadata=metadata,
            )

        # Smoking-gun field accessor: list every sentence that was
        # handed to the TTS engine, in order. Lets callers detect
        # spoken-text != displayed-text bugs at the response boundary.
        popped = self._pop_engine_enqueued_texts()
        if popped is not None:
            metadata["tts_sentences_enqueued"] = popped

        return TTSReplyResult(
            tts_text=tts_text,
            should_play_tts=True,
            metadata=metadata,
        )

    def _pop_engine_enqueued_texts(self) -> Optional[List[str]]:
        """Return the sentence list from the engine if it exposes one.

        Tolerates older engines / fakes without the accessor and
        returns ``None`` rather than crashing.
        """
        getter = getattr(
            self._tts_engine, "pop_session_enqueued_texts", None
        )
        if not callable(getter):
            return None
        try:
            out = getter()
        except Exception:  # noqa: BLE001 - debug-path must not raise
            return None
        if not isinstance(out, list):
            return None
        return [str(s) for s in out]
