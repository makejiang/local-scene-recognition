# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Partial-JSON extractor for token-level LLM streaming.

The Camera Companion's scene-QA prompt asks MiniCPM-o to emit a
single JSON object whose ``"answer"`` field carries the user-facing
reply text. With token-level streaming, we want to start enqueueing
sentences to the TTS engine *as the LLM produces them*, before the
JSON is complete. This module implements a tiny char-level state
machine that consumes incremental text deltas and emits complete
**sentences** of the ``"answer"`` field as soon as each becomes
stable.

Key design choices
------------------

- **Char-level scanner, not a full JSON parser.** We only need to
  recognize the ``"answer"`` key and read the matching string value
  while honoring JSON escape rules. Anything outside that field is
  skipped without parsing. The scanner is robust against tokenizer
  artifacts (trailing whitespace, BOM, partial UTF-8 boundaries)
  because partial bytes simply remain in the buffer until the next
  ``feed`` call.
- **Reuses ``tts_reply.split_into_sentences``** so the sentence
  boundary rules match the post-decode batch path exactly.
- **Markdown-fence tolerant** — handles ```` ```json …  ``` ```` like
  ``scene_response_parser.parse_scene_model_output`` does. The
  scanner skips any leading prose / fence until it finds the first
  ``{``.
- **Stdlib only**: no transformers, openvino, torch, etc. at
  import or runtime.

Lifecycle
---------

::

    extractor = StreamingAnswerExtractor(
        on_sentence=engine.enqueue_sentence,
        max_chars=800,
    )
    pipeline.generate_from_mixed(..., token_callback=extractor.feed)
    extractor.flush()
    if not extractor.found_answer:
        # malformed JSON — caller falls back to post-decode batch TTS
        ...
"""

from __future__ import annotations

import logging
from typing import Callable, List, Optional

from .scene_response_parser import strip_think_tags
from .tts_reply import split_into_sentences

logger = logging.getLogger(__name__)

__all__ = ["StreamingAnswerExtractor", "PassthroughSentenceStreamer"]


# State machine constants.
_STATE_SEEK_OBJECT = "seek_object"   # scanning for the first ``{``
_STATE_SEEK_KEY = "seek_key"         # inside the object, looking for "answer"
_STATE_IN_VALUE = "in_value"         # inside the answer string body
_STATE_DONE = "done"                 # answer string consumed


class StreamingAnswerExtractor:
    """Consume streamed text deltas; emit complete sentences from the
    JSON ``"answer"`` field.

    Parameters
    ----------
    on_sentence : Callable[[str], None]
        Invoked with each complete sentence as it becomes stable.
        Exceptions are logged and swallowed.
    max_chars : int
        Hard cap on the total number of answer characters this
        extractor will emit. After the cap is reached, additional
        feed() calls are no-ops. Mirrors
        ``TTSReplyController.max_text_length``.
    target_key : str
        The JSON key whose value should be streamed. Defaults to
        ``"answer"`` for the Camera Companion's scene schema.
    """

    def __init__(
        self,
        on_sentence: Callable[[str], None],
        *,
        max_chars: int = 800,
        target_key: str = "answer",
    ) -> None:
        if on_sentence is None or not callable(on_sentence):
            raise ValueError(
                "StreamingAnswerExtractor requires a callable on_sentence."
            )
        self._on_sentence = on_sentence
        self._max_chars = max(1, int(max_chars))
        self._target_key = str(target_key)

        self._state = _STATE_SEEK_OBJECT
        # Pre-object scanner ignores everything until ``{``.
        # SEEK_KEY scanner reads keys; when a string-key matches
        # ``target_key`` and is followed by a ``:`` and a ``"``, the
        # scanner transitions to IN_VALUE.
        self._buffer: List[str] = []
        self._key_buffer: List[str] = []
        self._in_string = False        # are we currently inside a "..." string in SEEK_KEY?
        self._escape_next = False
        self._after_key = False        # last key matched target; waiting for `:`
        self._answer_so_far: List[str] = []
        self._unemitted = ""           # not-yet-emitted answer text (sentence remainder)
        self._total_emitted = 0
        self._found_answer = False

    @property
    def found_answer(self) -> bool:
        """True iff the scanner ever entered the answer-value state.

        The Camera Companion uses this to decide whether to fall back
        to post-decode batch TTS when the model didn't emit a parsable
        ``"answer"`` field (markdown garbage, missing key, etc.).
        """
        return self._found_answer

    @property
    def text_so_far(self) -> str:
        """Cumulative answer text seen so far (post-unescape)."""
        return "".join(self._answer_so_far)

    def feed(self, delta: str) -> None:
        """Consume one streamed text delta. Emits complete sentences
        as side effects via ``on_sentence``.

        Safe to call with empty / None deltas; safe after :meth:`flush`
        or after the answer string completes (subsequent calls are
        no-ops).
        """
        if not delta or self._state == _STATE_DONE:
            return
        for ch in delta:
            self._consume_char(ch)
            if self._total_emitted >= self._max_chars:
                # Reached hard cap; flush nothing else.
                self._state = _STATE_DONE
                return

    def flush(self) -> None:
        """Emit any leftover sentence text at end-of-decode.

        If the answer string was opened but never closed (e.g. the
        model truncated mid-reply), emit whatever unemitted text
        remains. Idempotent.
        """
        if self._state in (_STATE_DONE,):
            return
        leftover = self._unemitted.strip()
        self._unemitted = ""
        if leftover and self._total_emitted < self._max_chars:
            room = self._max_chars - self._total_emitted
            chunk = leftover[:room]
            self._emit(chunk)
        self._state = _STATE_DONE

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _consume_char(self, ch: str) -> None:
        state = self._state
        if state == _STATE_SEEK_OBJECT:
            if ch == "{":
                self._state = _STATE_SEEK_KEY
            return
        if state == _STATE_SEEK_KEY:
            self._consume_in_object(ch)
            return
        if state == _STATE_IN_VALUE:
            self._consume_in_value(ch)
            return

    def _consume_in_object(self, ch: str) -> None:
        """Scan inside the JSON object looking for ``"<target_key>"``
        followed by a colon and the opening ``"`` of its value.

        State variables:
        - ``_in_string``: currently inside a JSON string.
        - ``_key_buffer``: the contents of the current string while
          we're inside one. Reset on string close.
        - ``_after_key``: the most recently closed string was the
          target key, and we're waiting for ``: "`` to start
          collecting the value.
        - ``_escape_next``: previous char was ``\\`` while inside a
          string; consume the next char literally.
        """
        # Inside a JSON string — collect chars into key buffer.
        if self._in_string:
            if self._escape_next:
                self._key_buffer.append(ch)
                self._escape_next = False
                return
            if ch == "\\":
                self._escape_next = True
                return
            if ch == '"':
                # Closing this string.
                key = "".join(self._key_buffer)
                self._key_buffer = []
                self._in_string = False
                # Only treat the close as a "target key" if we're
                # not currently expecting a value (i.e. we haven't
                # already seen ``: "`` and entered a string-value).
                # Distinguishing keys from string-values: a key
                # always appears before ``:``, a string-value after.
                # We track this with ``_after_key``: if it's True
                # before this string opened, this string IS the
                # value, not the next key.
                if self._after_key:
                    # We just closed the *value* of a non-target
                    # key (e.g. ``"scene_summary": "...".`` skipped).
                    self._after_key = False
                elif key == self._target_key:
                    self._after_key = True
                # Otherwise: a non-target key just closed. Wait for
                # ``:`` then a string-value to skip.
                return
            # Regular char inside string.
            self._key_buffer.append(ch)
            return

        # Outside any string.
        if ch == '"':
            # Opening a new string. If ``_after_key`` is True we just
            # transitioned past the colon for the target key, and
            # this string IS the value — switch to IN_VALUE.
            if self._after_key:
                self._after_key = False
                self._key_buffer = []
                self._state = _STATE_IN_VALUE
                self._found_answer = True
                return
            # Otherwise it's a key (or a non-target string value).
            self._in_string = True
            self._key_buffer = []
            return
        if ch == ":":
            # Colon between key and value. If ``_after_key`` is
            # True we keep it set so the *next* opening ``"``
            # transitions to IN_VALUE.
            return
        if ch == "{":
            # Nested object — we don't recurse. The prompt produces
            # a flat scene JSON; if a nested object appears, just
            # stay in SEEK_KEY and treat the matching ``}`` as a
            # no-op.
            return
        if ch == "}":
            # Object closed before we found the target.
            self._state = _STATE_DONE
            return
        # Anything else (whitespace, commas, list brackets, numbers
        # etc.) is ignored.

    def _consume_in_value(self, ch: str) -> None:
        # Inside the answer string. Honor JSON escape rules.
        if self._escape_next:
            self._escape_next = False
            mapped = _JSON_ESCAPE_MAP.get(ch, ch)
            self._append_answer(mapped)
            return
        if ch == "\\":
            self._escape_next = True
            return
        if ch == '"':
            # Answer string closed. Flush any trailing unemitted text
            # and transition to DONE.
            self.flush()
            return
        self._append_answer(ch)

    def _append_answer(self, ch: str) -> None:
        if self._total_emitted >= self._max_chars:
            self._state = _STATE_DONE
            return
        self._answer_so_far.append(ch)
        self._unemitted += ch
        # Sentence emission: when the unemitted buffer contains a
        # sentence terminator, run the splitter and emit each
        # complete sentence; keep the trailing partial in
        # ``self._unemitted``.
        if ch in _SENTENCE_BOUNDARY_CHARS:
            sentences = split_into_sentences(
                self._unemitted, max_chars=self._max_chars
            )
            if not sentences:
                return
            # If the last sentence does NOT end in a boundary
            # character, it's still a partial — keep it in unemitted.
            last_ends_with_boundary = sentences[-1] and (
                sentences[-1][-1] in _SENTENCE_BOUNDARY_CHARS
            )
            if last_ends_with_boundary:
                # All split sentences are complete.
                for s in sentences:
                    self._emit(s)
                self._unemitted = ""
            else:
                # Emit all but the last; keep the last as the
                # in-progress remainder.
                for s in sentences[:-1]:
                    self._emit(s)
                self._unemitted = sentences[-1]

    def _emit(self, sentence: str) -> None:
        text = sentence.strip()
        if not text:
            return
        room = self._max_chars - self._total_emitted
        if room <= 0:
            self._state = _STATE_DONE
            return
        if len(text) > room:
            text = text[:room]
        self._total_emitted += len(text)
        try:
            self._on_sentence(text)
        except Exception:  # noqa: BLE001 - opportunistic
            logger.exception(
                "on_sentence raised in StreamingAnswerExtractor"
            )


# Sentence terminators (mirror ``tts_reply._SENTENCE_END_RE`` content).
_SENTENCE_BOUNDARY_CHARS = frozenset("。！？!?；;.\n")


def _suffix_marker_prefix(text: str, marker: str) -> str:
    """Return the longest suffix of ``text`` that is a prefix of
    ``marker`` (case-insensitive).

    Used by ``PassthroughSentenceStreamer._drop_think`` to recognise
    a tag that the tokenizer cut across two deltas, e.g. trailing
    ``<thi`` when the next delta will begin with ``nk>``.
    """
    if not text or not marker:
        return ""
    lt = text.lower()
    lm = marker.lower()
    # Longest prefix of marker that matches a suffix of text.
    max_len = min(len(text), len(marker) - 1)
    for n in range(max_len, 0, -1):
        if lt.endswith(lm[:n]):
            return text[-n:]
    return ""


# JSON ``\X`` escape mappings inside the answer string. The scanner
# only emits the unescaped char so the TTS engine doesn't read
# literal backslashes aloud.
_JSON_ESCAPE_MAP = {
    '"': '"',
    "\\": "\\",
    "/": "/",
    "b": "\b",
    "f": "\f",
    "n": "\n",
    "r": "\r",
    "t": "\t",
}


# ---------------------------------------------------------------------------
# Passthrough sentence streamer (Fast mode)
# ---------------------------------------------------------------------------


class PassthroughSentenceStreamer:
    """Sentence streamer for Fast mode (no JSON envelope).

    When ``interaction.fast_mode`` is True, the prompt builder drops
    the JSON 'COT' envelope and the model emits a plain-text reply.
    This class forwards every delta straight to the sentence
    splitter — the very first emitted token can start feeding TTS
    because there is no scaffolding to skip past.

    API shape mirrors :class:`StreamingAnswerExtractor` so the
    environment_skill wiring is a one-line branch:

    - ``feed(delta: str)`` accumulates partial text and emits each
      complete sentence via the ``on_sentence`` callback.
    - ``flush()`` emits any final partial sentence at end-of-stream.
    - ``found_answer`` is always True (Fast mode never falls back to
      the post-decode batch path; plain text is the designed output).
    - ``answer_text`` returns the concatenation of every emitted
      sentence.

    Sentence boundaries match :func:`tts_reply.split_into_sentences`
    exactly so the TTS engine sees the same shape in both modes.
    """

    def __init__(
        self,
        on_sentence: Callable[[str], None],
        *,
        max_chars: int = 800,
    ) -> None:
        if on_sentence is None or not callable(on_sentence):
            raise ValueError("on_sentence must be a callable")
        self._on_sentence = on_sentence
        self._max_chars = max(1, int(max_chars))
        # Unemitted text that hasn't reached a sentence boundary yet.
        self._unemitted: str = ""
        # Sentences already handed to the callback, joined to form
        # ``answer_text`` at the end.
        self._emitted: List[str] = []
        self._total_emitted: int = 0
        # Always True — Fast mode never falls back to JSON parsing.
        self.found_answer: bool = True
        # State machine: True while we're inside a <think>...</think>
        # block that started in a previous delta. Stripping has to
        # span deltas because the model may emit ``<thi`` then ``nk>``
        # then the reasoning body then ``</think>`` in any chunking.
        self._in_think_block: bool = False
        # Trailing chars of the previous delta that COULD be the start
        # of a ``<think>`` or ``</think>`` marker. We hold them back
        # instead of emitting so the marker can be completed by the
        # next delta. Length is bounded by ``len("</think>") - 1``.
        self._drop_carry: str = ""

    def feed(self, delta: str) -> None:
        """Accumulate ``delta`` and emit any newly-complete sentences."""
        if not isinstance(delta, str) or not delta:
            return
        if self._total_emitted >= self._max_chars:
            return
        delta = self._drop_think(delta)
        if not delta:
            return
        self._unemitted += delta
        # Cheap pre-check: if no boundary character is in the buffer,
        # there's nothing to emit yet. Saves split_into_sentences calls
        # on every short token delta.
        if not any(ch in _SENTENCE_BOUNDARY_CHARS for ch in delta):
            return
        sentences = split_into_sentences(
            self._unemitted, max_chars=self._max_chars
        )
        if not sentences:
            return
        last_ends_with_boundary = sentences[-1] and (
            sentences[-1][-1] in _SENTENCE_BOUNDARY_CHARS
        )
        if last_ends_with_boundary:
            for s in sentences:
                self._emit(s)
            self._unemitted = ""
        else:
            for s in sentences[:-1]:
                self._emit(s)
            self._unemitted = sentences[-1]

    def flush(self, *, force: bool = True) -> None:
        """Emit any remaining partial sentence at end-of-stream.

        ``force=True`` (default, end-of-decode call): emit whatever
        is left, appending a Chinese full-stop "。" if the buffer
        ends without a terminator. Session b09cc684 turn_007 showed
        Token2Wav synthesising "看起来像悟空去" when the LLM emitted
        "看起来像悟空" without "。" — the vocoder guessed a
        continuation. Appending a real terminator gives Token2Wav a
        cleaner ending sound.

        ``force=False`` (mid-stream call, e.g. a streaming wrapper
        that hasn't seen end-of-decode yet): hold the partial back
        until either a terminator arrives in a future ``feed()`` or
        a final ``force=True`` flush. This prevents the partial-
        sentence misrender on Token2Wav.

        Either way: resets the ``<think>`` state machine so a
        truncated opener at end-of-decode doesn't silently swallow
        whatever flushed text remains.
        """
        # If a <think> opener was the very last thing the model
        # emitted, everything currently in self._unemitted came AFTER
        # the opener — we should drop it as in-think content.
        if self._in_think_block:
            self._unemitted = ""
            self._in_think_block = False
        # The carry buffer holds chars that COULD be the start of a
        # tag; at flush time, no further delta is coming — if the
        # carry is a full prefix of "<think>" it is dropped, otherwise
        # it was a false alarm and we keep it as legitimate output.
        if self._drop_carry:
            carry = self._drop_carry
            self._drop_carry = ""
            lower = carry.lower()
            if not ("<think>".startswith(lower) or "</think>".startswith(lower)):
                self._unemitted = carry + self._unemitted
        leftover = strip_think_tags(self._unemitted).strip()
        if not leftover:
            self._unemitted = ""
            return
        last_char = leftover[-1]
        has_terminator = last_char in _SENTENCE_BOUNDARY_CHARS
        if not force and not has_terminator:
            # Mid-stream: more deltas may complete the sentence;
            # hold the partial back. Don't clear self._unemitted
            # because the next feed() will continue accumulating.
            return
        self._unemitted = ""
        if force and not has_terminator:
            # End-of-decode: give Token2Wav a clean terminator so it
            # doesn't guess a continuation character.
            leftover = leftover + "。"
        self._emit(leftover)

    @property
    def answer_text(self) -> str:
        """Concatenation of every sentence handed to ``on_sentence``.

        Applies ``strip_think_tags`` defensively so the property is
        safe to read even if a malformed stream somehow let a tag
        through into an emitted sentence.
        """
        return strip_think_tags(" ".join(self._emitted)).strip()

    def _drop_think(self, delta: str) -> str:
        """Strip ``<think>...</think>`` content from ``delta``.

        Tracks an open tag across calls via ``self._in_think_block``
        so a block that spans multiple deltas is still recognised:
        ``<thi`` + ``nk>...`` + ``</think>`` collapses to ``""``.

        Also carries the trailing chars of each delta that COULD be
        the start of a marker (``<thi``, ``</thin``, etc.) in
        ``self._drop_carry`` so the marker is recognised even when
        the tokenizer cuts it in the middle.
        """
        out: List[str] = []
        # Prepend any carried partial-marker chars from the last call.
        buf = (self._drop_carry + delta) if self._drop_carry else delta
        self._drop_carry = ""
        while buf:
            if self._in_think_block:
                idx = buf.lower().find("</think>")
                if idx < 0:
                    # No close in what we have. The trailing chars MIGHT
                    # be the start of </think>; hold them back.
                    self._drop_carry = _suffix_marker_prefix(
                        buf, "</think>"
                    )
                    return "".join(out)
                buf = buf[idx + len("</think>"):]
                self._in_think_block = False
                continue
            idx = buf.lower().find("<think>")
            if idx < 0:
                # The trailing chars might be the start of <think>.
                # Emit the safe prefix and carry the suspect suffix.
                carry = _suffix_marker_prefix(buf, "<think>")
                if carry:
                    out.append(buf[: -len(carry)])
                    self._drop_carry = carry
                else:
                    out.append(buf)
                return "".join(out)
            out.append(buf[:idx])
            buf = buf[idx + len("<think>"):]
            self._in_think_block = True
        return "".join(out)

    def _emit(self, sentence: str) -> None:
        text = sentence.strip()
        if not text:
            return
        room = self._max_chars - self._total_emitted
        if room <= 0:
            return
        if len(text) > room:
            text = text[:room]
        self._emitted.append(text)
        self._total_emitted += len(text)
        try:
            self._on_sentence(text)
        except Exception:  # noqa: BLE001 - opportunistic
            logger.exception(
                "on_sentence raised in PassthroughSentenceStreamer"
            )
