# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Continuous mic capture for VAD-driven turn-taking.

Wraps ``sounddevice.RawInputStream`` into a producer-consumer pipeline:

- The audio thread (sounddevice's callback) pushes raw int16 PCM bytes
  into ``self._byte_queue`` (a ``queue.Queue[bytes]``).
- The consumer thread (the caller of :meth:`iter_frames`) pulls bytes
  off, accumulates them into a ring-style buffer, and yields
  ``chunk_samples``-long float32 frames normalized to ``[-1.0, 1.0]``.

We standardize on int16 PCM in / float32 frames out because Silero's
ONNX wants float32 and the rest of the codebase already uses
``_samples_to_int16_bytes`` for symmetry.

``sounddevice`` is imported lazily from ``sys.modules`` so tests can
inject a fake. No heavy imports happen at module load time.
"""

from __future__ import annotations

import array
import logging
import queue
import threading
from typing import Any, Iterator, List, Optional

logger = logging.getLogger(__name__)

__all__ = ["ContinuousAudioCapture"]


_INT16_MAX = 32767.0


def _int16_bytes_to_floats(buf: bytes) -> List[float]:
    """Convert a little-endian int16 PCM byte string to float32 list."""
    arr = array.array("h")
    arr.frombytes(buf)
    return [v / _INT16_MAX for v in arr]


class ContinuousAudioCapture:
    """Continuous 16 kHz mono mic capture.

    Parameters
    ----------
    sample_rate:
        Capture sample rate. Must be 16000 for VAD compatibility.
    sounddevice_module:
        Optional injected fake. ``None`` (the default) lazy-imports
        ``sounddevice`` from ``sys.modules`` on ``start()``.
    """

    def __init__(
        self,
        *,
        sample_rate: int = 16000,
        sounddevice_module: Optional[Any] = None,
    ) -> None:
        self._sample_rate = int(sample_rate)
        self._sd = sounddevice_module
        self._byte_queue: "queue.Queue[Optional[bytes]]" = queue.Queue()
        self._stream: Any = None
        self._lock = threading.Lock()
        self._running = False

    def start(self) -> None:
        """Open the input stream and begin pushing bytes to the queue.

        Raises ``RuntimeError`` if the capture is already running.
        """
        with self._lock:
            if self._running:
                raise RuntimeError(
                    "ContinuousAudioCapture.start: already running"
                )

            sd = self._sd
            if sd is None:
                import sys
                sd = sys.modules.get("sounddevice")
                if sd is None:
                    import sounddevice as _sd  # type: ignore
                    sd = _sd
                self._sd = sd

            def _callback(indata: Any, frames: int, time_info: Any, status: Any) -> None:
                if status:
                    # ``input overflow`` is by far the most common
                    # status on contended systems. The CFFI buffer
                    # ``indata`` is still copied verbatim into the
                    # byte queue, so the warning does NOT correspond
                    # to dropped audio data — every ASR transcript
                    # in the v12 / v13 sessions confirmed audio
                    # continuity even when the warning fired 5+
                    # times per turn. Demote that specific status
                    # to DEBUG to keep the live-demo console clean.
                    # Other (rarer) statuses still log at WARNING.
                    if "input overflow" in str(status):
                        logger.debug("audio callback status: %s", status)
                    else:
                        logger.warning("audio callback status: %s", status)
                # ``indata`` is a CFFI buffer of int16 bytes for
                # RawInputStream. ``bytes(indata)`` works for both
                # CFFI buffers and Python ``bytes`` test inputs.
                try:
                    self._byte_queue.put(bytes(indata))
                except Exception as exc:  # pragma: no cover - defensive
                    logger.warning("queue.put failed: %s", exc)

            stream = sd.RawInputStream(
                samplerate=self._sample_rate,
                channels=1,
                dtype="int16",
                callback=_callback,
                # ``blocksize=0`` lets sounddevice pick a buffer size
                # based on the latency hint. ``latency="high"`` asks
                # for ~50-100ms of headroom (vs the platform default
                # of ~10ms). Earlier real-machine sessions showed
                # the callback overrunning ("input overflow") under
                # heavy GPU/CPU load with this config, but the
                # underlying audio stream stays correct (every byte
                # is still copied to the queue). A previous attempt
                # to widen the buffer to ``blocksize=8000``+
                # ``latency=0.5`` was rejected by the Windows
                # portaudio backend on some default microphones,
                # crashing the whole runner at session start. Keep
                # the safe defaults; suppress the cosmetic
                # ``input overflow`` warning above instead.
                blocksize=0,
                latency="high",
            )
            stream.start()
            self._stream = stream
            self._running = True

    def stop(self) -> None:
        """Stop the input stream and signal ``iter_frames`` to terminate.

        Idempotent. Always safe to call after ``start``.
        """
        with self._lock:
            if not self._running:
                return
            self._running = False
            stream = self._stream
            self._stream = None

        if stream is not None:
            try:
                stream.stop()
            except Exception:
                pass
            try:
                stream.close()
            except Exception:
                pass

        # Wake the consumer with a poison pill so iter_frames returns.
        self._byte_queue.put(None)

    def drain(self) -> int:
        """Discard every queued audio chunk that hasn't been consumed.

        Returns the number of bytes dropped. Called by the
        continuous-voice runner after a TTS reply finishes playing,
        so the speaker→mic leakage that piled up while ``iter_frames``
        was waiting (because VAD was gated off and no consumer thread
        was draining) doesn't get processed as user speech on the
        next turn.

        The poison-pill sentinel (``None``) is preserved if it's
        already in the queue — we only drop ``bytes`` items.
        """
        dropped = 0
        leftover_sentinels = 0
        try:
            while True:
                item = self._byte_queue.get_nowait()
                if item is None:
                    leftover_sentinels += 1
                else:
                    dropped += len(item)
        except queue.Empty:
            pass
        # Restore any sentinels we accidentally pulled off.
        for _ in range(leftover_sentinels):
            self._byte_queue.put(None)
        return dropped

    def iter_frames(
        self,
        *,
        chunk_samples: int = 512,
        timeout: Optional[float] = None,
    ) -> Iterator[List[float]]:
        """Yield ``chunk_samples``-long float32 frames in [-1.0, 1.0].

        Drains ``self._byte_queue``, accumulates an internal byte
        buffer, and slices off ``chunk_samples * 2``-byte chunks.
        Stops cleanly when ``stop()`` is called (queue receives None)
        or when ``timeout`` expires between frames.
        """
        if chunk_samples <= 0:
            raise ValueError("chunk_samples must be positive")
        bytes_per_chunk = chunk_samples * 2  # int16

        pending = bytearray()
        while True:
            if len(pending) >= bytes_per_chunk:
                frame_bytes = bytes(pending[:bytes_per_chunk])
                del pending[:bytes_per_chunk]
                yield _int16_bytes_to_floats(frame_bytes)
                continue

            try:
                item = self._byte_queue.get(timeout=timeout)
            except queue.Empty:
                return
            if item is None:
                # Stop signal. Drain any remaining whole chunks.
                if len(pending) >= bytes_per_chunk:
                    frame_bytes = bytes(pending[:bytes_per_chunk])
                    del pending[:bytes_per_chunk]
                    yield _int16_bytes_to_floats(frame_bytes)
                return
            pending.extend(item)
