# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""MiniCPM-o TTS synthesis + local WAV playback bridge (Task 29).

Adapts a loaded MiniCPM-o-compatible pipeline (which exposes
``synthesize_speech(text, output_path=...) -> Optional[Path]``) to the
``speak(text)`` contract that ``TTSReplyController`` invokes. Each
``speak()`` call:

1. Builds a basename-safe unique ``.wav`` target under the configured
   output directory.
2. Calls ``pipeline.synthesize_speech(text, output_path=target)``.
3. Validates that the WAV exists and is non-empty.
4. Hands the path to an injected :class:`WavPlayer`.
5. Optionally deletes the WAV after playback.

The default :class:`_LocalSoundDeviceWavPlayer` lazy-imports
``sounddevice`` only inside ``play()`` / ``stop()`` and uses stdlib
``wave`` plus ``sounddevice.RawOutputStream`` so neither
``sounddevice``, ``numpy``, nor any other heavy module is imported at
module load time.

Errors and ``debug_snapshot()`` payloads are basenames-only; absolute
filesystem paths must not leak.
"""

from __future__ import annotations

import logging
import os
import queue
import re
import threading
import time
import uuid
import wave
from pathlib import Path
from typing import (
    Any,
    Callable,
    ClassVar,
    Dict,
    List,
    Optional,
    Protocol,
    Union,
    runtime_checkable,
)


logger = logging.getLogger(__name__)

PathLike = Union[str, Path]


# --- TTS text normalization ------------------------------------------------
# MiniCPM-o's Token2Wav cycle-locks / over-generates on Arabic digits mixed
# into CJK text (device field report: "3 加 6 等于 9" synthesised to 4.28s vs
# ~2.07s expected, flagged degenerate, retried, and written garbled anyway).
# Converting digit runs to Chinese numerals before synthesis keeps the input
# pure-CJK and pronounceable. We also give the synthesiser a clean sentence
# terminator so it doesn't guess a trailing continuation and clip the final
# syllable on very short replies ("六点整").

_CJK_DIGITS = "零一二三四五六七八九"
_SENTENCE_TERMINATORS = "。！？!?；;.…\n"


def _convert(n: int) -> str:
    """Positional Chinese numeral; always keeps the leading 一 before 十 (so
    embedded tens read correctly, e.g. 115 → 一百一十五). The top-level
    :func:`_int_to_chinese` strips that leading 一 for standalone 10–19."""
    if n < 10:
        return _CJK_DIGITS[n]
    if n < 100:
        tens, ones = divmod(n, 10)
        return _CJK_DIGITS[tens] + "十" + (_CJK_DIGITS[ones] if ones else "")
    if n < 1000:
        hundreds, rem = divmod(n, 100)
        s = _CJK_DIGITS[hundreds] + "百"
        if rem == 0:
            return s
        return s + (("零" + _CJK_DIGITS[rem]) if rem < 10 else _convert(rem))
    if n < 10000:
        thousands, rem = divmod(n, 1000)
        s = _CJK_DIGITS[thousands] + "千"
        if rem == 0:
            return s
        return s + (("零" + _convert(rem)) if rem < 100 else _convert(rem))
    if n < 100000000:
        wan, rem = divmod(n, 10000)
        s = _int_to_chinese(wan) + "万"
        if rem == 0:
            return s
        return s + (("零" + _convert(rem)) if rem < 1000 else _convert(rem))
    return "".join(_CJK_DIGITS[int(c)] for c in str(n))


def _int_to_chinese(n: int) -> str:
    """Render a non-negative-ish int as a Chinese numeral (correct for the
    small magnitudes this skill produces: coin cents, arithmetic results,
    clock numbers). Standalone 10–19 drop the leading 一 (十五, not 一十五)."""
    if n < 0:
        return "负" + _int_to_chinese(-n)
    out = _convert(n)
    if out.startswith("一十"):
        out = out[1:]
    return out


def _digits_to_chinese(text: str) -> str:
    """Replace each maximal digit run (with optional decimal point) with its
    Chinese-numeral reading, leaving CJK/Latin words untouched."""

    def _repl(m: "re.Match[str]") -> str:
        s = m.group(0)
        if "." in s:
            int_part, frac = s.split(".", 1)
            head = _int_to_chinese(int(int_part)) if int_part else "零"
            return head + "点" + "".join(_CJK_DIGITS[int(c)] for c in frac)
        return _int_to_chinese(int(s))

    return re.sub(r"\d+(?:\.\d+)?", _repl, text)


def _has_cjk(text: str) -> bool:
    return any(
        "一" <= c <= "鿿" or "㐀" <= c <= "䶿" for c in text
    )


# Seed offset between content-verify re-synthesis attempts. Kept well above the
# runtime's ``max_degenerate_retries`` (currently 3) so each attempt's internal
# duration-retry seed range is disjoint from the others.
_VERIFY_SEED_STEP = 8

# Chars stripped before comparing an ASR transcript to the intended TTS text.
_VERIFY_STRIP = "。！？!?；;，,、.…\n \t　\"'「」『』（）()《》"


def _normalize_for_compare(text: str) -> str:
    out = "".join(c for c in (text or "") if c not in _VERIFY_STRIP)
    return out.strip().lower()


def text_similarity(a: str, b: str) -> float:
    """Similarity in [0,1] between two strings after stripping punctuation /
    whitespace / brackets. Used to decide whether a TTS clip's ASR transcript
    matches the intended text. A faithful render scores high; a wrong-phoneme
    garble scores far lower."""
    from difflib import SequenceMatcher

    na, nb = _normalize_for_compare(a), _normalize_for_compare(b)
    if not na and not nb:
        return 1.0
    if not na or not nb:
        return 0.0
    return SequenceMatcher(None, na, nb).ratio()


def normalize_for_tts(text: str) -> str:
    """Prepare a single sentence for Token2Wav: digits→Chinese numerals plus a
    trailing sentence terminator when one is missing. Idempotent for text that
    is already terminated.

    Only applied to CJK-bearing text — the digit-garble and short-clip issues
    are specific to MiniCPM-o's Chinese synthesis, and rewriting digits in an
    otherwise English reply ("3 apples") would mispronounce it. Pure non-CJK
    text passes through untouched."""
    if not text or not text.strip() or not _has_cjk(text):
        return text
    out = _digits_to_chinese(text)
    stripped = out.rstrip()
    if stripped[-1] not in _SENTENCE_TERMINATORS:
        out = stripped + "。"
    return out


__all__ = [
    "MiniCPMTTSPlaybackEngine",
    "MiniCPMTTSPlaybackError",
    "WavPlayer",
]


class MiniCPMTTSPlaybackError(RuntimeError):
    """Raised when TTS synthesis or playback fails."""


@runtime_checkable
class WavPlayer(Protocol):
    """Duck-typed local WAV player."""

    def play(self, path: PathLike) -> None: ...
    def stop(self) -> None: ...


# stdlib ``wave`` reports sample width in bytes. ``sounddevice``
# RawOutputStream accepts ``int8`` / ``int16`` / ``int32`` PCM types.
_SUPPORTED_SAMPLE_WIDTHS: Dict[int, str] = {
    1: "int8",
    2: "int16",
    4: "int32",
}


def _safe_basename(prefix: str = "tts") -> str:
    """Return a basename-only timestamped wav filename."""
    safe = os.path.basename(str(prefix or "tts")) or "tts"
    if not safe.isascii() or "/" in safe or "\\" in safe:
        safe = "tts"
    return f"{safe}_{int(time.time() * 1000)}_{uuid.uuid4().hex[:8]}.wav"


def _basename_only_error(msg: str, path_hint: Optional[Path]) -> str:
    """Strip absolute-path leakage from an error message."""
    if not path_hint:
        return msg
    full = str(path_hint)
    if full and full in msg:
        msg = msg.replace(full, path_hint.name)
    parent = str(path_hint.parent)
    if parent and parent != "." and parent in msg:
        msg = msg.replace(parent, path_hint.parent.name)
    return msg


# ---------------------------------------------------------------------------
# Path ownership + WAV validation (Task 37)
# ---------------------------------------------------------------------------


def _safe_resolve(path: Path) -> Path:
    """Best-effort ``Path.resolve()`` that does not raise.

    On Windows ``Path.resolve()`` may raise for paths whose
    components do not exist; falling back to ``Path.absolute()``
    keeps the comparison meaningful for ownership checks.
    """
    try:
        return path.resolve()
    except OSError:
        try:
            return path.absolute()
        except Exception:
            return path


def _resolve_returned_path(
    returned: Any,
    target: Path,
    output_dir: Path,
) -> Path:
    """Resolve the path the pipeline returned to a deterministic
    absolute :class:`Path`.

    - ``None`` → canonical ``target``.
    - A returned path that resolves to the same canonical path as
      ``target`` (the engine's requested target) → ``target_abs``,
      regardless of whether the return was the absolute target or
      the relative string the engine passed in. This short-circuit
      (Task 43) prevents the legacy double-prefix bug where a
      pipeline that echoes its ``output_path`` argument would
      otherwise be re-joined onto ``output_dir``.
    - Other absolute paths → kept as-is (after canonicalization).
    - Other relative paths → resolved against ``output_dir``.

    The result is canonicalized via ``resolve()`` (best-effort) so
    ownership comparison is symlink-aware.
    """
    target_abs = _safe_resolve(target)
    if returned is None:
        return target_abs
    p = Path(returned)
    p_abs = _safe_resolve(p)
    if p_abs == target_abs:
        # Pipeline echoed the requested target (absolute or relative
        # form). Use the canonical target — never re-join on
        # ``output_dir`` or it would double-prefix when both inputs
        # were relative to the same CWD.
        return target_abs
    if p.is_absolute():
        return p_abs
    return _safe_resolve(output_dir / p)


def _is_inside(path: Path, root: Path) -> bool:
    """Return True iff ``path`` is the same as, or a descendant of,
    ``root``. Both are resolved (best-effort) before comparison.
    """
    p = _safe_resolve(path)
    r = _safe_resolve(root)
    try:
        return p == r or r in p.parents
    except Exception:
        return False


def _validate_wav(path: Path) -> None:
    """Raise :class:`MiniCPMTTSPlaybackError` unless ``path`` is a
    valid PCM ``.wav`` file with at least one frame.

    Order of checks: suffix → regular file → non-empty → stdlib
    ``wave.open`` succeeds → ``getnframes() > 0``. The ``is_file()``
    check naturally rejects directories and missing files.
    """
    if path.suffix.lower() != ".wav":
        raise MiniCPMTTSPlaybackError(
            f"synthesis produced non-wav file: {path.name}"
        )
    if not path.is_file():
        # Covers missing files and directories.
        raise MiniCPMTTSPlaybackError(
            f"synthesis produced no audio at {path.name}"
        )
    try:
        size = path.stat().st_size
    except OSError:
        raise MiniCPMTTSPlaybackError(
            f"synthesis produced unreadable file: {path.name}"
        )
    if size == 0:
        raise MiniCPMTTSPlaybackError(
            f"synthesis produced empty audio at {path.name}"
        )
    try:
        with wave.open(str(path), "rb") as wf:
            n_frames = wf.getnframes()
    except (wave.Error, EOFError, OSError) as exc:
        raise MiniCPMTTSPlaybackError(
            "synthesis produced invalid wav at "
            + _basename_only_error(f"{path.name}: {exc}", path)
        )
    if n_frames <= 0:
        raise MiniCPMTTSPlaybackError(
            f"synthesis produced wav with no frames at {path.name}"
        )


def _ownership_set(
    target: Optional[Path],
    actual: Optional[Path],
    output_dir: Path,
) -> "list[Path]":
    """Return the deduplicated list of paths the engine *owns* and is
    allowed to delete.

    Ownership rules:
    - The requested target is always owned (the engine created its
      slot under ``output_dir``).
    - The actual returned path is owned only when it lies inside
      ``output_dir``.
    - Paths are deduplicated by their resolved form so a returned
      path equal to the target is deleted exactly once.
    """
    out: "list[Path]" = []
    seen: "set[str]" = set()
    candidates: "list[Path]" = []
    if target is not None:
        candidates.append(target)
    if actual is not None and _is_inside(actual, output_dir):
        candidates.append(actual)
    for c in candidates:
        key = str(_safe_resolve(c))
        if key in seen:
            continue
        seen.add(key)
        out.append(c)
    return out


# ---------------------------------------------------------------------------
# Default local WAV player (lazy sounddevice + stdlib wave)
# ---------------------------------------------------------------------------


class _LocalSoundDeviceWavPlayer:
    """Default local WAV player.

    Reads PCM bytes via stdlib :mod:`wave` and writes them to
    ``sounddevice.RawOutputStream`` so numpy is never required. Only
    8-bit, 16-bit, and 32-bit PCM, mono or stereo, are supported.
    Anything else raises :class:`MiniCPMTTSPlaybackError`.
    """

    _CHUNK_FRAMES: ClassVar[int] = 1024

    def __init__(self) -> None:
        self._active_stream: Any = None

    def play(self, path: PathLike) -> None:
        wav_path = Path(path)

        with wave.open(str(wav_path), "rb") as wf:
            sampwidth = wf.getsampwidth()
            channels = wf.getnchannels()
            framerate = wf.getframerate()
            n_frames = wf.getnframes()

            if sampwidth not in _SUPPORTED_SAMPLE_WIDTHS:
                raise MiniCPMTTSPlaybackError(
                    f"unsupported PCM sample width: {sampwidth} bytes; "
                    f"supported widths are 1, 2, or 4."
                )
            if channels < 1 or channels > 2:
                raise MiniCPMTTSPlaybackError(
                    f"unsupported channel count: {channels}; "
                    f"supported is 1 or 2."
                )

            dtype = _SUPPORTED_SAMPLE_WIDTHS[sampwidth]
            pcm_bytes = wf.readframes(n_frames)

        try:
            import sounddevice  # type: ignore
        except ImportError as exc:
            raise MiniCPMTTSPlaybackError(
                "Local TTS playback requires the optional 'sounddevice' "
                "package. Install it with `pip install sounddevice`."
            ) from exc

        try:
            stream = sounddevice.RawOutputStream(
                samplerate=framerate,
                channels=channels,
                dtype=dtype,
            )
        except Exception as exc:
            raise MiniCPMTTSPlaybackError(
                f"failed to open sounddevice output stream: {exc}"
            ) from exc

        self._active_stream = stream
        try:
            stream.start()
            frame_bytes = sampwidth * channels
            chunk = self._CHUNK_FRAMES * frame_bytes
            offset = 0
            total = len(pcm_bytes)
            while offset < total:
                stream.write(pcm_bytes[offset : offset + chunk])
                offset += chunk
        except MiniCPMTTSPlaybackError:
            raise
        except Exception as exc:
            raise MiniCPMTTSPlaybackError(
                f"WAV playback failed: {exc}"
            ) from exc
        finally:
            try:
                stream.stop()
            except Exception:
                pass
            try:
                stream.close()
            except Exception:
                pass
            self._active_stream = None

    def stop(self) -> None:
        # Best-effort. Idempotent. Never raises.
        stream = self._active_stream
        if stream is None:
            return
        try:
            stop_fn = getattr(stream, "stop", None)
            if callable(stop_fn):
                stop_fn()
        except Exception:
            pass
        finally:
            self._active_stream = None


# ---------------------------------------------------------------------------
# Bridging engine
# ---------------------------------------------------------------------------


class MiniCPMTTSPlaybackEngine:
    """Bridge: MiniCPM-o synthesis -> local WAV playback.

    Implements the ``speak(text, pace=1.0) -> None`` and ``stop() -> None``
    contract that :class:`TTSReplyController` consumes.
    """

    def __init__(
        self,
        pipeline: Any,
        *,
        output_dir: PathLike = "./model_cache/camera_companion/tts",
        player: Optional[WavPlayer] = None,
        cleanup_after_playback: bool = True,
        retain_for_debug: bool = False,
        filename_prefix: str = "tts",
        on_playback_start: Optional["Callable[[], None]"] = None,
        on_playback_end: Optional["Callable[[], None]"] = None,
        content_verifier: Optional["Callable[[Path, str], bool]"] = None,
        verify_max_chars: int = 24,
        verify_attempts: int = 3,
    ) -> None:
        if pipeline is None:
            raise ValueError(
                "MiniCPMTTSPlaybackEngine requires a pipeline with "
                "synthesize_speech(text, output_path=...)"
            )
        self._pipeline = pipeline
        # Optional ASR-verify hook: ``content_verifier(wav_path, text) -> bool``
        # returns True when the synthesized audio actually says ``text``. On a
        # False result the engine re-synthesizes the sentence at a fresh
        # sampling seed (see ``_speak_one_sentence``) to escape a wrong-phoneme
        # trajectory that duration/energy degenerate checks cannot detect. Only
        # applied to short CJK replies to bound the added ASR cost.
        self._content_verifier = content_verifier
        self._verify_max_chars = int(verify_max_chars)
        self._verify_attempts = max(1, int(verify_attempts))
        # Task 43: canonicalize ``output_dir`` to an absolute path
        # once at construction so the engine becomes CWD-independent.
        # Combined with the equality short-circuit in
        # ``_resolve_returned_path``, this eliminates the
        # double-prefix bug observed when the constructor received a
        # relative path and the pipeline echoed its ``output_path``
        # argument verbatim.
        self._output_dir = _safe_resolve(Path(output_dir))
        self._player: WavPlayer = player or _LocalSoundDeviceWavPlayer()
        self._cleanup_after_playback = bool(cleanup_after_playback)
        self._retain_for_debug = bool(retain_for_debug)
        self._filename_prefix = str(filename_prefix or "tts")
        self._last_wav_basename: Optional[str] = None
        # Live-demo overlay hooks. Fire around ``player.play(...)``
        # only (not around synthesis) so the "answering" banner
        # reflects audible playback rather than silent inference time.
        # Exceptions raised by callbacks are swallowed — playback
        # itself must never break because of an overlay.
        self._on_playback_start: Optional["Callable[[], None]"] = (
            on_playback_start
        )
        self._on_playback_end: Optional["Callable[[], None]"] = (
            on_playback_end
        )
        # Streaming state (sentence-level TTS — Camera Companion live
        # demo). The worker thread is spawned by
        # ``start_streaming_session`` and torn down by
        # ``end_streaming_session`` / ``flush_and_wait``. The legacy
        # ``speak()`` path runs synthesize+play on the calling thread
        # and never touches the queue.
        self._stream_queue: Optional["queue.Queue[Optional[str]]"] = None
        self._stream_worker: Optional[threading.Thread] = None
        self._stream_lock = threading.Lock()
        self._stream_last_error: Optional[BaseException] = None
        # Barge-in flag. ``interrupt()`` sets this; ``_stream_loop``
        # checks it to skip queued sentences cleanly.
        self._interrupted = threading.Event()
        # Per-session timing stamps. Set by ``start_streaming_session``
        # / ``_stream_loop`` / ``flush_and_wait``; popped by callers
        # via ``pop_session_metrics`` for per-turn observability.
        self._session_t0: Optional[float] = None
        self._first_play_t: Optional[float] = None
        self._last_play_t: Optional[float] = None
        # Per-session synthesized-WAV basenames. Appended in
        # ``_speak_one_sentence`` after the WAV passes validation;
        # popped (and cleared) by callers via ``pop_session_basenames``
        # so per-turn diagnostic capture can move the files into a
        # per-turn directory.
        self._session_basenames: List[str] = []
        # Per-session list of sentences as handed to ``enqueue_sentence``.
        # Field debugging: if the user reports "TTS spoke text X but the
        # UI showed text Y", this list is the smoking gun proving what
        # text was passed to the synthesiser. Cleared on session start.
        self._session_enqueued_texts: List[str] = []
        # Wall-clock of the most recent ``flush_and_wait`` completion.
        # Used to distinguish a same-turn ``start_streaming_session →
        # enqueue`` (worker alive, recent flush ago = -1) from a real
        # cross-turn queue leak (worker alive but a previous flush
        # completed seconds ago). ``None`` means no flush has run yet.
        self._last_flush_at: Optional[float] = None

    def speak(self, text: str, pace: float = 1.0) -> None:
        """Synthesize ``text`` and play the resulting WAV.

        Task 37: tracks two distinct paths:

        - **requested target**: ``output_dir / safe_basename`` — the
          path the engine asks the pipeline to write to. The engine
          *owns* this slot regardless of what the pipeline does.
        - **actual**: the path the pipeline actually returns (or
          ``target`` if the pipeline returns ``None``). Relative
          returns are resolved against ``output_dir``.

        Validation runs before the player is invoked. Returned paths
        outside ``output_dir`` are rejected and **never deleted**;
        they are not the engine's to clean up. Cleanup deletes the
        engine's owned set: the requested target plus the actual
        path, deduplicated, and only when both retention flags
        permit.

        Camera Companion sentence-streaming TTS: this method is the
        legacy one-shot path and is preserved unchanged. Streaming
        callers use :meth:`start_streaming_session` +
        :meth:`enqueue_sentence` + :meth:`flush_and_wait` /
        :meth:`end_streaming_session`.
        """
        self._speak_one_sentence(text)

    def _should_verify_content(self, text: str) -> bool:
        """Only ASR-verify short CJK replies, to bound the added cost."""
        if self._content_verifier is None:
            return False
        stripped = text.strip()
        return bool(stripped) and len(stripped) <= self._verify_max_chars and _has_cjk(stripped)

    def _synthesize_verified(self, text: str, target: Path) -> Any:
        """Synthesize ``text`` to ``target``. For short CJK replies with a
        content verifier wired, transcribe the result and, on a text mismatch,
        re-synthesize at a fresh (non-overlapping) sampling seed until it
        matches or attempts run out — this escapes wrong-phoneme trajectories
        the duration/energy degenerate checks can't catch. Verifier exceptions
        fail open (keep the audio) so playback is never blocked."""
        if not self._should_verify_content(text):
            return self._pipeline.synthesize_speech(
                text, output_path=str(target)
            )
        returned: Any = None
        for i in range(self._verify_attempts):
            returned = self._pipeline.synthesize_speech(
                text,
                output_path=str(target),
                base_seed=i * _VERIFY_SEED_STEP,
            )
            wav = _resolve_returned_path(returned, target, self._output_dir)
            try:
                if self._content_verifier(wav, text):
                    return returned
            except Exception:  # noqa: BLE001 - never block playback on ASR
                return returned
            logger.info(
                "TTS content-verify: attempt %d/%d mismatch for %r; "
                "re-synthesizing at a new sampling seed.",
                i + 1, self._verify_attempts, text[:20],
            )
        return returned

    def _speak_one_sentence(self, text: str) -> None:
        """Synthesize + play one sentence, applying the same
        ownership / validation / cleanup contract as :meth:`speak`.

        Used by both the legacy ``speak`` path and the streaming
        worker.
        """
        # Normalize digits→Chinese numerals + ensure a trailing terminator
        # here, at the single per-sentence chokepoint every path funnels
        # through, so the synthesised WAV and its debug sidecar both reflect
        # exactly what Token2Wav received.
        text = normalize_for_tts(text)
        requested_target: Optional[Path] = None
        actual: Optional[Path] = None
        try:
            self._output_dir.mkdir(parents=True, exist_ok=True)
            requested_target = (
                self._output_dir / _safe_basename(self._filename_prefix)
            )

            # Phase 1: synthesis (with optional ASR content-verify + seed
            # retry for short CJK replies).
            try:
                returned = self._synthesize_verified(text, requested_target)
            except MiniCPMTTSPlaybackError:
                raise
            except Exception as exc:
                raise MiniCPMTTSPlaybackError(
                    "synthesis failed: "
                    + _basename_only_error(str(exc), requested_target)
                ) from exc

            # Phase 2: resolve actual + ownership gate.
            actual = _resolve_returned_path(
                returned, requested_target, self._output_dir
            )
            if not _is_inside(actual, self._output_dir):
                # The engine refuses to play files it does not own.
                # Keep the basename only — we never reveal where the
                # pipeline routed the file.
                raise MiniCPMTTSPlaybackError(
                    "synthesis returned path outside output dir: "
                    f"{actual.name}"
                )

            # Phase 3: validation gates.
            _validate_wav(actual)
            self._last_wav_basename = actual.name
            # Track every successfully validated WAV so the per-turn
            # diagnostic-capture path can move them into a per-turn
            # folder. Append AFTER validation so failed syntheses
            # don't pollute the list. Cleared on session start.
            self._session_basenames.append(actual.name)
            # Sidecar TXT: write the synthesised text next to the WAV
            # so the operator can compare "what we asked TTS to say"
            # with "what TTS produced" without trawling the server
            # log. Only fires when ``retain_for_debug=True`` since
            # otherwise the WAV is about to be deleted anyway.
            if self._retain_for_debug:
                try:
                    sidecar = actual.with_suffix(".txt")
                    sidecar.write_text(text, encoding="utf-8")
                except OSError:
                    # Best-effort — never fail playback for a debug file.
                    pass

            # Phase 4: playback.
            if self._on_playback_start is not None:
                try:
                    self._on_playback_start()
                except Exception:
                    pass
            try:
                try:
                    self._player.play(actual)
                except MiniCPMTTSPlaybackError:
                    raise
                except Exception as exc:
                    raise MiniCPMTTSPlaybackError(
                        "playback failed: "
                        + _basename_only_error(str(exc), actual)
                    ) from exc
            finally:
                if self._on_playback_end is not None:
                    try:
                        self._on_playback_end()
                    except Exception:
                        pass
        finally:
            if self._cleanup_after_playback and not self._retain_for_debug:
                # Delete every path the engine owns, deduplicated.
                # Outside paths were rejected before this finally; if
                # ``actual`` is still set and outside ``output_dir``,
                # ``_ownership_set`` excludes it automatically.
                for candidate in _ownership_set(
                    requested_target, actual, self._output_dir
                ):
                    try:
                        if candidate.is_file():
                            candidate.unlink()
                    except Exception:
                        pass

    # ------------------------------------------------------------------
    # Sentence-level streaming (Camera Companion live demo)
    # ------------------------------------------------------------------

    def start_streaming_session(self) -> None:
        """Spawn the streaming worker thread.

        Idempotent: a second call while a session is open returns
        without doing anything. The worker stays alive across
        multiple ``enqueue_sentence`` calls until
        :meth:`flush_and_wait` or :meth:`end_streaming_session` is
        called.
        """
        with self._stream_lock:
            if self._stream_worker is not None and self._stream_worker.is_alive():
                logger.info(
                    "tts_engine: start_streaming_session no-op (worker alive)"
                )
                return
            self._stream_queue = queue.Queue()
            self._stream_last_error = None
            self._session_t0 = time.monotonic()
            self._first_play_t = None
            self._last_play_t = None
            self._session_basenames = []
            self._session_enqueued_texts = []
            worker = threading.Thread(
                target=self._stream_loop,
                name="MiniCPMTTSPlaybackEngine.stream",
                daemon=True,
            )
            self._stream_worker = worker
            worker.start()

    def enqueue_sentence(self, text: str) -> None:
        """Hand one sentence to the streaming worker.

        Non-blocking. If no streaming session is open, one is opened
        on demand. The worker synthesizes and plays each sentence in
        FIFO order; subsequent ``enqueue_sentence`` calls return
        immediately while sentence #1 is still being synthesized,
        which is the whole point — first-audio latency drops to
        roughly the cost of one sentence's synthesis.
        """
        if not isinstance(text, str) or not text.strip():
            return
        with self._stream_lock:
            worker_alive = (
                self._stream_worker is not None
                and self._stream_worker.is_alive()
            )
            if not worker_alive:
                # Fall through to start_streaming_session so callers
                # can call enqueue_sentence directly without bracket.
                self._stream_queue = queue.Queue()
                self._stream_last_error = None
                self._session_t0 = time.monotonic()
                self._first_play_t = None
                self._last_play_t = None
                self._session_basenames = []
                self._session_enqueued_texts = []
                worker = threading.Thread(
                    target=self._stream_loop,
                    name="MiniCPMTTSPlaybackEngine.stream",
                    daemon=True,
                )
                self._stream_worker = worker
                worker.start()
            else:
                # Worker is alive. Two distinct cases:
                #
                #  (a) Same turn — token-streaming called
                #      ``start_streaming_session`` ahead of decode,
                #      and this is the first sentence emitted from
                #      the decode callback. The worker came up moments
                #      ago. ``_last_flush_at`` is either None (very
                #      first turn) or significantly older than the
                #      current session's start.
                #
                #  (b) Cross-turn leak — a previous turn's worker
                #      somehow survived ``flush_and_wait``. This is
                #      the real failure mode the WARNING was added
                #      to catch.
                #
                # Heuristic: if ``_last_flush_at`` was set AND the
                # current session started AFTER that flush, the
                # worker is from a fresh session and this is case
                # (a) — log INFO. Otherwise it's case (b) — WARN.
                q = self._stream_queue
                depth = q.qsize() if q is not None else -1
                # Same-turn iff the current session is FRESHER than
                # the most recent flush. Two cases count as "fresher":
                #   - no flush has ever run on this engine (very
                #     first turn — _last_flush_at is None).
                #   - a previous turn flushed, then a fresh session
                #     started AFTER that flush (_session_t0 >
                #     _last_flush_at).
                # Otherwise the worker must have leaked across turns.
                same_turn = self._session_t0 is not None and (
                    self._last_flush_at is None
                    or self._session_t0 > self._last_flush_at
                )
                if same_turn:
                    logger.info(
                        "tts_engine: enqueue while worker alive "
                        "(same-turn token-streaming, queue_depth=%d)",
                        depth,
                    )
                else:
                    logger.warning(
                        "tts_engine: enqueue while worker alive "
                        "(cross-turn leak suspected, queue_depth=%d, "
                        "new=%r)",
                        depth,
                        text[:80],
                    )
            assert self._stream_queue is not None
            self._stream_queue.put(text)
            self._session_enqueued_texts.append(text)
            logger.info(
                "tts_engine: enqueued sentence (n=%d, text=%r)",
                len(self._session_enqueued_texts),
                text[:80],
            )

    def flush_and_wait(self, timeout: Optional[float] = None) -> None:
        """Block until every queued sentence has been synthesized and
        played. Closes the session afterwards.

        Re-raises the worker's last exception so callers can react
        the same way they would to a synchronous :meth:`speak`
        failure. The exception is also recorded in
        ``self._stream_last_error`` for diagnostics.
        """
        with self._stream_lock:
            queue_obj = self._stream_queue
            worker = self._stream_worker
            depth = queue_obj.qsize() if queue_obj is not None else -1
            enq_count = len(self._session_enqueued_texts)

        logger.info(
            "tts_engine: flush_and_wait start (queue_depth=%d, enqueued=%d)",
            depth,
            enq_count,
        )
        if queue_obj is not None:
            queue_obj.put(None)
        if worker is not None and worker.is_alive():
            worker.join(timeout=timeout)

        with self._stream_lock:
            self._stream_queue = None
            self._stream_worker = None
            self._last_flush_at = time.monotonic()
        logger.info("tts_engine: flush_and_wait done")

        if self._stream_last_error is not None:
            err = self._stream_last_error
            self._stream_last_error = None
            raise err

    def end_streaming_session(self) -> None:
        """Alias for :meth:`flush_and_wait` with no timeout."""
        self.flush_and_wait(timeout=None)

    def _stream_loop(self) -> None:
        """Worker thread body: drain the queue until the sentinel.

        Each item is a sentence string. A ``None`` item is the
        sentinel that signals end-of-session. Exceptions are caught
        and stored in ``_stream_last_error`` so the next
        ``flush_and_wait`` can re-raise — we never let an exception
        kill the worker silently.
        """
        q = self._stream_queue
        if q is None:  # pragma: no cover - guarded by callers
            return
        while True:
            try:
                item = q.get()
            except Exception as exc:  # pragma: no cover - defensive
                self._stream_last_error = exc
                return
            if item is None:
                return
            if self._interrupted.is_set():
                # Drop any pending sentences without speaking them.
                continue
            if self._first_play_t is None:
                self._first_play_t = time.monotonic()
            try:
                self._speak_one_sentence(item)
            except BaseException as exc:
                # Record the first error and drain the rest of the
                # queue so the worker can exit cleanly.
                if self._stream_last_error is None:
                    self._stream_last_error = exc
                # Drain pending items without speaking them.
                try:
                    while True:
                        leftover = q.get_nowait()
                        if leftover is None:
                            self._last_play_t = time.monotonic()
                            return
                except queue.Empty:
                    pass
            else:
                # Stamp the moment after the most recent successful
                # play returns. The final value (when the worker is
                # told to exit via sentinel) becomes ``tts_total_ms``.
                self._last_play_t = time.monotonic()

    def pop_session_basenames(self) -> List[str]:
        """Return the WAV basenames synthesized in the current
        streaming session and clear the internal accumulator.

        Used by the per-turn diagnostic-capture path: the runner
        calls ``retain_for_debug=True`` to keep the WAVs on disk
        across the playback worker's cleanup, then reads this list
        after ``flush_and_wait`` and moves each named file into a
        per-turn directory. Empty list when no session ran.
        Idempotent: a second call after read returns ``[]``.
        """
        out = list(self._session_basenames)
        self._session_basenames = []
        return out

    def pop_session_enqueued_texts(self) -> List[str]:
        """Return the sentences handed to ``enqueue_sentence`` during
        the current streaming session and clear the internal list.

        This is the smoking-gun field-debug accessor: it tells the
        caller exactly what text TTS was asked to synthesise, in the
        order it was synthesised. Pair it with ``reply_text`` in the
        response payload to detect "spoken text != displayed text"
        bugs.

        Empty list when no session ran. Idempotent: a second call
        after read returns ``[]``.
        """
        out = list(self._session_enqueued_texts)
        self._session_enqueued_texts = []
        return out

    def pop_session_metrics(self) -> Dict[str, int]:
        """Return per-session TTS timings and clear the internal stamps.

        Keys (only included when stamps are present):
          - ``tts_first_audio_ms``: time from session-start to the
            moment ``_speak_one_sentence`` was first invoked.
          - ``tts_total_ms``: time from session-start to the moment
            the last sentence finished playing.

        Empty dict when no streaming session ran (e.g. the legacy
        one-shot ``speak`` path or token-streaming with no sentences).
        Idempotent: a second call after read returns ``{}``.
        """
        out: Dict[str, int] = {}
        t0 = self._session_t0
        if t0 is not None:
            if self._first_play_t is not None:
                out["tts_first_audio_ms"] = int(
                    (self._first_play_t - t0) * 1000
                )
            if self._last_play_t is not None:
                out["tts_total_ms"] = int(
                    (self._last_play_t - t0) * 1000
                )
        # Clear so the next session starts from zero.
        self._session_t0 = None
        self._first_play_t = None
        self._last_play_t = None
        return out

    def interrupt(self) -> None:
        """Barge-in: drain the streaming queue and stop the player.

        Idempotent. Never raises. Used by the continuous-voice loop
        when the user starts speaking while a TTS reply is mid-play.

        Concretely:
        1. Sets ``self._interrupted`` so the streaming worker drops
           every queued sentence on its next iteration.
        2. Drains the queue down to (and including) the sentinel so
           the worker exits promptly.
        3. Calls ``self._player.stop()`` to abort any in-flight
           ``play()``. The default ``_LocalSoundDeviceWavPlayer.stop``
           is idempotent and safe to call concurrently.
        4. Forgets the queue and worker handle so the next
           ``enqueue_sentence`` opens a fresh session.

        ``flush_and_wait`` after ``interrupt`` is a no-op (no session
        live); the recorded ``_stream_last_error`` is cleared so the
        cancellation does not re-raise into a normal flush call.
        """
        self._interrupted.set()
        with self._stream_lock:
            queue_obj = self._stream_queue
            worker = self._stream_worker
            depth = queue_obj.qsize() if queue_obj is not None else -1
        logger.info("tts_engine: interrupt (queue_depth=%d)", depth)

        if queue_obj is not None:
            # Push a sentinel so the worker wakes up and exits, then
            # drain anything left so memory doesn't accumulate.
            try:
                queue_obj.put_nowait(None)
            except Exception:
                pass
            try:
                while True:
                    leftover = queue_obj.get_nowait()
                    if leftover is None:
                        break
            except queue.Empty:
                pass

        # Tell the player to abort the current playback.
        try:
            self._player.stop()
        except Exception:
            pass

        if worker is not None and worker.is_alive():
            worker.join(timeout=2.0)

        with self._stream_lock:
            self._stream_queue = None
            self._stream_worker = None
            self._stream_last_error = None
        # Reset the flag so the *next* session is not poisoned.
        self._interrupted.clear()

    def stop(self) -> None:
        # Idempotent. Never raises.
        try:
            self._player.stop()
        except Exception:
            pass

    def debug_snapshot(self) -> Dict[str, Any]:
        return {
            "kind": "minicpm_tts_playback",
            "output_dir_basename": self._output_dir.name,
            "last_wav_basename": self._last_wav_basename,
            "cleanup_after_playback": self._cleanup_after_playback,
            "retain_for_debug": self._retain_for_debug,
        }
