# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Enums and request/response/session dataclasses for the Camera Companion.

Stdlib ``dataclasses`` and ``enum`` keep the import surface light. Enums
subclass ``(str, Enum)`` so they round-trip with their snake_case YAML/JSON
values and raise ``ValueError`` on unknown inputs.

Heavy dependencies (cv2, OpenVINO, sounddevice, torch, transformers) must
not be imported from this module.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class CompanionPersona(str, Enum):
    warm = "warm"
    neutral = "neutral"
    concise = "concise"


class SceneQuestionType(str, Enum):
    general = "general"
    objects = "objects"
    people = "people"
    emotion = "emotion"
    interaction = "interaction"
    safety = "safety"
    flashcard = "flashcard"
    flashcard_fr = "flashcard_fr"
    flashcard_ja = "flashcard_ja"
    flashcard_de = "flashcard_de"


class EmotionConfidence(str, Enum):
    unknown = "unknown"
    low = "low"
    medium = "medium"
    high = "high"


@dataclass
class CompanionSessionState:
    session_id: Optional[str] = None
    started_at: Optional[float] = None
    last_question_at: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    active: bool = True
    persona: "CompanionPersona" = CompanionPersona.warm
    turn_count: int = 0
    last_question: Optional[str] = None
    last_answer: Optional[str] = None
    last_scene_summary: Optional[str] = None
    latest_frame_id: Optional[str] = None
    history: List[Dict[str, Any]] = field(default_factory=list)
    stopped_at: Optional[float] = None


@dataclass
class CameraCompanionRequest:
    question_type: SceneQuestionType
    session_id: Optional[str] = None
    text_question: Optional[str] = None
    audio_path: Optional[str] = None
    image_path: Optional[str] = None
    persona: CompanionPersona = CompanionPersona.warm
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SceneUnderstanding:
    description: str
    objects: List[str] = field(default_factory=list)
    people_count: Optional[int] = None
    apparent_emotion: Optional[str] = None
    emotion_confidence: EmotionConfidence = EmotionConfidence.unknown
    safety_notes: List[str] = field(default_factory=list)


@dataclass
class CameraCompanionResponse:
    session_id: Optional[str]
    question_type: SceneQuestionType
    reply_text: str
    scene: Optional[SceneUnderstanding] = None
    should_play_tts: bool = False
    debug: Dict[str, Any] = field(default_factory=dict)
    suggested_interaction: Optional[str] = None
