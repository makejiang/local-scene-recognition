# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""OpenVINO-backed wrapper around the Silero VAD v3.1 ONNX model.

Silero ships an ONNX file (``silero_vad.onnx``, ~780 KB, MIT-licensed)
that takes a 16 kHz mono float32 frame of exactly 256 or 512 samples
along with split LSTM hidden / cell tensors (``h0`` / ``c0``, each
``[2, 1, 64]``) and returns a 2-class probability ``[non_speech,
speech]`` plus the next ``hn`` / ``cn``.

This module is a thin OpenVINO wrapper:

- ``model_path`` points at the v3.1 ONNX on disk. Newer Silero
  releases (v4 stateful, v5+ dynamic-rank) are NOT supported — they
  use different input names and either change semantics or fail to
  convert under older OpenVINO ONNX frontends. The adapter introspects
  the loaded model and raises ``RuntimeError`` with an install hint
  when the inputs don't match the v3.1 layout.
- It is read with ``core.read_model(...)`` and compiled lazily on
  first call.
- The adapter retains the LSTM state between calls (``self._h``,
  ``self._c``) and threads it back into every inference.
  ``reset()`` zeros both.
- The ``core`` argument is injectable so tests pass a fake. Production
  callers can use the default OpenVINO ``Core`` constructed lazily.

This module imports ``openvino`` and ``numpy`` lazily inside
``_ensure_loaded`` so the rest of the package can ``import`` it on
machines without OpenVINO present (the live demo's mock branch).

We standardize on **512 samples per chunk = 32 ms at 16 kHz**. The
``ContinuousAudioCapture`` and ``VADTurnTaker`` modules emit / expect
this exact size. Anything else raises ``ValueError``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional, Sequence, Union

__all__ = ["SileroVADAdapter", "SILERO_CHUNK_SAMPLES", "SILERO_SAMPLE_RATE"]

PathLike = Union[str, Path]

SILERO_SAMPLE_RATE: int = 16000
SILERO_CHUNK_SAMPLES: int = 512  # 32 ms at 16 kHz
_SILERO_VALID_CHUNK_SIZES = (256, 512)


def _default_core_factory() -> Any:
    """Lazy-import OpenVINO and return a fresh ``Core``."""
    import openvino  # type: ignore
    return openvino.Core()


class SileroVADAdapter:
    """OpenVINO-backed Silero VAD adapter.

    Parameters
    ----------
    model_path:
        Path to ``silero_vad.onnx`` on disk.
    core:
        Optional injected OpenVINO ``Core`` (or a fake exposing
        ``read_model`` / ``compile_model``). When ``None``, a real
        OpenVINO core is constructed lazily on first call.
    device:
        OpenVINO device for ``compile_model``. Defaults to ``"CPU"`` —
        the model is tiny (~1.5 MB) and CPU latency is well under a
        millisecond per frame.
    """

    def __init__(
        self,
        model_path: PathLike,
        *,
        core: Optional[Any] = None,
        device: str = "CPU",
    ) -> None:
        self._model_path = Path(model_path)
        self._core = core
        self._device = str(device)
        self._compiled: Any = None
        # Split LSTM state for the v3.1 ONNX. Both shaped (2, 1, 64).
        self._h: Any = None
        self._c: Any = None
        self._np: Any = None     # numpy module, lazy-loaded.
        # Compatibility flag: True iff the loaded model's input set
        # matches v3.1 (input/h0/c0). Set during ``_ensure_loaded``;
        # the test fakes leave this on the v3.1 path.
        self._is_v31: bool = True

    def _ensure_loaded(self) -> None:
        if self._compiled is not None:
            return
        if not self._model_path.is_file():
            raise FileNotFoundError(
                f"Silero VAD model not found at {self._model_path.name}; "
                "install it manually (see docs/camera_companion_live_demo.md)."
            )

        import numpy  # type: ignore
        self._np = numpy

        if self._core is None:
            self._core = _default_core_factory()

        try:
            model = self._core.read_model(str(self._model_path))
            self._compiled = self._core.compile_model(model, self._device)
        except Exception as exc:  # noqa: BLE001
            # Silero v5+ ONNX uses dynamic-rank Conv / ReduceMean ops that
            # older OpenVINO ONNX frontends can't convert. Re-raise with a
            # clear hint so the user installs v3.1 instead of seeing an
            # opaque per-frame conversion error spam.
            raise RuntimeError(
                "Silero VAD ONNX failed to load via OpenVINO. The most "
                "common cause is a Silero v5+ ONNX file: it uses dynamic-"
                "rank ops the OpenVINO ONNX frontend on this machine can't "
                "convert. Install the v3.1 ONNX (~780 KB) instead — see "
                "docs/camera_companion_live_demo.md for the curl command. "
                f"Underlying error: {exc.__class__.__name__}"
            ) from exc

        # Validate the model is the v3.1 layout we support. Real
        # OpenVINO models expose ``inputs`` (a list of ConstOutput
        # objects with ``.get_any_name()``); our test fakes don't, so
        # we skip introspection when those methods aren't available.
        inputs_attr = getattr(self._compiled, "inputs", None)
        if inputs_attr is not None:
            try:
                names = {p.get_any_name() for p in inputs_attr}
            except Exception:  # noqa: BLE001 - test fakes / odd backends
                names = None
            if names is not None and names and "h0" not in names:
                raise RuntimeError(
                    "Silero VAD ONNX has unexpected input layout: "
                    f"{sorted(names)}. The v3.1 ONNX exposes "
                    "{'input', 'h0', 'c0'}; v4 / v5 layouts (with 'sr' "
                    "or a combined 'state') are not supported. Install "
                    "the v3.1 ONNX — see docs/camera_companion_live_demo.md."
                )
        self._h, self._c = self._zero_state()

    def _zero_state(self) -> Any:
        # Silero v3.1 ONNX takes split LSTM tensors h0 / c0, each of
        # shape (2, 1, 64). Returns ``(h, c)`` as float32 zeros.
        zeros = self._np.zeros((2, 1, 64), dtype=self._np.float32)
        return zeros.copy(), zeros.copy()

    def reset(self) -> None:
        """Zero the LSTM state. Call between unrelated utterances."""
        if self._np is not None:
            self._h, self._c = self._zero_state()
        else:
            # Reset before first load: defer to next ensure_loaded.
            self._h = None
            self._c = None

    def process_chunk(self, samples: Sequence[float]) -> float:
        """Run one VAD inference over a 512-sample float32 chunk.

        Returns the speech-probability scalar in [0.0, 1.0].
        """
        n = len(samples) if hasattr(samples, "__len__") else 0
        if n not in _SILERO_VALID_CHUNK_SIZES:
            raise ValueError(
                f"Silero VAD requires a chunk of 256 or 512 samples; "
                f"got {n}."
            )

        self._ensure_loaded()

        np = self._np
        # Build the model inputs. Names match the Silero v3.1 ONNX
        # signature: ``input``, ``h0``, ``c0``.
        if hasattr(samples, "dtype"):
            audio = samples.astype(np.float32, copy=False)  # type: ignore[union-attr]
            audio = audio.reshape(1, -1)
        else:
            audio = np.asarray(samples, dtype=np.float32).reshape(1, -1)

        inputs = {
            "input": audio,
            "h0": self._h,
            "c0": self._c,
        }

        outputs = self._compiled(inputs)
        # Output names: ``output`` (shape [1, 2, 1] = [non-speech, speech]),
        # ``hn``, ``cn``.
        prob_arr = outputs["output"]
        # Carry state forward.
        self._h = outputs.get("hn", self._h)
        self._c = outputs.get("cn", self._c)

        # Extract the speech probability. Real OV returns shape
        # (1, 2, 1); index [0, 1, 0]. Test fakes return a scalar
        # ``[[prob]]`` for back-compat with the original v4-shaped
        # mocks, so fall back to the legacy [0][0] indexing first.
        try:
            prob = float(prob_arr[0][0])
            # If the array is 3-D and the [0][0] read gave us the
            # non-speech prob, take the speech index instead.
            arr_shape = getattr(prob_arr, "shape", None)
            if arr_shape is not None and len(arr_shape) == 3 and arr_shape[1] == 2:
                prob = float(prob_arr[0][1][0])
        except (TypeError, IndexError):
            # Defensive: some OV versions return numpy scalars directly.
            prob = float(np.asarray(prob_arr).reshape(-1)[-1])

        # Clamp prob defensively.
        if prob < 0.0:
            prob = 0.0
        elif prob > 1.0:
            prob = 1.0
        return prob
