# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Optional visible camera preview window for the Camera Companion live demo.

This module wraps an existing :class:`CameraPreviewController` and
displays its latest captured frame in a real OS-level window using
``cv2.imshow`` / ``cv2.waitKey``.

The window is **opt-in**: nothing in the Camera Companion runs this
class unless the user passes ``--show-preview`` on the live demo CLI.
``cv2`` is imported only inside :meth:`CameraPreviewWindow.start`, so
the module itself is safe to import on machines without OpenCV and
on the hermetic CI matrix.

Threading model
---------------

OpenCV's HighGUI uses the OS-native window system, which on Windows
**requires the GUI to run on the same thread that called
``namedWindow``** — and that thread must service ``waitKey`` regularly
or the window stays unpainted (a white rectangle). Our live demo's
main loop blocks on ``input()`` between turns, so the main thread is
not always available to pump the GUI.

To handle both worlds, ``CameraPreviewWindow`` supports two modes:

- ``mode="threaded"`` (default for non-Windows / tests) — spawns a
  background daemon thread that polls ``read_latest_frame()`` and
  calls ``imshow`` / ``waitKey`` on its own. Works on Linux/macOS
  where Win32 thread-affinity rules don't apply.
- ``mode="manual"`` (default on Windows) — does NOT spawn a thread.
  The caller pumps :meth:`pump` from the same thread that called
  :meth:`start`. The live demo's ``run_loop`` calls ``pump()`` in
  short bursts between user prompts, including a continuous burst
  while a voice recording is in progress so the preview stays live.

If ``mode="auto"`` (the default), the class picks ``"manual"`` on
Windows and ``"threaded"`` elsewhere.

Hermetic-test friendly: tests inject a fake ``cv2`` module via
``sys.modules`` to assert that ``imshow`` / ``waitKey`` /
``destroyWindow`` are called the right number of times without
touching real graphics hardware.
"""

from __future__ import annotations

import logging
import platform
import queue
import sys
import threading
import time
from typing import Any, NamedTuple, Optional, Tuple

logger = logging.getLogger(__name__)

__all__ = ["BannerSnapshot", "BannerState", "CameraPreviewWindow"]


_VALID_MODES = ("auto", "manual", "threaded")


# cv2.waitKey return values for the two keys the live demo cares
# about. Some cv2 builds set high bits on Windows; we mask with
# ``& 0xFF`` before comparing. Enter arrives as \r (13) on Windows
# and \n (10) on some Linux builds.
_CV2_KEY_ENTER_CODES = (13, 10)
_CV2_KEY_ESCAPE_CODES = (27,)
_CV2_KEY_NAME_ENTER = "enter"
_CV2_KEY_NAME_ESCAPE = "escape"


# ---------------------------------------------------------------------------
# Banner state (live-demo status overlay)
# ---------------------------------------------------------------------------


# OpenCV consumes BGR triples (the preview window converts the controller's
# RGB frames to BGR before imshow). Banner colors are stored BGR for the
# same reason — the PIL renderer in ``preview_banner`` handles the swap to
# RGB internally.
_LOADING_BG_BGR: Tuple[int, int, int] = (0, 255, 255)    # yellow
_LOADING_FG_BGR: Tuple[int, int, int] = (0, 0, 0)        # black
_READY_BG_BGR: Tuple[int, int, int] = (0, 200, 0)        # green
_READY_FG_BGR: Tuple[int, int, int] = (0, 0, 0)
_LISTENING_BG_BGR: Tuple[int, int, int] = (0, 0, 220)    # red
_LISTENING_FG_BGR: Tuple[int, int, int] = (255, 255, 255)
_ANSWERING_BG_BGR: Tuple[int, int, int] = (220, 128, 0)  # blue
_ANSWERING_FG_BGR: Tuple[int, int, int] = (0, 0, 0)
# PROCESSING uses the same yellow/black palette as LOADING by design —
# the two contexts never overlap (LOADING runs only at startup before
# the user presses Enter; PROCESSING runs only mid-session between VAD
# end_of_speech and TTS playback start). Sharing the palette is the
# user-requested spec.
_PROCESSING_BG_BGR: Tuple[int, int, int] = (0, 255, 255)  # yellow
_PROCESSING_FG_BGR: Tuple[int, int, int] = (0, 0, 0)      # black

_TEXT_LOADING = "启动中..."
_TEXT_READY = "启动完成，按Enter键开始"
_TEXT_LISTENING = "请说话"
_TEXT_ANSWERING = "正在回答"
_TEXT_PROCESSING = "正在处理"


class BannerSnapshot(NamedTuple):
    """Immutable view of the banner state used by the preview pump loop."""

    kind: str
    text: Optional[str]
    bg_color: Optional[Tuple[int, int, int]]
    fg_color: Optional[Tuple[int, int, int]]
    idle_prompt: Optional[str]


class BannerState:
    """Thread-safe holder for the preview window's status overlay.

    Two slots:
    - **top-center state slot** — one of ``loading`` / ``ready`` /
      ``listening`` / ``processing`` / ``answering`` (or ``none``).
      Mutated by lifecycle and runtime events (model load, VAD
      start/end, TTS start/end).
    - **bottom-left idle prompt slot** — persistent help text set once
      at session start and cleared at session end.

    The state class does not police transitions. Mutual exclusion
    between ``listening`` / ``processing`` / ``answering`` is enforced
    by the live-demo wiring (post-utterance VAD gate + TTS callbacks).

    Readers call :meth:`snapshot` to get an immutable namedtuple; the
    pump loop never holds the internal lock while drawing.
    """

    def __init__(self) -> None:
        self._kind: str = "none"
        self._text: Optional[str] = None
        self._bg_color: Optional[Tuple[int, int, int]] = None
        self._fg_color: Optional[Tuple[int, int, int]] = None
        self._idle_prompt: Optional[str] = None
        self._lock = threading.Lock()

    def set_loading(self) -> None:
        with self._lock:
            self._kind = "loading"
            self._text = _TEXT_LOADING
            self._bg_color = _LOADING_BG_BGR
            self._fg_color = _LOADING_FG_BGR

    def set_ready(self) -> None:
        with self._lock:
            self._kind = "ready"
            self._text = _TEXT_READY
            self._bg_color = _READY_BG_BGR
            self._fg_color = _READY_FG_BGR

    def set_listening(self) -> None:
        with self._lock:
            self._kind = "listening"
            self._text = _TEXT_LISTENING
            self._bg_color = _LISTENING_BG_BGR
            self._fg_color = _LISTENING_FG_BGR

    def set_answering(self) -> None:
        with self._lock:
            self._kind = "answering"
            self._text = _TEXT_ANSWERING
            self._bg_color = _ANSWERING_BG_BGR
            self._fg_color = _ANSWERING_FG_BGR

    def set_processing(self) -> None:
        """Yellow ``正在处理`` banner shown between VAD end_of_speech
        and TTS playback start. The blue ``set_answering`` banner
        cleanly overwrites this when TTS begins; the live-demo
        ``on_event`` finally-block defensively calls ``clear_state``
        too so the banner doesn't stick when TTS is disabled."""
        with self._lock:
            self._kind = "processing"
            self._text = _TEXT_PROCESSING
            self._bg_color = _PROCESSING_BG_BGR
            self._fg_color = _PROCESSING_FG_BGR

    def clear_state(self) -> None:
        """Reset the top-center slot; leave the idle prompt untouched."""
        with self._lock:
            self._kind = "none"
            self._text = None
            self._bg_color = None
            self._fg_color = None

    def set_idle_prompt(self, text: str) -> None:
        with self._lock:
            self._idle_prompt = str(text) if text else None

    def clear_idle_prompt(self) -> None:
        with self._lock:
            self._idle_prompt = None

    def snapshot(self) -> BannerSnapshot:
        with self._lock:
            return BannerSnapshot(
                kind=self._kind,
                text=self._text,
                bg_color=self._bg_color,
                fg_color=self._fg_color,
                idle_prompt=self._idle_prompt,
            )


def _resolve_mode(mode: str) -> str:
    """Map ``"auto"`` to a concrete mode based on the platform.

    Both Windows and non-Windows default to ``"threaded"`` — but the
    worker thread calls ``namedWindow``, ``imshow``, and ``waitKey``
    all on its own thread. cv2's HighGUI requires that the same
    thread own the entire window lifecycle; cross-thread access
    leaves the window unpainted on Windows.
    """
    normalized = (mode or "auto").strip().lower()
    if normalized not in _VALID_MODES:
        raise ValueError(
            f"unknown CameraPreviewWindow mode {mode!r}; expected one of "
            f"{list(_VALID_MODES)}"
        )
    if normalized != "auto":
        return normalized
    return "threaded"


class CameraPreviewWindow:
    """Visible cv2-backed preview window over a CameraPreviewController.

    Lifecycle:

    - :meth:`start` lazy-imports ``cv2`` and creates the window via
      :func:`cv2.namedWindow`. In threaded mode it also spawns a
      background daemon thread; in manual mode the caller is
      responsible for calling :meth:`pump` periodically.
    - :meth:`pump` (manual mode only — a no-op in threaded mode)
      reads the latest frame, calls ``imshow`` and ``waitKey``, and
      returns. Optionally accepts a ``duration_seconds`` argument to
      pump in a tight loop until the duration elapses (useful while
      a voice recording is in progress).
    - :meth:`stop` signals any worker thread to exit, joins it, and
      calls :func:`cv2.destroyWindow`. Idempotent. Never raises.

    Failure handling:

    - If ``cv2`` is not importable, :meth:`start` returns ``False``
      (with ``last_error`` set) and the live demo continues without
      a visible window.
    - Single ``imshow`` / ``waitKey`` exceptions are recorded in
      ``last_error`` and the loop survives until
      ``max_consecutive_errors`` is exceeded or :meth:`stop` is
      called.
    """

    DEFAULT_WINDOW_NAME = "Camera Companion preview"

    def __init__(
        self,
        controller: Any,
        *,
        window_name: str = DEFAULT_WINDOW_NAME,
        refresh_interval_seconds: float = 0.05,
        max_consecutive_errors: int = 5,
        mode: str = "auto",
        banner_state: Optional["BannerState"] = None,
        placeholder_frame: Optional[Any] = None,
    ) -> None:
        if controller is None:
            raise ValueError(
                "CameraPreviewWindow requires a CameraPreviewController-like "
                "object that exposes read_latest_frame()."
            )
        self._controller = controller
        self._window_name = str(window_name) or self.DEFAULT_WINDOW_NAME
        self._refresh_interval = max(0.01, float(refresh_interval_seconds))
        self._max_consecutive_errors = max(1, int(max_consecutive_errors))
        self._mode = _resolve_mode(mode)

        self._cv2: Any = None
        self._stop_event: Optional[threading.Event] = None
        self._thread: Optional[threading.Thread] = None
        self._running: bool = False
        self._window_created: bool = False
        self._consecutive_errors: int = 0
        self.last_error: Optional[str] = None

        # Live-demo overlay state. ``banner_state`` is caller-owned when
        # supplied so the live demo can mutate the same instance it
        # already wired into VAD / TTS callbacks.
        self._banner: BannerState = banner_state or BannerState()
        # Atomic reference: set / read without a lock. Used when the
        # frame controller has nothing to show yet (e.g. while the
        # model is loading and the camera is not open).
        self._placeholder_frame: Optional[Any] = placeholder_frame
        # Bounded queue of recognised keys (Enter / ESC) captured from
        # the cv2 window's waitKey. The cv2 display thread writes via
        # ``_record_key``; consumers (live-demo key-wait sites) read
        # via ``pop_key``. Bounded so a stuck consumer can't eat
        # memory — overflow drops silently.
        self._key_queue: "queue.Queue[str]" = queue.Queue(maxsize=16)
        # Separate non-consuming signal that ESC was captured. The
        # global ESC watcher waits on this event INSTEAD of consuming
        # the queue, so per-turn key-wait sites (arm prompt, press-
        # Enter-to-stop) still see every Enter the operator pressed.
        # ESC also remains in ``_key_queue`` for waiters that want to
        # observe it directly via ``pop_key``.
        self._escape_event: threading.Event = threading.Event()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    @property
    def mode(self) -> str:
        """Resolved mode after constructor (``"manual"`` or ``"threaded"``)."""
        return self._mode

    def start(self) -> bool:
        """Open the preview window.

        - In ``"manual"`` mode this calls ``namedWindow`` on the
          *current* thread; the caller must subsequently invoke
          :meth:`pump` from the same thread.
        - In ``"threaded"`` mode the actual ``namedWindow`` /
          ``imshow`` / ``waitKey`` calls all run on a dedicated
          worker thread (cv2 HighGUI requires single-thread
          ownership of a window's lifecycle on Windows).

        Returns ``True`` iff the window setup is initiated. The
        threaded path returns ``True`` immediately while the worker
        is still starting up; if the worker fails to import cv2 or
        create the window, ``last_error`` is populated and the
        caller can poll :meth:`is_running`.
        """
        if self._running:
            return True
        self._consecutive_errors = 0
        self._running = True

        if self._mode == "threaded":
            self._stop_event = threading.Event()
            self._thread = threading.Thread(
                target=self._display_loop,
                name="CameraPreviewWindow",
                daemon=True,
            )
            self._thread.start()
            return True

        # Manual mode: import + namedWindow on the caller thread.
        cv2_module = self._import_cv2()
        if cv2_module is None:
            self._running = False
            return False
        self._cv2 = cv2_module
        try:
            flag = getattr(cv2_module, "WINDOW_AUTOSIZE", 1)
            cv2_module.namedWindow(self._window_name, flag)
        except Exception as exc:  # pragma: no cover - defensive
            self.last_error = (
                f"namedWindow failed: {exc.__class__.__name__}: {exc}"
            )
            logger.warning(
                "CameraPreviewWindow.namedWindow failed: %s. Skipping "
                "visible preview.",
                exc,
            )
            self._cv2 = None
            self._running = False
            return False
        self._window_created = True
        return True

    def pump(self, duration_seconds: float = 0.0) -> None:
        """Pump one (or many) imshow + waitKey iterations.

        No-op in threaded mode. In manual mode:

        - ``duration_seconds <= 0``: a single iteration (one
          ``imshow`` + ``waitKey``).
        - ``duration_seconds > 0``: pump in a tight loop until the
          deadline expires or :meth:`stop` is called. The live demo
          calls this with a duration roughly equal to the voice
          ``--record-seconds`` so the preview stays live during
          recording.

        Always safe to call before :meth:`start` (no-op if the
        window was never created).
        """
        if self._mode != "manual":
            return
        if not self._running or self._cv2 is None:
            return

        if duration_seconds <= 0:
            self._pump_once()
            return

        deadline = time.monotonic() + float(duration_seconds)
        while self._running and time.monotonic() < deadline:
            self._pump_once()
            # Cooperative sleep so we don't burn the CPU. Subtract
            # the time imshow already took.
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            time.sleep(min(self._refresh_interval, remaining))

    def stop(self) -> None:
        """Signal the display thread (if any), join it, and ensure
        the window is destroyed.

        Idempotent. Never raises.

        In threaded mode the worker thread owns ``destroyWindow`` —
        this method just signals + joins. In manual mode this method
        calls ``destroyWindow`` directly on the caller's thread.
        """
        stop_event = self._stop_event
        thread = self._thread
        was_running = self._running
        manual_cv2 = self._cv2 if self._mode == "manual" else None
        manual_window_created = (
            self._window_created if self._mode == "manual" else False
        )

        self._stop_event = None
        self._thread = None
        self._running = False

        if stop_event is not None:
            stop_event.set()
        if thread is not None and thread.is_alive():
            thread.join(timeout=2.0)

        if self._mode == "manual":
            self._window_created = False
            if manual_cv2 is not None and manual_window_created:
                try:
                    manual_cv2.destroyWindow(self._window_name)
                except Exception as exc:  # pragma: no cover - defensive
                    logger.debug(
                        "CameraPreviewWindow.destroyWindow raised: %s", exc
                    )
                try:
                    manual_cv2.waitKey(1)
                except Exception:  # pragma: no cover - defensive
                    pass
            self._cv2 = None
        # In threaded mode, ``_display_loop`` already cleared
        # ``_window_created`` and ``_cv2`` in its finally block.

    def is_running(self) -> bool:
        return self._running

    # ------------------------------------------------------------------
    # Live-demo overlay surface
    # ------------------------------------------------------------------

    @property
    def banner(self) -> "BannerState":
        """Mutable banner state for the live-demo overlay."""
        return self._banner

    def set_placeholder_frame(self, frame: Optional[Any]) -> None:
        """Replace the BGR frame shown when the controller has nothing.

        Atomic reference assignment — readable from the pump worker
        without coordination.
        """
        self._placeholder_frame = frame

    def set_controller(self, controller: Any) -> None:
        """Swap the live frame source.

        Used by the live demo to hand the early window (constructed
        with a null controller) the real preview controller after the
        user presses Enter at the startup gate. Atomic reference swap;
        readable from the pump worker without coordination.
        """
        if controller is None:
            raise ValueError(
                "set_controller requires a CameraPreviewController-like "
                "object that exposes read_latest_frame()."
            )
        self._controller = controller

    # ------------------------------------------------------------------
    # Cv2 keyboard bridge (live-demo Enter / ESC capture)
    # ------------------------------------------------------------------

    def pop_key(self, timeout: float = 0.0) -> Optional[str]:
        """Return one of ``{"enter","escape"}`` if the cv2 window has
        delivered such a key since the last call, otherwise ``None``.

        cv2.waitKey only captures keys when the named window has OS
        focus, and only on the thread that owns the window. The
        threaded display loop captures every Enter / ESC via
        ``_record_key``; this method is the consumer side.

        ``timeout`` (seconds) controls how long the call blocks while
        waiting for a key. ``0.0`` (default) is non-blocking. Safe to
        call from any thread; safe to call before :meth:`start`
        (returns ``None`` because the queue is empty).
        """
        try:
            return self._key_queue.get(
                timeout=max(0.0, float(timeout))
            )
        except queue.Empty:
            return None

    def drain_keys(self) -> None:
        """Discard every pending Enter / ESC event AND reset the
        escape signal.

        Callers invoke this before entering a fresh key-wait so a
        stale press from the previous turn does not auto-fire the
        next prompt (e.g., the operator pressed Enter twice at the
        startup gate; the second press must not immediately stop
        the first voice recording).
        """
        while True:
            try:
                self._key_queue.get_nowait()
            except queue.Empty:
                break
        self._escape_event.clear()

    def wait_for_escape(self, timeout: float = 0.1) -> bool:
        """Non-consuming wait for an ESC captured from the cv2 window.

        Returns ``True`` if the escape event fires within ``timeout``,
        ``False`` on timeout. The companion queue is left untouched
        so per-turn key-wait sites (arm prompt, press-Enter-to-stop)
        still observe every Enter / ESC via :meth:`pop_key`. Used by
        the live demo's global ESC-quit watcher.
        """
        return self._escape_event.wait(
            timeout=max(0.0, float(timeout))
        )

    def escape_pressed(self) -> bool:
        """Return ``True`` if the cv2 window has captured an ESC at
        any point since the last :meth:`drain_keys`. Non-blocking
        complement to :meth:`wait_for_escape`."""
        return self._escape_event.is_set()

    def _record_key(self, code: int) -> None:
        """Map a raw ``cv2.waitKey`` return into ``enter`` / ``escape``
        and push it onto the queue. Unrecognised keys (and the no-key
        sentinel ``-1``) are ignored. The high bits some cv2 builds
        set are masked off first.

        ESC additionally fires the non-consuming ``_escape_event`` so
        the global watcher can observe it without draining the queue
        out from under per-turn key-wait sites.
        """
        if code is None or int(code) < 0:
            return
        masked = int(code) & 0xFF
        if masked in _CV2_KEY_ENTER_CODES:
            name = _CV2_KEY_NAME_ENTER
        elif masked in _CV2_KEY_ESCAPE_CODES:
            name = _CV2_KEY_NAME_ESCAPE
        else:
            return
        try:
            self._key_queue.put_nowait(name)
        except queue.Full:
            # Drop silently — consumers re-poll on a 50 ms tick, so
            # a stuck consumer would just lose a press, not crash.
            pass
        if name == _CV2_KEY_NAME_ESCAPE:
            self._escape_event.set()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _pump_once(self) -> None:
        """Single imshow + waitKey iteration. Used by both manual
        ``pump()`` and the threaded display loop."""
        cv2_module = self._cv2
        if cv2_module is None:
            return

        try:
            frame = self._controller.read_latest_frame()
        except Exception as exc:
            self._record_error(
                f"read_latest_frame raised: "
                f"{exc.__class__.__name__}: {exc}"
            )
            return

        placeholder = self._placeholder_frame
        if frame is None and placeholder is None:
            # Controller hasn't produced a frame yet AND no placeholder
            # is configured. Still pump waitKey so the window stays
            # responsive; do NOT count this as an error. Capture the
            # return value so Enter / ESC pressed in the cv2 window
            # before the first frame arrives still register.
            try:
                self._record_key(cv2_module.waitKey(1))
            except Exception:  # pragma: no cover - defensive
                pass
            return

        try:
            if frame is None:
                # Placeholder is already BGR — used by the live demo
                # to show a black surface while the model loads.
                display_frame = placeholder
            else:
                # Frames arrive as RGB (the controller's source converts
                # BGR→RGB so PIL save and model encoders see correct
                # colors); imshow expects BGR, so convert back here.
                from .camera_preview import _rgb_to_bgr

                display_frame = _rgb_to_bgr(frame)

            snapshot = self._banner.snapshot()
            if snapshot.kind != "none" or snapshot.idle_prompt is not None:
                # Lazy import keeps PIL+numpy off the hot pump path
                # when no banner is active. ``sys.modules`` caches the
                # second hit.
                from .preview_banner import draw_banners

                display_frame = draw_banners(display_frame, snapshot)

            cv2_module.imshow(self._window_name, display_frame)
            # waitKey gives the OS message pump a chance to actually
            # paint the window. ~30ms keeps the GUI responsive without
            # burning CPU. Capture the return value so Enter / ESC
            # pressed while the cv2 window has OS focus reach the
            # live-demo's key-wait sites via ``pop_key``.
            self._record_key(cv2_module.waitKey(1))
            self._consecutive_errors = 0
            self.last_error = None
        except Exception as exc:
            self._record_error(
                f"imshow raised: {exc.__class__.__name__}: {exc}"
            )

    def _record_error(self, message: str) -> None:
        self.last_error = message
        self._consecutive_errors += 1
        if self._consecutive_errors > self._max_consecutive_errors:
            self._running = False

    def _display_loop(self) -> None:
        """Threaded-mode display loop.

        cv2 HighGUI requires the same thread to own a window's
        ``namedWindow`` / ``imshow`` / ``waitKey`` / ``destroyWindow``
        lifecycle. So this worker imports cv2, creates the window,
        runs the polling loop, and destroys the window — all without
        the main thread ever touching cv2 GUI state.
        """
        stop_event = self._stop_event
        if stop_event is None:  # pragma: no cover - guarded by start()
            return

        cv2_module = self._import_cv2()
        if cv2_module is None:
            self._running = False
            return
        self._cv2 = cv2_module
        try:
            flag = getattr(cv2_module, "WINDOW_AUTOSIZE", 1)
            cv2_module.namedWindow(self._window_name, flag)
        except Exception as exc:
            self.last_error = (
                f"namedWindow failed: {exc.__class__.__name__}: {exc}"
            )
            logger.warning(
                "CameraPreviewWindow worker namedWindow failed: %s. "
                "Skipping visible preview.",
                exc,
            )
            self._cv2 = None
            self._running = False
            return
        self._window_created = True

        interval = self._refresh_interval
        try:
            while not stop_event.is_set():
                if stop_event.wait(timeout=interval):
                    break
                if not self._running:
                    break
                self._pump_once()
        finally:
            # Destroy the window from the same thread that owns it.
            if self._window_created and self._cv2 is not None:
                try:
                    self._cv2.destroyWindow(self._window_name)
                except Exception as exc:
                    logger.debug(
                        "CameraPreviewWindow worker destroyWindow "
                        "raised: %s",
                        exc,
                    )
                try:
                    self._cv2.waitKey(1)
                except Exception:
                    pass
            self._window_created = False

    def _import_cv2(self) -> Any:
        """Resolve ``cv2`` lazily.

        Tests inject a fake module via ``sys.modules['cv2']`` so this
        path is exercised without real OpenCV. We always go through
        ``sys.modules`` first so the injection is honored, then fall
        back to a real import.
        """
        injected = sys.modules.get("cv2")
        if injected is not None:
            return injected
        try:
            import cv2  # type: ignore
        except ImportError as exc:
            self.last_error = (
                "Visible camera preview requires the optional "
                "'opencv-python' package (cv2). Install it with "
                "`pip install opencv-python`."
            )
            logger.warning(
                "CameraPreviewWindow.start: cv2 not available (%s). "
                "Continuing without a visible preview window.",
                exc,
            )
            return None
        return cv2
