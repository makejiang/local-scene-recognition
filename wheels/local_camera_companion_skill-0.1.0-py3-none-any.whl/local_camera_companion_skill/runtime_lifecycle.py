# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Reusable real-pipeline lifecycle helper for Camera Companion runners.

The helper duck-types the pipeline. It supports three categories:

- Real adapters that expose ``load()``, ``unload()``, ``is_loaded()`` —
  fully managed.
- Pre-loaded pipelines (``is_loaded()`` returns ``True``) — never
  loaded or unloaded by the helper.
- Mocks / fakes without lifecycle methods — treated as already loaded;
  ``ensure_loaded`` and ``release`` are no-ops.

The helper records ownership: if the runner triggered ``load()``, the
runner also performs ``unload()`` on ``release()``. If a caller passed
in an already-loaded pipeline, the helper leaves it alone.

Heavy dependencies (``openvino``, ``cv2``, ``torch``, ``transformers``)
must NOT be imported by this module. The helper only uses stdlib.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from .privacy import sanitize_message


__all__ = ["LifecycleResult", "RuntimeLifecycle"]


@dataclass
class LifecycleResult:
    """Outcome of one ``ensure_loaded()`` call."""

    ok: bool
    stage: str  # "skipped" | "already_loaded" | "loaded" | "load_failed"
    reason: Optional[str] = None
    detail: Optional[str] = None


class RuntimeLifecycle:
    """Manages ``load`` / ``unload`` for a duck-typed pipeline."""

    def __init__(
        self,
        pipeline: Any,
        *,
        model_dir: Optional[str] = None,
    ) -> None:
        self._pipeline = pipeline
        self._model_dir = str(model_dir) if model_dir else None
        self._owns_load: bool = False
        self._loaded_event: Optional[LifecycleResult] = None

    @property
    def pipeline(self) -> Any:
        return self._pipeline

    def is_loaded(self) -> bool:
        fn = getattr(self._pipeline, "is_loaded", None)
        if callable(fn):
            try:
                return bool(fn())
            except Exception:
                return False
        return True

    def ensure_loaded(self) -> LifecycleResult:
        """Idempotent. Loads the pipeline if it has a ``load()`` method
        and is not already loaded. Records ownership."""

        if self._loaded_event is not None and self._loaded_event.ok:
            return self._loaded_event

        load_fn = getattr(self._pipeline, "load", None)
        is_loaded_fn = getattr(self._pipeline, "is_loaded", None)

        if not callable(load_fn):
            self._loaded_event = LifecycleResult(ok=True, stage="skipped")
            return self._loaded_event

        already = False
        if callable(is_loaded_fn):
            try:
                already = bool(is_loaded_fn())
            except Exception:
                already = False

        if already:
            self._loaded_event = LifecycleResult(
                ok=True, stage="already_loaded"
            )
            self._owns_load = False
            return self._loaded_event

        try:
            load_fn()
        except Exception as exc:
            detail = _sanitize_error_for_logging(str(exc), self._model_dir)
            # Task 41: best-effort partial cleanup. A fully
            # transactional pipeline (post-Task-41
            # ``MiniCPMO45Pipeline``) already unwinds itself —
            # including the *failing* adapter — before re-raising,
            # so calling ``unload()`` here is a no-op against a
            # clean slate. The call still runs to cover
            # caller-supplied non-transactional pipelines that
            # may have left partial state behind. Any error here is
            # swallowed because we are already in the failure path.
            unload_fn = getattr(self._pipeline, "unload", None)
            if callable(unload_fn):
                try:
                    unload_fn()
                except Exception:
                    pass
            self._loaded_event = LifecycleResult(
                ok=False,
                stage="load_failed",
                reason="load_failed",
                detail=detail,
            )
            return self._loaded_event

        self._owns_load = True
        self._loaded_event = LifecycleResult(ok=True, stage="loaded")
        return self._loaded_event

    def release(self) -> None:
        """Idempotent. Unloads only if this lifecycle owns the load and
        the pipeline exposes ``unload()``. Never raises."""

        if not self._owns_load:
            return
        unload_fn = getattr(self._pipeline, "unload", None)
        if not callable(unload_fn):
            self._owns_load = False
            return
        try:
            unload_fn()
        except Exception:
            pass
        finally:
            self._owns_load = False

    def debug_snapshot(self) -> Dict[str, Any]:
        """Basenames-only diagnostic payload."""
        return {
            "loaded": self.is_loaded(),
            "owns_load": self._owns_load,
            "model_dir_basename": (
                Path(self._model_dir).name if self._model_dir else None
            ),
            "stage": (
                self._loaded_event.stage if self._loaded_event else "pending"
            ),
        }


def _sanitize_error_for_logging(
    msg: str, model_dir: Optional[str]  # model_dir kept for back-compat
) -> str:
    """Sanitize an exception message before it reaches a user-visible
    surface.

    Task 42: delegates to the shared :func:`sanitize_message` so any
    absolute path the underlying exception happens to carry is
    reduced — not just the configured ``model_dir``. The
    ``model_dir`` parameter is retained so existing callers don't
    break, but it is no longer consulted.
    """
    return sanitize_message(msg) if msg else msg
