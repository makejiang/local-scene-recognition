# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Minimal CLI entry point for the Camera Companion Skill (Task 16).

This module exists so the ``local-camera-companion-skill`` console script
declared in ``pyproject.toml`` resolves to a callable. The full developer
demo lives in ``scripts/run_camera_companion_demo.py``; this module
deliberately keeps the install-time entry point lightweight.

Run:
    local-camera-companion-skill --help
    local-camera-companion-skill --version
"""

from __future__ import annotations

import argparse
from typing import List, Optional


_DEMO_HINT = (
    "For an interactive mock demo, run:\n"
    "    python scripts/run_camera_companion_demo.py --mock --describe\n"
    "or:\n"
    "    python scripts/run_camera_companion_gradio.py --mock"
)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="local-camera-companion-skill",
        description=(
            "Camera Companion Skill - minimal entry point. "
            "Use scripts/run_camera_companion_demo.py for the full demo."
        ),
        epilog=_DEMO_HINT,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="Print the camera companion package version and exit.",
    )
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    if args.version:
        from . import __version__

        print(__version__)
        return 0
    parser.print_help()
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
