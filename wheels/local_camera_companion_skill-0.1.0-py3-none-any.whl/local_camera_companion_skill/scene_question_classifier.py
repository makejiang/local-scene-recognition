# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Heuristic mapping from a user's question to its ``SceneQuestionType``.

Stdlib regex only. ``EnvironmentSkill`` calls
:func:`infer_scene_question_type` to auto-classify voice transcripts
so questions like "是否有电视" / "Is there a TV?" route to the
``objects`` scene prompt — which tells the model to enumerate
notable objects and ground its answer in them — instead of the
``general`` prompt that deprioritises object enumeration.

Real-machine session 1f057e4a... showed the model missing a
clearly-visible wall TV under the ``general`` prompt; routing
those queries to ``objects`` is the targeted fix.
"""

from __future__ import annotations

import re
from typing import Pattern, Tuple

from .schemas import SceneQuestionType

__all__ = ["infer_scene_question_type", "infer_scene_refresh_intent"]


# Each tuple holds the patterns that hint at one question type.
# The PRIORITY list below decides ordering — more-specific
# question types are tried first so e.g. "看到几个人" routes to
# ``people`` rather than the broader ``objects`` family.

# Flashcard: child shows an English-learning flashcard and asks for
# the English word. Chinese-trigger-only because English-speaking
# users don't need a translation mode. The patterns intentionally
# require BOTH an "image/card" demonstrative and an "English word"
# marker so generic "用英语怎么说" without a visual referent doesn't
# steal frames from the general path.
_FLASHCARD_PATTERNS: Tuple[Pattern[str], ...] = (
    # Direct: explicit "图上/图片/卡片" + "英语单词/英文单词/英文/英语"
    re.compile(
        r"(?:图(?:上|片(?:上)?|里|中)|卡片(?:上|里)?|这(?:张|个)卡片|"
        r"这(?:是|个|张)).{0,12}"
        r"(?:英语(?:单词|怎么说)|英文(?:单词|怎么说|是什么)|"
        r"英语是什么|英文是什么)"
    ),
    # Inverted: "英语单词/英文" appears first, "图/卡片/这个" after.
    re.compile(
        r"(?:英语单词|英文单词|英文|英语).{0,12}"
        r"(?:图(?:上|片|里|中)|卡片|这(?:个|张))"
    ),
    # Short imperative without an image marker but with the clear
    # "用英语/英文怎么说" + a demonstrative ("这", "这个"). Kids ask
    # this while holding the card without saying "图上".
    re.compile(
        r"这(?:个|是).{0,4}用?(?:英语|英文)(?:怎么说|单词|是什么)"
    ),
)

# French flashcard — mirrors _FLASHCARD_PATTERNS shape with 法语/法文.
_FLASHCARD_FR_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(
        r"(?:图(?:上|片(?:上)?|里|中)|卡片(?:上|里)?|这(?:张|个)卡片|"
        r"这(?:是|个|张)).{0,12}"
        r"(?:法语(?:单词|怎么说)|法文(?:单词|怎么说|是什么)|"
        r"法语是什么|法文是什么)"
    ),
    re.compile(
        r"(?:法语单词|法文单词|法文|法语).{0,12}"
        r"(?:图(?:上|片|里|中)|卡片|这(?:个|张))"
    ),
    re.compile(
        r"这(?:个|是).{0,4}用?(?:法语|法文)(?:怎么说|单词|是什么)"
    ),
)

# Japanese flashcard — mirrors _FLASHCARD_PATTERNS shape with 日语/日文.
_FLASHCARD_JA_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(
        r"(?:图(?:上|片(?:上)?|里|中)|卡片(?:上|里)?|这(?:张|个)卡片|"
        r"这(?:是|个|张)).{0,12}"
        r"(?:日语(?:单词|怎么说)|日文(?:单词|怎么说|是什么)|"
        r"日语是什么|日文是什么)"
    ),
    re.compile(
        r"(?:日语单词|日文单词|日文|日语).{0,12}"
        r"(?:图(?:上|片|里|中)|卡片|这(?:个|张))"
    ),
    re.compile(
        r"这(?:个|是).{0,4}用?(?:日语|日文)(?:怎么说|单词|是什么)"
    ),
)

# German flashcard — accepts both 德 and 徳 (the user's request used 徳).
_FLASHCARD_DE_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(
        r"(?:图(?:上|片(?:上)?|里|中)|卡片(?:上|里)?|这(?:张|个)卡片|"
        r"这(?:是|个|张)).{0,12}"
        r"(?:[德徳]语(?:单词|怎么说)|[德徳]文(?:单词|怎么说|是什么)|"
        r"[德徳]语是什么|[德徳]文是什么)"
    ),
    re.compile(
        r"(?:[德徳]语单词|[德徳]文单词|[德徳]文|[德徳]语).{0,12}"
        r"(?:图(?:上|片|里|中)|卡片|这(?:个|张))"
    ),
    re.compile(
        r"这(?:个|是).{0,4}用?(?:[德徳]语|[德徳]文)(?:怎么说|单词|是什么)"
    ),
)


# Objects: "do you see X", "is there X", enumeration prompts.
_OBJECT_PATTERNS: Tuple[Pattern[str], ...] = (
    # Chinese — high-confidence "see X" / "has X" / "what objects"
    # signals. ``​`` style boundaries don't apply to Chinese,
    # so we use literal substring matching via re.search.
    re.compile(
        r"(?:看(?:到|见)|见到|是否有|有没有|有什么|"
        r"什么(?:物品|东西|物体)|有(?:几|多少)(?:个|样)|"
        r"(?:画面|周围|环境)(?:中|里)?有.{1,12}吗|"
        r"有.{1,12}吗)"
    ),
    # English — match natural object-enumeration phrasings.
    re.compile(
        r"\b(?:is\s+there|do\s+you\s+see|can\s+you\s+see|"
        r"any\s+(?:visible\s+)?\w+|what\s+(?:objects?|items?|things?)|"
        r"list\s+(?:the\s+)?(?:visible\s+|notable\s+)?\w+)\b",
        re.IGNORECASE,
    ),
)

# People: "how many people" / "who is" — must beat objects so a
# "看到几个人" question doesn't route to objects.
_PEOPLE_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(r"(?:几个人|多少人|有人|是谁|谁在)"),
    re.compile(
        r"\b(?:how\s+many\s+people|who\s+is)\b", re.IGNORECASE
    ),
)

# Emotion: explicit feeling / mood vocabulary.
_EMOTION_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(r"(?:情绪|心情|感觉|开心|难过|高兴|伤心|看起来.*?吗)"),
    re.compile(
        r"\b(?:feel|mood|emotion|happy|sad|look\s+(?:happy|sad|tired))\b",
        re.IGNORECASE,
    ),
)

# Safety: hazards, danger, "is this safe".
_SAFETY_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(r"(?:安全|危险|风险|隐患)"),
    re.compile(
        r"\b(?:safe|danger(?:ous)?|hazard(?:s|ous)?|risk)\b",
        re.IGNORECASE,
    ),
)

# Interaction: "what can I do", "should I", suggestion prompts.
_INTERACTION_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(r"(?:怎么互动|该怎么做|应该|建议)"),
    re.compile(
        r"\b(?:what\s+can\s+i\s+(?:do|try)|should\s+i|"
        r"suggest(?:ion)?|recommend)\b",
        re.IGNORECASE,
    ),
)


# Most-specific first. ``general`` is the conservative fallback when
# no pattern fires.
_PRIORITY: Tuple[
    Tuple[Tuple[Pattern[str], ...], SceneQuestionType], ...
] = (
    # Foreign-language flashcards run first so language-specific tokens
    # ("法语", "日语", "德语"/"徳语") match before the broader English
    # flashcard tuple. The English tuple requires "英语/英文" so the
    # ordering is for clarity rather than correctness.
    (_FLASHCARD_FR_PATTERNS, SceneQuestionType.flashcard_fr),
    (_FLASHCARD_JA_PATTERNS, SceneQuestionType.flashcard_ja),
    (_FLASHCARD_DE_PATTERNS, SceneQuestionType.flashcard_de),
    # English flashcard — overlaps with the objects "有什么" family and
    # with the general fallback, so it must run before those tuples.
    (_FLASHCARD_PATTERNS, SceneQuestionType.flashcard),
    (_PEOPLE_PATTERNS, SceneQuestionType.people),
    (_EMOTION_PATTERNS, SceneQuestionType.emotion),
    (_SAFETY_PATTERNS, SceneQuestionType.safety),
    (_INTERACTION_PATTERNS, SceneQuestionType.interaction),
    (_OBJECT_PATTERNS, SceneQuestionType.objects),
)


def infer_scene_question_type(
    user_question: str,
    *,
    default: SceneQuestionType = SceneQuestionType.general,
) -> SceneQuestionType:
    """Map ``user_question`` to a ``SceneQuestionType`` using regex.

    Returns the matched type, or ``default`` (general) when nothing
    matches. Intentionally conservative — only fires for
    high-confidence patterns so existing call sites that pass the
    default ``general`` keep working unchanged when the question
    doesn't clearly fit one of the specialised types.
    """
    text = (user_question or "").strip()
    if not text:
        return default
    for patterns, qtype in _PRIORITY:
        for p in patterns:
            if p.search(text):
                return qtype
    return default


# Patterns suggesting the user is asking about the CURRENT camera
# frame, not a prior one. Hits drop the cached prior-scene summary
# in the prompt-builder call path so the LM isn't anchored to stale
# text describing a different scene.
#
# Real-machine root cause: in continuous-voice mode the user moves
# the camera between turns. The session manager keeps the previous
# turn's scene summary on ``state.last_scene_summary`` for legitimate
# follow-up questions ("zoom in on the laptop you mentioned"). When
# the user instead asks about the *new* scene ("现在这个环境怎么样"),
# that cached summary becomes a textual anchor that overrides the
# new image — the model rephrases the cached description instead of
# describing the new frame.
_REFRESH_INTENT_PATTERNS: Tuple[Pattern[str], ...] = (
    # Chinese: now / currently / this place / around / latest.
    # Catch-all phrases (能看到什么 / 看到什么 / 什么环境 /
    # 什么地方) added after session dbfccf5f981d49af... showed
    # voice users frequently ask these without an explicit
    # "现在/now" marker — they describe the current frame just as
    # reliably and were the residual gap that left the dialogue-
    # history pollution active.
    re.compile(
        r"(?:现在|此刻|目前|当下|当前|这个环境|这里|周围|"
        r"刚才看到|最新|这一(?:刻|帧)|这张图|这是.{0,3}(?:什么|地方|环境)|"
        r"能看到什么|看到什么|什么环境|什么地方)"
    ),
    # English: now / current / this scene|view|environment / around me.
    re.compile(
        r"\b(?:now|current(?:ly)?|this\s+(?:scene|view|"
        r"environment|frame|place|room)|around\s+me|latest|"
        r"what\s+do\s+you\s+see\s+now|just\s+now|right\s+now)\b",
        re.IGNORECASE,
    ),
)


def infer_scene_refresh_intent(user_question: str) -> bool:
    """Return True iff the question asks about the CURRENT frame.

    Caller drops the cached prior-scene summary in that case so the
    LM isn't anchored to stale text describing a different scene.
    Conservative: returns False for empty input and for follow-up
    questions that reference the prior moment ("zoom in on the
    laptop you mentioned"). Those should keep the cached summary
    so the model can answer coherently.
    """
    text = (user_question or "").strip()
    if not text:
        return False
    return any(p.search(text) for p in _REFRESH_INTENT_PATTERNS)
