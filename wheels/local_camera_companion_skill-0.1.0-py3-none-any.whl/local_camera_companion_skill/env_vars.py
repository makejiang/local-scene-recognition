# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Centralized environment-variable lookup with back-compat shim.

Camera Companion read its environment variables from the legacy
``LOCAL_ENGLISH_TUTOR_*`` prefix while it lived inside the English
Tutor codebase. Once the repository split into a Camera Companion-only
package the legacy prefix became misleading. This module renames each
variable to ``LOCAL_CAMERA_COMPANION_*`` while preserving the legacy
names as a one-release back-compat shim:

- Reads check the new name first.
- If the new name is unset *and* the legacy name is set, the legacy
  value is returned and a ``DeprecationWarning`` is emitted **once
  per process per variable** so noisy shells don't drown the logs.
- If neither is set, the caller's ``default`` is returned.

Operators can migrate at their leisure; CI workflows, docs, README,
and the ``run_camera_companion_live_demo.bat`` launcher all advertise
the new names. The shim itself is hermetic — no I/O beyond
``os.environ`` and ``warnings.warn``.

Used by:

- :mod:`local_minicpm_runtime.minicpm_o45_pipeline`
- :mod:`local_minicpm_runtime.ov_runtime.config_profiles`
- :mod:`local_minicpm_runtime.ov_runtime.language_model_step`
- :mod:`local_minicpm_runtime.ov_runtime.native_tts`
- :mod:`local_minicpm_runtime.ov_runtime.ov_core_manager`
- :mod:`local_minicpm_runtime.ov_runtime.token2wav_infer_steps`
- ``scripts/run_camera_companion_live_demo.py``
- ``scripts/run_real_camera_companion_smoke.py``
- ``tests/_runtime_helpers.py``
- ``tests/conftest.py``
"""

from __future__ import annotations

import os
import threading
import warnings
from typing import Dict, Mapping, Optional, Tuple


__all__ = [
    "ENV_RUN_REAL_TESTS",
    "ENV_MODEL_DIR",
    "ENV_DEVICE",
    "ENV_RUN_CAMERA_TESTS",
    "ENV_RUN_MIC_TESTS",
    "ENV_RUN_REAL_TTS",
    "ENV_AUDIO_PATH",
    "ENV_TEXTBOOK_IMAGE",
    "ENV_MAX_NEW_TOKENS",
    "ENV_OV_CONFIG_PROFILE",
    "ENV_OV_CACHE_DIR",
    "ENV_KV_CACHE",
    "ENV_DEBUG_LM_STEP",
    "ENV_DEBUG_TTS",
    "LEGACY_ENV_PREFIX",
    "NEW_ENV_PREFIX",
    "ALIASES",
    "get_env",
    "pop_env",
    "_reset_deprecation_state_for_tests",
]


LEGACY_ENV_PREFIX = "LOCAL_ENGLISH_TUTOR_"
NEW_ENV_PREFIX = "LOCAL_CAMERA_COMPANION_"


def _alias(suffix: str) -> Tuple[str, str]:
    return (NEW_ENV_PREFIX + suffix, LEGACY_ENV_PREFIX + suffix)


# Public canonical names. Every read site imports these constants
# (rather than literal strings) so a future rename touches one file.
ENV_RUN_REAL_TESTS = NEW_ENV_PREFIX + "RUN_REAL_TESTS"
ENV_MODEL_DIR = NEW_ENV_PREFIX + "MODEL_DIR"
ENV_DEVICE = NEW_ENV_PREFIX + "DEVICE"
ENV_RUN_CAMERA_TESTS = NEW_ENV_PREFIX + "RUN_CAMERA_TESTS"
ENV_RUN_MIC_TESTS = NEW_ENV_PREFIX + "RUN_MIC_TESTS"
ENV_RUN_REAL_TTS = NEW_ENV_PREFIX + "RUN_REAL_TTS"
ENV_AUDIO_PATH = NEW_ENV_PREFIX + "AUDIO_PATH"
ENV_TEXTBOOK_IMAGE = NEW_ENV_PREFIX + "TEXTBOOK_IMAGE"
ENV_MAX_NEW_TOKENS = NEW_ENV_PREFIX + "MAX_NEW_TOKENS"
ENV_OV_CONFIG_PROFILE = NEW_ENV_PREFIX + "OV_CONFIG_PROFILE"
ENV_OV_CACHE_DIR = NEW_ENV_PREFIX + "OV_CACHE_DIR"
ENV_KV_CACHE = NEW_ENV_PREFIX + "KV_CACHE"
ENV_DEBUG_LM_STEP = NEW_ENV_PREFIX + "DEBUG_LM_STEP"
ENV_DEBUG_TTS = NEW_ENV_PREFIX + "DEBUG_TTS"


# Map every new name to its legacy alias. Used by ``get_env`` and by
# ``tests/conftest.py`` to drop both names when the suite needs to
# guarantee a clean slate.
ALIASES: Dict[str, str] = dict(
    [
        _alias("RUN_REAL_TESTS"),
        _alias("MODEL_DIR"),
        _alias("DEVICE"),
        _alias("RUN_CAMERA_TESTS"),
        _alias("RUN_MIC_TESTS"),
        _alias("RUN_REAL_TTS"),
        _alias("AUDIO_PATH"),
        _alias("TEXTBOOK_IMAGE"),
        _alias("MAX_NEW_TOKENS"),
        _alias("OV_CONFIG_PROFILE"),
        _alias("OV_CACHE_DIR"),
        _alias("KV_CACHE"),
        _alias("DEBUG_LM_STEP"),
        _alias("DEBUG_TTS"),
    ]
)


# Track which legacy names have already emitted a deprecation warning
# so the message fires at most once per process per variable.
_WARNED_LEGACY: Dict[str, bool] = {}
_WARNED_LOCK = threading.Lock()


def _warn_legacy_once(legacy_name: str, new_name: str) -> None:
    """Emit a one-shot deprecation warning for an obsolete env var."""
    with _WARNED_LOCK:
        if _WARNED_LEGACY.get(legacy_name):
            return
        _WARNED_LEGACY[legacy_name] = True
    warnings.warn(
        (
            f"{legacy_name} is deprecated; use {new_name} instead. "
            f"The legacy name will be removed in a future release."
        ),
        DeprecationWarning,
        stacklevel=3,
    )


def get_env(
    name: str,
    default: Optional[str] = None,
    *,
    env: Optional[Mapping[str, str]] = None,
) -> Optional[str]:
    """Read ``name`` from the environment with legacy-alias fallback.

    Lookup order:

    1. If ``name`` is set in ``env`` (or :data:`os.environ` when ``env``
       is ``None``), return that value verbatim. The new prefix always
       wins, even when the legacy alias is also set.
    2. If ``name`` has a legacy alias and the alias is set, return the
       legacy value and emit a one-shot ``DeprecationWarning``.
    3. Otherwise return ``default``.

    ``env`` is accepted so callers (tests, the live demo's
    ``input_provider`` fixtures) can substitute a controlled mapping.
    """
    source: Mapping[str, str] = env if env is not None else os.environ
    new_val = source.get(name)
    if new_val is not None and new_val != "":
        return new_val
    legacy = ALIASES.get(name)
    if legacy is not None:
        legacy_val = source.get(legacy)
        if legacy_val is not None and legacy_val != "":
            _warn_legacy_once(legacy, name)
            return legacy_val
    # Honour explicit empty-string set on either name as "not set" so
    # callers don't have to special-case the empty string.
    return default


def pop_env(name: str, *, env: Optional[Dict[str, str]] = None) -> None:
    """Remove ``name`` AND its legacy alias from the environment.

    Used by ``tests/conftest.py`` to guarantee a clean slate for tests
    that should not be influenced by an operator-exported profile.
    """
    target = env if env is not None else os.environ
    target.pop(name, None)
    legacy = ALIASES.get(name)
    if legacy is not None:
        target.pop(legacy, None)


def _reset_deprecation_state_for_tests() -> None:
    """Clear the one-shot warning state so test cases can re-trigger
    the legacy-alias deprecation path independently. Tests use this
    inside a fixture; production code never calls it."""
    with _WARNED_LOCK:
        _WARNED_LEGACY.clear()
