# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Post-ASR acknowledgment clip player.

Plays a pre-rendered Chinese acknowledgment WAV ("好的，知道了。")
on a background thread between ASR completion and TTS reply
playback so the user gets audible feedback during the LLM forward
and TTS synthesis windows.

Heavy dependencies are not imported at module load time. The
default WAV player (``_LocalSoundDeviceWavPlayer``) is imported
lazily inside the playback thread; tests inject a stub via the
``wav_player`` constructor kwarg.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

__all__ = ["AckPlayer", "AckPlayerConfig", "AckDecision"]


@dataclass
class AckPlayerConfig:
    """Per-skill configuration for the post-ASR acknowledgment clip.

    ``wav_path`` is resolved at AckPlayer init time. ``response_language``
    mirrors ``CameraCompanionInteractionConfig.response_language`` so the
    player can skip itself when the user pinned an English-only session.
    """

    enabled: bool = True
    wav_path: Optional[Path] = None
    response_language: str = "auto"
    # Round-9: silent pause on the playback thread BEFORE the WAV
    # actually starts playing, measured from the moment
    # ``maybe_start_async`` is called (which is right after the
    # transcript is displayed in the web UI). During this pause the
    # caller has already returned to run the LLM in parallel, so the
    # ACK+delay window overlaps with LLM inference. Default 0.0
    # preserves round-8 behavior (no delay).
    delay_before_play_s: float = 0.0


@dataclass
class AckDecision:
    """Outcome of one call to ``AckPlayer.maybe_start_async``.

    ``started`` is True iff a NEW background thread was dispatched for
    this call. ``skip_reason`` is None on a successful start, otherwise
    one of: ``"disabled"``, ``"no_wav"``, ``"english_pinned"``,
    ``"empty_transcript"``, or ``"already_playing"`` (defensive — the
    caller is expected to ``wait()`` between turns).
    """

    started: bool
    skip_reason: Optional[str]


class AckPlayer:
    """Plays the acknowledgment WAV on a background thread.

    Thread model: at most one playback thread is alive at a time per
    AckPlayer instance. ``maybe_start_async`` is safe to call from any
    thread; ``wait`` blocks the caller until the current ack (if any)
    has finished. Both calls are no-ops when the skip predicates fire.

    The class is constructed once per skill instance and reused across
    voice turns.
    """

    def __init__(
        self,
        config: AckPlayerConfig,
        *,
        wav_player: Optional[Any] = None,
    ) -> None:
        self._config = config
        self._wav_player = wav_player
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

    @property
    def is_playing(self) -> bool:
        with self._lock:
            t = self._thread
        return t is not None and t.is_alive()

    def maybe_start_async(self, *, transcript: str) -> AckDecision:
        # Skip predicates in priority order.
        if not self._config.enabled:
            return AckDecision(started=False, skip_reason="disabled")
        wav_path = self._config.wav_path
        if wav_path is None or not Path(wav_path).exists():
            return AckDecision(started=False, skip_reason="no_wav")
        if (self._config.response_language or "").strip().lower() == "en":
            return AckDecision(started=False, skip_reason="english_pinned")
        if not (transcript or "").strip():
            return AckDecision(started=False, skip_reason="empty_transcript")

        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                # Defensive: the call site should wait() between turns
                # so this branch should not normally fire. Returning
                # ``already_playing`` lets the call site surface the
                # anomaly in debug without dispatching a competing
                # second thread.
                return AckDecision(started=False, skip_reason="already_playing")
            wav_player = self._wav_player or _lazy_default_player()
            thread = threading.Thread(
                target=self._run_playback,
                args=(
                    wav_player,
                    Path(wav_path),
                    float(self._config.delay_before_play_s or 0.0),
                ),
                name="AckPlayer",
                daemon=True,
            )
            self._thread = thread
        thread.start()
        return AckDecision(started=True, skip_reason=None)

    def wait(self, timeout: float = 8.0) -> None:
        with self._lock:
            t = self._thread
        if t is None:
            return
        t.join(timeout=timeout)
        if t.is_alive():
            logger.warning(
                "AckPlayer.wait timed out after %.2fs; next turn will "
                "start a fresh thread",
                timeout,
            )

    def _run_playback(
        self, wav_player: Any, wav_path: Path, delay_s: float = 0.0
    ) -> None:
        try:
            # Round-9: optional silent pause before actual playback.
            # Runs on the background thread so the caller of
            # ``maybe_start_async`` is not blocked. ``is_playing``
            # returns True during this pause because the thread is
            # alive — this is the desired semantic (ACK is scheduled,
            # not yet audible).
            if delay_s > 0:
                time.sleep(delay_s)
            wav_player.play(wav_path)
        except Exception as exc:  # noqa: BLE001 - background thread
            # Playback failure must never break the voice turn; log
            # at WARNING and let the thread exit cleanly.
            logger.warning(
                "AckPlayer playback failed: %s: %s",
                exc.__class__.__name__,
                exc,
            )


def _lazy_default_player() -> Any:
    """Import the default sounddevice-backed WAV player lazily so
    importing this module does not pull sounddevice into sys.modules.
    """
    from .tts_playback import _LocalSoundDeviceWavPlayer

    return _LocalSoundDeviceWavPlayer()
