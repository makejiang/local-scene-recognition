# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Robust parser for MiniCPM-o scene-understanding JSON output.

The parser converts raw model text into a structured payload built around
:class:`local_camera_companion_skill.schemas.SceneUnderstanding`. It is
intentionally tolerant:

* never raises on malformed input,
* normalizes ``emotion_confidence`` into the
  :class:`~local_camera_companion_skill.schemas.EmotionConfidence` enum,
* forces confidence to ``unknown`` whenever ``apparent_emotion`` is
  missing/empty (an interaction guardrail),
* truncates overlong answers,
* sanitizes JSON ``null`` values into safe empty defaults.

This module is stdlib-only — no cv2, OpenVINO, sounddevice, torch, or
transformers imports are introduced.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, List, Optional

from .schemas import EmotionConfidence, SceneUnderstanding

__all__ = [
    "CameraCompanionResponsePayload",
    "parse_scene_model_output",
    "parse_plain_text_output",
    "strip_think_tags",
    "strip_filler_prefix",
]


# Match ``` ```json {...} ``` ``` and any other fenced code-block
# wrapping the model occasionally emits despite the prompt rule
# "Do not wrap the JSON in markdown.". The pattern is
# whitespace-tolerant on both ends.
_MARKDOWN_JSON_FENCE_RE = re.compile(
    r"^\s*```(?:[a-zA-Z0-9_+-]*)\s*\n?(.*?)\n?\s*```\s*$",
    re.DOTALL,
)


def _strip_markdown_code_fence(text: str) -> str:
    """Remove a single layer of markdown code fences if the entire
    ``text`` is wrapped in one.

    Examples (all return ``"{...}"``):

      ``` ```json
      {...}
      ``` ```

      ``` ```
      {...}
      ``` ```

    A trailing fence with no leading fence, or text with prose
    around the fences, is returned unchanged so we don't truncate
    legitimately-prefixed model output.
    """
    if not text:
        return text
    match = _MARKDOWN_JSON_FENCE_RE.match(text.strip())
    if match is None:
        return text
    return match.group(1).strip()

# <think>...</think> reasoning blocks emitted by MiniCPM-o-4.5 on
# ambiguous prompts. Three shapes must be handled:
#   1. Fully closed: "<think>X</think>Y"     → "Y"
#   2. Open, no close (budget exhausted): "<think>X"  → ""
#   3. Close, no open (opener truncated):  "X</think>Y" → "Y"
_THINK_BLOCK_RE = re.compile(
    r"<think>.*?(?:</think>|\Z)", re.DOTALL | re.IGNORECASE
)
_THINK_CLOSE_TAIL_RE = re.compile(
    r"\A.*?</think>\s*", re.DOTALL | re.IGNORECASE
)


def strip_think_tags(text: str) -> str:
    """Remove ``<think>...</think>`` blocks from raw LLM output.

    Handles fully-closed blocks, an unterminated opener (truncated at
    the token budget), and a stray close tail (opener truncated at
    the start). Safe on empty / None-shaped input.
    """
    if not isinstance(text, str) or not text:
        return ""
    cleaned = _THINK_BLOCK_RE.sub("", text)
    lower = cleaned.lower()
    if "</think>" in lower and "<think>" not in lower:
        cleaned = _THINK_CLOSE_TAIL_RE.sub("", cleaned)
    return cleaned.strip()


# Assistant-template filler openers that MiniCPM-o emits despite the
# prompt asking for a direct answer. Each pattern is anchored to ^
# and matched in order; up to 3 sweeps are applied so chained fillers
# like "好的，当然，应该是..." collapse cleanly.
_FILLER_PREFIX_RES = (
    re.compile(r"^好的[，,]?\s*我来\s*(?:描述|介绍|说说|讲讲)?\s*[一]?[下]?[，,。]?\s*"),
    re.compile(r"^好的[，,。]\s*"),
    re.compile(r"^当然[，,。]?\s*"),
    re.compile(r"^请\s*让我\s*[，,。]?\s*"),
    re.compile(r"^我来\s*(?:描述|介绍|说说|讲讲)?\s*[一]?[下]?[，,。]?\s*"),
    # Match both ``OK`` and the spelled-out ``Okay`` — the latter
    # surfaced in real Marvis sessions when the LLM produced
    # acknowledgment-style replies that bypassed the previous regex.
    re.compile(r"^O[kK](?:ay)?[，,.!]?\s*", re.IGNORECASE),
    re.compile(r"^Sure[，,.!]?\s*", re.IGNORECASE),
    re.compile(r"^Of course[，,.!]?\s*", re.IGNORECASE),
    re.compile(r"^Let me\s+(?:describe|tell you|explain)[，,.:]?\s*", re.IGNORECASE),
)


def strip_filler_prefix(text: str) -> str:
    """Trim leading assistant-template fillers like "好的，我来描述一下".

    Applies the pattern table repeatedly so chained fillers collapse.
    Refuses to strip if the result would be shorter than ~4 chars
    (defends against eating an entire short legitimate answer).
    """
    if not isinstance(text, str) or not text:
        return ""
    out = text.strip()
    for _ in range(3):
        progressed = False
        for pat in _FILLER_PREFIX_RES:
            new = pat.sub("", out, count=1).strip()
            if new != out and len(new) >= 4:
                out = new
                progressed = True
                break
        if not progressed:
            break
    return out


# Strings that the model may emit to signal "no value" — treated as None.
_PLACEHOLDER_TOKENS = {"", "none", "(none)", "n/a", "na", "null"}

# Default fallback message when the model produces nothing usable.
_EMPTY_OUTPUT_MESSAGE = "Sorry, I couldn't analyze the scene right now."


@dataclass
class CameraCompanionResponsePayload:
    """Structured result of parsing a single scene-understanding response."""

    answer_text: str
    scene: SceneUnderstanding
    suggested_interaction: Optional[str] = None
    observable_cues: List[str] = field(default_factory=list)
    is_fallback: bool = False
    fallback_reason: Optional[str] = None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _strip_or_none(value: Any) -> Optional[str]:
    """Return a stripped string, or ``None`` for empty/placeholder values."""

    if value is None:
        return None
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    if stripped.lower() in _PLACEHOLDER_TOKENS:
        return None
    return stripped


def _as_str_list(value: Any) -> List[str]:
    """Coerce a JSON value into a list of non-empty strings."""

    if not isinstance(value, list):
        return []
    out: List[str] = []
    for item in value:
        if isinstance(item, str):
            cleaned = item.strip()
            if cleaned:
                out.append(cleaned)
    return out


def _as_optional_int(value: Any) -> Optional[int]:
    """Coerce a JSON value into an int, or return ``None`` for non-numeric."""

    if value is None:
        return None
    if isinstance(value, bool):
        # bool is a subclass of int; treat as non-numeric here.
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            return None
        return int(value)
    if isinstance(value, str):
        try:
            return int(value.strip())
        except ValueError:
            return None
    return None


def _normalize_confidence(value: Any) -> EmotionConfidence:
    """Return a valid :class:`EmotionConfidence`, defaulting to ``unknown``."""

    if isinstance(value, EmotionConfidence):
        return value
    if isinstance(value, str):
        candidate = value.strip().lower()
        for member in EmotionConfidence:
            if member.value == candidate:
                return member
    return EmotionConfidence.unknown


def _truncate(text: str, max_chars: int) -> str:
    """Cap ``text`` to ``max_chars`` characters."""

    if not isinstance(text, str):
        return ""
    if max_chars <= 0 or len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip()


def _safe_fallback(answer_text: str, reason: str) -> CameraCompanionResponsePayload:
    """Build a fallback payload with an empty :class:`SceneUnderstanding`."""

    return CameraCompanionResponsePayload(
        answer_text=answer_text,
        scene=SceneUnderstanding(description=""),
        suggested_interaction=None,
        observable_cues=[],
        is_fallback=True,
        fallback_reason=reason,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def parse_scene_model_output(
    raw_output: str,
    *,
    max_answer_chars: int = 1200,
) -> CameraCompanionResponsePayload:
    """Parse raw model output into a :class:`CameraCompanionResponsePayload`.

    The function never raises. Malformed JSON falls back to surfacing the
    raw text as the answer; empty input yields a canned apology.
    """

    try:
        text = (raw_output or "").strip()
        if not text:
            return _safe_fallback(_EMPTY_OUTPUT_MESSAGE, "empty_output")

        # The prompt explicitly forbids markdown fences, but the model
        # occasionally emits ``` ```json {...} ``` ``` anyway. Strip a
        # single layer of fences before json.loads so the parser
        # succeeds on the inner JSON instead of falling through to
        # the safe-fallback path (which would surface the raw fenced
        # string as ``reply_text`` and TTS would speak it verbatim).
        candidate = _strip_markdown_code_fence(text)

        try:
            data = json.loads(candidate)
        except json.JSONDecodeError:
            return _safe_fallback(_truncate(text, max_answer_chars), "malformed_json")

        if not isinstance(data, dict):
            return _safe_fallback(_truncate(text, max_answer_chars), "malformed_json")

        scene_summary_raw = data.get("scene_summary")
        description = (
            scene_summary_raw.strip()
            if isinstance(scene_summary_raw, str)
            else ""
        )

        objects = _as_str_list(data.get("visible_objects"))
        people_count = _as_optional_int(data.get("visible_people_count"))
        observable_cues = _as_str_list(data.get("observable_cues"))
        apparent_emotion = _strip_or_none(data.get("apparent_emotion"))
        emotion_confidence = _normalize_confidence(data.get("emotion_confidence"))

        if apparent_emotion is None:
            emotion_confidence = EmotionConfidence.unknown

        safety_note = _strip_or_none(data.get("safety_note"))
        safety_notes: List[str] = [safety_note] if safety_note else []

        scene = SceneUnderstanding(
            description=description,
            objects=objects,
            people_count=people_count,
            apparent_emotion=apparent_emotion,
            emotion_confidence=emotion_confidence,
            safety_notes=safety_notes,
        )

        answer_raw = data.get("answer")
        answer_text = answer_raw.strip() if isinstance(answer_raw, str) else ""
        answer_text = _truncate(answer_text, max_answer_chars)

        suggested_interaction = _strip_or_none(data.get("suggested_interaction"))

        return CameraCompanionResponsePayload(
            answer_text=answer_text,
            scene=scene,
            suggested_interaction=suggested_interaction,
            observable_cues=observable_cues,
            is_fallback=False,
            fallback_reason=None,
        )
    except Exception:
        # Defense in depth: the parser must never raise, even on input
        # shapes we did not anticipate.
        snippet = (raw_output or "").strip() if isinstance(raw_output, str) else ""
        return _safe_fallback(_truncate(snippet, max_answer_chars), "malformed_json")


def parse_plain_text_output(
    raw_output: str,
    *,
    max_answer_chars: int = 1200,
) -> CameraCompanionResponsePayload:
    """Parse a Fast-mode plain-text model output.

    Fast mode (``--fast-mode``) drops the JSON 'COT' envelope so the
    model emits one short sentence answering the user's question.
    This parser is the matching consumer: trivial wrapper that puts
    the model's whole reply into ``answer_text`` and leaves every
    scene-scaffolding field empty.

    ``is_fallback`` is False because in Fast mode plain text is the
    designed output — NOT a parser failure. This prevents the
    truncated-JSON TTS-skip guard in
    :mod:`local_camera_companion_skill.environment_skill` from
    firing on a legitimate Fast-mode reply.

    The parser also strips ``<think>...</think>`` reasoning blocks
    and leading assistant-template fillers ("好的，我来描述一下",
    "OK", "Sure", "Of course") so neither reaches TTS verbatim.
    """
    text = (raw_output or "").strip() if isinstance(raw_output, str) else ""
    text = strip_think_tags(text)
    text = strip_filler_prefix(text)
    return CameraCompanionResponsePayload(
        answer_text=_truncate(text, max_answer_chars),
        scene=SceneUnderstanding(description=""),
        suggested_interaction=None,
        observable_cues=[],
        is_fallback=False,
        fallback_reason=None,
    )
