# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""ASR adapter abstraction for the Camera Companion Skill.

Defines the typed result, the Protocol every backend implements, a
working :class:`MockASRAdapter` that validates audio file metadata
without decoding, and a :func:`create_asr_adapter` factory whose only
fully-implemented backend right now is ``"mock"``.

Real backends (``whisper_cpp``, ``sherpa_onnx``, ``sensevoice``,
``minicpm_audio``) are reserved as named placeholders so future tasks
can wire them in. Heavy dependencies — ``sounddevice``, ``torch``,
``transformers``, ``whisper``, ``sherpa_onnx`` — must not be imported
at module load time.

Error messages reference basenames only so absolute filesystem paths
do not leak into user-facing exceptions.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import (
    Any,
    ClassVar,
    Dict,
    Optional,
    Pattern,
    Protocol,
    Sequence,
    Tuple,
    Union,
    runtime_checkable,
)

from .privacy import merged_metadata, sanitize_message

logger = logging.getLogger(__name__)

__all__ = [
    "ASRResult",
    "ASRAdapter",
    "MockASRAdapter",
    "MiniCPMAudioASRAdapter",
    "create_asr_adapter",
]


PathLike = Union[str, Path]


_DEFAULT_ALLOWED_EXTENSIONS: Sequence[str] = (
    ".wav",
    ".mp3",
    ".m4a",
    ".flac",
    ".ogg",
)

# Backend names reserved for future implementation. They are recognized
# by the factory (so callers get a precise error) but not yet wired.
# ``minicpm_audio`` was previously listed here; Task 23 implements it as
# a real backend, so it is no longer a placeholder.
_PLACEHOLDER_BACKENDS = frozenset(
    {
        "whisper_cpp",
        "sherpa_onnx",
        "sensevoice",
    }
)


@dataclass
class ASRResult:
    """Structured result of one transcription call."""

    text: str
    language: Optional[str] = None
    confidence: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class ASRAdapter(Protocol):
    """Common interface every ASR backend must satisfy."""

    def transcribe(self, audio_path: PathLike) -> ASRResult: ...


def _normalize_extensions(allowed: Sequence[str]) -> tuple[str, ...]:
    out: list[str] = []
    for ext in allowed:
        s = str(ext).strip().lower()
        if not s:
            continue
        if not s.startswith("."):
            s = "." + s
        out.append(s)
    return tuple(out)


class MockASRAdapter:
    """Deterministic mock backend used by default tests.

    The adapter validates file metadata only; it does not decode the
    audio. Configure ``transcript`` to control the returned text.
    """

    def __init__(
        self,
        transcript: str = "",
        *,
        allowed_extensions: Sequence[str] = _DEFAULT_ALLOWED_EXTENSIONS,
        strict_validation: bool = True,
        language: Optional[str] = None,
        confidence: Optional[float] = None,
    ) -> None:
        self._transcript = str(transcript)
        self._allowed_extensions = _normalize_extensions(allowed_extensions)
        self._strict_validation = bool(strict_validation)
        self._language = language
        self._confidence = confidence

    def transcribe(self, audio_path: PathLike) -> ASRResult:
        path = Path(audio_path).expanduser()

        if not path.is_file():
            raise FileNotFoundError(f"audio file not found: {path.name}")

        suffix = path.suffix.lower()
        if suffix not in self._allowed_extensions:
            raise ValueError(
                f"unsupported audio extension: {path.suffix!s}; "
                f"allowed={list(self._allowed_extensions)}"
            )

        if self._strict_validation and path.stat().st_size == 0:
            raise ValueError(f"empty audio file: {path.name}")

        return ASRResult(
            text=self._transcript.strip(),
            language=self._language,
            confidence=self._confidence,
            metadata={
                "backend": "mock",
                "audio_basename": path.name,
            },
        )


# ---------------------------------------------------------------------------
# MiniCPM-o-4.5 native ASR adapter
# ---------------------------------------------------------------------------


_DEFAULT_TRANSCRIPTION_PROMPT = (
    "You are a strict transcription engine. Listen to the audio clip and "
    "produce ONLY a verbatim transcript of what was said. Do not add tutoring "
    "feedback, scene analysis, headings, JSON, or markdown. Reply with the "
    "transcript text only, on a single line if possible."
)

# Per-language output-language directives appended to the English
# transcription prompt above. Round-4 tried switching the WHOLE
# prompt body to Chinese for ``language="Chinese"``; MiniCPM-o
# then echoed the Chinese body as if it were the transcription
# (field session 22:49 turn 3: transcript was literally
# ``"你好，我是严格的语音转录引擎..."``). Round-5 reverts to a
# single English body and uses a stronger English-side language
# directive — English instructions don't echo because the model
# has been trained to treat them as system text, not as content.
_LANGUAGE_DIRECTIVE_CHINESE = (
    "You MUST output the transcript in Simplified Chinese only. "
    "NEVER translate the audio into English. NEVER output English "
    "characters in the response. If you hear Chinese speech, the "
    "transcript must be Chinese characters."
)
_LANGUAGE_DIRECTIVE_ENGLISH = (
    "You MUST output the transcript in English only. "
    "NEVER translate the audio into another language."
)

# Stronger prompt suffix used by the one-shot retry when the first
# transcription attempt produced a suspiciously short output for the
# audio clip duration. Real-machine session 6040112f turns 3-10
# showed the audio encoder summarising 13-hanzi questions down to
# 3-10 char "topic gloss" transcripts; the retry pushes the model
# toward verbatim reproduction.
_RETRY_VERBATIM_PROMPT_SUFFIX = (
    " IMPORTANT: produce a COMPLETE verbatim transcript of the entire "
    "audio clip. Do NOT summarise. Do NOT shorten. If the audio is "
    "Chinese, transcribe every spoken hanzi without paraphrasing."
)

# Heuristic thresholds for the short-transcript retry.
#   - audio_duration_s >= 1.5 s: clip has enough speech to be worth
#     re-transcribing (under 1.5 s the user genuinely may have only
#     uttered a fragment).
#   - audio_rms >= 0.015: same floor as the short-clip Layer-A gate
#     elsewhere in this file; below that the encoder is grounded on
#     near-silence and a retry won't help.
#   - len(transcript) <= 4: a typical Chinese question is ≥10 chars;
#     under 4 is "就是他" / "就是我" territory, the topic-gloss
#     failure mode session 6040112f surfaced.
_RETRY_MIN_DURATION_S = 1.5
_RETRY_MIN_RMS = 0.015
_RETRY_MAX_TRANSCRIPT_LEN = 4


# Strings that the model sometimes prefixes its transcript with.
_TRANSCRIPT_PREFIX_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(
        r"^\s*(?:transcript|asr_text|text|result|output)\s*:\s*",
        re.IGNORECASE,
    ),
    re.compile(r"^\s*teacher\s*:\s*", re.IGNORECASE),
    re.compile(r"^\s*中文解释\s*:\s*", re.IGNORECASE),
    re.compile(r"^\s*```(?:json|text)?\s*", re.IGNORECASE),
)
_TRANSCRIPT_SUFFIX_PATTERN = re.compile(r"\s*```\s*$")


def _strip_transcript_wrappers(text: str) -> str:
    """Strip common heading prefixes and markdown fences."""
    out = (text or "").strip()
    if not out:
        return ""
    changed = True
    while changed and out:
        changed = False
        for pat in _TRANSCRIPT_PREFIX_PATTERNS:
            new = pat.sub("", out, count=1)
            if new != out:
                out = new.strip()
                changed = True
                break
    out = _TRANSCRIPT_SUFFIX_PATTERN.sub("", out).strip()
    return out


# ASR template-prefix bleed patterns. Real-machine session
# dd39d149... showed the audio LM wrapping short questions in
# template prefixes:
#   user: 你能看到什么          → ASR: 如果你能看到什么
#   user: 你能看到后面的黑板吗   → ASR: 行，我能看到背后是一个黑板吗
# The remainder is correct — strip the prefix and keep the rest.
# Conservative: only strip when the result is at least 4 chars so
# we don't mangle a fragment.
_HALLUCINATION_PREFIX_RES: Tuple[Pattern[str], ...] = (
    # 如果 prefix only when followed by 你能/我能 (don't strip
    # legitimate conditional questions like "如果下雨我们怎么办").
    re.compile(r"^如果(?=[你我]能)"),
    # 行 + comma prefix (verbal-tic / template).
    re.compile(r"^行[，,]\s*"),
    # 好的，我会X / 好的，请X / 好的，X — 4d5053bc real-machine
    # session showed the audio LM wrapping commands like
    # "请描述一下周围的环境" in 好的，(我会)? template prefixes.
    # Order: try the more specific 好的，我会 first so it strips
    # both the prefix AND the verb wrapper; the broader 好的[，,]
    # pattern is the fallback for plain wrappers.
    re.compile(r"^好的[，,]\s*我会"),
    re.compile(r"^好的[，,]\s*"),
)


def _strip_hallucinatory_prefix(text: str) -> str:
    out = text or ""
    for pat in _HALLUCINATION_PREFIX_RES:
        new = pat.sub("", out, count=1).strip()
        if new != out and len(new) >= 4:
            out = new
    return out


# Session b09cc684 turn_008 — MiniCPM-o's audio encoder leaked
# training-data special tokens at the start of the transcript:
#   ASR: "<|SOA:58 Italy <|UTT:1|>我知道这是龙珠里的悟空，请说一下"
# The user's real speech ("我知道这是龙珠里的悟空，请说一下") is
# AFTER the leak. The KV-cache reset in audio_runtime.py is the
# primary defense but doesn't always prevent leakage; this filter
# is the safety net. Only strips at the PREFIX — a stray <|...|>
# token in the middle of a transcript is rare and worth keeping
# visible in diagnostics rather than silently scrubbing.
def _strip_special_tokens(text: str) -> Tuple[str, str]:
    """Strip leaked ``<|SOA:...|>`` / ``<|UTT:...|>`` prefix tokens.

    The audio encoder occasionally emits MALFORMED nested tokens
    (session b09cc684 turn_008 saw ``<|SOA:58 Italy <|UTT:1|>``
    with the first ``<|SOA:`` never closed). To handle both
    well-formed (``<|FOO|>``) and malformed (``<|FOO ...``) shapes
    we scan procedurally:

      1. Skip leading whitespace.
      2. If we see ``<|``, consume until the next ``|>`` OR the
         next ``<|`` (whichever comes first). That handles the
         nested-open case.
      3. Repeat until we no longer see ``<|`` at the cursor.

    Returns ``(cleaned, stripped_prefix)`` where ``stripped_prefix``
    is the raw text that was removed (returned so the live demo
    can surface it in the JSONL for diagnostics rather than
    silently scrubbing).
    """
    if not isinstance(text, str) or not text:
        return "", ""
    # Quick fast-path: nothing to do if no ``<|`` at the start
    # (after optional whitespace).
    if "<|" not in text[:8]:
        return text, ""
    cursor = 0
    n = len(text)
    # Skip leading whitespace before the first ``<|``.
    while cursor < n and text[cursor].isspace():
        cursor += 1
    prefix_end = cursor
    while prefix_end < n - 1 and text[prefix_end] == "<" and text[prefix_end + 1] == "|":
        # Find the end of this token: nearest ``|>`` OR next ``<|``,
        # whichever comes first. Bail if neither exists (truncated
        # at end of string).
        close = text.find("|>", prefix_end + 2)
        next_open = text.find("<|", prefix_end + 2)
        if close == -1 and next_open == -1:
            # Token never terminates; the whole rest of the string
            # is special-token soup with no clear end. Don't strip
            # unconditionally; leave a sane bound.
            break
        if close == -1 or (next_open != -1 and next_open < close):
            # Malformed: this token has no ``|>`` before the next
            # ``<|`` opens. Treat the inner content as part of the
            # leaked prefix and continue at the next ``<|``.
            prefix_end = next_open
        else:
            # Well-formed: advance past the ``|>``.
            prefix_end = close + 2
        # Skip whitespace between tokens.
        while prefix_end < n and text[prefix_end].isspace():
            prefix_end += 1
    if prefix_end == cursor:
        return text, ""
    prefix = text[:prefix_end]
    cleaned = text[prefix_end:].lstrip()
    return cleaned, prefix.strip()


# Trailing ``<|...|>`` tokens. Field session showed MiniCPM-o emitting
# ``<|EOA|>`` (end-of-audio) at the tail of the transcript when the
# audio LM hit its budget mid-output. We strip a single trailing
# token (and any chained tokens after it) so the visible transcript
# isn't polluted. Only fires at the END of the string.
_TRAILING_SPECIAL_TOKEN_RE = re.compile(
    r"\s*(?:<\|[^|]{0,64}\|>\s*)+\s*$"
)

# Bare numeric ID prefix from the audio tokenizer. Looks like
# ``118_1_0_0`` or ``118_0516`` (digits + underscore-separated
# digits). Field evidence shows two shapes:
#   - ``118_1_0_0<|EOA|>`` (3 underscores)
#   - ``118_0516``         (1 underscore, round-4 field session)
# Both are raw audio token IDs leaking past detokenisation. To
# avoid eating legitimate short tokens like ``1_a`` or ``1_2`` we
# require at least ONE underscore AND a leading run of >=3 digits
# (so ``1_2`` stays put but ``118_0516`` strips).
_NUMERIC_ID_PREFIX_RE = re.compile(r"^\s*\d{3,}(?:_\d+)+\s*")


def _strip_trailing_special_tokens(text: str) -> Tuple[str, str]:
    """Remove trailing ``<|...|>`` tokens (e.g. ``<|EOA|>``).

    Returns ``(cleaned, stripped_tail)``. ``stripped_tail`` is the
    raw substring removed (for diagnostics); empty string when nothing
    was stripped.
    """
    if not isinstance(text, str) or not text:
        return text or "", ""
    m = _TRAILING_SPECIAL_TOKEN_RE.search(text)
    if not m:
        return text, ""
    return text[: m.start()].rstrip(), m.group(0).strip()


def _strip_numeric_id_prefix(text: str) -> Tuple[str, str]:
    """Remove bare audio-tokenizer numeric ID prefix like ``118_1_0_0``
    or ``118_0516``.

    Conservative: requires a leading run of >=3 digits followed by at
    least one ``_<digits>`` group, so legitimate inputs like
    ``1_apple`` (alphabetic component), ``1_2`` (too short),
    and ``2024`` (no underscore) are not eaten. Real field evidence
    of both 3-group (``118_1_0_0``) and 2-group (``118_0516``)
    shapes drove the >=3-digit-prefix heuristic.
    Returns ``(cleaned, stripped_prefix)``.
    """
    if not isinstance(text, str) or not text:
        return text or "", ""
    m = _NUMERIC_ID_PREFIX_RE.match(text)
    if not m:
        return text, ""
    return text[m.end():].lstrip(), m.group(0).strip()


def _extract_text_from_json(data: Any) -> Optional[str]:
    """Walk a JSON-like dict for common transcript keys."""
    if isinstance(data, dict):
        for key in ("text", "transcript", "asr_text"):
            v = data.get(key)
            if isinstance(v, str) and v.strip():
                return v.strip()
        result = data.get("result")
        if isinstance(result, dict):
            for key in ("text", "transcript", "asr_text"):
                v = result.get(key)
                if isinstance(v, str) and v.strip():
                    return v.strip()
    return None


def _parse_transcript(raw: str) -> str:
    """Parse a raw model output string into a clean transcript."""
    if not isinstance(raw, str):
        return ""
    text = raw.strip()
    if not text:
        return ""
    if text.startswith("{") or text.startswith("["):
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            data = None
        if data is not None:
            from_json = _extract_text_from_json(data)
            if from_json is not None:
                return _strip_transcript_wrappers(from_json)
    return _strip_transcript_wrappers(text)


# ---------------------------------------------------------------------------
# Hallucination gating — defends against MiniCPM-o low-SNR canned phrases
# ---------------------------------------------------------------------------

# Normalised RMS in [0.0, 1.0] below which we treat the clip as silent
# enough that the LM is likely to hallucinate a high-prior canned phrase
# instead of a transcript. Calibration: real speech at low mic gain
# measures > 0.01; ambient + silence stay < 0.005.
_DEFAULT_LOW_ENERGY_THRESHOLD = 0.005

# Short-clip duration gate. Very short Chinese utterances (3-hanzi
# "这是什么", ~0.6 s) consistently produce degenerate audio encoder
# outputs that the LM then fills with a chatbot template
# hallucination ("如果你觉得无聊的话，可以试试看这本书"). Calibration:
# - Real "这是什么" at normal volume sits in RMS 0.02-0.04.
# - Genuine continuous speech longer than 1 s rarely sits below
#   RMS 0.015 unless the mic gain is off.
# So clips shorter than 1.0 s with RMS below 0.015 are gated.
_DEFAULT_SHORT_CLIP_DURATION_S = 1.0
_DEFAULT_SHORT_CLIP_ENERGY_THRESHOLD = 0.015

# Patterns that match MiniCPM-o-4.5 canned-phrase fallbacks observed
# on silent / low-SNR captures.
#
# Real-machine reproducers across PR #232 / PR #234 sessions:
# - "当然，我会严格遵循您的指示。"   (turn_004, turn_009 of session 5ea4)
# - "当然可以，请问您今天过得怎么样？" (turn_002 of session 5ea4)
# - "当然，我会尽力而为。"             (turn_003 of session 05a6 — same family)
# - "请提供音频文件"                   (PR #232 commit message)
#
# The two MiniCPM-o canned-phrase families share the same shape
# "当然(，)我[会能][verb-phrase]..." regardless of which verb the
# model picked. The first regex catches the family broadly so a
# new verb the model invents tomorrow is also covered; the next
# three are belt-and-suspenders exact-match guards in case a future
# canned phrase doesn't begin with 当然.
_DEFAULT_HALLUCINATION_PATTERNS: Tuple[Pattern[str], ...] = (
    re.compile(r"当然[，,]?\s*(?:我[会能]|可以)"),
    re.compile(r"我会严格遵循您的指示"),
    re.compile(r"请问您今天过得怎么样"),
    re.compile(r"请提供音频文件"),
    # New families observed in session dd39d149... at healthy
    # rms 0.05-0.1 — the audio encoder + LM produced these
    # template completions on real but ambiguous Chinese clips
    # of "请描述一下周围的环境" / "你能看到什么".
    re.compile(r"就是说[，,]?\s*我刚才说的那些话"),
    re.compile(r"当我们打开.{0,12}文件夹"),
)

# Energy ceiling above which we trust a transcript even when it
# matches a hallucination pattern (a real learner who actually says
# "请问您今天过得怎么样？" must not be dropped). Calibration:
# - turn_003 of session 05a6 hallucinated at rms=0.036; needs to be
#   inside the ceiling.
# - Real Chinese speech in turns 005-012 of the same session sat at
#   rms 0.05-0.11; comfortably above the ceiling.
# So 0.04 is well-separated from both edges.
_DEFAULT_HALLUCINATION_ENERGY_CEILING = 0.04


# Layer C: unconditional assistant-template detector. Real-machine
# session 9bd8f7cc transcribed energetic real speech (RMS 0.066,
# 0.078) as the audio LM's own canned chatbot response:
#
#   turn_001: "当然，请提供音频文件，我将为您进行转录。"
#   turn_003: "当然，请提供音频内容，我将为您进行准确的语音转文字。"
#
# These are not "noise-induced" hallucinations the RMS gate was
# designed for; they are unambiguous assistant-template leakage
# (the model speaks AS the assistant being asked to transcribe,
# rather than transcribing the user's speech). They MUST be
# dropped regardless of RMS — no human Camera Companion user
# would utter "I will perform the transcription for you" verbatim.
#
# The patterns are deliberately narrow so a real speaker cannot
# accidentally trip them. Each pattern requires BOTH a polite
# opener (当然 / 好的) AND a transcription-assistant verb cluster
# (提供.*音频 / 转录 / 语音转文字 / 听您说话). The compound match
# is what makes these safe to drop unconditionally.
_ASSISTANT_TEMPLATE_PATTERNS: Tuple[Pattern[str], ...] = (
    # "当然，请提供音频文件，我将为您进行转录。" — session 9bd8f7cc turn_001
    # "当然，请提供音频内容，我将为您进行准确的语音转文字。" — turn_003
    re.compile(r"请提供.{0,12}(?:音频|录音|语音)"),
    re.compile(r"我(?:将|会).{0,8}(?:为您|帮您).{0,8}(?:转录|语音转文字|转写)"),
    # "好的，没问题！请继续讲下去，我会认真听您说" — session 9bd8f7cc reply text
    # The model says this when it interpreted the user's speech as a
    # request to start transcribing rather than as content to transcribe.
    re.compile(r"我会(?:认真)?听您说"),
    re.compile(r"请继续讲下去"),
    # "如果你有任何问题或需要帮助，请随时告诉我。" — session 77970ee6 turn_001
    # (RMS 0.024, just above the Layer-A silence gate). The audio
    # encoder produced near-silent embeddings on a 1.09 s clip and the
    # LM filled in with this canonical chatbot opener. The pattern is
    # narrow on purpose — a real Chinese speaker would phrase the
    # offer as "有问题告诉我" or "需要的话叫我", not the polite
    # full-form "如果你有任何问题".
    re.compile(r"如果你有任何问题"),
    re.compile(r"请随时(?:告诉|联系|找)我"),
    # Session 77970ee6 follow-up — user said "这是什么" (3 hanzi,
    # ~0.6 s clip) and the audio encoder produced degenerate
    # embeddings. The LM filled with another textbook chatbot
    # template: "如果你觉得无聊的话，可以试试看这本书。" The
    # "如果你觉得X的话" opener is a MiniCPM-o SFT-leakage
    # signature; "可以试试看这/那..." is the typical conjugate.
    re.compile(r"如果你觉得.{0,12}的话"),
    re.compile(r"可以试试看?[这那]"),
    # Session b09cc684 turn_003 — user said "你能描述一下他当前的
    # 动作吗" (~2.66 s clip, RMS 0.044). Audio encoder emitted a
    # SFT-template musing about decision-making instead of
    # transcribing the question. Both regexes must trigger for a
    # match (we OR them as separate entries — Layer-C uses .search,
    # so either being present is sufficient evidence of the SFT
    # leakage shape). Narrow on purpose so a real user saying just
    # "我做事情" doesn't trip the filter.
    re.compile(r"如果一个人.{0,8}做.{0,8}事情"),
    re.compile(r"因为.{0,8}情绪.{0,8}想法.{0,8}改变.{0,8}行为"),
)


def _looks_like_assistant_template(
    text: str,
    *,
    patterns: Sequence[Pattern[str]] = _ASSISTANT_TEMPLATE_PATTERNS,
) -> bool:
    """Return True iff ``text`` matches an assistant-template phrase
    no human user would say verbatim. Unlike
    :func:`_looks_like_hallucination`, this filter is NOT gated on
    audio energy — assistant-template leakage occurs on healthy-RMS
    real speech too (session 9bd8f7cc: 0.066 / 0.078).
    """
    if not text:
        return False
    return any(p.search(text) for p in patterns)


def _audio_rms_int16(path: Path) -> float:
    """RMS of a mono PCM16 WAV in [0.0, 1.0]. Stdlib only.

    Returns ``1.0`` (treat as fully energetic — never gate) when the
    file isn't a 16-bit PCM WAV. The adapter is responsible for any
    other format-mismatch handling; this helper is only an
    opportunistic pre-filter, not the source of truth on file
    validity.
    """
    rms, _ = _audio_rms_and_duration_int16(path)
    return rms


def _audio_rms_and_duration_int16(path: Path) -> Tuple[float, float]:
    """Return ``(rms, duration_seconds)`` for a mono PCM16 WAV.

    RMS is in [0.0, 1.0]. Duration is in seconds (float). Returns
    ``(1.0, 0.0)`` for unreadable or non-PCM16 files so the adapter
    never gates on an unparseable header. Single ``wave.open`` call
    so the short-clip gate doesn't read the file twice.
    """
    import math
    import struct
    import wave

    try:
        with wave.open(str(path), "rb") as wf:
            sw = wf.getsampwidth()
            sr = wf.getframerate()
            nframes = wf.getnframes()
            if sw != 2 or nframes == 0 or sr <= 0:
                return 1.0, 0.0
            raw = wf.readframes(nframes)
            duration = float(nframes) / float(sr)
    except wave.Error:
        return 1.0, 0.0
    n = len(raw) // 2
    if n == 0:
        return 0.0, duration
    samples = struct.unpack(f"<{n}h", raw[: 2 * n])
    sq_sum = sum(s * s for s in samples)
    rms = math.sqrt(sq_sum / n) / 32768.0
    return rms, duration


def _resolve_audio_runtime(pipeline: Any) -> Optional[Any]:
    """Walk a MiniCPM-o pipeline / omni adapter to find an audio
    runtime that exposes ``prewarm_encoder``.

    Real path: ``MiniCPMO45Pipeline._omni_adapter._ov_model.audio_runtime``.
    Mock pipelines and test fakes may attach the runtime directly. We
    accept any attribute traversal that ends in something with a
    callable ``prewarm_encoder``.
    """
    candidates = [
        pipeline,
        getattr(pipeline, "audio_runtime", None),
        getattr(pipeline, "_audio_runtime", None),
    ]
    for adapter_attr in ("_omni_adapter", "omni_adapter"):
        adapter = getattr(pipeline, adapter_attr, None)
        if adapter is None:
            continue
        candidates.append(adapter)
        for model_attr in ("_ov_model", "ov_model", "runtime"):
            model = getattr(adapter, model_attr, None)
            if model is None:
                continue
            candidates.append(getattr(model, "audio_runtime", None))
    for cand in candidates:
        if cand is None:
            continue
        if callable(getattr(cand, "prewarm_encoder", None)):
            return cand
    return None


def _resolve_text_runtime(pipeline: Any) -> Optional[Any]:
    """Walk a MiniCPM-o pipeline to find a text runtime that exposes
    ``prewarm_lm_cpu_twin``.

    Real path: ``pipeline._omni_adapter._ov_model.text_runtime``.
    The text runtime hosts the LM step, which owns the CPU twin
    used by ``audio_offload=True``. We pre-compile that twin during
    the live-demo startup banner so the first audio turn doesn't
    pay the 30-60 s OpenVINO cold compile.
    """
    for adapter_attr in ("_omni_adapter", "omni_adapter"):
        adapter = getattr(pipeline, adapter_attr, None)
        if adapter is None:
            continue
        for model_attr in ("_ov_model", "ov_model", "runtime"):
            model = getattr(adapter, model_attr, None)
            if model is None:
                continue
            cand = getattr(model, "text_runtime", None)
            if cand is not None and callable(
                getattr(cand, "prewarm_lm_cpu_twin", None)
            ):
                return cand
    # Some test fakes attach the text runtime directly.
    cand = getattr(pipeline, "text_runtime", None)
    if cand is not None and callable(
        getattr(cand, "prewarm_lm_cpu_twin", None)
    ):
        return cand
    return None


def _looks_like_hallucination(
    text: str,
    audio_rms: float,
    *,
    patterns: Sequence[Pattern[str]],
    energy_ceiling: float,
) -> bool:
    """Return True iff ``text`` matches a known canned-phrase pattern
    AND ``audio_rms`` is below ``energy_ceiling``.

    The energy gate is the critical half: pattern-matching alone
    would drop legitimate speech that coincidentally uses one of the
    canned phrases.
    """
    if not text or audio_rms >= energy_ceiling:
        return False
    return any(p.search(text) for p in patterns)


class MiniCPMAudioASRAdapter:
    """ASR backend that delegates to a MiniCPM-o-4.5 pipeline.

    The adapter does not load a model itself - it accepts an
    already-constructed pipeline by injection. Default tests inject a
    fake pipeline; production callers inject the real OpenVINO adapter.

    Heavy dependencies (OpenVINO, torch, transformers, sounddevice) are
    not imported at module load time. The adapter only invokes
    ``pipeline.generate_from_audio`` or ``pipeline.generate_from_mixed``.
    """

    DEFAULT_MAX_NEW_TOKENS: ClassVar[int] = 256
    # Fast mode caps the audio transcribe budget. A clear short clip
    # transcribes in well under 64 tokens; if the audio encoder
    # produced near-silent / degenerate embeddings the LM otherwise
    # grinds through the full 256 budget (real-machine session
    # 77970ee6 turn_001 spent 67 s decoding hallucinated chatbot
    # template tokens). Capping at 64 aborts that case in roughly
    # 1/4 the time and the Layer-C assistant-template filter still
    # drops the short hallucinated phrase before TTS speaks it.
    # Successively tuned: 256 → 64 → 32 → 24 → 64. Session
    # 6040112f showed the 24 cap was too tight for real Chinese
    # questions ("你能给我讲一个有关这个手办的故事吗" is 17 hanzi,
    # ~20 tokens with the MiniCPM tokenizer; with 24-cap the
    # encoder learned to truncate to a "topic gloss" of 3-10 chars
    # rather than transcribe verbatim). 64 gives ~50-hanzi room
    # for full questions while still aborting the 60-second
    # degenerate decodes from the b09cc684 era (now also bounded
    # by --asr-on-gpu running the LM on iGPU, not the CPU twin).
    DEFAULT_FAST_MODE_MAX_NEW_TOKENS: ClassVar[int] = 64

    def __init__(
        self,
        pipeline: Any,
        *,
        mode: str = "audio",
        prompt: Optional[str] = None,
        language: Optional[str] = None,
        strict_validation: bool = True,
        max_new_tokens: int = DEFAULT_MAX_NEW_TOKENS,
        allowed_extensions: Sequence[str] = _DEFAULT_ALLOWED_EXTENSIONS,
        metadata: Optional[Dict[str, Any]] = None,
        low_energy_threshold: float = _DEFAULT_LOW_ENERGY_THRESHOLD,
        hallucination_patterns: Optional[Sequence[Pattern[str]]] = None,
        hallucination_energy_ceiling: float = _DEFAULT_HALLUCINATION_ENERGY_CEILING,
        short_clip_duration_s: float = _DEFAULT_SHORT_CLIP_DURATION_S,
        short_clip_energy_threshold: float = _DEFAULT_SHORT_CLIP_ENERGY_THRESHOLD,
        fast_mode: bool = False,
        audio_offload: bool = True,
    ) -> None:
        if pipeline is None:
            raise ValueError(
                "MiniCPMAudioASRAdapter requires a MiniCPM-o-compatible pipeline"
            )
        normalized_mode = str(mode).strip().lower()
        if normalized_mode not in ("audio", "mixed"):
            raise ValueError(
                f"unsupported MiniCPMAudioASRAdapter mode: {mode!r}; "
                f"expected 'audio' or 'mixed'"
            )

        self._pipeline = pipeline
        self._mode = normalized_mode
        self._prompt = prompt
        self._language = language
        self._strict_validation = bool(strict_validation)
        # When ``fast_mode`` is on, lower the per-transcribe token
        # budget so degenerate audio inputs abort quickly. Caller may
        # still pass an explicit ``max_new_tokens=...`` to override
        # (we take the min so an explicit cap is never silently
        # raised by Fast mode).
        requested_budget = max(1, int(max_new_tokens))
        if fast_mode:
            requested_budget = min(
                requested_budget, self.DEFAULT_FAST_MODE_MAX_NEW_TOKENS
            )
        self._max_new_tokens = requested_budget
        self._fast_mode = bool(fast_mode)
        self._allowed_extensions = _normalize_extensions(allowed_extensions)
        self._extra_metadata: Dict[str, Any] = dict(metadata or {})
        self._low_energy_threshold = float(low_energy_threshold)
        self._hallucination_patterns: Tuple[Pattern[str], ...] = tuple(
            hallucination_patterns
            if hallucination_patterns is not None
            else _DEFAULT_HALLUCINATION_PATTERNS
        )
        self._hallucination_energy_ceiling = float(
            hallucination_energy_ceiling
        )
        self._short_clip_duration_s = float(short_clip_duration_s)
        self._short_clip_energy_threshold = float(short_clip_energy_threshold)
        # When True (default), audio decoding routes the LM through a
        # CPU-pinned twin to dodge the OpenCL 4 GB single-allocation
        # cap on integrated Intel iGPUs. Operators on hardware that
        # doesn't hit the cap can flip this to False via
        # ``--asr-on-gpu`` for a 5-10x speed-up — INT4 LM forward
        # runs roughly an order of magnitude faster on the iGPU.
        self._audio_offload = bool(audio_offload)

    def _build_prompt(self) -> str:
        # Round-5: single English prompt body + a strong English-side
        # language directive. Round-4 tried a Chinese-body prompt for
        # ``language="Chinese"`` but the model echoed it as the
        # transcription. English prompts don't echo because the model
        # treats them as system instructions, not content to continue.
        if self._prompt and self._prompt.strip():
            base = self._prompt.strip()
        else:
            base = _DEFAULT_TRANSCRIPTION_PROMPT
        if not self._language:
            return base
        lang_norm = self._language.strip().lower()
        if lang_norm == "chinese":
            directive = _LANGUAGE_DIRECTIVE_CHINESE
        elif lang_norm == "english":
            directive = _LANGUAGE_DIRECTIVE_ENGLISH
        else:
            # Unknown language label — keep the legacy soft hint
            # rather than emitting a directive we don't have a
            # validated template for.
            return f"{base} Transcription language hint: {self._language}."
        return f"{base} {directive}"

    def _call_pipeline(self, prompt: str, audio_path: str) -> Any:
        """Single point of pipeline invocation for ``transcribe`` and
        the short-transcript retry. Forwards ``audio_offload`` only
        when the pipeline's signature accepts it (mock pipelines and
        older test fakes have a narrower signature)."""
        if self._mode == "audio":
            import inspect as _inspect

            try:
                _sig = _inspect.signature(self._pipeline.generate_from_audio)
                _accepts = "audio_offload" in _sig.parameters
            except (TypeError, ValueError):
                _accepts = False
            if _accepts:
                return self._pipeline.generate_from_audio(
                    prompt,
                    audio_path=audio_path,
                    max_new_tokens=self._max_new_tokens,
                    audio_offload=self._audio_offload,
                )
            return self._pipeline.generate_from_audio(
                prompt,
                audio_path=audio_path,
                max_new_tokens=self._max_new_tokens,
            )
        # "mixed" mode (vision-audio prefill).
        return self._pipeline.generate_from_mixed(
            prompt,
            audio_path=audio_path,
            max_new_tokens=self._max_new_tokens,
        )

    def warmup(self) -> Dict[str, Any]:
        """Force the MiniCPM-o audio path to compile + upload weights
        so the first ``transcribe()`` doesn't pay the OpenVINO
        cold-start cost.

        Pre-compiles BOTH (a) the audio encoder and (b) the LM CPU
        twin used by ``audio_offload=True``. Skipping either of these
        leaves a ~30-60 s cold-compile inside turn 1's ``asr_ms``.

        Returns ``{"compile_ms": int, "skipped": bool,
        "reason": Optional[str], "encoder_compile_ms": int,
        "lm_cpu_twin_compile_ms": int}``. ``compile_ms`` is the SUM
        of the two sub-steps. ``skipped=True`` iff no work was done.
        Idempotent + best-effort.
        """
        if getattr(self, "_warmup_done", False):
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": "already_warm",
                "encoder_compile_ms": 0,
                "lm_cpu_twin_compile_ms": 0,
            }

        encoder_info = self._warmup_audio_encoder()
        lm_info = self._warmup_lm_cpu_twin()
        self._warmup_done = True

        encoder_ms = int(encoder_info.get("compile_ms", 0) or 0)
        lm_ms = int(lm_info.get("compile_ms", 0) or 0)
        both_skipped = bool(encoder_info.get("skipped", False)) and bool(
            lm_info.get("skipped", False)
        )
        # Reason aggregation: surface the FIRST non-trivial reason
        # so the live-demo banner shows why nothing happened. A
        # ``None`` reason is "all good"; we keep it None when at
        # least one sub-step actually compiled.
        if not both_skipped:
            reason: Optional[str] = None
        else:
            reason = encoder_info.get("reason") or lm_info.get("reason")
        return {
            "compile_ms": encoder_ms + lm_ms,
            "skipped": both_skipped,
            "reason": reason,
            "encoder_compile_ms": encoder_ms,
            "lm_cpu_twin_compile_ms": lm_ms,
        }

    def _warmup_audio_encoder(self) -> Dict[str, Any]:
        runtime = _resolve_audio_runtime(self._pipeline)
        if runtime is None:
            return {"compile_ms": 0, "skipped": True, "reason": "no_audio_runtime"}
        prewarm = getattr(runtime, "prewarm_encoder", None)
        if not callable(prewarm):
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": "prewarm_encoder_unavailable",
            }
        try:
            info = prewarm()
        except Exception as exc:  # noqa: BLE001 - best effort
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": f"{type(exc).__name__}: {exc}",
            }
        if not isinstance(info, dict):
            return {"compile_ms": 0, "skipped": True, "reason": "bad_return"}
        return info

    def _warmup_lm_cpu_twin(self) -> Dict[str, Any]:
        runtime = _resolve_text_runtime(self._pipeline)
        if runtime is None:
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": "no_text_runtime",
            }
        prewarm = getattr(runtime, "prewarm_lm_cpu_twin", None)
        if not callable(prewarm):
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": "prewarm_lm_cpu_twin_unavailable",
            }
        try:
            info = prewarm()
        except Exception as exc:  # noqa: BLE001 - best effort
            return {
                "compile_ms": 0,
                "skipped": True,
                "reason": f"{type(exc).__name__}: {exc}",
            }
        if not isinstance(info, dict):
            return {"compile_ms": 0, "skipped": True, "reason": "bad_return"}
        return info

    def transcribe(self, audio_path: PathLike) -> ASRResult:
        path = Path(audio_path).expanduser()

        if not path.is_file():
            raise FileNotFoundError(f"audio file not found: {path.name}")

        suffix = path.suffix.lower()
        if suffix not in self._allowed_extensions:
            raise ValueError(
                f"unsupported audio extension: {path.suffix!s}; "
                f"allowed={list(self._allowed_extensions)}"
            )

        if self._strict_validation and path.stat().st_size == 0:
            raise ValueError(f"empty audio file: {path.name}")

        audio_rms, audio_duration_s = _audio_rms_and_duration_int16(path)
        reserved_base: Dict[str, Any] = {
            "backend": "minicpm_audio",
            "audio_basename": path.name,
            "mode": self._mode,
            "audio_rms": round(audio_rms, 6),
            "audio_duration_s": round(audio_duration_s, 3),
        }
        if self._language:
            reserved_base["language"] = self._language

        # Layer A: input-side low-energy gate. Skips the pipeline call
        # entirely on near-silent clips so MiniCPM-o can't fabricate a
        # canned-phrase hallucination from noise.
        if (
            self._low_energy_threshold > 0.0
            and audio_rms < self._low_energy_threshold
        ):
            reserved = {**reserved_base, "asr_drop_reason": "low_energy"}
            return ASRResult(
                text="",
                language=self._language,
                confidence=None,
                metadata=merged_metadata(reserved, self._extra_metadata),
            )

        # Layer A': short-clip gate. Sub-1 s utterances at moderate
        # but not strong RMS reliably trigger MiniCPM-o template
        # hallucinations (real session 77970ee6 — "这是什么" 0.6 s at
        # RMS 0.024 → "如果你觉得无聊的话，可以试试看这本书。"). Drop
        # at Layer-A so the LM never runs and the 8 s decode is saved.
        # Long-but-quiet clips still pass — only the combination of
        # "short AND quiet" is gated.
        if (
            self._short_clip_duration_s > 0.0
            and self._short_clip_energy_threshold > 0.0
            and audio_duration_s > 0.0
            and audio_duration_s < self._short_clip_duration_s
            and audio_rms < self._short_clip_energy_threshold
        ):
            reserved = {
                **reserved_base,
                "asr_drop_reason": "low_energy_short_clip",
            }
            return ASRResult(
                text="",
                language=self._language,
                confidence=None,
                metadata=merged_metadata(reserved, self._extra_metadata),
            )

        prompt = self._build_prompt()

        try:
            raw = self._call_pipeline(prompt, str(path))
        except Exception as exc:
            # Sanitize the downstream pipeline message before
            # embedding it. The raw exception may carry an absolute
            # path (e.g. ``[Errno 2] No such file: '/var/run/foo.wav'``)
            # which must never reach the caller's terminal or logs.
            safe = sanitize_message(str(exc))
            raise RuntimeError(
                f"MiniCPM audio transcription failed for {path.name}: {safe}"
            ) from exc

        # Pull sub-timings from the pipeline (encoder forward, LM
        # prefill, LM decode). Best-effort: mock pipelines and test
        # fakes won't expose ``last_audio_timings`` and that's fine.
        sub_timings = getattr(self._pipeline, "last_audio_timings", None)
        if isinstance(sub_timings, dict):
            for key in (
                "encoder_ms",
                "lm_prefill_ms",
                "lm_decode_ms",
                "lm_step_count",
            ):
                if key in sub_timings:
                    reserved_base[f"asr_{key}"] = int(
                        sub_timings.get(key, 0) or 0
                    )

        transcript = _parse_transcript(raw if isinstance(raw, str) else "")

        # Short-transcript retry. Real-machine session 6040112f
        # showed the audio encoder summarising 13-hanzi user
        # questions ("你能给我讲一个有关这个手办的故事吗") down to
        # 3-10 char "topic gloss" fragments ("就是他", "就是我",
        # "就是这个手办的故事吗？"). When the audio is long enough
        # to be a real sentence AND has healthy energy AND the
        # first attempt's transcript is tiny, retry once with a
        # stricter "verbatim" prompt suffix. Cost: at most ONE
        # extra ``generate_from_audio`` call per turn, gated to
        # ~10-20% of turns. Mixed mode is skipped because that
        # path is already a separate use case.
        if (
            self._mode == "audio"
            and audio_duration_s >= _RETRY_MIN_DURATION_S
            and audio_rms >= _RETRY_MIN_RMS
            and len(transcript.strip()) <= _RETRY_MAX_TRANSCRIPT_LEN
        ):
            first_attempt_length = len(transcript.strip())
            # Record the retry was attempted regardless of outcome
            # so diagnostics show how often this codepath fires.
            reserved_base["asr_short_transcript_retry"] = True
            reserved_base["asr_first_attempt_length"] = first_attempt_length
            retry_prompt = prompt + _RETRY_VERBATIM_PROMPT_SUFFIX
            try:
                raw_retry = self._call_pipeline(retry_prompt, str(path))
            except Exception:  # noqa: BLE001 - retry is best-effort
                raw_retry = None
            if isinstance(raw_retry, str):
                retry_transcript = _parse_transcript(raw_retry)
                # Only ADOPT the retry transcript if it's actually
                # longer; otherwise keep the first attempt so we
                # don't lose ground on edge cases.
                if len(retry_transcript.strip()) > first_attempt_length:
                    transcript = retry_transcript

        # Layer 0: strip leaked <|SOA:...|> / <|UTT:...|> training-
        # token prefixes from the audio encoder's KV cache (session
        # b09cc684 turn_008). Runs FIRST so the downstream Layer-B/C
        # template matchers see the user's real speech.
        transcript, stripped_special = _strip_special_tokens(transcript)
        if stripped_special:
            reserved_base["asr_special_tokens_stripped"] = stripped_special
        # Layer 0b: trailing ``<|...|>`` tokens (e.g. ``<|EOA|>``) +
        # bare numeric audio-token IDs at the prefix (e.g.
        # ``118_1_0_0``). Real field session showed both in the same
        # transcript: ``118_1_0_0<|EOA|>``. Log loudly when either
        # fires so on-device runs surface the model misbehaviour.
        transcript, stripped_tail = _strip_trailing_special_tokens(transcript)
        if stripped_tail:
            reserved_base["asr_special_tokens_stripped_tail"] = stripped_tail
            logger.warning(
                "asr_adapter: stripped trailing special tokens %r",
                stripped_tail,
            )
        transcript, stripped_num = _strip_numeric_id_prefix(transcript)
        if stripped_num:
            reserved_base["asr_numeric_id_prefix_stripped"] = stripped_num
            logger.warning(
                "asr_adapter: stripped numeric ID prefix %r",
                stripped_num,
            )
        # If the entire transcript was special-token soup with no
        # real words after strip, treat as a drop rather than an
        # empty transcript (different reason fields aid diagnosis).
        if (stripped_special or stripped_tail or stripped_num) and not transcript.strip():
            reserved = {
                **reserved_base,
                "asr_drop_reason": "special_tokens_only",
            }
            return ASRResult(
                text="",
                language=self._language,
                confidence=None,
                metadata=merged_metadata(reserved, self._extra_metadata),
            )

        # Trim known hallucinatory prefixes ("如果你能看到什么" →
        # "你能看到什么", "行，..." → "..."). Conservative: only fires
        # when the remainder is at least 4 chars.
        transcript = _strip_hallucinatory_prefix(transcript)

        # Layer C: unconditional assistant-template detector. Runs
        # before Layer B because the assistant-template patterns are
        # a strict subset of the broader canned-phrase family — when
        # both match we want the more specific drop reason in the
        # metadata. Real-machine session 9bd8f7cc showed these phrases
        # leaking on RMS=0.07 audio (well above Layer B's ceiling).
        if _looks_like_assistant_template(transcript):
            reserved = {
                **reserved_base,
                "asr_drop_reason": "assistant_template",
            }
            return ASRResult(
                text="",
                language=self._language,
                confidence=None,
                metadata=merged_metadata(reserved, self._extra_metadata),
            )

        # Layer B: output-side template detector. Only fires when
        # audio energy is below the ceiling, so a real learner saying
        # one of the canned phrases is not dropped.
        if _looks_like_hallucination(
            transcript,
            audio_rms,
            patterns=self._hallucination_patterns,
            energy_ceiling=self._hallucination_energy_ceiling,
        ):
            reserved = {
                **reserved_base,
                "asr_drop_reason": "hallucination_template",
            }
            return ASRResult(
                text="",
                language=self._language,
                confidence=None,
                metadata=merged_metadata(reserved, self._extra_metadata),
            )

        # Caller-provided ``metadata`` is recursively sanitized and
        # cannot overwrite reserved fields.
        meta = merged_metadata(reserved_base, self._extra_metadata)

        return ASRResult(
            text=transcript,
            language=self._language,
            confidence=None,
            metadata=meta,
        )


def create_asr_adapter(backend: str, **kwargs: Any) -> ASRAdapter:
    """Construct an ASR adapter for the requested ``backend``.

    Currently implemented:
      - ``"mock"``           -> :class:`MockASRAdapter`
      - ``"minicpm_audio"``  -> :class:`MiniCPMAudioASRAdapter`
        (requires ``pipeline=...`` injection).

    Reserved names (``"whisper_cpp"``, ``"sherpa_onnx"``, ``"sensevoice"``)
    raise :class:`NotImplementedError`; anything else raises
    :class:`ValueError`.
    """

    name = str(backend).strip().lower()

    if name == "mock":
        return MockASRAdapter(**kwargs)

    if name == "minicpm_audio":
        if "pipeline" not in kwargs:
            raise ValueError(
                "create_asr_adapter('minicpm_audio') requires a "
                "MiniCPM-o-compatible pipeline= keyword argument"
            )
        return MiniCPMAudioASRAdapter(**kwargs)

    if name in _PLACEHOLDER_BACKENDS:
        raise NotImplementedError(
            f"ASR backend {name!r} is reserved but not yet implemented. "
            f"Use 'mock' or 'minicpm_audio' for now."
        )

    raise ValueError(f"unknown ASR backend: {backend!r}")
